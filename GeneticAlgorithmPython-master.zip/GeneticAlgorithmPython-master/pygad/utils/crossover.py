"""
The pygad.utils.crossover module has all the built-in crossover operators.
"""

import numpy

class Crossover:

    def __init__():
        pass

    def single_point_crossover(self, parents, offspring_size):
        """
        Apply single-point crossover between pairs of parents. One
        random split point is picked per offspring; the genes before
        the point come from the first parent and the genes from the
        point onward come from the second parent.

        Parameters
        ----------
        parents : numpy.ndarray
            A 2D array of parent solutions, one row per parent.
        offspring_size : tuple
            ``(num_offspring, num_genes)``. Shape of the offspring
            array to return.

        Returns
        -------
        offspring : numpy.ndarray
            A 2D array of the produced offspring with shape
            ``offspring_size``.
        """

        offspring = self.initialize_parents_array(offspring_size)

        # Randomly generate all the K points at which crossover takes place between each two parents. The point does not have to be always at the center of the solutions.
        # This saves time by calling the self.numpy_random_generator.randint() function only once.
        crossover_points = self.numpy_random_generator.randint(low=0,
                                                high=parents.shape[1], 
                                                size=offspring_size[0])

        for k in range(offspring_size[0]):
            # Check if the crossover_probability parameter is used.
            if not (self.crossover_probability is None):
                probs = self.numpy_random_generator.random(size=parents.shape[0])
                indices = list(set(numpy.where(probs < self.crossover_probability)[0]))

                # If no parent satisfied the probability, no crossover is applied and a parent is selected as is.
                if len(indices) == 0:
                    offspring[k, :] = parents[k % parents.shape[0], :]
                    continue
                elif len(indices) == 1:
                    parent1_idx = indices[0]
                    parent2_idx = parent1_idx
                else:
                    indices = self.python_random_generator.sample(indices, 2)
                    parent1_idx = indices[0]
                    parent2_idx = indices[1]
            else:
                # Index of the first parent to mate.
                parent1_idx = k % parents.shape[0]
                # Index of the second parent to mate.
                parent2_idx = (k+1) % parents.shape[0]

            # The first half of the offspring's genes comes from the first parent.
            offspring[k, 0:crossover_points[k]] = parents[parent1_idx, 0:crossover_points[k]]
            # The second half of the offspring's genes comes from the second parent.
            offspring[k, crossover_points[k]:] = parents[parent2_idx, crossover_points[k]:]

            if self.allow_duplicate_genes == False:
                offspring[k], _, _ = self.solve_duplicate_genes(solution=offspring[k])
        
        return offspring

    def two_points_crossover(self, parents, offspring_size):
        """
        Apply two-points crossover. Two split points are picked per
        offspring; the genes outside ``[point1, point2)`` come from the
        first parent and the genes inside come from the second parent.

        Parameters
        ----------
        parents : numpy.ndarray
            A 2D array of parent solutions, one row per parent.
        offspring_size : tuple
            ``(num_offspring, num_genes)``. Shape of the offspring
            array to return.

        Returns
        -------
        offspring : numpy.ndarray
            A 2D array of the produced offspring with shape
            ``offspring_size``.
        """

        offspring = self.initialize_parents_array(offspring_size)

        # Randomly generate all the K pairs of points at which crossover takes place between each two parents.
        # This saves time by calling the self.numpy_random_generator.randint() function only twice.
        # The 2 points of a pair are different values in [0, num_genes], and every such pair is equally likely.
        # If the chromosome has only a single gene, the points are 0 and 1: the gene is copied from the second parent.
        points_a = self.numpy_random_generator.randint(low=0,
                                        high=parents.shape[1] + 1,
                                        size=offspring_size[0])
        points_b = self.numpy_random_generator.randint(low=0,
                                        high=parents.shape[1],
                                        size=offspring_size[0])
        # Skip the value of the first point so that the 2 points differ.
        points_b[points_b >= points_a] += 1

        # The second point must always be greater than the first point.
        crossover_points_1 = numpy.minimum(points_a, points_b)
        crossover_points_2 = numpy.maximum(points_a, points_b)

        for k in range(offspring_size[0]):

            if not (self.crossover_probability is None):
                probs = self.numpy_random_generator.random(size=parents.shape[0])
                indices = list(set(numpy.where(probs < self.crossover_probability)[0]))

                # If no parent satisfied the probability, no crossover is applied and a parent is selected.
                if len(indices) == 0:
                    offspring[k, :] = parents[k % parents.shape[0], :]
                    continue
                elif len(indices) == 1:
                    parent1_idx = indices[0]
                    parent2_idx = parent1_idx
                else:
                    indices = self.python_random_generator.sample(indices, 2)
                    parent1_idx = indices[0]
                    parent2_idx = indices[1]
            else:
                # Index of the first parent to mate.
                parent1_idx = k % parents.shape[0]
                # Index of the second parent to mate.
                parent2_idx = (k+1) % parents.shape[0]

            # The genes from the beginning of the chromosome up to the first point are copied from the first parent.
            offspring[k, 0:crossover_points_1[k]] = parents[parent1_idx, 0:crossover_points_1[k]]
            # The genes from the second point up to the end of the chromosome are copied from the first parent.
            offspring[k, crossover_points_2[k]:] = parents[parent1_idx, crossover_points_2[k]:]
            # The genes between the 2 points are copied from the second parent.
            offspring[k, crossover_points_1[k]:crossover_points_2[k]] = parents[parent2_idx, crossover_points_1[k]:crossover_points_2[k]]

            if self.allow_duplicate_genes == False:
                offspring[k], _, _ = self.solve_duplicate_genes(solution=offspring[k])
        return offspring

    def uniform_crossover(self, parents, offspring_size):
        """
        Apply uniform crossover. For each gene independently, the value
        is copied from one of the two mating parents picked at random.

        Parameters
        ----------
        parents : numpy.ndarray
            A 2D array of parent solutions, one row per parent.
        offspring_size : tuple
            ``(num_offspring, num_genes)``. Shape of the offspring
            array to return.

        Returns
        -------
        offspring : numpy.ndarray
            A 2D array of the produced offspring with shape
            ``offspring_size``.
        """

        offspring = self.initialize_parents_array(offspring_size)

        # Randomly generate all the genes sources at which crossover takes place between each two parents. 
        # This saves time by calling the self.numpy_random_generator.randint() function only once.
        # There is a list of 0 and 1 for each offspring.
        # [0, 1, 0, 0, 1, 1]: If the value is 0, then take the gene from the first parent. If 1, take it from the second parent.
        genes_sources = self.numpy_random_generator.randint(low=0,
                                             high=2, 
                                             size=offspring_size)

        for k in range(offspring_size[0]):
            if not (self.crossover_probability is None):
                probs = self.numpy_random_generator.random(size=parents.shape[0])
                indices = list(set(numpy.where(probs < self.crossover_probability)[0]))

                # If no parent satisfied the probability, no crossover is applied and a parent is selected.
                if len(indices) == 0:
                    offspring[k, :] = parents[k % parents.shape[0], :]
                    continue
                elif len(indices) == 1:
                    parent1_idx = indices[0]
                    parent2_idx = parent1_idx
                else:
                    indices = self.python_random_generator.sample(indices, 2)
                    parent1_idx = indices[0]
                    parent2_idx = indices[1]
            else:
                # Index of the first parent to mate.
                parent1_idx = k % parents.shape[0]
                # Index of the second parent to mate.
                parent2_idx = (k+1) % parents.shape[0]

            # The gene will be copied from the first parent if the current gene index is 0.
            # The gene will be copied from the second parent if the current gene index is 1.
            offspring[k, :] = numpy.where(genes_sources[k] == 0, 
                                          parents[parent1_idx, :], 
                                          parents[parent2_idx, :])

            if self.allow_duplicate_genes == False:
                offspring[k], _, _ = self.solve_duplicate_genes(solution=offspring[k])

        return offspring

    def sbx_crossover(self, parents, offspring_size):
        """
        Apply Simulated Binary Crossover (SBX). For each gene, the
        offspring value is drawn from a distribution centered on the
        parents. The spread of this distribution is set by
        ``self.sbx_crossover_eta`` (a higher value means the child
        stays closer to the parents).

        The bounded form is used. The per-gene bounds come from
        ``get_initial_population_range``.

        Parameters
        ----------
        parents : numpy.ndarray
            A 2D array of parent solutions, one row per parent.
        offspring_size : tuple
            (num_offspring, num_genes). Shape of the offspring array
            to return.

        Returns
        -------
        offspring : numpy.ndarray
            A 2D array of offspring with shape offspring_size.
        """
        offspring = self.initialize_parents_array(offspring_size)

        eta = float(self.sbx_crossover_eta)
        near_zero = 1e-14

        for k in range(offspring_size[0]):
            if not (self.crossover_probability is None):
                probs = self.numpy_random_generator.random(size=parents.shape[0])
                indices = list(set(numpy.where(probs < self.crossover_probability)[0]))

                if len(indices) == 0:
                    offspring[k, :] = parents[k % parents.shape[0], :]
                    continue
                elif len(indices) == 1:
                    parent1_idx = indices[0]
                    parent2_idx = parent1_idx
                else:
                    indices = self.python_random_generator.sample(indices, 2)
                    parent1_idx = indices[0]
                    parent2_idx = indices[1]
            else:
                parent1_idx = k % parents.shape[0]
                parent2_idx = (k + 1) % parents.shape[0]

            for gene_idx in range(offspring_size[1]):
                if self.is_categorical_gene(gene_idx):
                    # Blending two categories has no meaning, so the child
                    # takes the value of one parent, each with equal chance.
                    if self.numpy_random_generator.random() < 0.5:
                        offspring[k, gene_idx] = parents[parent1_idx, gene_idx]
                    else:
                        offspring[k, gene_idx] = parents[parent2_idx, gene_idx]
                    continue
                range_min, range_max = self.get_bounded_operator_gene_range(gene_idx)
                lower, upper = float(range_min), float(range_max)
                p1 = float(numpy.clip(parents[parent1_idx, gene_idx], lower, upper))
                p2 = float(numpy.clip(parents[parent2_idx, gene_idx], lower, upper))
                y1 = min(p1, p2)
                y2 = max(p1, p2)

                if y2 - y1 < near_zero:
                    # The two parents have the same value on this gene.
                    offspring[k, gene_idx] = self.convert_bounded_operator_gene_value(gene_idx, p1)
                    continue

                # Beta is the spread factor that controls how far the
                # child can move away from the parents.
                beta = 1.0 + 2.0 * min(y1 - lower, upper - y2) / (y2 - y1)
                alpha = 2.0 - pow(beta, -(eta + 1.0))
                rand_u = self.numpy_random_generator.random()
                if rand_u <= 1.0 / alpha:
                    beta_q = pow(rand_u * alpha, 1.0 / (eta + 1.0))
                else:
                    beta_q = pow(1.0 / (2.0 - rand_u * alpha), 1.0 / (eta + 1.0))

                # SBX makes 2 children, symmetric around the parents' mean.
                # Pick one of them at random so that the child is not always below the mean.
                if self.numpy_random_generator.random() < 0.5:
                    child = 0.5 * ((y1 + y2) - beta_q * (y2 - y1))
                else:
                    child = 0.5 * ((y1 + y2) + beta_q * (y2 - y1))
                child = numpy.clip(child, lower, upper)
                offspring[k, gene_idx] = self.convert_bounded_operator_gene_value(gene_idx, child)

            offspring[k] = self.prepare_bounded_operator_solution(parents[parent1_idx], offspring[k])

        return offspring

    def scattered_crossover(self, parents, offspring_size):
        """
        Apply scattered crossover. For each gene independently, the
        value is copied from one of the two mating parents picked at
        random. (Same mechanic as ``uniform_crossover`` but kept as a
        separate operator for backwards compatibility.)

        Parameters
        ----------
        parents : numpy.ndarray
            A 2D array of parent solutions, one row per parent.
        offspring_size : tuple
            ``(num_offspring, num_genes)``. Shape of the offspring
            array to return.

        Returns
        -------
        offspring : numpy.ndarray
            A 2D array of the produced offspring with shape
            ``offspring_size``.
        """

        offspring = self.initialize_parents_array(offspring_size)

        # Randomly generate all the genes sources at which crossover takes place between each two parents. 
        # This saves time by calling the self.numpy_random_generator.randint() function only once.
        # There is a list of 0 and 1 for each offspring.
        # [0, 1, 0, 0, 1, 1]: If the value is 0, then take the gene from the first parent. If 1, take it from the second parent.
        genes_sources = self.numpy_random_generator.randint(low=0,
                                             high=2, 
                                             size=offspring_size)

        for k in range(offspring_size[0]):
            if not (self.crossover_probability is None):
                probs = self.numpy_random_generator.random(size=parents.shape[0])
                indices = list(set(numpy.where(probs < self.crossover_probability)[0]))

                # If no parent satisfied the probability, no crossover is applied and a parent is selected.
                if len(indices) == 0:
                    offspring[k, :] = parents[k % parents.shape[0], :]
                    continue
                elif len(indices) == 1:
                    parent1_idx = indices[0]
                    parent2_idx = parent1_idx
                else:
                    indices = self.python_random_generator.sample(indices, 2)
                    parent1_idx = indices[0]
                    parent2_idx = indices[1]
            else:
                # Index of the first parent to mate.
                parent1_idx = k % parents.shape[0]
                # Index of the second parent to mate.
                parent2_idx = (k+1) % parents.shape[0]

            # The gene will be copied from the first parent if the current gene index is 0.
            # The gene will be copied from the second parent if the current gene index is 1.
            offspring[k, :] = numpy.where(genes_sources[k] == 0, 
                                          parents[parent1_idx, :], 
                                          parents[parent2_idx, :])

            if self.allow_duplicate_genes == False:
                offspring[k], _, _ = self.solve_duplicate_genes(solution=offspring[k])
        return offspring
