from pygad.visualize import plot

__version__ = "1.2.2"
