# `pygad` Module

This section of the documentation discusses the `pygad` module.

With the `pygad` module, you can create, run, save, and load instances of the genetic algorithm. It solves both single-objective and multi-objective optimization problems.

## `pygad.GA` Class

The `pygad` module has a class named `GA` for building the genetic algorithm. This section explains the class constructor, its methods, functions, and attributes.

<!-- sphinx
(ga-constructor)=
-->
### `__init__()`

To create an instance of the `pygad.GA` class, the constructor accepts several parameters. These let you adjust the genetic algorithm for different types of applications.

The constructor validates settings before generating a population or calling gene constraints. Counts accept Python and NumPy integers, excluding Boolean values; ranges, probabilities, and distribution indices must be finite. Mutable settings such as gene spaces, per-gene ranges, and adaptive mutation rates are copied, so changing the original containers does not change the GA configuration.

The `pygad.GA` class constructor supports the parameters below, grouped by purpose. Click a parameter to expand its full description.

#### Population and Generations

<details>
<summary><code>num_generations</code>: Number of generations to run.</summary>

Number of generations per `run()` call. Must be a non-negative integer; `0` evaluates the initial population without evolving it.

</details>

<details>
<summary><code>num_parents_mating</code>: How many solutions are selected as parents.</summary>

Number of solutions to be selected as parents. Must be an integer between `1` and `sol_per_pop`, inclusive.

</details>

<details>
<summary><code>sol_per_pop</code>: Number of solutions in the population.</summary>

Number of solutions (i.e. chromosomes) within the population. This parameter has no action if `initial_population` parameter exists.

</details>

<details>
<summary><code>num_genes</code>: Number of genes in each solution.</summary>

Number of genes in the solution/chromosome. This parameter is not needed if the user feeds the initial population to the `initial_population` parameter.

</details>

<details>
<summary><code>initial_population</code>: Start from your own population.</summary>

A population you provide yourself to start the run instead of a random one. It defaults to `None`, in which case PyGAD builds the initial population from the `sol_per_pop` and `num_genes` parameters.

Pass a non-empty rectangular 2D list, tuple, or NumPy array of numeric values. PyGAD infers both dimensions from its shape, overriding any explicit `sol_per_pop` and `num_genes` values. It copies and converts the values using `gene_type`, applies `gene_constraint`, and repairs duplicates when `allow_duplicate_genes=False`. Supplied values may lie outside the gene space or initialization ranges; replacements follow the initialization settings. See [Creating the Initial Population](https://pygad.readthedocs.io/en/latest/gene_values.html#creating-the-initial-population).

If `initial_population` is `None` and either `sol_per_pop` or `num_genes` is also `None`, an exception is raised.

Introduced in [PyGAD 2.0.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-0-0) and higher.

</details>

<details>
<summary><code>stop_criteria=None</code>: Stop early when a condition is met.</summary>

One or more conditions that stop the evolution early. Each criterion is a string made of a stop word and a number, like `"reach_40"`.

Four stop words are supported:

- `reach`: stop when the fitness is greater than or equal to a given value. Example: `"reach_40"` stops once the fitness is `>= 40`.
- `saturate`: stop when the fitness does not change for a given number of generations. Example: `"saturate_7"` stops if the fitness stays the same for 7 generations in a row.
- `time`: stop when the time spent inside `run()` is at least the given number of seconds. Example: `"time_30"` stops the run after 30 seconds.
- `evaluations`: stop when the number of solutions whose fitness was evaluated inside `run()` reaches the given count. Example: `"evaluations_1000"` stops after at least 1000 solution evaluations. A batch counts once per solution, and adaptive mutation's offspring evaluations are included. Cached fitness values do not count. The criterion is checked at generation boundaries, so the count can exceed the threshold.

You can also pass a list, tuple, or 1D NumPy array of criteria; the run stops as soon as any one of them is met. Duplicate criteria are removed while preserving their order.

The counts for `saturate` and `evaluations` must be positive integers. Fractional counts are rejected. The threshold for `reach` must be finite, and the duration for `time` must be finite and non-negative; `time_0` stops at the first stopping check. Scientific notation is accepted, for example `evaluations_1e3` or `time_1e-2`. For multi-objective problems, `reach_10_20` requires both objective thresholds to be met; a single threshold applies to every objective.

`saturate_N` counts consecutive completed generations whose best fitness equals the preceding population's best fitness, including the initial population as the baseline. `saturate_1` stops after one unchanged generation. Any change resets the count, so matching endpoints with changes in between do not count as saturation. Multi-objective problems compare the whole best-fitness vector. Each `run()` starts a new saturation count while `generations_completed` continues increasing across runs.

Added in [PyGAD 2.15.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-15-0). The `time` and `evaluations` keywords were added in PyGAD 3.6.0.

</details>

#### Fitness Function

<details>
<summary><code>fitness_func</code>: Function that scores each solution.</summary>

The function, bound method, or callable instance that calculates the fitness of a solution. This is the one parameter you almost always need to set.

A fitness **function** must accept 3 parameters:

1. The instance of the `pygad.GA` class.
2. A single solution.
3. The index of the solution in the population. Adaptive mutation passes `None` because its offspring do not yet have a current-population index; calculate their fitness from the passed solution.

If you pass a **method**, it takes a fourth parameter for the method's class instance.

A callable instance's `__call__(self, ga_instance, solution, solution_idx)` uses the same three fitness arguments after `self`. Functions, bound methods, callable instances, and `functools.partial` are supported when their signatures accept PyGAD's positional arguments. Additional optional parameters are allowed. Required keyword-only parameters and asynchronous callables are rejected during construction. Process evaluation transports the callable and current GA state with cloudpickle; custom attributes and resources must be serializable. Thread evaluation shares the GA instance, so changes to shared state need synchronization.

Return a single number for a single-objective problem, or a `list`, `tuple`, or `numpy.ndarray` for a multi-objective problem (supported since [PyGAD 3.2.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-2-0)).

See [Preparing the fitness_func Parameter](https://pygad.readthedocs.io/en/latest/steps_to_use.html#preparing-the-fitness-func-parameter) for how to build one.

</details>

<details>
<summary><code>fitness_batch_size=None</code>: Score the solutions in batches.</summary>

Calculates the fitness in batches instead of one solution at a time.

- `1` or `None` (default): the fitness function is called once per solution.
- An integer where `1 < fitness_batch_size <= sol_per_pop`: solutions are grouped into batches of this size, and the fitness function is called once per batch.

In batch mode, the second fitness argument is a two-dimensional array of solutions and the third is a list of their population indices. Adaptive mutation passes `None` as the third argument instead. Return a `list`, `tuple`, or NumPy array with one fitness value per solution (a scalar for each single-objective solution, or an objective vector for each multi-objective solution). Cached rows are skipped, so batches can contain non-contiguous indices and the final batch can be smaller than the configured size.

See [Batch Fitness Calculation](https://pygad.readthedocs.io/en/latest/fitness_calculation.html#batch-fitness-calculation) for details and examples. Added in [PyGAD 2.19.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-19-0).

</details>

#### Genes: Values and Types

<details>
<summary><code>gene_type=float</code>: Data type (and precision) of the genes.</summary>

Sets the data type (and optional precision) of the genes. It defaults to `float`, so every gene is a `float`.

You can set it to:

- **One type for all genes:** `int`, `float`, NumPy signed or unsigned integer types with widths of 8, 16, 32, or 64 bits, or `numpy.float16`, `numpy.float32`, or `numpy.float64`. Example: `gene_type=int`.
- **A type per gene:** a `list`, `tuple`, or `numpy.ndarray` with one type per gene. Example: `gene_type=[int, float, numpy.int8]`.
- **A float precision:** pair a `float` type with the number of decimal places. Example: `gene_type=[float, 2]`.

Integer conversion truncates towards zero. Floating-point values are rounded before casting, using nearest-even rounding at halfway points. Precision can be `None` to leave values unrounded, or an integer including `0` and negative values. For example, `[float, -1]` rounds to tens. Integer types may only be paired with `None`.

The same rules apply to initialization, mutation, custom operators, and the outputs of `on_parents`, `on_crossover`, and `on_mutation`, independently of `allow_duplicate_genes`. Python `int` uses signed 64-bit conversion for candidate arrays and population columns on every platform, including Windows with NumPy 1.x. Explicit NumPy types keep their requested widths. Per-gene type specifications and saved best solutions preserve mixed scalar types using object arrays. See [Conversion and Rounding Rules](https://pygad.readthedocs.io/en/latest/gene_values.html#conversion-and-rounding-rules) for storage limits and handling larger Python integers.

Version history:

- [PyGAD 2.9.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-9-0): a single numeric type can be used.
- [PyGAD 2.14.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-14-0): a type per gene can be used.
- [PyGAD 2.15.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-15-0): a precision can be set for `float` types.

</details>

<details>
<summary><code>gene_space=None</code>: Allowed values or range for each gene.</summary>

Sets the allowed values for each gene, so you can limit the search space to a range or to a set of discrete values.

You can set it to:

- **The same space for all genes:** a `list`/`tuple`/`range`/`numpy.ndarray`. Example: `gene_space=[0.3, 5.2, -4, 8]` limits every gene to those 4 values.
- **A space per gene:** a nested list/tuple, one sub-list per gene. Example: `gene_space=[[0.4, -5], [0.5, -3.2, 8.2, -9], ...]` (the first sub-list is for the first gene, and so on).
- **A continuous range:** a dictionary with `low` and `high` (and an optional `step`). Example: `{'low': 2, 'high': 4}` limits the gene to the range from 2 to 4.
- **`None` for a gene:** that gene is initialized from `init_range_low`/`init_range_high`, and mutated using `random_mutation_min_val`/`random_mutation_max_val`.

Version history:

- Added in [PyGAD 2.5.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-5-0).
- [PyGAD 2.9.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-9-0): NumPy arrays can be used.
- [PyGAD 2.11.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-11-0): a dictionary can set the low and high limits.
- [PyGAD 2.15.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-15-0): the `"step"` key was added.

</details>

<details>
<summary><code>gene_constraint=None</code>: Functions that restrict gene values.</summary>

A list of callables (functions), one per gene, that restrict the values a gene can take. Before a value is chosen for a gene, its callable checks that the candidate value is valid. A list or tuple must contain exactly one callable or `None` per gene. Each callable must accept the solution and candidate values as 2 positional arguments; bound methods, callable instances, and partial functions are supported.

Added in [PyGAD 3.5.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-5-0). See the [Gene Constraint](https://pygad.readthedocs.io/en/latest/gene_values.html#gene-constraint) section for more information.

</details>

<details>
<summary><code>init_range_low=-4</code>: Lower bound for the initial gene values.</summary>

The lower value of the random range from which the gene values in the initial population are selected. `init_range_low` defaults to `-4`. Available in [PyGAD 1.0.20](https://pygad.readthedocs.io/en/latest/releases.html#pygad-1-0-20) and higher. Supplied values are preserved, but this bound is used when replacing a value to satisfy a constraint or repair duplicates. Generated range values stay within their bounds after conversion and rounding. See [Creating the Initial Population](https://pygad.readthedocs.io/en/latest/gene_values.html#creating-the-initial-population).

</details>

<details>
<summary><code>init_range_high=4</code>: Upper bound for the initial gene values.</summary>

The upper value of the random range from which the gene values in the initial population are selected. `init_range_high` defaults to `+4`. Available in [PyGAD 1.0.20](https://pygad.readthedocs.io/en/latest/releases.html#pygad-1-0-20) and higher. Supplied values are preserved, but this bound is used when replacing a value to satisfy a constraint or repair duplicates. Generated range values stay within their bounds after conversion and rounding. See [Creating the Initial Population](https://pygad.readthedocs.io/en/latest/gene_values.html#creating-the-initial-population).

</details>

<details>
<summary><code>allow_duplicate_genes=True</code>: Allow repeated values within a solution.</summary>

Added in [PyGAD 2.13.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-13-0). If `True`, then a solution/chromosome may have duplicate gene values. If `False`, PyGAD tries to give each gene a different numeric value after conversion and rounding. Repair can follow chains of replacements using each destination gene's space, range, type, precision, and constraint. If no usable alternative is found, duplicates remain with a warning unless warnings are suppressed. See [Prevent Duplicates in Gene Values](https://pygad.readthedocs.io/en/latest/gene_values.html#prevent-duplicates-in-gene-values).

For permutation encodings where every value in `gene_space` is already used, random and adaptive mutation try a compatible swap instead of keeping the selected gene unchanged. The fallback preserves destination gene types, numeric values, gene spaces, uniqueness, and constraints. Each gene can participate in at most one fallback swap per mutation pass. If no compatible partner exists, the gene stays unchanged. See [Mutation Methods](utils.md#mutation-methods).

</details>

<details>
<summary><code>sample_size=100</code>: Sample size used when searching for a valid value.</summary>

The size of the sample of candidate values PyGAD draws when it needs to pick a gene value. It defaults to `100`.

It is useful when `allow_duplicate_genes=False` or `gene_constraint` is used. If PyGAD cannot find a unique value or a value that meets a constraint, increase this parameter.

Duplicate repair considers finite spaces in full. For constraints depending on other genes, an additional search checks up to `sample_size * num_genes` tentative assignments when replacement chains do not satisfy all constraints.

Added in [PyGAD 3.5.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-5-0). See the [sample_size Parameter](https://pygad.readthedocs.io/en/latest/gene_values.html#sample-size-parameter) section for more information.

</details>

#### Parent Selection

<details>
<summary><code>parent_selection_type="sss"</code>: How the parents are selected.</summary>

How the parents are selected. It defaults to `"sss"`.

The built-in types are:

- `sss`: steady-state selection.
- `rws`: roulette wheel selection.
- `sus`: stochastic universal selection.
- `rank`: rank selection.
- `random`: random selection.
- `tournament`: tournament selection.
- `nsga2`: NSGA-II selection (multi-objective).
- `tournament_nsga2`: Tournament selection that ranks competitors with NSGA-II non-dominated sorting and crowding distance.
- `nsga3`: NSGA-III selection (multi-objective). Requires the `nsga3_num_divisions` parameter.
- `tournament_nsga3`: Tournament selection that ranks competitors with NSGA-III niche count instead of crowding distance. Requires the `nsga3_num_divisions` parameter.

You can also pass your own parent selection function (since [PyGAD 2.16.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-16-0)). See [User-Defined Crossover, Mutation, and Parent Selection Operators](https://pygad.readthedocs.io/en/latest/user_defined_operators.html#user-defined-crossover-mutation-and-parent-selection-operators).

</details>

<details>
<summary><code>K_tournament=3</code>: Contestants per tournament selection.</summary>

For `tournament`, `tournament_nsga2`, and `tournament_nsga3`, this is the number of contestants per tournament. It must be a positive integer and defaults to `3`. Values larger than `sol_per_pop` are clipped to the population size with a warning unless warnings are suppressed. Other selection types do not use this parameter.

</details>

<details>
<summary><code>nsga3_num_divisions=None</code>: Number of divisions per objective axis for NSGA-III.</summary>

Only used when `parent_selection_type` is `'nsga3'` or `'tournament_nsga3'`. It is the number of divisions per objective axis used to build the structured reference points (the `p` parameter from Deb & Jain 2014). The total number of reference points is `C(M + p - 1, p)` where `M` is the number of objectives. Must be a positive integer. Defaults to `None`.

If `sol_per_pop` is smaller than the resulting number of reference points, PyGAD raises a warning and grows the population to match before the generational loop starts.

</details>

#### Keeping Solutions

<details>
<summary><code>keep_elitism=1</code>: Keep the best solutions each generation.</summary>

The number of best solutions (the elitism) to keep in the next generation. It defaults to `1`, so only the best solution is kept.

- `0`: elitism is turned off.
- A positive integer `K` (with `0 <= keep_elitism <= sol_per_pop`): the best `K` solutions are kept.

If this parameter is not `0`, then `keep_parents` has no effect.

Added in [PyGAD 2.18.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-18-0). To see how `keep_elitism` and `keep_parents` work together, see [How the Number of Offspring Is Decided](https://pygad.readthedocs.io/en/latest/generations.html#how-the-number-of-offspring-is-decided).

</details>

<details>
<summary><code>keep_parents=-1</code>: Keep the parents in the next generation.</summary>

The number of parents to keep in the next population. It defaults to `-1`.

- `-1`: keep all the parents.
- `0`: keep no parents.
- A positive integer: keep that many parents.

The value must be an integer from `-1` through `num_parents_mating`. Passing `None` uses the default of keeping all parents.

This parameter has an effect only when `keep_elitism=0` (since [PyGAD 2.18.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-18-0)). Since PyGAD 2.20.0, the parents' fitness from the last generation is not re-used if `keep_parents=0`.

To see how `keep_parents` and `keep_elitism` work together, see [How the Number of Offspring Is Decided](https://pygad.readthedocs.io/en/latest/generations.html#how-the-number-of-offspring-is-decided).

</details>

#### Crossover

<details>
<summary><code>crossover_type="single_point"</code>: How parents are combined into offspring.</summary>

The type of crossover. It defaults to `"single_point"`.

The built-in types are:

- `single_point`: single-point crossover.
- `two_points`: two-point crossover.
- `uniform`: uniform crossover.
- `scattered`: scattered crossover (since [PyGAD 2.9.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-9-0)).
- `sbx`: simulated binary crossover. The standard real-coded operator. Requires the `sbx_crossover_eta` parameter.

You can also pass your own crossover function (since [PyGAD 2.16.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-16-0)). See [User-Defined Crossover, Mutation, and Parent Selection Operators](https://pygad.readthedocs.io/en/latest/user_defined_operators.html#user-defined-crossover-mutation-and-parent-selection-operators).

If `crossover_type=None`, the crossover step is skipped and no offspring are created, so the next generation reuses the current population (since [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2)).

</details>

<details>
<summary><code>sbx_crossover_eta=30</code>: Distribution index for SBX crossover.</summary>

Only used when `crossover_type` is `'sbx'`. Sets how close the children stay to the parents. A higher value means children stay closer. Must be a finite positive number. Defaults to `30`.

Each crossed gene selects the lower or upper SBX child with equal probability. This avoids consistently moving genes below their parents' midpoint. The bounds come from each gene's `gene_space`, falling back to its initialization range for a `None` space. Reversed initialization bounds are sorted for calculation. Supplied parent values outside these bounds are clipped before the SBX calculation. Results apply the destination type, precision, space, constraints, and duplicate policy; an invalid proposed child falls back to its parent.

</details>

<details>
<summary><code>crossover_probability=None</code>: Chance a parent is used for crossover.</summary>

The probability of selecting a parent for crossover. Its value must be between 0.0 and 1.0.

For each parent, a random value between 0.0 and 1.0 is generated. If that value is less than `crossover_probability`, the parent is selected. Setting `0` copies parents without crossing them.

Added in [PyGAD 2.5.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-5-0) and higher.

</details>

<!-- sphinx
(mutation-controls)=
-->
#### Mutation

<details>
<summary><code>mutation_type="random"</code>: How offspring genes are mutated.</summary>

The type of mutation. It defaults to `"random"`.

The built-in types are:

- `random`: random mutation.
- `swap`: swap mutation.
- `inversion`: inversion mutation.
- `scramble`: scramble mutation.
- `adaptive`: adaptive mutation (since [PyGAD 2.10.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-10-0)). See [Adaptive Mutation](https://pygad.readthedocs.io/en/latest/adaptive_mutation.html#adaptive-mutation) and [Use Adaptive Mutation in PyGAD](https://pygad.readthedocs.io/en/latest/adaptive_mutation.html#use-adaptive-mutation-in-pygad).
- `polynomial`: polynomial mutation. The standard real-coded operator used together with SBX. Requires the `polynomial_mutation_eta` parameter.

You can also pass your own mutation function (since [PyGAD 2.16.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-16-0)). See [User-Defined Crossover, Mutation, and Parent Selection Operators](https://pygad.readthedocs.io/en/latest/user_defined_operators.html#user-defined-crossover-mutation-and-parent-selection-operators).

Permutation mutations (`swap`, `inversion`, and `scramble`) check the complete proposed solution against destination gene spaces, types, constraints, and the duplicate policy. An incompatible permutation is retried; if no acceptable proposal is found, the solution is retained. With no explicit mutation probability, count, or percentage, swap selects one pair and inversion/scramble use their usual half-length segment. When a control is explicitly supplied, it selects the eligible positions: swap exchanges pairs, inversion reverses the selected values, and scramble shuffles them. Fewer than 2 eligible positions leave the solution unchanged; an odd number in swap leaves one eligible position unpaired.

If `mutation_type=None`, the mutation step is skipped and the offspring are used unchanged (since [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2)).

</details>

<details>
<summary><code>polynomial_mutation_eta=20</code>: Distribution index for polynomial mutation.</summary>

Only used when `mutation_type` is `'polynomial'`. Sets the size of the change. A higher value means a smaller change. Must be a finite positive number. Defaults to `20`.

Polynomial mutation uses the gene-space bounds, falling back to the initialization range for a `None` space. It supports probabilities, explicit counts, and percentages. When none is explicitly supplied, its default per-gene probability is `1 / num_genes`. It clips supplied values before calculation, converts and rounds the results, and checks spaces, constraints, and duplicates before accepting the complete solution.

</details>

<details>
<summary><code>mutation_probability=None</code>: Per-gene chance of mutation.</summary>

The probability of selecting a gene for mutation. Its value must be between 0.0 and 1.0.

For each gene, a random value between 0.0 and 1.0 is generated. If that value is less than `mutation_probability`, the gene is selected. Setting `0` leaves the offspring unchanged, including permutation and polynomial mutation; `1` selects every gene. Adaptive mutation takes 2 probabilities, for below-average and above-average solutions, respectively.

Only the active mutation control is validated: `mutation_probability` takes precedence over `mutation_num_genes`, which takes precedence over `mutation_percent_genes`. Values for inactive controls are ignored. Built-in operators apply these controls; custom mutation functions implement their own selection rules. Added in [PyGAD 2.5.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-5-0) and higher.

</details>

<details>
<summary><code>mutation_by_replacement=False</code>: Replace the gene value instead of adding to it.</summary>

A bool that controls how `random` and `adaptive` mutation change a gene when drawing random values. Finite gene spaces select replacement values directly.

- `True`: replace the gene with the randomly generated value.
- `False` (default): add the random value to the gene.

For NumPy integer gene types, both modes clip the resulting value to the type's limits before casting. For example, a `numpy.uint8` gene at `0` stays at `0` when adding `-1`. See [Conversion and Rounding Rules](gene_values.md#conversion-and-rounding-rules).

Supported in [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2) and higher. See the [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2) release notes for an example.

</details>

<details>
<summary><code>mutation_percent_genes="default"</code>: Percentage of genes to mutate.</summary>

The percentage of genes to mutate. It defaults to the string `"default"`, which becomes `10` (10% of the genes). The value must be `> 0` and `<= 100`.

PyGAD computes `mutation_num_genes` by multiplying the percentage by `num_genes` and discarding the fractional part. If this gives `0`, it selects `1` gene and warns unless warnings are suppressed. Adaptive mutation requires 2 percentages, for below-average and above-average solutions, respectively.

This parameter has no effect if `mutation_probability` or `mutation_num_genes` is set, or if `mutation_type` is `None` (since [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2)).

</details>

<details>
<summary><code>mutation_num_genes=None</code>: Number of genes to mutate.</summary>

The number of genes eligible for mutation. It defaults to `None`, meaning no number is set. When active, it must be an integer between `1` and `num_genes`, inclusive. Adaptive mutation requires 2 counts, for below-average and above-average solutions, respectively. Permutation operators may leave selected positions unchanged when a compatible rearrangement is unavailable.

This parameter has no effect if `mutation_probability` is set, or if `mutation_type` is `None` (since [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2)).

</details>

<details>
<summary><code>random_mutation_min_val=-1.0</code>: Lower bound of the random mutation value.</summary>

For `random` mutation, the start of the range from which a random value is drawn and added to the gene. It defaults to `-1`.

This parameter has no effect if `mutation_type` is `None` (since [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2)).

</details>

<details>
<summary><code>random_mutation_max_val=1.0</code>: Upper bound of the random mutation value.</summary>

For `random` mutation, the end of the range from which a random value is drawn and added to the gene. It defaults to `+1`.

This parameter has no effect if `mutation_type` is `None` (since [PyGAD 2.2.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-2-2)).

</details>

#### Lifecycle Callbacks

<details>
<summary><code>on_start=None</code>: Called once before the run starts.</summary>

A function (or method) called once before the run starts.

- As a **function**, it takes 1 parameter: the instance of the genetic algorithm.
- As a **method**, it takes a second parameter for the method's object.

Added in [PyGAD 2.6.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-6-0).

</details>

<details>
<summary><code>on_fitness=None</code>: Called after the fitness is calculated.</summary>

A function (or method) called before parent selection after the fitness of all solutions is calculated. It receives `on_fitness(ga_instance, population_fitness)` and may return replacement fitness with the same shape, or modify the supplied array in place and return `None`. Both forms are validated before selection, and saved best solutions are updated to agree with the resulting fitness.

- As a **function**, it takes 2 parameters: the instance of the genetic algorithm, and a NumPy array of all the solutions' fitness values.
- As a **method**, it takes a third parameter for the method's object.

Added in [PyGAD 2.6.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-6-0).

</details>

<details>
<summary><code>on_parents=None</code>: Called after the parents are selected.</summary>

A function (or method) called after the parents are selected.

- As a **function**, it takes 2 parameters: the selected parents, and the instance of the genetic algorithm.
- As a **method**, it takes a third parameter for the method's object.

Added in [PyGAD 2.6.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-6-0).

</details>

<details>
<summary><code>on_crossover=None</code>: Called after crossover.</summary>

A function called each time crossover is applied. It takes 2 parameters: the instance of the genetic algorithm, and the offspring generated by crossover.

Added in [PyGAD 2.6.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-6-0).

</details>

<details>
<summary><code>on_mutation=None</code>: Called after mutation.</summary>

A function called each time mutation is applied. It takes 2 parameters: the instance of the genetic algorithm, and the offspring after mutation.

Added in [PyGAD 2.6.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-6-0).

</details>

<details>
<summary><code>on_generation=None</code>: Called after each generation.</summary>

A function called after each generation. It takes 1 parameter: the instance of the genetic algorithm.

If it returns the string `"stop"`, the `run()` method stops without completing the remaining generations.

Added in [PyGAD 2.6.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-6-0).

</details>

<details>
<summary><code>on_stop=None</code>: Called once when the run ends.</summary>

A function called once just before the run ends (or after the last generation). It takes 2 parameters: the instance of the genetic algorithm, and the list of the last population's fitness values.

Added in [PyGAD 2.6.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-6-0).

</details>

#### Saving and Logging

<details>
<summary><code>save_best_solutions=False</code>: Save the best solution of each generation.</summary>

When `True`, the best solution of each generation is saved into the `best_solutions` attribute. When `False` (default), nothing is saved and `best_solutions` stays empty.

Supported in [PyGAD 2.9.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-9-0).

</details>

<details>
<summary><code>save_solutions=False</code>: Save every solution of each generation.</summary>

If `True`, then all solutions in each generation are appended into the `solutions` list, with their fitness in `solutions_fitness`. Each run includes its starting and final populations. `solutions_generations` records one generation number per saved population. Supported in [PyGAD 2.15.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-15-0).

</details>

<details>
<summary><code>logger=None</code>: Custom logger for the outputs.</summary>

An instance of the `logging.Logger` class used to log the outputs. When set, messages are logged instead of printed with `print()`. If `None`, PyGAD uses its default logger and adds a console `StreamHandler` only when it has no handlers. Existing handlers are preserved. Invalid logger values raise a `TypeError` naming the parameter.

Added in [PyGAD 3.0.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-0-0). See [Logging Outputs](https://pygad.readthedocs.io/en/latest/logging.html#logging-outputs) for more information.

</details>

<details>
<summary><code>suppress_warnings=False</code>: Turn warning messages on or off.</summary>

A bool parameter to control whether the warning messages are printed or not. It defaults to `False`.

</details>

#### Performance and Reproducibility

<details>
<summary><code>parallel_processing=None</code>: Use threads or processes to speed up fitness.</summary>

Runs the fitness calculation in parallel. It defaults to `None` (no parallel processing).

You can set it to:

- **`None` or integer `0`:** disable parallel processing.
- **A positive integer:** the number of threads. Example: `parallel_processing=5` uses 5 threads (the same as `["thread", 5]`).
- **A list/tuple of 2 elements:** the first is `"process"` or `"thread"`; the second is a positive maximum worker count, `None` for the executor's default, or `0` to disable parallel processing. Example: `parallel_processing=["process", 10]` uses up to 10 processes.

Validation normalizes a positive integer to `["thread", count]` and a zero worker count to `None`. Workers are created only for uncached fitness work and reused during one `run()`, including adaptive offspring evaluation. Completion, early stopping, and exceptions shut down the pool. Calling `cal_pop_fitness()` outside a run uses a temporary pool. Process-based scripts should start the GA under `if __name__ == "__main__":`.

Added in [PyGAD 2.17.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-17-0). See [Parallel Processing in PyGAD](https://pygad.readthedocs.io/en/latest/fitness_calculation.html#parallel-processing-in-pygad) for more information.

</details>

<details>
<summary><code>random_seed=None</code>: Seed for reproducible runs.</summary>

The seed for this instance's NumPy and Python random generators. Accepts `None` or a Python/NumPy integer from `0` through `2**32 - 1`. Setting it makes built-in operations reproducible (for example, `random_seed=2`). With `None`, each instance starts with an automatically initialized state.

Each GA owns `numpy_random_generator` (a `numpy.random.RandomState`) and `python_random_generator` (a `random.Random`). Creating or running another GA and drawing from the global generators do not alter its state. Repeated `run()` calls continue the same generator states, and checkpoints preserve them. To reproduce random draws in custom operators or callbacks, use these instance generators, for example `ga_instance.numpy_random_generator.random()`. Global random draws in user code need their own seed. Seeded results may differ between PyGAD versions. See `examples/example_constructor_parameters.py` for an example.

Added in [PyGAD 2.18.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-18-0).

</details>

You do not have to set all of these parameters when you create an instance of the `GA` class. The most important one is `fitness_func`, which defines the fitness function.

It is OK to set the value of any of the 2 parameters `init_range_low` and `init_range_high` to be equal, higher, or lower than the other parameter (i.e. `init_range_low` is not needed to be lower than `init_range_high`). The same holds for the `random_mutation_min_val` and `random_mutation_max_val` parameters.

If both the `mutation_type` and `crossover_type` parameters are `None`, then the genetic algorithm cannot evolve at all. As a result, it cannot find a solution better than the best solution in the initial population.

The parameters are validated by calling the `validate_parameters()` method of the `utils.validation.Validation` class inside the constructor. If any parameter is not correct, an exception is raised and the `valid_parameters` attribute is set to `False`.

<!-- python-examples
example_constructor_parameters.py
-->

**Python example**

**[Constructor settings and random seeds](../../examples/example_constructor_parameters.py)**

Use callable fitness signatures, NumPy counts, and independent seeded GA instances.

`examples/example_constructor_parameters.py`

<details>
<summary>Run this example</summary>

**Requires:** PyGAD

From the repository root, with the repository version of PyGAD installed:

```console
python examples/example_constructor_parameters.py
```

</details>

<!-- /python-examples -->

## Extended Classes

To keep the library modular and structured, the code is split into several scripts, where each script has one or more classes. Each class has its own purpose.

Here is the list of scripts and the classes that the `pygad.GA` class extends:

1. `utils/engine.py`:
   1. `utils.engine.GAEngine`: Runs the GA loop and owns the run-time lifecycle helpers.
2. `utils/validation.py`
   1. `utils.validation.Validation`: Validates every constructor parameter and dispatches `parent_selection_type` / `crossover_type` / `mutation_type` to the right method.
3. `utils/parent_selection.py`
   1. `utils.parent_selection.ParentSelection`: All built-in parent selection operators, including `nsga2_selection`, `tournament_selection_nsga2`, `nsga3_selection`, and `tournament_selection_nsga3`.
4. `utils/crossover.py`
   1. `utils.crossover.Crossover`: Built-in crossover operators.
5. `utils/mutation.py`
   1. `utils.mutation.Mutation`: Built-in mutation operators.
6. `utils/nsga.py`
   1. `utils.nsga.NSGA`: Building blocks shared by NSGA-II and NSGA-III (`non_dominated_sorting`, `get_non_dominated_set`).
7. `utils/nsga2.py`
   1. `utils.nsga2.NSGA2`: NSGA-II specific primitives (`crowding_distance`, `sort_solutions_nsga2`).
8. `utils/nsga3.py`
   1. `utils.nsga3.NSGA3`: NSGA-III algorithm primitives (reference points, ideal point, extreme points, intercepts, normalization, association, niching).
9. `utils/report.py`
   1. `utils.report.Report`: Builds a PDF report of the run (`generate_report`).
10. `helper/unique.py`
    1. `helper.unique.Unique`: Routines that resolve duplicate genes inside a solution.
11. `helper/misc.py`
    1. `helper.misc.Helper`: Generic helpers used across the library (population dtype handling, per-gene value generation, constraint sampling, lifecycle summary).
12. `visualize/plot.py`
    1. `visualize.plot.Plot`: All plot methods. See [`pygad.visualize`](https://pygad.readthedocs.io/en/latest/visualize.html).
13. `visualize/lifecycle.py`
    1. Internal helpers that describe the configured lifecycle and draw its flowchart without running the GA or calling user functions.

`utils.engine.GAEngine` also extends `utils.parallel.FitnessEvaluation`, so `pygad.GA` indirectly inherits its fitness dispatch and serialization methods. See the [pygad.utils.parallel reference](utils.md#pygadutilsparallel-submodule) for all of its methods, the process-worker function, and runtime attributes.

Since the `pygad.GA` class extends such classes, the attributes and methods inside them can be retrieved by instances of the `pygad.GA` class.

### Class Attributes

* `supported_int_types`: A list of the supported types for the integer numbers.
* `supported_float_types`: A list of the supported types for the floating-point numbers.
* `supported_int_float_types`: A list of the supported types for all numbers. It just concatenates the previous 2 lists.

### Other Instance Attributes & Methods

Constructor settings and user callables are stored as instance attributes, with some values normalized during validation. Numeric counts become Python integers, mutable parameter containers are copied, and inactive mutation counts/percentages are normalized to `None`/`"default"`. Active operators are exposed as `select_parents`, `crossover`, and `mutation`. The following sections describe additional instance attributes and inherited methods; the supported numeric type lists above are class attributes.

> The `GA` class gains the attributes of its parent classes via inheritance, making them accessible through the `GA` object even if they are defined externally to its specific class body.

> Names that begin with an underscore (for example `_bootstrap_nsga3_reference_points`) are internal helpers. They are listed below for completeness but are not part of the stable API; do not rely on their signature staying the same across releases.

#### Lifecycle

##### Attributes

- `generations_completed`: Number of the last completed generation.
- `run_completed`: Set to `True` only after the `run()` method completes gracefully.
- `valid_parameters`: Set to `True` when all the parameters passed in the `GA` class constructor are valid.
- `run_start_time`: Monotonic clock value captured after `on_start` and before initial fitness evaluation in each `run()`. Used by the `time_<seconds>` stop criterion; it is not a wall-clock timestamp. Internal.
- `logger`: Logger object from the `logging` module. Supported in [PyGAD 3.0.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-0-0).

##### Methods

- `run()`: Runs the generation loop. The main entry point.
- `run_loop_head(best_solution_fitness)`: Per-generation pre-loop bookkeeping. Internal; called from inside `run()`. Added in [PyGAD 3.3.1](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-3-1).
- `run_select_parents(call_on_parents=True)`: Select parents and call `on_parents` when defined. Internal; called from inside `run()`. Pass `call_on_parents=False` when refreshing the parent set at the end of `run()`. Added in [PyGAD 3.3.1](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-3-1).
- `run_crossover()`: Apply crossover and call `on_crossover` when defined. Internal. Added in [PyGAD 3.3.1](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-3-1).
- `run_mutation()`: Apply mutation and call `on_mutation` when defined. Internal. Added in [PyGAD 3.3.1](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-3-1).
- `run_update_population()`: Replace `self.population` with the crossed-over and mutated offspring. Internal. Added in [PyGAD 3.3.1](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-3-1).
- `summary(...)`: Prints a Keras-like summary of the PyGAD lifecycle. Added in [PyGAD 2.19.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-19-0). See [Print Lifecycle Summary](https://pygad.readthedocs.io/en/latest/logging.html#print-lifecycle-summary).
- `plot_lifecycle(title="PyGAD - Lifecycle", font_size=11, show_parameters=True, save_dir=None, show=True)`: Draws the configured lifecycle with operators, callbacks, population replacement, and stopping decisions. Works before or after `run()` and returns a matplotlib figure. See [plot_lifecycle()](visualize.md#plot_lifecycle).

#### Population and Initialization

##### Attributes

- `population`: A NumPy array that initially holds the initial population and is later updated after each generation.
- `initial_population`: Frozen copy of the initial population, set after `initialize_population` runs.
- `pop_size`: A `(sol_per_pop, num_genes)` tuple describing the population shape.
- `gene_type_single`: `True` when every gene shares the same dtype; `False` when `gene_type` is a list/tuple/numpy.ndarray. Added in [PyGAD 2.14.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-14-0).
- `gene_space_unpacked`: An inspection snapshot of converted values in `gene_space`. Small finite spaces are kept in full; large ranges, stepped dictionaries, and continuous intervals contribute at most 100 values per gene by default. Generation and duplicate repair read the original space, so inspection samples do not restrict the available values and `None` entries remain random. For example, `range(1, 5)` becomes `[1, 2, 3, 4]`; `{'low': 2, 'high': 4}` becomes a finite sample. Added in [PyGAD 3.1.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-1-0).

##### Methods

- `initialize_population(allow_duplicate_genes, gene_type, gene_constraint)`: Build the initial population, apply gene types and constraints, resolve duplicates when not allowed.
- `generate_initial_population(num_solutions)`: Sample new population values in bulk and prepare the resulting solutions. Also used by NSGA-III population growth.
- `prepare_initial_population(population)`: Convert generated or supplied rows, apply constraints, and repair duplicates.
- `apply_initial_population_gene_constraints(population)`: Replace rejected values using initialization candidates, warning when no candidate satisfies a constraint.
- `sample_initial_population_gene_values(gene_index, num_values)`: Sample one column from its space or initialization range.
- `get_initial_population_gene_candidates(gene_index, sample_size, all_integer_values=True)`: Return converted replacement candidates for initialization constraints and duplicate repair.
- `initialize_parents_array(shape)`: Allocate an empty parents (or offspring) array with the right dtype.
- `change_population_dtype_and_round(population)`: Cast a 2D population to the dtype encoded in `self.gene_type` and round non-integer genes.
- `change_gene_dtype_and_round(gene_index, gene_value)`: Apply one gene's type and precision to a scalar or an array of candidates, preserving the input shape.
- `round_genes(solutions)`: Convert and round genes in a 2D array according to `self.gene_type`. Update the input array when its dtype matches the converted output.
- `prepare_operator_output(population, build_initial_pop=False)`: Apply gene types and precision, then repair duplicates if `allow_duplicate_genes=False`. SBX and polynomial mutation use initialization bounds for repair.
- `get_initial_population_range(gene_index)`: Return the `[init_range_low, init_range_high]` window for a specific gene.
- `get_random_mutation_range(gene_index)`: Return the `[random_mutation_min_val, random_mutation_max_val]` window for a specific gene.
- `get_gene_dtype(gene_index)`: Return the `(type, precision)` pair for a specific gene.
- `generate_gene_value(...)`: Sample a single gene value from the gene space or from the configured range.
- `generate_gene_value_from_space(...)`: Sample a single gene value from `gene_space`.
- `generate_gene_value_randomly(...)`: Sample a single gene value from the configured numeric range.

#### Fitness

##### Attributes

- `last_generation_fitness`: Fitness values of the solutions in the last generation. Added in [PyGAD 2.12.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-12-0).
- `previous_generation_fitness`: Fitness of the population one step before `last_generation_fitness`. Used to skip re-evaluating solutions PyGAD has already seen. Added in [PyGAD 2.16.2](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-16-2).
- `best_solutions_fitness`: Fitness history of the best solution per generation, including the final population. Recorded even when `save_best_solutions=False`; with saving enabled, entries correspond to `best_solutions`.
- `best_solutions_generations`: The actual generation number for each entry in `best_solutions_fitness`. Repeated runs retain both the final and starting snapshots at their boundary.
- `best_solutions`: A NumPy array of the best solution per generation. Only populated when `save_best_solutions=True`.
- `solutions`: All visited solutions when `save_solutions=True`.
- `solutions_fitness`: Fitness for every entry in `solutions`.
- `solutions_generations`: One generation number per saved population when `save_solutions=True`. The solutions and their fitness retain one entry per solution.
- `num_fitness_evaluations`: Number of solutions evaluated during the current `run()`, including adaptive offspring and every solution in returned fitness batches. Cache hits do not count. Each run resets the counter after `on_start`; direct fitness evaluations outside a run increment the existing count. `evaluations_<N>` checks the count at generation boundaries, so the run can exceed the requested budget by a generation's work.
- `best_solution_generation`: Actual generation at which the best saved fitness was reached, using the same single-objective or NSGA-II ordering as `best_solution()`. `-1` until `run()` completes, or when an older checkpoint lacks the winning snapshot's generation number. See [Saved Fitness across Repeated Runs](fitness_calculation.md#saved-fitness-across-repeated-runs).

##### Methods

- `cal_pop_fitness()`: Compute the fitness of every solution in the current population, reusing previously calculated values where possible.
- `best_solution(pop_fitness=None)`: Return the best solution in the current population, its fitness, and its population index. Pass the current population's fitness to avoid additional evaluation. See [best_solution()](utils.md#best_solution) for single-objective and multi-objective selection rules.
- `adaptive_mutation_population_fitness(offspring)`: Return `(average_fitness, offspring_fitness)` using retained solutions and actual offspring before mutation. See the [adaptive fitness reference](utils.md#adaptive_mutation_population_fitnessoffspring).

#### Fitness Worker Lifecycle (internal)

The `FitnessEvaluation` mixin manages these attributes and methods. They may not exist on a newly constructed or loaded GA until first use; use the public configuration parameters to control evaluation.

##### Attributes

- `_fitness_run_active`: `True` while `run()` is active; set to `False` on exit, including errors.
- `_fitness_executor`: Lazily created run-owned thread or process executor, or `None` after shutdown. Pools for direct evaluations outside a run are temporary and not stored here.
- `_fitness_executor_config`: Normalized `(mode, max_workers)` tuple for the active pool, or `None` after shutdown.

##### Methods

- `__getstate__()`: Return serializable instance state excluding the three runtime worker attributes.
- `_shutdown_fitness_executor()`: Detach the run-owned executor and wait for submitted work to finish.
- `_fitness_pool()`: Context manager supplying a reusable run-owned pool or a temporary pool outside a run.
- `_map_fitness(tasks)`: Yield fitness results in task order using serial calls, threads, or process snapshots.
- `_evaluate_fitness(population, indices, adaptive=False)`: Evaluate selected rows, prepare scalar or batch arguments, validate results, and update the evaluation count.

The [complete fitness dispatch reference](utils.md#pygadutilsparallel-submodule) documents parameters, return values, exceptions, process isolation, and attribute lifetimes.

#### Parent Selection (general)

##### Attributes

- `last_generation_parents`: Parents selected in the last generation. Added in [PyGAD 2.12.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-12-0).
- `last_generation_parents_indices`: Indices of the selected parents in `self.population`. Added in [PyGAD 2.15.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-15-0).

##### Methods

- `select_parents(fitness, num_parents)`: Active parent-selection method. Bound during validation according to `parent_selection_type`.
- `steady_state_selection(fitness, num_parents)`: Steady-state selection.
- `rank_selection(fitness, num_parents)`: Rank-based selection.
- `random_selection(fitness, num_parents)`: Random selection.
- `tournament_selection(fitness, num_parents)`: K-tournament selection.
- `roulette_wheel_selection(fitness, num_parents)`: Roulette-wheel selection.
- `stochastic_universal_selection(fitness, num_parents)`: SUS selection.
- `wheel_cumulative_probs(probs, num_parents)`: Build the `[start, end)` ranges used by RWS and SUS.

#### Multi-Objective Optimization (NSGA-II)

##### Attributes

- `pareto_fronts`: List of the Pareto fronts of the last generation when running a multi-objective problem. Each front is a NumPy array of `(population_index, fitness_vector)` pairs. Added in [PyGAD 3.2.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-3-2-0).

##### Methods

- `non_dominated_sorting(fitness)`: Sort the population into Pareto fronts. Defined in `utils.nsga.NSGA` and shared with NSGA-III.
- `get_non_dominated_set(curr_solutions)`: Split the current set of solutions into a dominated and non-dominated subset. Defined in `utils.nsga.NSGA`.
- `crowding_distance(pareto_front, fitness)`: Per-solution crowding distance inside a Pareto front. Defined in `utils.nsga2.NSGA2`.
- `sort_solutions_nsga2(fitness, find_best_solution=False)`: Sort population indices best-to-worst using Pareto fronts and crowding distance for MOO; descending fitness for SOO. Defined in `utils.nsga2.NSGA2`.
- `nsga2_selection(fitness, num_parents)`: NSGA-II parent selection. Defined in `utils.parent_selection.ParentSelection`.
- `tournament_selection_nsga2(fitness, num_parents)`: K-tournament with non-dominated rank + crowding distance as tiebreakers. Defined in `utils.parent_selection.ParentSelection`.

#### Multi-Objective Optimization (NSGA-III)

##### Attributes

- `nsga3_num_divisions`: Stored value of the `nsga3_num_divisions` constructor parameter. Used when building the reference grid.
- `nsga3_reference_points`: Structured grid of reference points on the unit simplex. A 2D NumPy array of shape `(n_points, num_objectives)` where each row sums to 1. Built once before the generation loop starts (`_bootstrap_nsga3_reference_points`). Re-used for every generation.

##### Methods (algorithm primitives in `utils.nsga3.NSGA3`)

- `nsga3_generate_reference_points(num_objectives, num_divisions)`: Build the Das-Dennis grid.
- `nsga3_compute_ideal_point(fitness)`: Best fitness per objective across the input rows (column max under maximization).
- `nsga3_find_extreme_points(fitness, ideal_point, epsilon=NSGA3_ASF_EPSILON)`: For each objective, find the row that best represents the corner of that axis using the ASF.
- `nsga3_compute_intercepts(extreme_points, ideal_point, fallback_fitness)`: Fit a hyperplane through the extreme points and return per-axis intercepts. Falls back to the nadir on singular systems.
- `nsga3_normalize_fitness(fitness, ideal_point, intercepts)`: Scale each fitness row to the unit hypercube and clip outliers to `[0, 1]`.
- `nsga3_associate_to_reference_points(normalized, reference_points)`: For every normalized row, find the closest reference line and the perpendicular distance to it.
- `nsga3_niching_select(critical_front_indices, critical_front_associations, critical_front_distances, accepted_associations, num_reference_points, num_to_select)`: Niching loop that picks survivors from the critical front to preserve diversity across reference points.

##### Methods (selection in `utils.parent_selection.ParentSelection`)

- `nsga3_selection(fitness, num_parents)`: NSGA-III parent selection.
- `tournament_selection_nsga3(fitness, num_parents)`: K-tournament with niche count + perpendicular distance as tiebreakers.
- `_nsga3_pick_critical_front_survivors(...)`: Run normalization and niching on `P_next ∪ critical_front` and return the picked survivors. Internal.
- `_nsga3_pick_tournament_winner(...)`: Decide the winner of one K-tournament round under NSGA-III rules. Internal.
- `_nsga3_build_parents(final_indices, num_parents)`: Copy the chosen rows out of the population into a new parents array. Internal.

##### Methods (bootstrap and population growth in `utils.engine.GAEngine`)

- `_bootstrap_nsga3_reference_points()`: Build the reference-point grid once, right after the first fitness evaluation. Calls `_nsga3_grow_population` when `sol_per_pop` is smaller than the reference count.
- `_nsga3_grow_population(required_size, num_objectives)`: Append random solutions to `self.population`, update `sol_per_pop` / `pop_size` / `num_offspring`, re-evaluate fitness.
- `_nsga3_generate_extra_random_solutions(count)`: Build `count` random solutions respecting the gene space, init range, gene type, gene constraints, and `allow_duplicate_genes` rules.
- `_nsga3_generate_single_random_gene(gene_idx, partial_solution)`: Sample a single gene value using initial-population settings (not mutation settings).
- `_nsga3_apply_gene_constraints(population)`: Enforce `gene_constraint` on the new rows.
- `_nsga3_resolve_duplicate_genes(population)`: Resolve duplicate genes in the new rows when `allow_duplicate_genes=False`.

##### Module-level helpers (in `pygad.utils.nsga3`)

- `NSGA3_ASF_EPSILON`: Off-axis weight used by the ASF inside `nsga3_find_extreme_points`.
- `NSGA3_INTERCEPT_NEAR_ZERO`: Threshold under which an intercept gap is treated as zero.
- `_nsga3_pick_target_reference_point(niche_counts, critical_front_associations, remaining_positions)`: Choose the next reference point for the niching loop. Internal.
- `_nsga3_pick_candidate_at_reference(candidates_at_target, critical_front_distances, niche_count_at_target)`: Choose a candidate at a given reference point. Internal.
- `_nsga3_enumerate_compositions(num_objectives, num_divisions)`: Yield every non-negative integer tuple summing to `num_divisions`. Internal.

##### Module-level helpers (in `pygad.utils.parent_selection`)

- `_nsga3_validate_multi_objective_fitness(fitness, supported_int_float_types, method_name)`: Raise when the GA was set to NSGA-III but the fitness function returned scalars.
- `_nsga3_accumulate_fronts(pareto_fronts, num_parents)`: Walk the Pareto fronts and split them into the accepted set + the critical front.

#### Crossover

##### Attributes

- `last_generation_offspring_crossover`: Offspring after crossover. Added in [PyGAD 2.12.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-12-0).

##### Methods

- `crossover()`: Active crossover operator. Bound during validation according to `crossover_type`.
- `single_point_crossover(parents, offspring_size)`: Single-point crossover.
- `two_points_crossover(parents, offspring_size)`: Two-point crossover.
- `uniform_crossover(parents, offspring_size)`: Uniform crossover.
- `scattered_crossover(parents, offspring_size)`: Scattered crossover.
- `sbx_crossover(parents, offspring_size)`: Simulated binary crossover. Uses `self.sbx_crossover_eta`.

#### Mutation

##### Attributes

- `last_generation_offspring_mutation`: Offspring after mutation. Added in [PyGAD 2.12.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-12-0).
- `last_generation_offspring_mutation_indices`: Indices of mutated offspring inside `self.population`.

##### Methods

- `mutation()`: Active mutation operator. Bound during validation according to `mutation_type`.
- `random_mutation(offspring)`: Random mutation (replaces or adds a uniform random value).
- `swap_gene_by_space(solution, gene_idx, swapped_genes=None)`: Compatible-swap fallback when a unique replacement cannot be selected from the gene space. Modifies the solution in place and optionally records the swapped positions for the current mutation pass.
- `swap_mutation(offspring)`: Swap mutation.
- `inversion_mutation(offspring)`: Inversion mutation.
- `scramble_mutation(offspring)`: Scramble mutation.
- `adaptive_mutation(offspring)`: Adaptive mutation. Uses `adaptive_mutation_population_fitness`.
- `polynomial_mutation(offspring)`: Polynomial mutation. Uses `self.polynomial_mutation_eta`.
- `mutation_change_gene_dtype_and_round(...)`: Round and re-cast a mutated gene to the configured dtype/precision.

#### Elitism

##### Attributes

- `last_generation_elitism`: Elitism solutions from the last generation. Added in [PyGAD 2.18.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-18-0).
- `last_generation_elitism_indices`: Population indices of `last_generation_elitism`. Added in [PyGAD 2.19.0](https://pygad.readthedocs.io/en/latest/releases.html#pygad-2-19-0).

#### Gene Constraints and Duplicate Resolution

##### Methods

- `validate_gene_constraint_callable_output(selected_values, values)`: Sanity-check the return value of a user-defined `gene_constraint`.
- `filter_gene_values_by_constraint(values, solution, gene_idx)`: Run `gene_constraint[gene_idx]` and return the filtered list.
- `get_valid_gene_constraint_values(...)`: Sample candidate values until one satisfies the gene constraint.
- `solve_duplicate_genes(solution, build_initial_pop=False, ...)`: Shared repair for a solution using each gene's space, range, type, precision, and constraint. Returns the repaired copy, remaining duplicate indices, and their count. Can follow chains of replacements.
- `solve_duplicate_genes_in_population(population, build_initial_pop=False)`: Convert and round population rows before applying the shared repair.
- `get_duplicate_gene_indices(solution)`: Return the indices after the first occurrence of each repeated value.
- `solution_satisfies_gene_constraints(solution)`: Check every constraint against a complete candidate solution.
- `get_gene_space_values(..., all_values=True)`: Return converted candidates for one gene. The default includes complete finite domains for duplicate repair; `all_values=False` samples ranges, stepped dictionaries, and integer intervals without allocating their complete domains.
- `is_gene_value_in_space(...)`: Check a swap candidate against the original finite space or continuous bounds.
- `solve_duplicate_genes_randomly(...)`: Compatibility helper for the shared repair using explicit random ranges.
- `solve_duplicate_genes_by_space(...)`: Compatibility helper for the shared repair using `gene_space`.
- `solve_duplicates_deeply(...)`: Compatibility helper for replacement-chain repair. Returns `None` when no duplicates are resolved.
- `unique_int_gene_from_range(...)`: Pick an integer gene that does not already appear in the solution.
- `unique_float_gene_from_range(...)`: Pick a float gene that does not already appear in the solution.
- `unique_gene_by_space(...)`: Pick a unique value from `gene_space`.
- `unique_genes_by_space(...)`: Pick unique values for several genes from `gene_space`.
- `select_unique_value(...)`: Pick an unused candidate when possible, otherwise keep the current value.
- `find_two_duplicates(solution, gene_space_unpacked)`: Find a duplicated gene with alternative values in its space.
- `unpack_gene_space(...)`: Build an inspection snapshot of `gene_space`, sampling large lazy domains without allocating them in full.
- `get_bounded_operator_gene_range(gene_index)`: Resolve SBX/polynomial bounds from a gene's space or initialization range.
- `convert_bounded_operator_gene_value(gene_index, value)`: Apply the destination type and precision and select an allowed value.
- `prepare_changed_operator_solution(...)`: Validate a complete converted proposal against spaces, constraints, and duplicates.
- `prepare_bounded_operator_solution(...)`: Repair bounded-operator constraints and accept a valid proposal or retain the original solution.

#### Saving, Loading, and Reporting

##### Methods

- `save(filename)`: Pickle the GA instance to disk (uses `cloudpickle`).
- `generate_report(filename, ...)`: Build a PDF report of the run. See [`generate_report()`](#generate-report) below.
- `push_to_vilvik(...)`: Optional convenience wrapper around the Vilvik SDK.

Note that the attributes with names starting with `last_generation_` are updated after each generation.

The next sections discuss the methods available in the `pygad.GA` class.

### `save()`

The `save()` method in the `pygad.GA` class saves the genetic algorithm instance as a pickled object.

Accepts the following parameter:

* `filename`: Name of the file to save the instance. No extension is needed.

The file is written as `filename + ".pkl"` using cloudpickle. Saving during a run excludes live worker handles and the active-run flag through `__getstate__()`. The remaining GA state, including custom attributes, must be serializable. [pygad.load()](pygad.md#pygadload) restores the saved optimization state; the next `run()` creates a new pool when needed. A checkpoint does not contain in-flight worker tasks.

<!-- sphinx
(generate-report)=
-->
### `generate_report()`

Builds a PDF report of the current GA run. It bundles the configuration table, a run-summary table, the best solution, and every applicable plot. Requires the optional `report` extra:

```
pip install pygad[report]
```

Call it after `run()` finishes. A minimal example:

```python
ga_instance.run()
ga_instance.generate_report("my_run")  # writes my_run.pdf next to the script
```

Parameters:

- `filename` (`str`, required): Output path. `.pdf` is appended automatically if missing.
- `title` (`str` or `None`, default `None`): Title shown on the first page. Defaults to `"PyGAD run report"`.
- `sections` (iterable of `str` or `None`, default `None`): Sections to include and their order. Valid entries are `"title"`, `"configuration"`, `"run_summary"`, `"best_solution"`, `"plots"`, and `"notes"`. When `None`, every section is included in their default order.
- `include_plots` (iterable of `str`, `"all"`, or `None`, default `None`): Plots to embed under the `"plots"` section. `None` or `"all"` auto-selects every plot whose preconditions are met by this run. Pass a list of plot method names to include only those.
- `figure_size_inches` (`(float, float)`, default `(7.0, 4.5)`): Width and height (in inches) used when each plot is drawn for the report.
- `notes` (`str` or `None`, default `None`): Free-form text rendered in the optional `"notes"` section.
- `page_size` (`str`, default `"letter"`): Either `"letter"` or `"A4"`.

The report skips any plot whose preconditions are not met. For example, `plot_pareto_front_curve` is included only for multi-objective runs with 2 or 3 objectives; `plot_non_dominated_hypervolume` is included only when `save_solutions=True` is set on the GA.

The title page shows the PyGAD logo. The image ships with the package, so it works without network access. If the image file is missing, the report is built without it.

<!-- python-examples
example_generate_report.py
-->

**Python example**

**[PDF report](../../examples/example_generate_report.py)**

Export the run configuration, summary, best solution, and applicable plots to PDF.

`examples/example_generate_report.py`

<details>
<summary>Run this example</summary>

**Requires:** PyGAD with the report extra (Matplotlib and ReportLab)

From the repository root, with the repository version of PyGAD installed:

```console
python examples/example_generate_report.py
```

</details>

<!-- /python-examples -->

## Functions in `pygad`

Besides the methods available in the `pygad.GA` class, this section discusses the functions available in `pygad`. Up to this time, there is only a single function named `load()`.

<!-- sphinx
(loading-ga-checkpoint)=
-->
### `pygad.load()`

Reads a saved instance of the genetic algorithm. This is not a method but a function that is indented under the `pygad` module. So, it could be called by the pygad module as follows: `pygad.load(filename)`.

Accepts the following parameter:

* `filename`: Name of the file holding the saved instance of the genetic algorithm. No extension is needed.

Returns the genetic algorithm instance.

<!-- sphinx
(updating-loaded-fitness-function)=
-->
#### Updating the Fitness Function after Loading

The checkpoint includes the fitness function assigned when `save()` was called. Editing a function in the script does not automatically replace the function in a loaded GA. Assign the updated callable explicitly:

```python
loaded_ga_instance = pygad.load("saved_ga")
loaded_ga_instance.fitness_func = updated_fitness_func
loaded_ga_instance.run()
```

`updated_fitness_func` must accept the same three fitness arguments and return values compatible with the saved `fitness_batch_size`. For example, adding logging while keeping the fitness formula unchanged allows existing fitness values to be reused. Cached solutions still skip the function; replacing the callable does not force every solution to be reevaluated.

If the new function changes the objective, its data, or the meaning of the fitness values, start a fresh GA using the saved chromosomes as its initial population. This avoids reusing scores calculated for the previous objective:

```python
new_ga_instance = pygad.GA(
    num_generations=20,
    num_parents_mating=5,
    initial_population=loaded_ga_instance.population.copy(),
    fitness_func=new_objective_fitness_func,
)
new_ga_instance.run()
```

Set the constructor options needed by the new problem, including `gene_type`, `gene_space`, constraints, operators, and batch settings. This starts new fitness histories and generation counters; it reuses the chromosomes, not the previous run's fitness values.

<!-- python-examples
example_load_fitness_function.py
-->

**Python example**

**[Change a loaded fitness function](../../examples/example_load_fitness_function.py)**

Replace the fitness callable after loading, or start fresh when the objective changes.

`examples/example_load_fitness_function.py`

<details>
<summary>Run this example</summary>

**Requires:** PyGAD

From the repository root, with the repository version of PyGAD installed:

```console
python examples/example_load_fitness_function.py
```

</details>

<!-- /python-examples -->

## Using PyGAD

<!-- navigation-grid: 1 2 2 2 -->

- [Steps to Use PyGAD](steps_to_use.md) — A step-by-step walkthrough to build and run the genetic algorithm.
- [Life Cycle of PyGAD](lifecycle.md) — How a generation runs and where each callback is called.

<!-- /navigation-grid -->

## Examples

This section gives the complete code of some examples that use `pygad`. Each subsection builds a different example.

<!-- navigation-grid: 1 2 2 2 -->

- [Linear Model - Single Objective](pygad_example_linear.md)
- [Linear Model - Multi-Objective](pygad_example_multi_objective.md)
- [Reproducing Images](pygad_example_reproducing_images.md)

<!-- /navigation-grid -->

### Clustering

For a 2-cluster problem, the code is available [here](https://github.com/ahmedfgad/GeneticAlgorithmPython/blob/master/example_clustering_2.py). For a 3-cluster problem, the code is [here](https://github.com/ahmedfgad/GeneticAlgorithmPython/blob/master/example_clustering_3.py). The 2 examples are using artificial samples.

Soon a tutorial will be published at [Paperspace](https://blog.paperspace.com/author/ahmed) to explain how clustering works using the genetic algorithm with examples in PyGAD.

<!-- python-examples
clustering/example_clustering_2.py
clustering/example_clustering_3.py
-->

**Python examples**

**[2-cluster example](../../examples/clustering/example_clustering_2.py)**

Optimize 2 cluster centers for generated two-dimensional data.

`examples/clustering/example_clustering_2.py`

<details>
<summary>Run this example</summary>

**Requires:** PyGAD, Matplotlib

From the repository root, with the repository version of PyGAD installed:

```console
python examples/clustering/example_clustering_2.py
```

</details>

**[3-cluster example](../../examples/clustering/example_clustering_3.py)**

Optimize 3 cluster centers for generated two-dimensional data.

`examples/clustering/example_clustering_3.py`

<details>
<summary>Run this example</summary>

**Requires:** PyGAD, Matplotlib

From the repository root, with the repository version of PyGAD installed:

```console
python examples/clustering/example_clustering_3.py
```

</details>

<!-- /python-examples -->

### CoinTex Game Playing using PyGAD

The code is available at the [CoinTex GitHub project](https://github.com/ahmedfgad/CoinTex/tree/master/PlayerGA). CoinTex is an Android game written in Python using the Kivy framework. Find CoinTex at [Google Play](https://play.google.com/store/apps/details?id=coin.tex.cointexreactfast): https://play.google.com/store/apps/details?id=coin.tex.cointexreactfast

Check this [Paperspace tutorial](https://blog.paperspace.com/building-agent-for-cointex-using-genetic-algorithm) for how the genetic algorithm plays CoinTex: https://blog.paperspace.com/building-agent-for-cointex-using-genetic-algorithm. Check also this [YouTube video](https://youtu.be/Sp_0RGjaL-0) showing the genetic algorithm while playing CoinTex.

<!-- sphinx
:::{toctree}
:hidden:

steps_to_use
lifecycle
pygad_example_linear
pygad_example_multi_objective
pygad_example_reproducing_images
:::
-->
