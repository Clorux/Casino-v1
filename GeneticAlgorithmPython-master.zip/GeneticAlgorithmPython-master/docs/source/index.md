# PyGAD - Python Genetic Algorithm!

[PyGAD](https://github.com/ahmedfgad/GeneticAlgorithmPython) is an open-source Python library for building the genetic algorithm and optimizing machine learning algorithms. It works with [Keras](https://keras.io) and [PyTorch](https://pytorch.org).

The current release is PyGAD 3.8.1, dated October 11, 2026.
Read the [release notes](releases.md#pygad-381).

Watch the [PyGAD 3.8.0 release video on YouTube](https://youtu.be/8pdIiMAMLUM).

![PYGAD-LOGO](images/101267295-c74c0180-375f-11eb-9ad0-f8e37bd796ce.png)

*Logo designed by [Asmaa Kabil](https://www.linkedin.com/in/asmaa-kabil-9901b7b6)*

> Try [Vilvik](https://vilvik.com), a free cloud-based tool powered by PyGAD. It makes optimization easier by reducing or removing the need for coding, and it shows helpful visualizations.

> Run PyGAD in the cloud with [Vilvik](https://vilvik.com): push your PyGAD problem to Vilvik, let it run in the cloud, and get the results back.

<!-- documentation-figure: 100% -->

![Run PyGAD in the cloud with Vilvik](images/pygad_vilvik_cloud.png)

Push your PyGAD problem to [Vilvik](https://vilvik.com) and run it in the cloud. To get started, follow this tutorial: [Push your PyGAD problem to Vilvik in 10 minutes](https://vilvik.com/blog/@vilvik/pygad-to-vilvik-in-10-minutes).

<!-- /documentation-figure -->

[PyGAD](https://github.com/ahmedfgad/GeneticAlgorithmPython) supports different types of crossover, mutation, and parent selection operators. It lets you optimize many types of problems with the genetic algorithm by writing your own fitness function. It works with both single-objective and multi-objective optimization problems.

Besides building the genetic algorithm, PyGAD builds and optimizes machine learning algorithms. At the moment, [PyGAD](https://pypi.org/project/pygad) supports building and training (using the genetic algorithm) artificial neural networks for classification problems.

The library is under active development, and new features are added often. Please contact us if you want a feature to be supported.

# Donation & Support

You can donate to PyGAD through:

- [Open Collective](https://opencollective.com/pygad): [opencollective.com/pygad](https://opencollective.com/pygad)
- PayPal: Use either this link [paypal.me/ahmedfgad](https://paypal.me/ahmedfgad) or the e-mail address ahmed.f.gad@gmail.com
- Interac e-Transfer: Use the e-mail address ahmed.f.gad@gmail.com
- Buy a product at [Teespring](https://pygad.creator-spring.com/): [pygad.creator-spring.com](https://pygad.creator-spring.com)

# Installation

To install [PyGAD](https://pypi.org/project/pygad), use pip to download and install the library from [PyPI](https://pypi.org/project/pygad) (Python Package Index). The library is available on PyPI at this page: https://pypi.org/project/pygad.

Install PyGAD with the following command:

```
pip3 install pygad
```

# Quick Start

To get started with [PyGAD](https://pypi.org/project/pygad), import it.

```python
import pygad
```

[PyGAD](https://pypi.org/project/pygad) can optimize a wide range of problems. As a quick and simple example, let us find the best set of weights that satisfy the following function:

```
y = f(w1:w6) = w1x1 + w2x2 + w3x3 + w4x4 + w5x5 + w6x6
where (x1,x2,x3,x4,x5,x6)=(4,-2,3.5,5,-11,-4.7) and y=44
```

The first step is to prepare the inputs and the output of this equation.

```python
function_inputs = [4,-2,3.5,5,-11,-4.7]
desired_output = 44
```

The next step is to write the fitness function that calculates a fitness value for each solution. Here is one example.

If the fitness function returns a number, then the problem is single-objective. If it returns a `list`, `tuple`, or `numpy.ndarray`, then it is a multi-objective problem (even if it has a single element).

```python
def fitness_func(ga_instance, solution, solution_idx):
    output = numpy.sum(solution*function_inputs)
    fitness = 1.0 / numpy.abs(output - desired_output)
    return fitness
```

Next, prepare the parameters of [PyGAD](https://pypi.org/project/pygad). Here is an example set of parameters.

```python
fitness_function = fitness_func

num_generations = 50
num_parents_mating = 4

sol_per_pop = 8
num_genes = len(function_inputs)

init_range_low = -2
init_range_high = 5

parent_selection_type = "sss"
keep_parents = 1

crossover_type = "single_point"

mutation_type = "random"
mutation_percent_genes = 10
```

After the parameters are ready, create an instance of the **pygad.GA** class.

```python
ga_instance = pygad.GA(num_generations=num_generations,
                       num_parents_mating=num_parents_mating, 
                       fitness_func=fitness_function,
                       sol_per_pop=sol_per_pop, 
                       num_genes=num_genes,
                       init_range_low=init_range_low,
                       init_range_high=init_range_high,
                       parent_selection_type=parent_selection_type,
                       keep_parents=keep_parents,
                       crossover_type=crossover_type,
                       mutation_type=mutation_type,
                       mutation_percent_genes=mutation_percent_genes)
```

After creating the instance, call the `run()` method to start the optimization.

```python
ga_instance.run()
```

After the `run()` method completes, you can access information about the best solution found by PyGAD.

```python
solution, solution_fitness, solution_idx = ga_instance.best_solution()
print("Parameters of the best solution : {solution}".format(solution=solution))
print("Fitness value of the best solution = {solution_fitness}".format(solution_fitness=solution_fitness))

prediction = numpy.sum(numpy.array(function_inputs)*solution)
print("Predicted output based on the best solution : {prediction}".format(prediction=prediction))
```

```
Parameters of the best solution : [3.92692328 -0.11554946 2.39873381 3.29579039 -0.74091476 1.05468517]
Fitness value of the best solution = 157.37320042925006
Predicted output based on the best solution : 44.00635432206546
```

There is much more you can do with PyGAD. Read the documentation to explore its features.

# PyGAD's Modules

[PyGAD](https://pypi.org/project/pygad) has the following modules:

1. The main module has the same name as the library, `pygad`. It is the main interface to build the genetic algorithm.
2. The `nn` module builds artificial neural networks.
3. The `gann` module optimizes neural networks (for classification and regression) using the genetic algorithm.
4. The `cnn` module builds convolutional neural networks.
5. The `gacnn` module optimizes convolutional neural networks using the genetic algorithm.
6. The `kerasga` module trains [Keras](https://keras.io) models using the genetic algorithm.
7. The `torchga` module trains [PyTorch](https://pytorch.org) models using the genetic algorithm.
8. The `visualize` module visualizes the results.
9. The `utils` module holds the operators (crossover, mutation, and parent selection) and the NSGA-II and NSGA-III code.
10. The `helper` module has some helper functions.

The documentation explains these modules.

# PyGAD Citation - Bibtex Formatted

If you used PyGAD, please consider citing its paper with the following details:

```
@article{gad2023pygad,
  title={Pygad: An intuitive genetic algorithm python library},
  author={Gad, Ahmed Fawzy},
  journal={Multimedia Tools and Applications},
  pages={1--14},
  year={2023},
  publisher={Springer}
}
```

**Genetic Algorithm**

- [`pygad` Module](pygad.md)
- [More About PyGAD](pygad_more.md)
- [Examples](examples.md)

<!-- sphinx
```{toctree}
:hidden:
:maxdepth: 1
:caption: Genetic Algorithm

pygad
pygad_more
examples
```
-->

**Operators & Visualization**

- [`pygad.utils` Module](utils.md)
- [`pygad.visualize` Module](visualize.md)
- [`pygad.helper` Module](helper.md)

<!-- sphinx
```{toctree}
:hidden:
:maxdepth: 1
:caption: Operators & Visualization

utils
visualize
helper
```
-->

**Neural Networks**

- [`pygad.nn` Module](nn.md)
- [`pygad.gann` Module](gann.md)
- [`pygad.cnn` Module](cnn.md)
- [`pygad.gacnn` Module](gacnn.md)

<!-- sphinx
```{toctree}
:hidden:
:maxdepth: 1
:caption: Neural Networks

nn
gann
cnn
gacnn
```
-->

**Keras & PyTorch**

- [`pygad.kerasga` Module](kerasga.md)
- [`pygad.torchga` Module](torchga.md)

<!-- sphinx
```{toctree}
:hidden:
:maxdepth: 1
:caption: Keras & PyTorch

kerasga
torchga
```
-->

**Releases**

- [Release History](releases.md)

<!-- sphinx
```{toctree}
:hidden:
:maxdepth: 1
:caption: Releases

releases
```
-->

**Help & Resources**

- [Help & Resources](help.md)

<!-- sphinx
```{toctree}
:hidden:
:maxdepth: 1
:caption: Help & Resources

help
```
-->
