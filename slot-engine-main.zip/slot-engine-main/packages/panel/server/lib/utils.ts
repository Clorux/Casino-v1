import fs from "fs"
import fsAsync, { glob } from "fs/promises"
import readline from "readline"
import path from "path"
import { Context } from "hono"
import { Variables } from ".."
import {
  parseLookupTable,
  parseLookupTableSegmented,
  Statistics,
  type PayoutStatistics,
  type TagItem,
  type SimulationSummary,
  type SlotGame,
} from "@slot-engine/core"
import { PANEL_GAME_CONFIG_FILE, SYMBOL_COLORS } from "./constants"
import { PanelGameConfig } from "../types"
import chalk from "chalk"
import z from "zod"

export function round(value: number, decimals: number) {
  return Number(value.toFixed(decimals))
}

export function getGameById(gameId: string, c: Context<{ Variables: Variables }>) {
  const games = c.get("config").games
  return games.find((g) => g.getConfig().id === gameId)
}

export function getGameInfo(game: SlotGame) {
  const conf = game.getConfig()
  const meta = game.getMetadata()

  return {
    id: conf.id,
    name: conf.name,
    path: meta.rootDir,
    maxWin: conf.maxWinX,
    isValid: meta.isCustomRoot,
    modes: Object.values(conf.gameModes).map((mode) => ({
      name: mode.name,
      cost: mode.cost,
      rtp: mode.rtp,
    })),
  }
}

export function loadOrCreatePanelGameConfig(game: SlotGame | undefined) {
  if (!game?.getMetadata().isCustomRoot) return

  const filePath = path.join(game.getMetadata().rootDir, PANEL_GAME_CONFIG_FILE)
  const exists = fs.existsSync(filePath)
  let isFileBroken = false

  if (exists) {
    const config = JSON.parse(
      fs.readFileSync(filePath, {
        encoding: "utf-8",
      }),
    ) as Partial<PanelGameConfig>

    const propsToCheck = [
      config.id,
      config.simulation,
      config.simulation?.concurrency,
      config.simulation?.maxPendingSims,
      config.simulation?.maxDiskBuffer,
      config.simulation?.simRunsAmount,
      config.forceStop,
      config.betSimulations,
      config.reelSets,
    ]

    isFileBroken = propsToCheck.some((p) => p === undefined)

    if (!isFileBroken) {
      return config as PanelGameConfig
    }
  }

  // File does not exist or is broken, create a new one
  const defaultConfig: PanelGameConfig = {
    id: game.getConfig().id,
    simulation: {
      simRunsAmount: {},
      concurrency: 8,
      maxPendingSims: 25,
      maxDiskBuffer: 150,
      makeUncompressedBooks: false,
    },
    betSimulations: [],
    reelSets: [],
    forceStop: false,
  }

  fs.writeFileSync(filePath, JSON.stringify(defaultConfig, null, 2), "utf-8")

  if (isFileBroken) {
    console.warn(
      chalk.yellow(
        `Panel game config file for game "${game.getConfig().name}" was broken or outdated. It was reset to default values.`,
      ),
    )
  }

  if (!exists) {
    console.log(
      chalk.gray(
        `Created new panel game config file for game "${game.getConfig().name}".`,
      ),
    )
  }

  return defaultConfig
}

export function savePanelGameConfig(game: SlotGame, config: PanelGameConfig) {
  const filePath = path.join(game.getMetadata().rootDir, PANEL_GAME_CONFIG_FILE)
  fs.writeFileSync(filePath, JSON.stringify(config, null, 2), "utf-8")
  return config
}

export function loadSummaryFile(game: SlotGame) {
  const meta = game.getMetadata()
  const filePath = meta.paths.simulationSummary
  if (!fs.existsSync(filePath)) return

  const data = JSON.parse(
    fs.readFileSync(filePath, {
      encoding: "utf-8",
    }),
  ) as SimulationSummary

  return data
}

export function loadStatsSummaryFile(game: SlotGame) {
  const meta = game.getMetadata()
  const filePath = meta.paths.statsSummary
  if (!fs.existsSync(filePath)) return

  const data = JSON.parse(
    fs.readFileSync(filePath, {
      encoding: "utf-8",
    }),
  ) as Statistics[]

  return data
}

const rangeValuesSchema = z.record(z.string(), z.number())

const payoutRangeBreakdownSchema = z.object({
  overall: rangeValuesSchema,
  criteria: z.record(z.string(), rangeValuesSchema),
})

const payoutStatisticsSchema = z.array(
  z.object({
    gameMode: z.string(),
    allPayouts: payoutRangeBreakdownSchema,
    uniquePayouts: payoutRangeBreakdownSchema,
    payoutChances: payoutRangeBreakdownSchema,
  }),
) satisfies z.ZodType<PayoutStatistics[]>

export function loadStatsPayoutsFile(game: SlotGame): PayoutStatistics[] | undefined {
  const meta = game.getMetadata()
  const filePath = meta.paths.statsPayouts
  if (!fs.existsSync(filePath)) return

  const parsed = payoutStatisticsSchema.safeParse(
    JSON.parse(
      fs.readFileSync(filePath, {
        encoding: "utf-8",
      }),
    ),
  )

  if (!parsed.success) return

  return parsed.data
}

export async function exploreLookupTable(opts: {
  game: SlotGame
  mode: string
  cursor?: string
  take: number
  filter?: string | qs.ParsedQs | (string | qs.ParsedQs)[]
  payoutRange: { min: number; max: number }
}) {
  const { game, mode, cursor, take, filter, payoutRange } = opts
  const offset = parseInt(cursor || "0", 10)
  const meta = game.getMetadata()

  const lutPath = meta.paths.lookupTablePublish(mode)
  const lutSegmentedPath = meta.paths.lookupTableSegmented(mode)

  if (!fs.existsSync(lutPath) || !fs.existsSync(lutSegmentedPath)) return

  const indexPath = meta.paths.lookupTableIndex(mode)
  const indexSegmentedPath = meta.paths.lookupTableSegmentedIndex(mode)

  const bookIds = await filterByTags({
    game,
    mode,
    filter: filter as Record<string, string> | undefined,
  })

  const { rows, nextCursor } = await readLutRows({
    path: lutPath,
    indexPath,
    offset,
    take,
    bookIds,
    payoutRange,
  })
  const segmented = await readLutRows({
    path: lutSegmentedPath,
    indexPath: indexSegmentedPath,
    offset,
    take,
    bookIds,
    payoutRange,
  })

  return {
    lut: parseLookupTable(rows.join("\n")),
    lutSegmented: parseLookupTableSegmented(segmented.rows.join("\n")),
    nextCursor,
  }
}

async function getByteOffsetFromIndex(indexPath: string, row: number) {
  if (!fs.existsSync(indexPath)) return

  const indexFile = await fsAsync.open(indexPath, "r")
  const buffer = Buffer.alloc(8)
  await indexFile.read(buffer, 0, 8, row * 8)
  await indexFile.close()

  return Number(buffer.readBigUInt64LE())
}

export async function readLutRows(opts: {
  path: string
  indexPath: string
  offset: number
  take: number
  bookIds?: number[]
  payoutRange?: { min: number; max: number }
}) {
  const { path: filePath, indexPath, offset, take, bookIds, payoutRange } = opts

  const hasBookIds = opts.bookIds && opts.bookIds.length > 0
  const isSegmented = filePath.includes("segmented") || filePath.includes("Segmented")
  const hasFilters = hasBookIds || payoutRange

  const byteOffset = await getByteOffsetFromIndex(indexPath, offset)
  const stream = fs.createReadStream(filePath, { start: byteOffset })
  const rl = readline.createInterface({
    input: stream,
    crlfDelay: Infinity,
  })

  const rows = []
  let rowsScanned = 0
  let nextCursor: number | null = null

  for await (const line of rl) {
    if (hasFilters) {
      rowsScanned++
      const cols = line.split(",")

      if (hasBookIds) {
        const id = Number(cols[0])
        if (!bookIds!.includes(id)) continue
      }

      if (payoutRange) {
        const payout = isSegmented
          ? Number(cols[2]) + Number(cols[3]) // LUT segmented values are stored as decimals
          : Number(cols[2]) / 100 // LUT values are stored as integers (payout * 100)
        if (payout < payoutRange.min || payout > payoutRange.max) continue
      }

      rows.push(line)
      if (rows.length >= take) {
        nextCursor = offset + rowsScanned
        break
      }
    } else {
      // No filters
      rows.push(line)
      if (rows.length > take) {
        nextCursor = offset + rows.length - 1 // -1 because we pop the last result
        rows.pop()
        break
      }
    }
  }

  stream.destroy()

  return {
    rows,
    nextCursor,
  }
}

export function getTagKeys(opts: { game: SlotGame; mode: string }) {
  const { game, mode } = opts
  const tagKeysPath = game.getMetadata().paths.tagKeys(mode)
  if (!fs.existsSync(tagKeysPath)) return

  const data = JSON.parse(
    fs.readFileSync(tagKeysPath, {
      encoding: "utf-8",
    }),
  ) as Record<string, string[]>

  return data
}

async function filterByTags(opts: {
  game: SlotGame
  mode: string
  filter: Record<string, string> | undefined
}) {
  const { game, mode, filter } = opts

  if (!filter || Object.keys(filter).length === 0) return []

  const tagsFile = game.getMetadata().paths.tags(mode)
  if (!fs.existsSync(tagsFile)) return []

  const stream = fs.createReadStream(tagsFile)
  const rl = readline.createInterface({
    input: stream,
    crlfDelay: Infinity,
  })

  const bookIds = new Set<number>()

  // Every unique tag fits in one line, so we can just scan the file line by line.
  for await (const l of rl) {
    // Skip empty or invalid lines, e.g. first and last lines which contain only brackets for opening/closing the array
    if (l.trim() === "" || l.length < 5) continue

    try {
      const line = l.trim().replace(/,$/, "") // Remove trailing comma if present
      const tag = JSON.parse(line) as TagItem
      let matches = true

      for (const [key, value] of Object.entries(filter)) {
        if (!tag.search.find((s) => s.name === key && s.value === value)) {
          matches = false
          break
        }
      }

      if (matches) {
        tag.bookIds.forEach((id) => bookIds.add(id))
      }
    } catch (error) {
      console.log("Error parsing tag line:", error)
      continue
    }
  }

  stream.destroy()

  return Array.from(bookIds)
}

export async function getReelSets(game: SlotGame) {
  const buildPath = game.getMetadata().rootDir
  const reelSetPaths: string[] = []
  for await (const p of glob(`${buildPath}/**/reels_*.csv`)) {
    reelSetPaths.push(p)
  }

  const reelSets = reelSetPaths.map((p) => {
    const filename = path.basename(p)
    return {
      path: p,
      name: filename,
    }
  })

  return reelSets
}

export function writeReelSet(path: string, reels: string[][]) {
  const maxLength = Math.max(...reels.map((reel) => reel.length))

  const rows: string[] = []
  for (let s = 0; s < maxLength; s++) {
    const row: string[] = []
    for (let r = 0; r < reels.length; r++) {
      row.push(reels[r]![s] ?? "")
    }
    rows.push(row.join(","))
  }

  const csvContent = rows.join("\n")
  fs.writeFileSync(path, csvContent, "utf-8")
}

export function assignColorsToSymbols(game: SlotGame) {
  const symbols = game.getConfig().symbols
  const symbolColors: Record<string, string> = {}
  const colors = Object.values(SYMBOL_COLORS)
  let colorIndex = 0

  for (const symbol of symbols.values()) {
    symbolColors[symbol.id] = colors[colorIndex]!
    colorIndex++
    if (colorIndex >= colors.length) {
      colorIndex = 0
    }
  }

  return symbolColors
}
