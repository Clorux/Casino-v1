import {
  type APIGamesResponse,
  type APIStatusResponse,
  type APIGameResponse,
  type APIGameInfoResponse,
  type APIGameGetSimConfResponse,
  type PanelGameConfig,
  type APIGameSimSummaryResponse,
  type APIGameExploreResponse,
  type APIGameExploreBookResponse,
  type APIGameTagKeysResponse,
  type APIGameGetBetSimConfResponse,
  type APIGamePostBetSimConfResponse,
  type APIGamePostSimConfResponse,
  type BetSimulationConfig,
  type APIGamePostBetSimRunResponse,
  type APIGameStatsSummaryResponse,
  type APIGameStatsPayoutsResponse,
  type APIGameReelSetsResponse,
  type APIGameGetReelSetResponse,
  type APIMessageResponse,
} from "../../../server/types"
import type { SimulationOptions } from "./types"

export class FetchError extends Error {
  code: number
  type: string

  constructor(code: number, message: string, type: string = "FetchError") {
    super(message)
    this.code = code
    this.type = type
  }
}

export async function api<TData>(endpoint: string, opts?: RequestInit) {
  const res = await fetch(`/api/${endpoint}`, opts)

  if (!res.ok) {
    throw new FetchError(res.status, res.statusText)
  }

  return res.json() as Promise<TData>
}

export const query = {
  status: () => api<APIStatusResponse>("status"),
  games: () => api<APIGamesResponse>("games"),
  game: (id: string) => api<APIGameResponse>(`games/${id}`),
  gameInfo: (id: string) => api<APIGameInfoResponse>(`games/${id}/info`),
  gameSimConf: (id: string) => api<APIGameGetSimConfResponse>(`games/${id}/sim-conf`),
  gameBetSimConf: (id: string) =>
    api<APIGameGetBetSimConfResponse>(`games/${id}/bet-sim-conf`),
  gameSimSummary: (id: string) =>
    api<APIGameSimSummaryResponse>(`games/${id}/sim-summary`),
  gameExplore: (opts: {
    gameId: string
    mode: string
    cursor: number | null
    filter?: Array<{ name: string; value: string }>
    payoutRange?: { min: number; max: number }
  }) => {
    const { gameId, cursor, mode, filter, payoutRange } = opts
    const params = new URLSearchParams()

    if (cursor) {
      params.append("cursor", cursor.toString())
    }

    if (payoutRange) {
      params.append("pMin", payoutRange.min.toString())
      params.append("pMax", payoutRange.max.toString())
    }

    if (filter) {
      filter.forEach(({ name, value }) => {
        params.append(`filter[${name}]`, value)
      })
    }

    return api<APIGameExploreResponse>(
      `games/${gameId}/explore/${mode}?${params.toString()}`,
    )
  },
  gameExploreBook: (id: string, mode: string, bookId: number) =>
    api<APIGameExploreBookResponse>(`games/${id}/explore/${mode}/${bookId}`),
  gameTagKeys: (id: string, mode: string) =>
    api<APIGameTagKeysResponse>(`games/${id}/tag-keys/${mode}`),
  gameStatsSummary: (id: string) =>
    api<APIGameStatsSummaryResponse>(`games/${id}/stats-summary`),
  gameStatsPayouts: (id: string) =>
    api<APIGameStatsPayoutsResponse>(`games/${id}/stats-payouts`),
  gameReelSets: (id: string) => api<APIGameReelSetsResponse>(`games/${id}/reel-sets`),
  gameReelSet: (id: string, reelSetName: string) =>
    api<APIGameGetReelSetResponse>(`games/${id}/reel-sets/${reelSetName}`),
}

export const mutation = {
  gameSimConf: (id: string, data: PanelGameConfig["simulation"]) =>
    api<APIGamePostSimConfResponse>(`games/${id}/sim-conf`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    }),
  gameBetSimConf: (id: string, data: BetSimulationConfig[]) =>
    api<APIGamePostBetSimConfResponse>(`games/${id}/bet-sim-conf`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    }),
  startSimulation: (gameId: string, opts: SimulationOptions) =>
    api<void>(`games/${gameId}/sim-run`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(opts),
    }),
  stopSimulation: (gameId: string) =>
    api<void>(`games/${gameId}/sim-stop`, {
      method: "POST",
    }),
  startBetSimulation: (gameId: string, config: BetSimulationConfig) =>
    api<APIGamePostBetSimRunResponse>(
      `games/${gameId}/bet-sim-run?configId=${config.id}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(config),
      },
    ),
  saveReelSet: (
    gameId: string,
    reelSetName: string,
    data: { reels: string[][]; colors: Record<string, string> },
  ) =>
    api<APIMessageResponse>(`games/${gameId}/reel-sets/${reelSetName}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    }),
}

export type APIResponse<T> = T extends keyof typeof query
  ? Awaited<ReturnType<(typeof query)[T]>>
  : never
