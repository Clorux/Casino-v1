import {
  IconAlertCircle,
  IconBusinessplan,
  IconInfoCircle,
  IconLoader2,
  IconMoodPuzzled,
  IconPlayerPlay,
  IconPlus,
  IconReport,
  IconReportAnalytics,
  IconReportMoney,
  IconSettings,
  IconTrash,
  IconUsers,
} from "@tabler/icons-react"
import { useGameContext } from "../../context/GameContext"
import { useEffect, useRef, useState } from "react"
import { Button } from "../Button"
import { NumberInput } from "../NumberInput"
import { mutation, query } from "../../lib/queries"
import { useMutation, useQuery } from "@tanstack/react-query"
import { ErrorDisplay } from "../Error"
import { Skeleton } from "../Skeleton"
import type { BetSimulationConfig, BetSimulationStats } from "../../../../server/types"
import { Select, SelectContent, SelectItem, SelectTrigger } from "../Select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../Tabs"
import { SimulationLoading } from "../Loading"
import { Statistics } from "../Statistics"

const DEFAULT_CONFIG: BetSimulationConfig = {
  id: "",
  players: {
    count: 100,
    startingBalance: 1000,
  },
  betGroups: [],
}

function makeDefaultConfig(): BetSimulationConfig {
  return {
    ...DEFAULT_CONFIG,
    id: crypto.randomUUID().split("-")[0],
  }
}

function makeDefaultBetGroup(mode: string) {
  return {
    id: crypto.randomUUID().split("-")[0],
    mode,
    betAmount: 1,
    spins: 500,
  }
}

export const GameBetSimulation = () => {
  const { gameId, game } = useGameContext()

  const { data, isFetching, error, dataUpdatedAt } = useQuery({
    queryKey: ["game", "bet-sim-conf", gameId],
    queryFn: async () => {
      return await query.gameBetSimConf(gameId)
    },
    refetchOnWindowFocus: false,
  })

  const updateConfMutation = useMutation({
    mutationKey: ["game", "bet-sim-conf", gameId],
    mutationFn: async (data: BetSimulationConfig[]) => {
      return await mutation.gameBetSimConf(gameId, data)
    },
  })

  const [betConfigs, setBetConfigs] = useState<BetSimulationConfig[]>([])
  const lastDataTimestamp = useRef<number | null>(null)
  const isUserChange = useRef(false)

  useEffect(() => {
    if (!data) return
    if (lastDataTimestamp.current === dataUpdatedAt) return

    setBetConfigs(data.configs)
    lastDataTimestamp.current = dataUpdatedAt
  }, [data, dataUpdatedAt])

  useEffect(() => {
    if (!isUserChange.current) return
    if (!data) return

    updateConfMutation.mutate(betConfigs)
    isUserChange.current = false
  }, [betConfigs, data])

  useEffect(() => {
    lastDataTimestamp.current = null
    isUserChange.current = false
  }, [gameId])

  if (error) return <ErrorDisplay error={error} />

  if (!data || isFetching) {
    return (
      <div>
        <Skeleton className="h-64 rounded-2xl" />
        <Skeleton className="h-64 mt-4 rounded-2xl" />
        <Skeleton className="h-64 mt-4 rounded-2xl" />
      </div>
    )
  }

  function addBetSimConfig() {
    isUserChange.current = true
    setBetConfigs((prev) => [...prev, makeDefaultConfig()])
  }

  function onConfigChange(config: BetSimulationConfig) {
    isUserChange.current = true
    setBetConfigs((prev) => prev.map((c) => (c.id === config.id ? config : c)))
  }

  function removeSimulation(id: string) {
    isUserChange.current = true
    setBetConfigs((prev) => prev.filter((c) => c.id !== id))
  }

  return (
    <div>
      {betConfigs.length > 0 ? (
        betConfigs.map((config, index) => (
          <BetSimulation
            config={config}
            onValueChange={onConfigChange}
            removeSimulation={removeSimulation}
            key={index}
            isSaving={updateConfMutation.isPending}
          />
        ))
      ) : (
        <div className="p-8 rounded-2xl bg-ui-900 shadow-card flex flex-col items-center text-center">
          <h4>No simulation configured</h4>
          <p className="mt-1 mb-4 text-ui-500">
            See how your game might perform with your current results
          </p>
          <Button onClick={() => addBetSimConfig()}>
            <IconSettings size={20} stroke={1.5} aria-hidden />
            Configure
          </Button>
        </div>
      )}
      {betConfigs.length > 0 && (
        <Button variant="secondary" onClick={() => addBetSimConfig()}>
          <IconPlus size={20} stroke={1.5} aria-hidden />
          Add another Simulation
        </Button>
      )}
    </div>
  )
}

interface BetSimulationProps {
  config: BetSimulationConfig
  onValueChange: (config: BetSimulationConfig) => void
  removeSimulation: (id: string) => void
  isSaving: boolean
}

const BetSimulation = ({
  config,
  onValueChange,
  removeSimulation,
  isSaving,
}: BetSimulationProps) => {
  const { game, gameId } = useGameContext()
  const avgRtps =
    game.modes.map((m) => m.rtp).reduce((a, b) => a + b, 0) / game.modes.length

  const [tab, setTab] = useState("config")

  function updatePlayerCount(count: number | null) {
    const newConfig = {
      ...config,
      players: { ...config.players, count: count ?? config.players.count },
    }
    onValueChange(newConfig)
  }

  function updateStartingBalance(balance: number | null) {
    const newConfig = {
      ...config,
      players: {
        ...config.players,
        startingBalance: balance ?? config.players.startingBalance,
      },
    }
    onValueChange(newConfig)
  }

  function addBetGroup() {
    const newConfig = {
      ...config,
      betGroups: [...config.betGroups, makeDefaultBetGroup(game.modes[0]?.name || "")],
    }
    onValueChange(newConfig)
  }

  function changeGroupMode(id: string, mode: string) {
    const newConfig = {
      ...config,
      betGroups: config.betGroups.map((bg) => (bg.id === id ? { ...bg, mode } : bg)),
    }
    onValueChange(newConfig)
  }

  function updateGroupSpins(id: string, spins: number | null) {
    const newConfig = {
      ...config,
      betGroups: config.betGroups.map((bg) =>
        bg.id === id ? { ...bg, spins: spins ?? bg.spins } : bg,
      ),
    }
    onValueChange(newConfig)
  }

  function updateGroupBetAmnt(id: string, betAmount: number | null) {
    const newConfig = {
      ...config,
      betGroups: config.betGroups.map((bg) =>
        bg.id === id ? { ...bg, betAmount: betAmount ?? bg.betAmount } : bg,
      ),
    }
    onValueChange(newConfig)
  }

  function removeBetGroup(id: string) {
    const newConfig = {
      ...config,
      betGroups: config.betGroups.filter((bg) => bg.id !== id),
    }
    onValueChange(newConfig)
  }

  const betGroupModes = game.modes.map((m) => ({
    label: `${m.name} (Cost: ${m.cost}x)`,
    value: m.name,
  }))

  function getModeRtp(modeName: string) {
    const mode = game.modes.find((m) => m.name === modeName)
    return mode ? mode.rtp * 100 : 0
  }

  function getModeCost(modeName: string) {
    const mode = game.modes.find((m) => m.name === modeName)
    return mode ? mode.cost : 1
  }

  const [results, setResults] = useState<BetSimulationStats | null>(null)

  const simulationMutation = useMutation({
    mutationKey: ["game", "bet-simulation", gameId, config.id],
    mutationFn: async () => {
      return await mutation.startBetSimulation(gameId, config)
    },
    onSuccess(data, _, __, context) {
      setTab("results")
      setResults(data.results)
    },
  })

  const frmt = new Intl.NumberFormat().format

  const canNotSimulate =
    config.betGroups.length === 0 || isSaving || simulationMutation.isPending

  const isBusy = isSaving || simulationMutation.isPending

  return (
    <div className="mb-4 p-4 rounded-2xl bg-ui-900 shadow-card">
      <Tabs value={tab} onValueChange={setTab}>
        <div className="flex items-center gap-2">
          <TabsList>
            <TabsTrigger value="config">
              <IconSettings size={20} stroke={1.5} aria-hidden />
              Configuration
            </TabsTrigger>
            <TabsTrigger value="results">
              <IconReportAnalytics size={20} stroke={1.5} aria-hidden />
              Results
            </TabsTrigger>
          </TabsList>
          <Button
            className="ml-auto"
            disabled={canNotSimulate}
            onClick={() => simulationMutation.mutate()}
          >
            {isBusy ? (
              <IconLoader2 size={20} stroke={1.5} className="animate-spin" aria-hidden />
            ) : (
              <IconPlayerPlay size={20} stroke={1.5} aria-hidden />
            )}
            Start Simulation
          </Button>
          <Button variant="ghost-destructive" onClick={() => removeSimulation(config.id)}>
            <IconTrash size={20} stroke={1.5} aria-hidden />
            Remove Simulation
          </Button>
        </div>
        <TabsContent value="config" className="relative pt-6">
          {simulationMutation.isPending && (
            <div className="absolute z-1 inset-0 rounded-xl bg-ui-900/75 backdrop-blur-sm flex items-center justify-center">
              <SimulationLoading isLoading={true} />
            </div>
          )}

          <h4 className="flex items-center gap-2">
            <IconUsers size={20} stroke={1.5} className="text-ui-500" aria-hidden />
            Virtual Players
          </h4>
          <div className="flex gap-4 mt-3 mb-8">
            <NumberInput
              label="Player Count"
              step={1}
              min={1}
              max={2000}
              inputMode="numeric"
              className="w-full"
              value={config.players.count}
              onValueChange={(v) => updatePlayerCount(v)}
            />
            <NumberInput
              label="Starting Balance"
              step={50}
              min={1}
              max={20_000}
              inputMode="numeric"
              className="w-full"
              value={config.players.startingBalance}
              onValueChange={(v) => updateStartingBalance(v)}
            />
          </div>
          <div className="flex items-center gap-4">
            <h4 className="flex items-center gap-2">
              <IconBusinessplan
                size={20}
                stroke={1.5}
                className="text-ui-500"
                aria-hidden
              />
              Bet Groups <span className="tabular">({config.betGroups.length})</span>
            </h4>
            <Button variant="secondary" size="sm" onClick={addBetGroup}>
              <IconPlus size={20} stroke={1.5} aria-hidden />
              Add Bet Group
            </Button>
          </div>
          <p className="mt-1 mb-4 text-ui-500">
            Bet groups are played sequentially for each player, reflecting a virtual
            betting session.
          </p>
          <div className="grid grid-cols-2 gap-4 max-h-96 pr-2 scrollbar-thin overflow-y-auto">
            {config.betGroups.map((bg, index) => (
              <div key={index} className="p-4 rounded-xl bg-ui-950 flex flex-col gap-4">
                <Select
                  label="Mode"
                  value={bg.mode}
                  multiple={false}
                  onValueChange={(v) => changeGroupMode(bg.id, v || "")}
                  items={betGroupModes}
                >
                  <SelectTrigger className="w-full" />
                  <SelectContent>
                    {betGroupModes.map((m) => (
                      <SelectItem key={m.value} value={m.value}>
                        {m.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex gap-4">
                  <NumberInput
                    label="Number of Bets"
                    step={10}
                    min={1}
                    max={5000}
                    inputMode="numeric"
                    className="w-full"
                    value={bg.spins}
                    onValueChange={(v) => updateGroupSpins(bg.id, v)}
                  />
                  <NumberInput
                    label="Bet"
                    step={0.1}
                    min={0.1}
                    max={1000}
                    inputMode="decimal"
                    className="w-full"
                    value={bg.betAmount}
                    onValueChange={(v) => updateGroupBetAmnt(bg.id, v)}
                  />
                </div>
                <div>
                  <div className="mb-2 text-ui-100">Estimated Balance Loss:</div>
                  <dl className="tabular">
                    <div className="flex justify-between gap-4 py-1">
                      <dt className="text-ui-500">0% RTP:</dt>
                      <dd>{frmt(bg.betAmount * bg.spins * getModeCost(bg.mode))}</dd>
                    </div>
                    <div className="flex justify-between gap-4 py-1">
                      <dt className="text-ui-500">50% RTP:</dt>
                      <dd>
                        {frmt((bg.betAmount * bg.spins * getModeCost(bg.mode)) / 2)}
                      </dd>
                    </div>
                    <div className="flex justify-between gap-4 py-1">
                      <dt className="text-ui-500">{getModeRtp(bg.mode)}% RTP:</dt>
                      <dd>
                        {frmt(
                          (bg.betAmount *
                            bg.spins *
                            getModeCost(bg.mode) *
                            (100 - getModeRtp(bg.mode))) /
                            100,
                        )}
                      </dd>
                    </div>
                  </dl>
                </div>
                <div className="-mb-2 pt-2 flex gap-4 justify-between items-center border-t border-ui-700">
                  <div className="min-w-0 truncate text-xs text-ui-500" title={bg.id}>
                    {bg.id}
                  </div>
                  <Button
                    variant="ghost-destructive"
                    isIconButton
                    aria-label="Remove bet group"
                    onClick={() => removeBetGroup(bg.id)}
                  >
                    <IconTrash size={20} stroke={1.5} aria-hidden />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="results" className="relative pt-6">
          {simulationMutation.isPending && (
            <div className="absolute z-1 inset-0 rounded-xl bg-ui-900/75 backdrop-blur-sm flex items-center justify-center">
              <SimulationLoading isLoading={true} />
            </div>
          )}

          {!results && (
            <div className="py-8 flex flex-col justify-center items-center text-center">
              <div className="size-14 mb-4 flex items-center justify-center rounded-xl bg-ui-800">
                <IconMoodPuzzled size={32} stroke={1.5} aria-hidden />
              </div>
              <h4>No Results available</h4>
              <p className="mt-1 text-ui-500">Start the simulation to see results</p>
            </div>
          )}
          {results && (
            <div className="max-h-124 overflow-y-auto scrollbar-thin pr-2">
              {results.warnings.map((w, i) => (
                <div
                  key={i}
                  className="px-3 py-2 rounded-xl bg-warning-950 mb-4 flex gap-2"
                >
                  <IconAlertCircle
                    size={20}
                    stroke={1.5}
                    className="shrink-0 text-warning-500"
                    aria-hidden
                  />
                  {w}
                </div>
              ))}

              <h4 className="flex items-center gap-2 mb-3">
                <IconReportAnalytics
                  size={20}
                  stroke={1.5}
                  className="text-ui-500"
                  aria-hidden
                />
                Bet Results
              </h4>
              <div className="grid grid-cols-3 gap-2">
                <Statistics label="Total Bets" value={frmt(results.totalBets)} />
                <Statistics label="Average Bets" value={frmt(results.avgBets)} />
                <Statistics label="Median Bets" value={frmt(results.medianBets)} />
              </div>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <Statistics label="P20 Bets" value={frmt(results.low20PercentileBets)} />
                <Statistics label="P80 Bets" value={frmt(results.high20PercentileBets)} />
              </div>

              <h4 className="flex items-center gap-2 mt-8 mb-3">
                <IconReportMoney
                  size={20}
                  stroke={1.5}
                  className="text-ui-500"
                  aria-hidden
                />
                Profit Results
              </h4>
              <div className="grid grid-cols-2 gap-2">
                <Statistics label="Total Wager" value={frmt(results.totalWager)} />
                <Statistics
                  label="Total Profit"
                  value={frmt(results.totalProfit)}
                  description="Should be negative. This (positive) amount would go to the casino"
                  isSuccess={results.totalProfit < 0}
                  successText={`${frmt(Math.abs(results.totalProfit))} goes to the casino`}
                  isDanger={results.totalProfit > 0}
                  dangerText={`${frmt(results.totalProfit)} profit for players!`}
                  isWarning={!results.totalProfit}
                  warningText="An error occurred, try again"
                />
                <Statistics label="Num Bets Profit" value={frmt(results.numBetsProfit)} />
                <Statistics label="Num Bets Loss" value={frmt(results.numBetsLoss)} />
              </div>
              <div className="grid grid-cols-4 gap-2 mt-2">
                <Statistics
                  label="Average Profit"
                  value={frmt(results.avgProfit)}
                  isSuccess={results.totalProfit < 0}
                  successText="Avg. amount per player goes to the casino"
                  isDanger={results.totalProfit > 0}
                  dangerText="Avg. amount per player is profit!"
                />
                <Statistics label="Median Profit" value={frmt(results.medianProfit)} />
                <Statistics
                  label="Min Profit"
                  value={frmt(results.minProfit)}
                  description="Of player at end of simulations"
                />
                <Statistics
                  label="Max Profit"
                  value={frmt(results.maxProfit)}
                  description="Of player at end of simulations"
                />
              </div>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <Statistics
                  label="P20 Profit"
                  value={frmt(results.low20PercentileProfit)}
                />
                <Statistics
                  label="P80 Profit"
                  value={frmt(results.high20PercentileProfit)}
                />
                <Statistics
                  label="Standard Deviation"
                  value={frmt(results.payoutStdDev)}
                  description="This value might vary strongly. It's best to run multiple simulations to get a better idea of this value"
                />
              </div>

              <h4 className="flex items-center gap-2 mt-8 mb-3">
                <IconReportMoney
                  size={20}
                  stroke={1.5}
                  className="text-ui-500"
                  aria-hidden
                />
                Miscellaneous
              </h4>
              <div className="grid grid-cols-3 gap-2">
                <Statistics
                  label="Longest Win Streak"
                  value={frmt(results.longestWinStreak)}
                />
                <Statistics
                  label="Longest Lose Streak"
                  value={frmt(results.longestLoseStreak)}
                  isWarning={results.longestLoseStreak >= 50}
                  warningText="Value is quite high"
                />
                <Statistics
                  label="Longest 0-Win Streak"
                  value={frmt(results.longest0Streak)}
                  isWarning={results.longest0Streak >= 25}
                  warningText="Value is quite high"
                />
                <Statistics
                  label="Nice Wins"
                  value={frmt(results.hits15)}
                  description=">= 15x, < 40x"
                />
                <Statistics
                  label="Mega Wins"
                  value={frmt(results.hits40)}
                  description=">= 40x, < 90x"
                />
                <Statistics
                  label="Sensational Wins"
                  value={frmt(results.hits90)}
                  description=">= 90x"
                />
              </div>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <Statistics
                  label="Highest Balance"
                  value={frmt(results.highestBalance)}
                  description="Of player at end of simulations"
                />
                <Statistics
                  label="Lowest Balance"
                  value={frmt(results.lowestBalance)}
                  description="Of player at end of simulations"
                />
              </div>

              <h4 className="flex items-center gap-2 mt-8 mb-3">
                <IconReport size={20} stroke={1.5} className="text-ui-500" aria-hidden />
                RTP Results
              </h4>
              <div className="grid grid-cols-2 gap-2">
                <Statistics
                  label="Average RTP"
                  value={frmt(results.avgRtp)}
                  description="Might be inaccurate for smaller simulations"
                  isWarning={Math.abs(results.avgRtp - avgRtps) >= 7}
                  warningText="RTP deviates significantly"
                  isSuccess={Math.abs(results.avgRtp - avgRtps) < 7}
                  successText="RTP is within expected range"
                />
                <Statistics
                  label="Median RTP"
                  value={frmt(results.medianRtp)}
                  description="Might be inaccurate for smaller simulations"
                  isWarning={Math.abs(results.avgRtp - avgRtps) >= 7}
                  warningText="RTP deviates significantly"
                  isSuccess={Math.abs(results.avgRtp - avgRtps) < 7}
                  successText="RTP is within expected range"
                />
                <Statistics label="Highest RTP" value={frmt(results.highestRtp)} />
                <Statistics label="Lowest RTP" value={frmt(results.lowestRtp)} />
              </div>

              <h4 className="flex items-center gap-2 mt-8 mb-3">
                <IconReport size={20} stroke={1.5} className="text-ui-500" aria-hidden />
                ResultSet Criteria
              </h4>
              <div>
                {Object.entries(results.visualization.criteriaPerGroup).map(
                  ([groupId, criteria]) => (
                    <div key={groupId} className="mt-4">
                      <h6 className="mb-2">
                        Group <span translate="no">{groupId}</span>
                      </h6>
                      <div className="grid grid-cols-4 gap-2">
                        {Object.entries(criteria).map(([crit, count]) => (
                          <Statistics key={crit} label={crit} value={frmt(count)} />
                        ))}
                      </div>
                    </div>
                  ),
                )}
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  )
}
