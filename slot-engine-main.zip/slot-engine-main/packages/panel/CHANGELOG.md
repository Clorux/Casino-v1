# @slot-engine/panel

## 0.3.0

### Minor Changes

- Compatibility with `@slot-engine/lgs` - Thanks @nordowl

- Complete UI redesign - Thanks @nordowl

- Add a "Play Game" tab to launch your game connected to the Slot Engine LGS - Thanks @nordowl

- Add a replay mode to the Play Game tab - Thanks @nordowl

### Patch Changes

- Reelset designer: add option to duplicate a reel - Thanks @nordowl

- Explorer: "Jump to Book ID" jumps to 0-based book IDs - Thanks @nordowl

- Add payout chances (chance of hitting a payout range during play). Visible in Panel or in `stats_payouts.json` - Thanks @nordowl
- Updated dependencies [[`5db7385`](https://github.com/slot-engine/slot-engine/commit/5db7385436143a6aac22120839d266947aa9cd17), [`a8c46c8`](https://github.com/slot-engine/slot-engine/commit/a8c46c8c6816f96d029eb85ce00753e485267df3), [`55e419a`](https://github.com/slot-engine/slot-engine/commit/55e419a5cda1547c633c96e3883959f11816f339), [`1dc5942`](https://github.com/slot-engine/slot-engine/commit/1dc59422837103304323081810ed23d795e8b69f), [`c8efb2c`](https://github.com/slot-engine/slot-engine/commit/c8efb2cf3b1ce54728d8c668fd749e629168b369)]:
  - @slot-engine/core@0.4.0

## 0.2.4

### Patch Changes

- Updated dependencies [[`b12a55f`](https://github.com/slot-engine/slot-engine/commit/b12a55facaacb1da6b77c5802853ae6d373adfb6)]:
  - @slot-engine/core@0.3.3

## 0.2.3

### Patch Changes

- Improve reelset designer: add options; more compact styling - Thanks @nordowl

## 0.2.2

### Patch Changes

- Updated dependencies [[`22012bb`](https://github.com/slot-engine/slot-engine/commit/22012bb71dff60ae3cdf080fbb78c25f5302f4e7), [`61e13bd`](https://github.com/slot-engine/slot-engine/commit/61e13bdc8190d95f3db5b7e110aebb6eea287873)]:
  - @slot-engine/core@0.3.2

## 0.2.1

### Patch Changes

- Updated dependencies [[`41710bd`](https://github.com/slot-engine/slot-engine/commit/41710bd73b20cfa03559be00e587f00d49f56ffc)]:
  - @slot-engine/core@0.3.1

## 0.2.0

### Minor Changes

- Replaced Force Records API with Tagging API for improved clarity ([#86](https://github.com/slot-engine/slot-engine/pull/86)) - Thanks @nordowl

### Patch Changes

- Introduced new optimizer that replaces the old Rust optimizer ([#87](https://github.com/slot-engine/slot-engine/pull/87)) - Thanks @nordowl

- Updated dependencies [[`e59d47b`](https://github.com/slot-engine/slot-engine/commit/e59d47b35901c726cbdd45c8a6b008412837436a), [`682f489`](https://github.com/slot-engine/slot-engine/commit/682f489272a87c49d9e02b8bec4fd2a899ac7eb9), [`e8e01a2`](https://github.com/slot-engine/slot-engine/commit/e8e01a2afb1d971cf5eec4d689de036905d9bca6), [`034a62f`](https://github.com/slot-engine/slot-engine/commit/034a62f16785208ab767334c3a40c440f1f69f58), [`48a57f1`](https://github.com/slot-engine/slot-engine/commit/48a57f17d8031932b3fd0fe405b52e01e87bfb39)]:
  - @slot-engine/core@0.3.0

## 0.1.14

### Patch Changes

- Updated dependencies [[`9072aa5`](https://github.com/slot-engine/slot-engine/commit/9072aa59092ce98dcfba04c45524ab5a6ee003a6)]:
  - @slot-engine/core@0.2.12

## 0.1.13

### Patch Changes

- Updated dependencies [[`fbf5bd7`](https://github.com/slot-engine/slot-engine/commit/fbf5bd75078229a0fcc80c84d43cd0de03a428bb)]:
  - @slot-engine/core@0.2.11

## 0.1.12

### Patch Changes

- Updated dependencies [[`1e087b6`](https://github.com/slot-engine/slot-engine/commit/1e087b6f9cb90d6214ec29bc982ed4f48e99d809), [`bf1f6d9`](https://github.com/slot-engine/slot-engine/commit/bf1f6d9e00614a1cc8e42032434773e145f02680), [`584a06a`](https://github.com/slot-engine/slot-engine/commit/584a06ae1e0c8f99cb15d3c143eea5176297a67f), [`5e6251c`](https://github.com/slot-engine/slot-engine/commit/5e6251c18fbf0a77f0641e5b4c7b033b74c5d536)]:
  - @slot-engine/core@0.2.10

## 0.1.11

### Patch Changes

- Updated dependencies [[`fa094c1`](https://github.com/slot-engine/slot-engine/commit/fa094c1f3997ab6e91608d469296131e18f7c1a7), [`ed96833`](https://github.com/slot-engine/slot-engine/commit/ed968337881cf5554fe270b279232e119c441567)]:
  - @slot-engine/core@0.2.9

## 0.1.10

### Patch Changes

- Updated dependencies [[`3ab6033`](https://github.com/slot-engine/slot-engine/commit/3ab603317b9f31c4ec1369b0c93c1f23ab257d57)]:
  - @slot-engine/core@0.2.8

## 0.1.9

### Patch Changes

- Remove preference for number formatting (Intl.NumberFormat undefined) - Thanks @nordowl

- Explorer: Add payout range filters - Thanks @nordowl

- Updated dependencies [[`577c708`](https://github.com/slot-engine/slot-engine/commit/577c708773a05b900b571d132b3ea76242e2a644)]:
  - @slot-engine/core@0.2.7

## 0.1.8

### Patch Changes

- Updated dependencies [[`46ff673`](https://github.com/slot-engine/slot-engine/commit/46ff67331571b5edc8cd195b744e6a4bde2f5837)]:
  - @slot-engine/core@0.2.6

## 0.1.7

### Patch Changes

- Updated dependencies [[`de4a55a`](https://github.com/slot-engine/slot-engine/commit/de4a55ae2a5d7ef5827d03d7d8e2db7ec6514f32), [`de4a55a`](https://github.com/slot-engine/slot-engine/commit/de4a55ae2a5d7ef5827d03d7d8e2db7ec6514f32)]:
  - @slot-engine/core@0.2.5

## 0.1.6

### Patch Changes

- Set default `analysisOpts.recordStats` when running tasks - Thanks @nordowl

- Updated dependencies [[`b1c3d56`](https://github.com/slot-engine/slot-engine/commit/b1c3d56dc7c1c8c31545723baac4e63a4702059b), [`e4641e6`](https://github.com/slot-engine/slot-engine/commit/e4641e607b0798e3ebf13a198ac04491c9158bbc)]:
  - @slot-engine/core@0.2.4

## 0.1.5

### Patch Changes

- Updated dependencies [[`8fe0eba`](https://github.com/slot-engine/slot-engine/commit/8fe0eba93d2a18b1b16748cde80bd465ae8d91e8), [`cf5372d`](https://github.com/slot-engine/slot-engine/commit/cf5372df1ecf925e23823fc20d28f9325575164f)]:
  - @slot-engine/core@0.2.3

## 0.1.4

### Patch Changes

- Reel Set Designer: Add overview of symbol counts per reel - Thanks @nordowl

- Reel Set Designer: Add ability to insert symbols at specific position - Thanks @nordowl

- Reel Set Editor: Refactor; Refine UI and add features - Thanks @nordowl

- Updated dependencies [[`217cbec`](https://github.com/slot-engine/slot-engine/commit/217cbec6b624c69bcc289673ed58ec1d5466ab04)]:
  - @slot-engine/core@0.2.2

## 0.1.3

### Patch Changes

- Explorer: Add button to jump to book ID - Thanks @nordowl

## 0.1.2

### Patch Changes

- Add better indicator in reel set editor if no reels found - Thanks @nordowl

- Add checkbox to enable writing uncompressed book files - Thanks @nordowl

- Updated dependencies [[`4661ce9`](https://github.com/slot-engine/slot-engine/commit/4661ce96123ab0f0ff7aa36814a6a6e89cbd0006), [`81cd177`](https://github.com/slot-engine/slot-engine/commit/81cd177e2b6358102c1895f14d5cff5681d17287)]:
  - @slot-engine/core@0.2.1

## 0.1.1

### Patch Changes

- Fix wrong dist-client path - Thanks @nordowl

## 0.1.0

### Minor Changes

- Initial release 0.1.0 ([#45](https://github.com/slot-engine/slot-engine/pull/45)) - Thanks @nordowl

### Patch Changes

- Updated dependencies [[`6804d74`](https://github.com/slot-engine/slot-engine/commit/6804d74021a4bf8b9c8bf2e62490ff77c9d5aa11), [`952fceb`](https://github.com/slot-engine/slot-engine/commit/952fcebbb297019de24902ff3870e16acbafb9a0), [`b2a6868`](https://github.com/slot-engine/slot-engine/commit/b2a6868857a442feec7652f68e4ea4de17264267), [`8835832`](https://github.com/slot-engine/slot-engine/commit/883583213a6bd83d7cc290f892398a359e5ea4ca), [`8835832`](https://github.com/slot-engine/slot-engine/commit/883583213a6bd83d7cc290f892398a359e5ea4ca), [`0183257`](https://github.com/slot-engine/slot-engine/commit/01832573712c3a29ec4f7ac1673333653551ea6f), [`785b028`](https://github.com/slot-engine/slot-engine/commit/785b0286c25ab757dac43e742630fd088546cd6b), [`bf72434`](https://github.com/slot-engine/slot-engine/commit/bf72434ae1398186643fea1545f6e89de62a9e1a), [`cd92eea`](https://github.com/slot-engine/slot-engine/commit/cd92eea8286279dbffa4f5928d5e8f75ab679da8), [`72e7a22`](https://github.com/slot-engine/slot-engine/commit/72e7a22a4bdac162b0ca1dc99aade5590c32c732)]:
  - @slot-engine/core@0.2.0
