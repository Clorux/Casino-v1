export {
  type InferGameType,
  type AnyUserData,
  type AnyGameModes,
  type AnySymbols,
  type GameHooks,
  type GameModeCompleteInfo,
  type SpinType,
  type Reels,
  type LookupTable,
  type LookupTableSegmented,
} from "./src/types"

export { SPIN_TYPE } from "./src/constants"

export {
  createSlotGame,
  defineGameModes,
  defineSymbols,
  defineUserState,
} from "./src/createSlotGame"

export { type SlotGameType as SlotGame } from "./src/slot-game"

export { type WrittenBook } from "./src/book"
export { BookReader } from "./src/book/reader"

export { GameMode } from "./src/game-mode"
export { GameSymbol } from "./src/game-symbol"
export { ResultSet } from "./src/result-set"

export { type OptimizationConfig } from "./src/optimizer"
export {
  type GameModeOptimization,
  type OptimizationTarget,
  type TargetMatch,
  type ScaleRule,
} from "@slot-engine/optimizer"

export { parseLookupTable, parseLookupTableSegmented } from "./src/analysis/utils"
export {
  type PayoutRangeBreakdown,
  type PayoutStatistics,
  type Statistics,
} from "./src/analysis"

export { type TagItem } from "./src/tagger"

export { type SimulationSummary } from "./src/simulation"

export { type GameContext } from "./src/game-context"

export { LinesWinType } from "./src/win-types/LinesWinType"
export { ClusterWinType } from "./src/win-types/ClusterWinType"
export { ManywaysWinType } from "./src/win-types/ManywaysWinType"
export {
  WinType,
  type WinCombination,
  type WinPostProcessFn,
  type WinTypeOpts,
} from "./src/win-types"

export { GeneratedReelSet } from "./src/reel-set/GeneratedReelSet"
export { StaticReelSet } from "./src/reel-set/StaticReelSet"

export { StandaloneBoard } from "./src/board/StandaloneBoard"

export { RandomNumberGenerator } from "./src/rng"
