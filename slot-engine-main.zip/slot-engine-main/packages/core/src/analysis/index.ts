import fs from "fs"
import assert from "assert"
import {
  getAvgWin,
  getLessBetHitrate,
  getMaxWin,
  getMaxwinHitrate,
  getMinWin,
  getNonZeroHitrate,
  getNullHitrate,
  getPayoutWeights,
  getRtp,
  getStandardDeviation,
  getTotalLutWeight,
  getUniquePayouts,
  getVariance,
  parseLookupTable,
  parseLookupTableSegmented,
} from "./utils"
import { round, writeJsonFile } from "../../utils"
import { isMainThread } from "worker_threads"
import { SlotGame } from "../slot-game"
import { TagItem } from "../tagger"
import { LookupTable } from "../types"
import chalk from "chalk"
import { computePayoutStatistics } from "./payout-ranges"

export class Analysis {
  protected readonly game: SlotGame

  constructor(game: SlotGame<any, any, any>) {
    this.game = game
  }

  async runAnalysis(opts: AnalysisOpts) {
    const { gameModes, tagStats = [] } = opts

    if (!isMainThread) return // IMPORTANT: Prevent workers from kicking off (multiple) analysis runs
    console.log(chalk.gray("Starting analysis..."))

    this.getNumberStats(gameModes)
    this.getWinRanges(gameModes)
    if (tagStats.length > 0) {
      this.getTagStats(gameModes, tagStats)
    }

    console.log("Analysis complete. Files written to build directory.")
  }

  private getNumberStats(gameModes: string[]) {
    const meta = this.game.getMetadata()
    const stats: Statistics[] = []

    for (const modeStr of gameModes) {
      const mode = this.getGameModeConfig(modeStr)

      const lutOptimized = parseLookupTable(
        fs.readFileSync(meta.paths.lookupTablePublish(modeStr), "utf-8"),
      )
      const totalWeight = getTotalLutWeight(lutOptimized)
      const payoutWeights = getPayoutWeights(lutOptimized)
      const maxWin = getMaxWin(payoutWeights)

      this.warnAboutZeroWeightBooks(modeStr, lutOptimized, maxWin)

      stats.push({
        gameMode: mode.name,
        totalWeight,
        avgWin: getAvgWin(payoutWeights),
        rtp: getRtp(payoutWeights, mode.cost),
        minWin: getMinWin(payoutWeights),
        maxWin,
        stdDev: getStandardDeviation(payoutWeights),
        variance: getVariance(payoutWeights),
        nonZeroHitRate: getNonZeroHitrate(payoutWeights),
        nullHitRate: getNullHitrate(payoutWeights),
        maxwinHitRate: getMaxwinHitrate(payoutWeights),
        lessBetHitRate: getLessBetHitrate(payoutWeights, mode.cost),
        uniquePayouts: getUniquePayouts(payoutWeights),
      })
    }

    writeJsonFile(meta.paths.statsSummary, stats)
  }

  private warnAboutZeroWeightBooks(mode: string, lut: LookupTable, maxWin: number) {
    let zeroWeightBooks = 0
    let topPayout = -Infinity

    for (const [, weight, payout] of lut) {
      if (weight <= 0) zeroWeightBooks++
      if (payout / 100 > topPayout) topPayout = payout / 100
    }

    if (zeroWeightBooks === 0) return

    const message =
      topPayout > maxWin
        ? `Max win ${maxWin}x unhittable in mode ${mode}. Highest payout is ${topPayout}x.`
        : "Some of your books have zero weight, which may lead to unexpected behavior."

    console.log(chalk.yellow(message))
  }

  private getWinRanges(gameModes: string[]) {
    const meta = this.game.getMetadata()

    const payoutRanges = gameModes.map((modeStr) => {
      const lutSegmented = parseLookupTableSegmented(
        fs.readFileSync(meta.paths.lookupTableSegmented(modeStr), "utf-8"),
      )
      const lutPublished = parseLookupTable(
        fs.readFileSync(meta.paths.lookupTablePublish(modeStr), "utf-8"),
      )
      return computePayoutStatistics(modeStr, lutSegmented, lutPublished)
    })

    writeJsonFile(meta.paths.statsPayouts, payoutRanges)
  }

  private getTagStats(gameModes: string[], tagStatsConfig: TagStatsConfig[]) {
    const meta = this.game.getMetadata()
    const allStats: TagStatistics[] = []

    for (const modeStr of gameModes) {
      const lutOptimized = parseLookupTable(
        fs.readFileSync(meta.paths.lookupTablePublish(modeStr), "utf-8"),
      )
      const totalWeight = getTotalLutWeight(lutOptimized)
      const weightMap = new Map<number, number>()
      lutOptimized.forEach(([bookId, weight]) => {
        weightMap.set(bookId, weight)
      })

      const tagsPath = meta.paths.tags(modeStr)
      if (!fs.existsSync(tagsPath)) continue

      const tags: TagItem[] = JSON.parse(fs.readFileSync(tagsPath, "utf-8"))

      const modeStats: TagStatistics = {
        gameMode: modeStr,
        groups: [],
      }

      for (const config of tagStatsConfig) {
        const groupName = config.name || config.groupBy.join("_")
        const aggregated = new Map<
          string,
          {
            properties: Record<string, string>
            count: number
            totalWeight: number
          }
        >()

        for (const tag of tags) {
          const searchMap = new Map(tag.search.map((s) => [s.name, s.value]))

          if (config.filter) {
            let matches = true
            for (const [key, value] of Object.entries(config.filter)) {
              if (searchMap.get(key) !== value) {
                matches = false
                break
              }
            }
            if (!matches) continue
          }

          const hasAllProps = config.groupBy.every((prop) => searchMap.has(prop))
          if (!hasAllProps) continue

          const key = config.groupBy.map((prop) => searchMap.get(prop)!).join("|")
          const properties = Object.fromEntries(
            config.groupBy.map((prop) => [prop, searchMap.get(prop)!]),
          )

          let totalWeight = 0
          for (const bookId of tag.bookIds) {
            totalWeight += weightMap.get(bookId) ?? 0
          }

          const existing = aggregated.get(key)
          if (existing) {
            existing.count += tag.timesTriggered
            existing.totalWeight += totalWeight
          } else {
            aggregated.set(key, {
              properties,
              count: tag.timesTriggered,
              totalWeight,
            })
          }
        }

        const items = Array.from(aggregated.entries())
          .map(([key, data]) => {
            const hitRate = round(totalWeight / data.totalWeight, 4)
            return {
              key,
              properties: data.properties,
              count: data.count,
              hitRateString: `1 in ${Math.round(hitRate).toLocaleString()}`,
              hitRatePercentage: round((1 / hitRate) * 100, 4),
              hitRate,
            } satisfies TagStatisticsItem
          })
          .sort((a, b) => a.hitRate - b.hitRate)

        modeStats.groups.push({
          name: groupName,
          groupBy: config.groupBy,
          filter: config.filter,
          items,
        })
      }

      allStats.push(modeStats)
    }

    writeJsonFile(meta.paths.statsTags, allStats)
  }

  private getGameModeConfig(mode: string) {
    const config = this.game.getConfig().gameModes[mode]
    assert(config, `Game mode "${mode}" not found in game config`)
    return config
  }
}

export interface PayoutRangeBreakdown {
  overall: Record<string, number>
  criteria: Record<string, Record<string, number>>
}

export interface PayoutStatistics {
  gameMode: string
  allPayouts: PayoutRangeBreakdown
  uniquePayouts: PayoutRangeBreakdown
  payoutChances: PayoutRangeBreakdown
}

export interface AnalysisOpts {
  /**
   * Which game modes to analyze.
   */
  gameModes: string[]
  /**
   * Configure which tagged properties to analyze.
   * This will provide you with hit rates for the specified groupings.
   * Each entry defines a grouping strategy for statistics.
   *
   * @example
   * ```ts
   * tagStats: [
   *   { groupBy: ["symbolId", "kind", "spinType"] }, // All win combinations
   *   { groupBy: ["symbolId", "kind"], filter: { spinType: "basegame" } }, // Base game win combinations only
   *   { groupBy: ["criteria"] }, // Hit rate by result set criteria
   * ]
   * ```
   */
  tagStats?: TagStatsConfig[]
}

export interface TagStatsConfig {
  /**
   * Properties to group by from the tagged search entries.\
   * E.g. `["symbolId", "kind", "spinType"]` for symbol hit rates.
   */
  groupBy: string[]
  /**
   * Optional filter to only include tags matching these values.
   */
  filter?: Record<string, string>
  /**
   * Optional custom name for this stats group in the output.
   */
  name?: string
}

export interface TagStatistics {
  gameMode: string
  groups: Array<{
    name: string
    groupBy: string[]
    filter?: Record<string, string>
    items: TagStatisticsItem[]
  }>
}

type TagStatisticsItem = {
  key: string
  properties: Record<string, string>
  count: number
  hitRateString: string
  hitRatePercentage: number
  hitRate: number
}

export interface Statistics {
  gameMode: string
  totalWeight: number
  rtp: number
  avgWin: number
  minWin: number
  maxWin: number
  stdDev: number
  variance: number
  maxwinHitRate: number
  nonZeroHitRate: number
  nullHitRate: number
  lessBetHitRate: number
  uniquePayouts: number
}
