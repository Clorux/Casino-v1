import {
  GameMode,
  GameSymbol,
  InferGameType,
  ResultSet,
  createSlotGame,
  defineGameModes,
  defineSymbols,
  defineUserState,
  SPIN_TYPE,
} from "@slot-engine/core"
import { REELS } from "./src/reels"
import { onHandleGameFlow } from "./src/onHandleGameFlow"
import { maxwinReelsEvaluation } from "./src/evaluations"

export const userState = defineUserState({
  boardMultis: [] as number[][],
})

export type UserStateType = typeof userState

export const symbols = defineSymbols({
  S: new GameSymbol({
    id: "S",
    properties: {
      isScatter: true,
    },
  }),
  W: new GameSymbol({
    id: "W",
    pays: {
      5: 1,
      6: 1.5,
      7: 1.75,
      8: 2,
      9: 2.5,
      10: 5,
      11: 7.5,
      12: 15,
      13: 35,
      14: 70,
      15: 150,
    },
    properties: { isWild: true },
  }),
  H1: new GameSymbol({
    id: "H1",
    pays: {
      5: 1,
      6: 1.5,
      7: 1.75,
      8: 2,
      9: 2.5,
      10: 5,
      11: 7.5,
      12: 15,
      13: 35,
      14: 70,
      15: 150,
    },
  }),
  H2: new GameSymbol({
    id: "H2",
    pays: {
      5: 0.75,
      6: 1,
      7: 1.25,
      8: 1.5,
      9: 2,
      10: 4,
      11: 6,
      12: 12.5,
      13: 30,
      14: 60,
      15: 100,
    },
  }),
  H3: new GameSymbol({
    id: "H3",
    pays: {
      5: 0.5,
      6: 0.75,
      7: 1,
      8: 1.25,
      9: 1.5,
      10: 3,
      11: 4.5,
      12: 10,
      13: 20,
      14: 40,
      15: 60,
    },
  }),
  H4: new GameSymbol({
    id: "H4",
    pays: {
      5: 0.4,
      6: 0.5,
      7: 0.75,
      8: 1,
      9: 1.25,
      10: 2,
      11: 3,
      12: 5,
      13: 10,
      14: 20,
      15: 40,
    },
  }),
  L1: new GameSymbol({
    id: "L1",
    pays: {
      5: 0.3,
      6: 0.4,
      7: 0.5,
      8: 0.75,
      9: 1,
      10: 1.5,
      11: 2.5,
      12: 3.5,
      13: 8,
      14: 15,
      15: 30,
    },
  }),
  L2: new GameSymbol({
    id: "L2",
    pays: {
      5: 0.25,
      6: 0.3,
      7: 0.4,
      8: 0.5,
      9: 0.75,
      10: 1.25,
      11: 2,
      12: 3,
      13: 6,
      14: 12,
      15: 25,
    },
  }),
  L3: new GameSymbol({
    id: "L3",
    pays: {
      5: 0.2,
      6: 0.25,
      7: 0.3,
      8: 0.4,
      9: 0.5,
      10: 1,
      11: 1.5,
      12: 2.5,
      13: 5,
      14: 10,
      15: 20,
    },
  }),
})

export type SymbolsType = typeof symbols

export const gameModes = defineGameModes({
  base: new GameMode({
    name: "base",
    cost: 1,
    rtp: 0.96,
    reelsAmount: 7,
    symbolsPerReel: [7, 7, 7, 7, 7, 7, 7],
    isBonusBuy: false,
    reelSets: [...Object.values(REELS)],
    resultSets: [
      new ResultSet({
        criteria: "0",
        quota: 0.4,
        multiplier: 0,
        reelWeights: {
          [SPIN_TYPE.BASE_GAME]: { base: 1 },
          [SPIN_TYPE.FREE_SPINS]: { bonus: 1 },
        },
      }),
      new ResultSet({
        criteria: "basegame",
        quota: 0.4,
        reelWeights: {
          [SPIN_TYPE.BASE_GAME]: { base: 1 },
          [SPIN_TYPE.FREE_SPINS]: { bonus: 1 },
        },
      }),
      new ResultSet({
        criteria: "freespins",
        quota: 0.1,
        forceFreespins: true,
        reelWeights: {
          [SPIN_TYPE.BASE_GAME]: { base: 1 },
          [SPIN_TYPE.FREE_SPINS]: { bonus: 1 },
        },
      }),
      new ResultSet({
        criteria: "maxwin",
        quota: 0.01,
        forceMaxWin: true,
        forceFreespins: true,
        reelWeights: {
          [SPIN_TYPE.BASE_GAME]: { base: 1 },
          [SPIN_TYPE.FREE_SPINS]: { bonus: 1 },
          evaluate: maxwinReelsEvaluation,
        },
      }),
    ],
  }),
  bonus: new GameMode({
    name: "bonus",
    cost: 100,
    rtp: 0.96,
    reelsAmount: 7,
    symbolsPerReel: [7, 7, 7, 7, 7, 7, 7],
    isBonusBuy: true,
    reelSets: [...Object.values(REELS)],
    resultSets: [
      new ResultSet({
        criteria: "freespins",
        quota: 0.9,
        forceFreespins: true,
        reelWeights: {
          [SPIN_TYPE.BASE_GAME]: { base: 1 },
          [SPIN_TYPE.FREE_SPINS]: { bonus: 1 },
        },
      }),
      new ResultSet({
        criteria: "maxwin",
        quota: 0.01,
        forceMaxWin: true,
        forceFreespins: true,
        reelWeights: {
          [SPIN_TYPE.BASE_GAME]: { base: 1 },
          [SPIN_TYPE.FREE_SPINS]: { bonus: 1 },
          evaluate: maxwinReelsEvaluation,
        },
      }),
    ],
  }),
})

export type GameModesType = typeof gameModes

export type GameType = InferGameType<GameModesType, SymbolsType, UserStateType>

export const game = createSlotGame<GameType>({
  id: "example-02",
  name: "Example Cluster Game",
  maxWinX: 5000,
  gameModes,
  symbols,
  padSymbols: 1,
  userState,
  hooks: {
    onHandleGameFlow,
  },
  rootDir: __dirname, // optional, but required if connecting this game to @slot-engine/panel
})

game.configureSimulation({
  simRunsAmount: {
    base: 20000,
    bonus: 20000,
  },
  concurrency: 8,
})

game.configureOptimization({
  base: {
    targets: {
      "0": {},
      basegame: { hitRate: 4 },
      freespins: { hitRate: 150, rtp: 0.38 },
      maxwin: { hitRate: 500_000 },
    },
  },
  bonus: {
    targets: {
      freespins: {},
      maxwin: { hitRate: 5000 },
    },
  },
})

game.runTasks({
  doSimulation: true,
  doOptimization: true,
  doAnalysis: true,
  analysisOpts: {
    gameModes: ["base", "bonus"],
    tagStats: [{ groupBy: ["symbolId", "kind", "spinType"] }, { groupBy: ["criteria"] }],
  },
})
