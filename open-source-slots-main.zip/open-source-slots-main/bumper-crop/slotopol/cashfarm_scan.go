package cashfarm

import (
	"context"
	"fmt"
	"io"
	"math"

	"github.com/slotopol/server/game/slot"
)

// Bonus game expectation
// calculation see at generator/prov/novomatic/cashfarmbon.lua
const Ebon = 50

func CalcStat(ctx context.Context, sp *slot.ScanPar) (float64, float64) {
	var reels, _ = ReelsMap.FindClosest(sp.MRTP)
	var g = NewGame()
	var s = slot.NewStatCascade(sn, 5)

	var calc = func(w io.Writer) (float64, float64) {
		var N1 = float64(s.Casc[0].N.Load())
		var N2 = float64(s.Casc[1].N.Load())
		var N3 = float64(s.Casc[2].N.Load())
		var N4 = float64(s.Casc[3].N.Load())
		var N5 = float64(s.Casc[4].N.Load())
		var lrtp, srtp = s.RTPsym(g.Cost(), scat)
		var rtpsym = lrtp + srtp
		var qfarm = float64(s.SumBH(farmbn)) / N1
		var rtpbon = Ebon * qfarm
		var rtp = rtpsym + rtpbon
		fmt.Fprintf(w, "symbols: %.5g(lined) + %.5g(scatter) = %.6f%%\n", lrtp*100, srtp*100, rtpsym*100)
		fmt.Fprintf(w, "N[2] = %.10g, Ec2 = Kf2 = 1/%.5g\n", N2, N1/N2)
		fmt.Fprintf(w, "N[3] = %.10g, Ec3 = 1/%.5g, Kf3 = 1/%.5g\n", N3, N1/N3, N2/N3)
		fmt.Fprintf(w, "N[4] = %.10g, Ec4 = 1/%.5g, Kf4 = 1/%.5g\n", N4, N1/N4, N3/N4)
		fmt.Fprintf(w, "N[5] = %.10g, Ec5 = 1/%.5g, Kf5 = 1/%.5g\n", N5, N1/N5, N4/N5)
		fmt.Fprintf(w, "Mcascade = %.5g, ACL = %.5g, Kfading = 1/%.5g, Ncascmax = %d\n", s.Mcascade(), s.ACL(), s.Kfading(), s.Ncascmax())
		fmt.Fprintf(w, "farm bonuses: hit rate 1/%.5g, rtp = %.6f%%\n", N1/float64(s.SumBH(farmbn)), rtpbon*100)
		fmt.Fprintf(w, "RTP = %.5g(sym) + %.5g(farm) = %.6f%%\n", rtpsym*100, rtpbon*100, rtp*100)
		return rtp, math.NaN()
	}

	return slot.ScanReelsCommon(ctx, sp, s, g, reels, calc)
}
