package fairyqueen

import (
	"context"
	"fmt"
	"io"
	"math"
	"os"
	"sync"

	"github.com/slotopol/server/game/slot"
)

func BruteForce5x3es2(ctx context.Context, sp *slot.ScanPar, s slot.Simulator, g *Game, reels slot.Reelx, es slot.Sym) {
	var tn64 = uint64(sp.TN)
	var r3 = reels.Reel(3)
	var r4 = reels.Reel(4)
	var r5 = reels.Reel(5)
	var wg sync.WaitGroup
	wg.Add(sp.TN)
	for ti := range tn64 {
		var sg = g.Clone()
		var N uint64
		go func() {
			defer wg.Done()

			var wins slot.Wins
			var x slot.Pos
			for x = 1; x <= 2; x++ {
				if es != scat {
					g.SetSym(x, 1, es)
					g.SetSym(x, 2, es)
					g.SetSym(x, 3, es)
				} else {
					g.SetSym(x, 1, 0)
					g.SetSym(x, 2, scat)
					g.SetSym(x, 3, 0)
				}
			}

			for i3 := range r3 {
				sg.SetCol(3, r3, i3)
				for i4 := range r4 {
					sg.SetCol(4, r4, i4)
					for i5 := range r5 {
						N++
						if N%slot.CtxGranulation == 0 {
							select {
							case <-ctx.Done():
								return
							default:
							}
						}
						if N%tn64 != ti {
							continue
						}
						sg.SetCol(5, r5, i5)
						s.Simulate(sg, &wins, sp.MRTP)
						wins.Reset()
					}
				}
			}
		}()
	}
	wg.Wait()
}

func BruteForce5x3es3(ctx context.Context, sp *slot.ScanPar, s slot.Simulator, g *Game, reels slot.Reelx, es slot.Sym) {
	var tn64 = uint64(sp.TN)
	var r4 = reels.Reel(4)
	var r5 = reels.Reel(5)
	var wg sync.WaitGroup
	wg.Add(sp.TN)
	for ti := range tn64 {
		var sg = g.Clone()
		var N uint64
		go func() {
			defer wg.Done()

			var wins slot.Wins
			var x slot.Pos
			for x = 1; x <= 3; x++ {
				if es != scat {
					g.SetSym(x, 1, es)
					g.SetSym(x, 2, es)
					g.SetSym(x, 3, es)
				} else {
					g.SetSym(x, 1, 0)
					g.SetSym(x, 2, scat)
					g.SetSym(x, 3, 0)
				}
			}

			for i4 := range r4 {
				sg.SetCol(4, r4, i4)
				for i5 := range r5 {
					N++
					if N%slot.CtxGranulation == 0 {
						select {
						case <-ctx.Done():
							return
						default:
						}
					}
					if N%tn64 != ti {
						continue
					}
					sg.SetCol(5, r5, i5)
					s.Simulate(sg, &wins, sp.MRTP)
					wins.Reset()
				}
			}
		}()
	}
	wg.Wait()
}

func CalcStatBon(ctx context.Context, sp *slot.ScanPar, es slot.Sym) (float64, float64, float64) {
	var g = NewGame(sp.Sel)
	g.FSR = 10 // set free spins mode
	g.ES = es
	var reels = g.GetReels(sp.MRTP)
	var s = slot.NewStatGeneric(sn, 5)

	var calc = func(w io.Writer) (float64, float64) {
		var lrtp, srtp = s.RTPsym(g.Cost(), scat)
		var rtpsym = lrtp + srtp
		var q = s.FSQ()
		var sq = 1 / (1 - q)
		if q > 0 {
			fmt.Fprintf(w, "symbols: %.5g(lined) + %.5g(scatter) = %.6f%%\n", lrtp*100, srtp*100, rtpsym*100)
			fmt.Fprintf(w, "free: HRfg = 1/%.5g, q = %.5g, sq = 1/(1-q) = %.5g\n", 1/s.FGQ(), q, sq)
		}
		fmt.Fprintf(w, "RTP[%d] = %.6f%%\n", es, rtpsym*100)
		return rtpsym, math.NaN()
	}

	func() {
		var ctx2, cancel2 = context.WithCancel(ctx)
		defer cancel2()
		if ReelNumBon[g.ES-1] == 2 {
			// var total = uint64(len(reels.Reel(3))) * uint64(len(reels.Reel(4))) * uint64(len(reels.Reel(5)))
			BruteForce5x3es2(ctx2, sp, s, g, reels, g.ES)
		} else {
			// var total = uint64(len(reels.Reel(4))) * uint64(len(reels.Reel(5)))
			BruteForce5x3es3(ctx2, sp, s, g, reels, g.ES)
		}
	}()
	var erp, sigma = calc(os.Stdout)
	var q = s.FSQ()
	return erp, sigma, q
}

func CalcStatReg(ctx context.Context, sp *slot.ScanPar) (float64, float64) {
	fmt.Printf("*bonus reels calculations*\n")
	var rtpe = map[slot.Sym]float64{}
	var qe = map[slot.Sym]float64{}
	var es slot.Sym
	for es = 2; es <= scat; es++ {
		fmt.Printf("*calculations for expanding symbol [%d]*\n", es)
		rtpe[es], _, qe[es] = CalcStatBon(ctx, sp, es)
		if ctx.Err() != nil {
			return 0, 0
		}
	}
	var rtpsym, qfs float64
	for _, es := range ReelExpSym {
		rtpsym += rtpe[es]
		qfs += qe[es]
	}
	rtpsym /= float64(len(ReelExpSym))
	qfs /= float64(len(ReelExpSym))
	var sqfs = 1 / (1 - qfs)
	var rtpfs = sqfs * rtpsym
	fmt.Printf("free: HRfg = 1/%.5g, q = %.5g, sq = 1/(1-q) = %.5g\n", 10/qfs, qfs, sqfs)
	fmt.Printf("RTPfs = sq*rtp(sym) = %.5g*%.5g = %.6f%%\n", sqfs, rtpsym*100, rtpfs*100)

	fmt.Printf("*regular reels calculations*\n")
	var g = NewGame(sp.Sel)
	var s = slot.NewStatGeneric(sn, 5)

	var calc = func(w io.Writer) (float64, float64) {
		var lrtp, srtp = s.RTPsym(g.Cost(), scat)
		var rtpsym = lrtp + srtp
		var q = s.FSQ()
		var sq = 1 / (1 - q)
		var rtp = rtpsym + q*rtpfs
		fmt.Fprintf(w, "symbols: %.5g(lined) + %.5g(scatter) = %.6f%%\n", lrtp*100, srtp*100, rtpsym*100)
		fmt.Fprintf(w, "free: HRfg = 1/%.5g, q = %.5g, sq = 1/(1-q) = %.5g\n", 1/s.FGQ(), q, sq)
		fmt.Fprintf(w, "RTP = %.5g(sym) + %.5g*%.5g(fg) = %.6f%%\n", rtpsym*100, q, rtpfs*100, rtp*100)
		return rtp, math.NaN()
	}

	return slot.ScanReelsCommon(ctx, sp, s, g, calc)
}
