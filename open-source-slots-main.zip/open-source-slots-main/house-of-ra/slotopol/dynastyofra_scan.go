package dynastyofra

import (
	"context"
	"fmt"
	"io"

	"github.com/slotopol/server/game/slot"
)

func CalcStat(ctx context.Context, sp *slot.ScanPar) (float64, float64) {
	fmt.Printf("\n(1/2) bonus reels calculations\n")
	var sb = slot.NewStatGeneric(sn, 5)
	{
		var g = NewGame(sp.Sel)
		g.FSR = 10 // set free spins mode
		var calc = func(w io.Writer) (float64, float64) {
			return slot.Parsheet_fgretrig(w, sp, sb, g.Cost(), 1, 10)
		}
		slot.ScanReelsCommon(ctx, sp, sb, g, calc)
	}

	if ctx.Err() != nil {
		return 0, 0
	}

	fmt.Printf("\n(2/2) regular reels calculations\n")
	var sr = slot.NewStatGeneric(sn, 5)
	{
		var g = NewGame(sp.Sel)
		var calc = func(w io.Writer) (float64, float64) {
			return slot.Parsheet_fgretrig_split(w, sp, sr, sb, g.Cost(), 1, 10)
		}
		return slot.ScanReelsCommon(ctx, sp, sr, g, calc)
	}
}
