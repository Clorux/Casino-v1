<script lang="ts">
	import NumberFlow from '$lib/index.js'
</script>

<NumberFlow value={42} />
