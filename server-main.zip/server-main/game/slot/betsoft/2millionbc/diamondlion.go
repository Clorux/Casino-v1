package twomillionbc

import "github.com/slotopol/server/game/slot"

// Average gain = 175
var DiamondLion = [...]float64{
	50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190, 200, 210, 220, 230, 240, 250, 260, 270, 280, 290, 300,
}

func DiamondLionSpawn(rng *slot.Rand, bet float64) float64 {
	var mult = DiamondLion[rng.N(len(DiamondLion))]
	return bet * mult
}
