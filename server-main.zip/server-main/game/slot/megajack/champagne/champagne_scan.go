package champagne

import (
	"context"
	"fmt"
	"io"
	"math"

	"github.com/slotopol/server/game/slot"
)

var (
	EVbot float64 // expectation of 1 bottle
	EVmjc float64 // Bottle game calculated expectation
)

func ExpBottle() {
	// avr 1 bottle gain
	EVbot = 0
	for _, v := range Bottles {
		EVbot += float64(v)
	}
	EVbot /= float64(len(Bottles))

	// expectation
	var E float64
	var n = 0
	for i := 0; i < len(Bottles); i++ {
		for j := i + 1; j < len(Bottles); j++ {
			if Bottles[i] == Bottles[j] {
				E += float64(Bottles[i]) * 4
			} else {
				E += float64(Bottles[i] + Bottles[j])
			}
			n++
		}
	}
	E /= float64(n)
	EVmjc = E
}

func CalcStatBon(ctx context.Context, sp *slot.ScanPar) (float64, float64) {
	var g = NewGame(sp.Sel)
	g.FSR = 15 // set free spins mode
	var s = slot.NewStatGeneric(sn, 5)
	s.BonDim(mjap)
	s.JackDim(mjj)

	var calc = func(w io.Writer) (float64, float64) {
		var N = s.Count()
		var lrtp, srtp = s.RTPsym(g.Cost(), scat)
		var rtpsym = lrtp + srtp
		var q = s.FSQ()
		var sq = 1 / (1 - q)
		var qmjc = s.BonusHits(mjc) / N / float64(g.Sel)
		var rtpmjc = EVmjc * qmjc
		var rtp = sq * (rtpsym + rtpmjc)
		fmt.Fprintf(w, "symbols: %.5g(lined) + %.5g(scatter) = %.6f%%\n", lrtp*100, srtp*100, rtpsym*100)
		fmt.Fprintf(w, "free: HRfg = 1/%.5g, q = %.5g, sq = 1/(1-q) = %.5g\n", 1/s.FGQ(), q, sq)
		fmt.Fprintf(w, "bottle bonuses: hit rate 1/%.5g, rtp = %.6f%%\n", N/s.BonusHits(mjc), rtpmjc*100)
		if s.JackHits(mjj) > 0 {
			fmt.Fprintf(w, "jackpots: count %g, frequency 1/%.12g\n", s.JackHits(mjj), N/s.JackHits(mjj))
		}
		fmt.Fprintf(w, "RTP = sq*(rtp(sym)+rtp(mjc)) = %.5g*(%.5g+%.5g) = %.6f%%\n", sq, rtpsym*100, rtpmjc*100, rtp*100)
		return rtp, math.NaN()
	}

	return slot.ScanReelsCommon(ctx, sp, s, g, calc)
}

func CalcStatReg(ctx context.Context, sp *slot.ScanPar) (float64, float64) {
	fmt.Printf("*bonus games calculations*\n")
	ExpBottle()
	fmt.Printf("len = %d, avr bottle gain = %.5g, EV = %g\n", len(Bottles), EVbot, EVmjc)
	fmt.Printf("*free games calculations*\n")
	var rtpfs, _ = CalcStatBon(ctx, sp)
	if ctx.Err() != nil {
		return 0, 0
	}
	fmt.Printf("*regular games calculations*\n")
	var g = NewGame(sp.Sel)
	g.FSR = 0 // no free spins
	var s = slot.NewStatGeneric(sn, 5)
	s.BonDim(mjap)
	s.JackDim(mjj)

	var calc = func(w io.Writer) (float64, float64) {
		var N = s.Count()
		var lrtp, srtp = s.RTPsym(g.Cost(), scat)
		var rtpsym = lrtp + srtp
		var q = s.FSQ()
		var sq = 1 / (1 - q)
		var qmjc = s.BonusHits(mjc) / N / float64(g.Sel)
		var rtpmjc = EVmjc * qmjc
		var rtp = rtpsym + rtpmjc + q*rtpfs
		fmt.Fprintf(w, "symbols: %.5g(lined) + %.5g(scatter) = %.6f%%\n", lrtp*100, srtp*100, rtpsym*100)
		fmt.Fprintf(w, "free: HRfg = 1/%.5g, q = %.5g, sq = 1/(1-q) = %.5g\n", 1/s.FGQ(), q, sq)
		fmt.Fprintf(w, "champagne bonuses: hit rate 1/%.5g, rtp = %.6f%%\n", N/s.BonusHits(mjc), rtpmjc*100)
		if s.JackHits(mjj) > 0 {
			fmt.Fprintf(w, "jackpots: count %g, frequency 1/%.12g\n", s.JackHits(mjj), N/s.JackHits(mjj))
		}
		fmt.Fprintf(w, "RTP = rtp(sym) + rtp(mjc) + q*rtp(fg) = %.5g + %.5g + %.5g*%.5g = %.6f%%\n", rtpsym*100, rtpmjc*100, q, rtpfs*100, rtp*100)
		return rtp, math.NaN()
	}

	return slot.ScanReelsCommon(ctx, sp, s, g, calc)
}
