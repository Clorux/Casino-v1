//go:build !prod || full || ct

package fusionfruitbeat

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed fusionfruitbeat_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "CT Interactive", Name: "Fusion Fruit Beat", LNum: 20, Date: game.Date(2020, 11, 26)}, // see: https://www.slotsmate.com/software/ct-interactive/fusion-fruit-beat
		{Prov: "CT Interactive", Name: "Lady Emerald", LNum: 20, Date: game.Date(2021, 3, 1)},        // see: https://www.slotsmate.com/software/ct-interactive/lady-emerald
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPlpay |
			game.GPlsel |
			game.GPfgno |
			game.GPscat |
			game.GPwild,
		SX: 5,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["ctinteractive/fusionfruitbeat/rmap"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
