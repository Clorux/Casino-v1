package halloweenfruits

// See: https://www.slotsmate.com/software/ct-interactive/ct-gaming-halloween-fruits

import (
	"github.com/slotopol/server/game/slot"
)

const (
	sn         = 12   // number of symbols
	wild, scat = 1, 2 // wild & scatter symbol IDs
)

var ReelsBon slot.Reelx

var ReelsMap slot.ReelsMap[slot.Reelx]

// Lined payment.
var LinePay = [sn][5]float64{
	{},                  //  1 wild (2, 3, 4, 5 reels only)
	{},                  //  2 scatter (2, 3, 4 reels only)
	{0, 0, 20, 50, 300}, //  3 witch
	{0, 0, 15, 30, 100}, //  4 cat
	{0, 0, 15, 30, 100}, //  5 banana
	{0, 0, 15, 30, 100}, //  6 grape
	{0, 0, 10, 15, 50},  //  7 apple
	{0, 0, 10, 15, 50},  //  8 melon
	{0, 0, 10, 15, 30},  //  9 orange
	{0, 0, 10, 15, 30},  // 10 lemon
	{0, 0, 10, 15, 30},  // 11 plum
	{0, 0, 10, 15, 30},  // 12 cherry
}

// Scatters payment.
var ScatPay = [5]float64{0, 0, 0, 3, 5} // 2 scatter

// Bet lines
var BetLines = slot.BetLinesCT5x3[:]

type Game struct {
	slot.Grid5x3 `yaml:",inline"`
	slot.Slotx   `yaml:",inline"`
}

// Declare conformity with SlotGeneric interface.
var _ slot.SlotGeneric = (*Game)(nil)

func NewGame(sel int) *Game {
	var g = &Game{
		Slotx: slot.Slotx{
			Sel: sel,
			Bet: 1,
		},
	}
	g.SpinReels(slot.WySRNG, g.GetReels(slot.InitRTP))
	return g
}

func (g *Game) Clone() slot.SlotGeneric {
	var clone = *g
	return &clone
}

func (g *Game) Scanner(wins *slot.Wins) error {
	g.ScanLined(wins)
	g.ScanScatters(wins)
	return nil
}

// Lined symbols calculation.
func (g *Game) ScanLined(wins *slot.Wins) {
	for li, line := range BetLines[:g.Sel] {
		var numl slot.Pos = 5
		var syml = g.LX(1, line)
		var x slot.Pos
		for x = 2; x <= 5; x++ {
			var sx = g.LX(x, line)
			if sx != syml && sx != wild {
				numl = x - 1
				break
			}
		}

		if pay := LinePay[syml-1][numl-1]; pay > 0 {
			*wins = append(*wins, slot.WinItem{
				Pay: g.Bet * pay,
				MP:  1,
				Sym: syml,
				Num: numl,
				LI:  li + 1,
				XY:  line.HitxL(numl),
			})
		}
	}
}

// Scatters calculation.
func (g *Game) ScanScatters(wins *slot.Wins) {
	if count := g.SymNum(scat); count >= 4 {
		var pay = ScatPay[min(count-1, 4)]
		*wins = append(*wins, slot.WinItem{
			Pay: g.Bet * float64(g.Sel) * pay,
			MP:  1,
			Sym: scat,
			Num: count,
			XY:  g.SymPos(scat),
			FS:  15,
		})
	}
}

func (g *Game) GetReels(mrtp float64) slot.Reelx {
	if g.FSR == 0 {
		var reels, _ = ReelsMap.FindClosest(mrtp)
		return reels
	} else {
		return ReelsBon
	}
}

func (g *Game) Spin(rng *slot.Rand, mrtp float64) {
	g.SpinReels(rng, g.GetReels(mrtp))
}

func (g *Game) SetSel(sel int) error {
	return g.SetSelNum(sel, len(BetLines))
}
