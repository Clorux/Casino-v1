package smileyxwild

import (
	"context"
	"io"

	"github.com/slotopol/server/game/slot"
)

func CalcStat(ctx context.Context, sp *slot.ScanPar) (float64, float64) {
	var g = NewGame(sp.Sel)
	g.M2 = 3 // average wild multiplier on 2 reel
	g.M4 = 3 // average wild multiplier on 4 reel
	var s = slot.NewSnapFlat(sn, 5)

	var calc = func(w io.Writer) (float64, float64) {
		return slot.Parsheet_simple(w, sp, s, g.Cost())
	}

	return slot.ScanReelsCommon2(ctx, sp, s, g, calc)
}
