//go:build !prod || full || ct

package sapphirelagoon

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed sapphirelagoon_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "CT Interactive", Name: "Sapphire Lagoon", LNum: 25, Date: game.Date(2016, 6, 15)}, // see: https://www.slotsmate.com/software/ct-interactive/sapphire-lagoon
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPlpay |
			game.GPlsel |
			game.GPfgseq |
			game.GPfgmult |
			game.GPstscat |
			game.GPwild,
		SX: 5,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["ctinteractive/sapphirelagoon/rmap"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
