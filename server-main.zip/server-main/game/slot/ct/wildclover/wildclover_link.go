//go:build !prod || full || ct

package wildclover

import (
	_ "embed"

	"github.com/slotopol/server/game"
)

//go:embed wildclover_data.yaml
var data []byte

var Info = game.AlgInfo{
	Aliases: []game.GameAlias{
		{Prov: "CT Interactive", Name: "Wild Clover", LNum: 20, Date: game.Date(2015, 9, 15)},       // see: https://www.slotsmate.com/software/ct-interactive/wild-clover
		{Prov: "CT Interactive", Name: "The Mighty Aztecs", LNum: 20, Date: game.Date(2023, 5, 12)}, // see: https://www.slotsmate.com/software/ct-interactive/the-mighty-aztecs
	},
	AlgDescr: game.AlgDescr{
		GT: game.GTslot,
		GP: game.GPlpay |
			game.GPlsel |
			game.GPfgno |
			game.GPscat |
			game.GPwild,
		SX: 5,
		SY: 3,
		SN: sn,
		LN: len(BetLines),
		BN: 0,
	},
	Update: func(ai *game.AlgInfo) { ai.RTP = game.MakeRtpList(ReelsMap) },
}

func init() {
	Info.SetupFactory(func(sel int) game.Gamble { return NewGame(sel) }, CalcStat)
	game.DataRouter["ctinteractive/wildclover/rmap"] = &ReelsMap
	game.LoadMap = append(game.LoadMap, data)
}
