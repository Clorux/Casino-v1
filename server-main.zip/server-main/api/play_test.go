package api_test

import (
	"bytes"
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/slotopol/server/api"
	cfg "github.com/slotopol/server/config"
	"github.com/slotopol/server/core"
	"github.com/slotopol/server/prng"
	"github.com/slotopol/server/util"

	"github.com/gin-gonic/gin"
)

const (
	// JWT-token signing keys
	testAccessKey  = "skJgM4NsbP3fs4k7vh0gfdkgGl8dJTszdLxZ1sQ9ksFnxbgvw2RsGH8xxddUV479"
	testRefreshKey = "zxK4dUnuq3Lhd1Gzhpr3usI5lAzgvy2t3fmxld2spzz7a5nfv0hsksm9cheyutie"

	// client emulation, device Pixel 8
	testUserAgentNew = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/155.0.8059.88 Mobile Safari/537.36"
	testUserAgentOld = "Mozilla/5.0 (Linux; Android 14; Pixel 8 Build/UQ1A.240205.002) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.60 Mobile Safari/537.36"

	// admin credentials
	testAdminID     = 1
	testAdminEmail  = "admin@example.org"
	testAdminSecret = "0YBoaT"

	// test user credentials
	testUserID     = 3
	testUserEmail  = "player@example.org"
	testUserSecret = "iVI05M"
)

// set of bets per line
var betset = []float64{0.1, 0.2, 0.5, 1, 2, 5, 10}

// set of sums to add to wallet
var sumset = []float64{
	50, 50, 50, 50,
	100, 100, 100, 100, 100, 100,
	200, 200, 200, 200,
	250, 250, 250, 250, 250, 250,
	300, 300,
	500, 500, 500, 500, 500, 500, 500, 500,
	600,
	700,
	800,
	1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000,
	1500, 1500,
	2000, 2000,
	5000, 5000,
	10000,
}

var (
	ErrHttpNotOk   = errors.New("http response is not ok")
	ErrAlienServer = errors.New("alien server")
)

func setuphints(req *http.Request) {
	req.Header.Set("User-Agent", testUserAgentNew)
	req.Header.Set("Sec-CH-UA", `"Google Chrome";v="155", "Chromium";v="155", "Not=A?Brand";v="24"`)
	req.Header.Set("Sec-CH-UA-Mobile", "?1")
	req.Header.Set("Sec-CH-UA-Platform", `"Android"`)
	req.Header.Set("Sec-CH-UA-Platform-Version", `"14.0.0"`)
	req.Header.Set("Sec-CH-UA-Model", `"Pixel 8"`)
}

func ping(t *testing.T, r *gin.Engine) (err error) {
	var req = httptest.NewRequest("GET", "/ping", nil)
	req.Header.Set("User-Agent", testUserAgentOld)
	var w = httptest.NewRecorder()
	r.ServeHTTP(w, req)
	if w.Code != http.StatusOK {
		err = fmt.Errorf("%w, ping failed, code %d", ErrHttpNotOk, w.Code)
		t.Error(err)
	}
	var resp = w.Result()
	if !strings.HasPrefix(resp.Header.Get("Server"), "slotopol/") {
		err = fmt.Errorf("%w, header: %s", ErrAlienServer, resp.Header.Get("Server"))
		t.Error(err)
	}
	return
}

func authping(t *testing.T, r *gin.Engine, token string) (err error) {
	var req = httptest.NewRequest("GET", "/authping", nil)
	setuphints(req)
	req.Header.Set("Authorization", "Bearer "+token)
	var w = httptest.NewRecorder()
	r.ServeHTTP(w, req)
	if w.Code != http.StatusOK {
		err = fmt.Errorf("%w, authping failed, code %d", ErrHttpNotOk, w.Code)
		t.Error(err)
	}
	var resp = w.Result()
	if !strings.HasPrefix(resp.Header.Get("Server"), "slotopol/") {
		err = fmt.Errorf("%w, header: %s", ErrAlienServer, resp.Header.Get("Server"))
		t.Error(err)
	}
	return
}

func posthdr(t *testing.T, r *gin.Engine, path string, hdr http.Header, arg any) (ret gin.H, err error) {
	var b []byte

	if b, err = json.Marshal(arg); err != nil {
		t.Error(err)
	}
	var req = httptest.NewRequest("POST", path, bytes.NewReader(b))
	req.Header = hdr
	setuphints(req)
	var w = httptest.NewRecorder()
	r.ServeHTTP(w, req)
	if w.Code == http.StatusNoContent {
		return
	}
	if w.Code >= http.StatusBadRequest {
		err = fmt.Errorf("%w, path '%s', code %d", ErrHttpNotOk, path, w.Code)
		t.Error(err)
	}
	var resp = w.Result()
	if !strings.HasPrefix(resp.Header.Get("Server"), "slotopol/") {
		err = fmt.Errorf("%w, header: %s", ErrAlienServer, resp.Header.Get("Server"))
		t.Error(err)
		return
	}
	if b, err = io.ReadAll(resp.Body); err != nil {
		t.Error(err)
		return
	}
	if err = json.Unmarshal(b, &ret); err != nil {
		t.Error(err)
		return
	}
	if w.Code >= http.StatusBadRequest {
		t.Logf("message: %v, code: %v", ret["what"], ret["code"])
	}
	return
}

func post(t *testing.T, r *gin.Engine, path string, token string, arg any) (ret gin.H, err error) {
	var hdr = http.Header{}
	hdr.Set("Content-Type", "application/json")
	hdr.Set("Accept", "application/json")
	if token != "" {
		hdr.Set("Authorization", "Bearer "+token)
	}
	return posthdr(t, r, path, hdr, arg)
}

// Sign-in and sign-out by different ways.
func testSignin(t *testing.T, r *gin.Engine) (err error) {
	var arg, ret gin.H

	// Sign-in with credentials
	arg = gin.H{
		"email":  testUserEmail,
		"secret": testUserSecret,
	}
	if ret, err = post(t, r, "/signin", "", arg); err != nil {
		return
	}
	var tok1 = ret["access"].(string)
	var sid1 = ret["sid"]
	t.Logf("[sign-in] %s with credentials, sid=%g", ret["email"], sid1)

	if err = authping(t, r, tok1); err != nil {
		return
	}
	t.Logf("[authping]")

	// Sign-in with UID and secret
	arg = gin.H{
		"uid":    testUserID,
		"secret": testUserSecret,
	}
	if ret, err = post(t, r, "/signin", "", arg); err != nil {
		return
	}
	var tok2 = ret["access"].(string)
	var sid2 = ret["sid"]
	t.Logf("[sign-in] %s with uid and secret, sid=%g", ret["email"], ret["sid"])

	if err = authping(t, r, tok2); err != nil {
		return
	}
	t.Logf("[authping]")

	arg = gin.H{"sid": sid1}
	if ret, err = post(t, r, "/signout", tok2, arg); err != nil {
		return
	}
	t.Logf("[signout] sid=%g, by another session", sid1)

	// Sign-in with login and hash
	var sigtime = time.Now().Format(time.RFC3339)
	var h = hmac.New(sha256.New, util.S2B(sigtime))
	h.Write(util.S2B(testAdminSecret))
	var hs256 = h.Sum(nil)
	arg = gin.H{
		"email":   testAdminEmail,
		"sigtime": sigtime,
		"hs256":   hex.EncodeToString(hs256),
	}
	if ret, err = post(t, r, "/signin", "", arg); err != nil {
		return
	}
	var tok3 = ret["access"].(string)
	var ref3 = ret["refrsh"]
	var sid3 = ret["sid"]
	t.Logf("[sign-in] %s with login and hash, sid=%g", ret["email"], ret["sid"])

	if err = authping(t, r, tok3); err != nil {
		return
	}
	t.Logf("[authping]")

	arg = gin.H{"refrsh": ref3}
	if ret, err = post(t, r, "/token", "", arg); err != nil {
		return
	}
	tok3 = ret["access"].(string)
	t.Logf("[token] %s expire %s, sid=%g", ret["email"], ret["expire"], ret["sid"])

	if err = authping(t, r, tok3); err != nil {
		return
	}
	t.Logf("[authping]")

	arg = gin.H{"uid": testUserID}
	if ret, err = post(t, r, "/sessions", tok3, arg); err != nil {
		return
	}
	t.Logf("[sessions] uid=%d, %d sessions", testUserID, len(ret["sessions"].([]interface{})))

	arg = gin.H{"sid": sid2}
	if ret, err = post(t, r, "/signout", tok3, arg); err != nil {
		return
	}
	t.Logf("[signout] sid=%g, by admin session", sid2)

	arg = gin.H{}
	if ret, err = post(t, r, "/signout", tok3, arg); err != nil {
		return
	}
	t.Logf("[signout] sid=%g, own session, by token", sid3)
	return
}

// Simulate a player playing a game with random bets and lines selected,
// and sometimes making double-ups on wins.
func testSinglePlay(t *testing.T, r *gin.Engine) (err error) {
	const cid, uid uint64 = 1, 3
	var admtoken, usrtoken string
	var admsid, usrsid any
	var arg, ret gin.H
	var gid uint64
	var wallet, gain float64
	var fsr int

	var rng = prng.New(prng.NewWyRand(0))

	// Sign-in admin in order to top up player account
	arg = gin.H{
		"email":  testAdminEmail,
		"secret": testAdminSecret,
	}
	if ret, err = post(t, r, "/signin", "", arg); err != nil {
		return
	}
	admtoken = ret["access"].(string)
	admsid = ret["sid"]
	t.Logf("[sign-in] %s, sid=%g", arg["email"], admsid)

	// Sign-in player with predefined credentials
	arg = gin.H{
		"email":  testUserEmail,
		"secret": testUserSecret,
	}
	if ret, err = post(t, r, "/signin", "", arg); err != nil {
		return
	}
	usrtoken = ret["access"].(string)
	usrsid = ret["sid"]
	t.Logf("[sign-in] %s, sid=%g", arg["email"], usrsid)

	// Join game
	arg = gin.H{
		"cid":   cid,        // 'virtual' club
		"uid":   testUserID, // player ID
		"alias": "Novomatic / Dolphins Pearl",
	}
	if ret, err = post(t, r, "/game/new", usrtoken, arg); err != nil {
		return
	}
	gid = uint64(ret["gid"].(float64))
	wallet = ret["wallet"].(float64)
	t.Logf("[new] gid: %d, wallet: %.2f", gid, wallet)

	var bet, sel = 1., 5
	arg = gin.H{
		"gid": gid,
		"bet": bet,
	}
	post(t, r, "/slot/bet/set", usrtoken, arg)
	t.Logf("[bet/set] gid: %d, bet: %g", gid, bet)
	arg = gin.H{
		"gid": gid,
		"sel": sel,
	}
	post(t, r, "/slot/sel/set", usrtoken, arg)
	t.Logf("[sel/set] gid: %d, sel: %d", gid, sel)

	// Play the game with 100 spins
	for range 100 {
		// check money at wallet
		if wallet < bet*float64(sel) {
			var sum float64
			for wallet+sum < bet*float64(sel) {
				sum = sumset[rng.N(len(sumset))]
			}
			arg = gin.H{
				"cid": cid,
				"uid": testUserID,
				"sum": sum,
			}
			if ret, err = post(t, r, "/prop/wallet/add", admtoken, arg); err != nil {
				return
			}
			wallet = ret["wallet"].(float64)
			t.Logf("[wallet/add] gid: %d, wallet: %.2f, sum: %g", gid, wallet, sum)
		}

		// make spin
		arg = gin.H{
			"gid": gid,
		}
		if ret, err = post(t, r, "/slot/spin", usrtoken, arg); err != nil {
			return
		}
		var game = ret["game"].(map[string]any)
		if v, ok := game["gain"]; ok {
			gain = v.(float64)
		} else {
			gain = 0
		}
		if v, ok := game["fsr"]; ok {
			fsr = int(v.(float64))
		} else {
			fsr = 0
		}
		wallet = ret["wallet"].(float64)
		t.Logf("[spin] gid: %d, slid: %d, fsr: %d, wallet: %.2f, gain: %g", gid, uint64(ret["slid"].(float64)), fsr, wallet, gain)

		// no any more actions on free spins
		if fsr > 0 {
			continue
		}

		// if there has a win, make double-ups sometime
		if gain > 0 && rng.Float64() < 0.3 {
			for {
				arg = gin.H{
					"gid":  gid,
					"mult": 2,
					"half": rng.Float64() < 0.25,
				}
				if ret, err = post(t, r, "/slot/doubleup", usrtoken, arg); err != nil {
					return
				}
				var gain = ret["gain"].(float64)
				wallet = ret["wallet"].(float64)
				t.Logf("[doubleup] gid: %d, mlid: %d, wallet: %.2f, gain: %g", gid, uint64(ret["mlid"].(float64)), wallet, gain)
				if gain == 0 {
					break
				}
				if rng.Float64() < 0.5 {
					arg = gin.H{
						"gid": gid,
					}
					post(t, r, "/slot/collect", usrtoken, arg)
					t.Logf("[collect] gid: %d", gid)
					break
				}
			}
		}

		// change bet value sometimes
		if rng.Float64() < 1./25. {
			bet = betset[rng.N(len(betset))]
			arg = gin.H{
				"gid": gid,
				"bet": bet,
			}
			post(t, r, "/slot/bet/set", usrtoken, arg)
			t.Logf("[bet/set] gid: %d, bet: %g", gid, bet)
		}

		// change selected bet lines sometimes
		if rng.Float64() < 1./25. {
			sel = 3 + rng.N(8)
			arg = gin.H{
				"gid": gid,
				"sel": sel,
			}
			post(t, r, "/slot/sel/set", usrtoken, arg)
			t.Logf("[sel/set] gid: %d, sel: %d", gid, sel)
		}
	}

	arg = gin.H{"sid": usrsid}
	if ret, err = post(t, r, "/signout", usrtoken, arg); err != nil {
		return
	}
	t.Logf("[signout] sid=%g, own session", usrsid)

	arg = gin.H{"sid": admsid}
	if ret, err = post(t, r, "/signout", admtoken, arg); err != nil {
		return
	}
	t.Logf("[signout] sid=%g, own session", admsid)
	return
}

func TestAPI(t *testing.T) {
	var err error

	// Set debug logger
	cfg.Verbose = 3
	cfg.InitLogger()

	// Load yaml-files
	if _, err = core.LoadInternalYaml(context.Background()); err != nil {
		t.Fatalf("can not load internal yaml files: %s", err.Error())
		return
	}
	core.UpdateAlgList()
	core.CheckAlgList()

	// Prepare in-memory database
	cfg.CfgPath = "../appdata"
	if err = core.InitXORM(); err != nil {
		t.Fatalf("can not initialize xorm: %s", err.Error())
	}
	// Close database connection
	defer func() {
		if err = core.DoneXORM(); err != nil {
			t.Fatal(err)
		}
	}()

	gin.SetMode(gin.TestMode)
	var r = gin.New()
	r.HandleMethodNotAllowed = true
	api.SetupRouter(r)

	// Setup test JWT-token signing keys
	cfg.Cfg.AccessKey = testAccessKey
	cfg.Cfg.RefreshKey = testRefreshKey

	// Send "ping" and check that server is our
	t.Run("ping", func(t *testing.T) {
		if err = ping(t, r); err != nil {
			return
		}
		t.Log("[ping]")
	})

	// go test -v -run ^TestAPI$/^signin$ ./api
	t.Run("signin", func(t *testing.T) {
		testSignin(t, r)
	})

	// go test -v -count=1 -run ^TestAPI$/^play$ ./api
	t.Run("play", func(t *testing.T) {
		testSinglePlay(t, r)
	})
}
