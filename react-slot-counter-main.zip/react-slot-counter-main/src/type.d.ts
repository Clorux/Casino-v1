declare module "*.module.scss";
