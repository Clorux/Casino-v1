# MIT License
#
# Copyright (c) 2023 Playtika Ltd.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from pybandits.model.base import (
    Model,
    ModelCC,
    ModelDP,
    ModelMO,
)
from pybandits.model.beta import (
    BaseBeta,
    BaseBetaMO,
    Beta,
    BetaCC,
    BetaDP,
    BetaMO,
    BetaMOCC,
)
from pybandits.model.bnn._guide import (
    ParameterizedScaleAutoNormal,
    _wrap_guide_with_kl_scale,
)
from pybandits.model.bnn._typing import (
    ActivationFunctions,
    OptaxKind,
    VIMethods,
)
from pybandits.model.bnn.config import (
    BnnLayerParams,
    BnnParams,
    CategoricalFeatureConfig,
    EarlyStopping,
    EmbeddingParams,
    FeaturesConfig,
)
from pybandits.model.bnn.network import (
    BaseBayesianNeuralNetwork,
    BaseBayesianNeuralNetworkMO,
    BayesianNeuralNetwork,
    BayesianNeuralNetworkCC,
    BayesianNeuralNetworkDP,
    BayesianNeuralNetworkMO,
    BayesianNeuralNetworkMOCC,
    GaussianBayesianNeuralNetwork,
)
from pybandits.model.bnn.priors import (
    BaseLocationScaleArray,
    NormalArray,
    StudentTArray,
)

__all__ = [
    "VIMethods",
    "ActivationFunctions",
    "OptaxKind",
    "Model",
    "ModelCC",
    "ModelDP",
    "ModelMO",
    "BaseBeta",
    "Beta",
    "BetaCC",
    "BetaDP",
    "BaseBetaMO",
    "BetaMO",
    "BetaMOCC",
    "BaseLocationScaleArray",
    "StudentTArray",
    "NormalArray",
    "CategoricalFeatureConfig",
    "FeaturesConfig",
    "EmbeddingParams",
    "BnnLayerParams",
    "BnnParams",
    "EarlyStopping",
    "ParameterizedScaleAutoNormal",
    "_wrap_guide_with_kl_scale",
    "BaseBayesianNeuralNetwork",
    "BayesianNeuralNetwork",
    "BayesianNeuralNetworkCC",
    "BayesianNeuralNetworkDP",
    "BaseBayesianNeuralNetworkMO",
    "BayesianNeuralNetworkMO",
    "BayesianNeuralNetworkMOCC",
    "GaussianBayesianNeuralNetwork",
]
