# Changelog

## 3.0 — Stats, Loot & Guardians

Initial GitHub publication of the existing v3.0 game.

- Full C++20 game and simulator source, Windows icon resources, and build script.
- Roguelike progression through branching pachinko dungeons, with five character stats, abilities, patrons, relics, runes, and Guardians.
- Procedural boards and synthesized music, autosaves, Hall of Fame, character records, and unlockable Descent Levels.
- Existing developer tools for content, save/load, ball physics, aiming, and balance checks.
- Player, build, and source guides; contribution instructions; preview image; and MIT license.
- Portable Windows x64 download distributed through GitHub Releases.

This entry describes the first published snapshot. Earlier private development history is not included.
