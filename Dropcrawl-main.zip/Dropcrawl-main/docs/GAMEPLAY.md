# Playing Dropcrawl

[Back to the README](../README.md)

## How a run works

* **Pick a ball (species) and a background.** There are **18 balls × 25 backgrounds**, each with its own spread of the
  five stats. Most backgrounds start you with exactly **one ability** (some also start you in the service of a god);
  everything else you earn along the way.
* **Descend.** Each area is a series of rooms chosen from the stairs (Monster Dens, Elite Lairs, Shops, Rest Sites,
  Treasure Vaults, Altars, Strange Passages), ending with a **Guardian**. The stairs also show the shape of each board.
  * **The Upper Halls** come first.
  * Then choose a branch (three of four are offered): **Fungal Lair**, **Drowned Halls**, **Clockwork Mines** or the
    **Slime Pits**.
  * Then another (three of four): **Crypt**, **Ember Forge**, **Frozen Vaults** or **the Abyss**.
  * Branch Guardians guard the two **Runes** you need to enter **the Core**.
* **Win** by beating the House and escaping with the Orb of Chance.
* **Permadeath.** The run autosaves; when you die, a character file is written to `morgue\` and your score goes to the
  Hall of Fame.

### A turn

1. **Aim** with the mouse (the dotted guide shows the path to the first bounce) and **click to launch**.
2. **Power.** The ball starts with your *base power* and gains **+1 for every pin** it hits. Special pegs and board toys
   add more or multiply it.
3. **Damage.** Hitting a monster deals damage equal to the ball's power (Strength adds to it, and Dexterity gives a chance
   of a **critical hit**), then its power resets. A ball that keeps bouncing on a monster without touching any peg in
   between loses force (glancing blows), so you can't juggle a monster to death.
4. **Discharge.** When a ball leaves the board it **discharges half its leftover power** into your **focus target**. A
   *Strike* pocket discharges all of it. **Right-click a monster** (or press Tab) to choose the focus.
5. **Monsters act.** Every monster shows its next action (its *intent*) and a countdown above it; a red countdown means
   it acts after your next shot. Nothing is hidden (except what the Tumbler does): hover over anything for full details.

### The board is always busy

* **14 board formats** give every floor a shape: Classic, Funnel, Split, stacked Tiers, a Plinko grid, an Arena ring,
  an Hourglass, a rocky Cavern, Zigzag ramps, Islands, a Bumper Bowl, a moving Carnival, a Pachislot machine and a
  symmetrical Temple. The Tumbler can even rebuild a live board into a different format.
* **Balls never get stuck crawling.** Ramps and shelves are steep enough to roll down, a ball resting on one always
  keeps rolling downhill (even against the wind), and a ball that goes a couple of seconds without getting any lower
  or hitting anything new slowly grows heavier until it drops. Portals and rifts carry a ball at most twice, and a
  ball that does get wedged is lifted out to the nearest open spot.
* **25 pin layouts** and **55 hand-made set pieces** go on top: tulip rows, **slot machines**, drop-target banks,
  rollover lanes, slingshot kickers, pendulums, windmills, gear towers, geysers, rifts, singularities, shrines, healing
  wells, pinatas, dice tables, cannon batteries, lightning rods, constellations, rune roads, gem clusters, locked cages,
  loot nests, trampolines, spinner rows...
* **78 kinds of pegs.** Special pegs (crit, gold, heal, mana, multiball, fire, ice, poison, spark, crystal, warp, jelly,
  mirror, vampire, chaos, frost, clover, anvil, feather, void, shield, seed, rune, and new: prism, dice, star, moon,
  hourglass, blood, cannon, lightning rod, combo, snowball, echo, brand, jackpot) are used up when hit and new ones
  appear every turn. Board objects include bumpers, bells, coin stacks, springs, magnets, ghost pins, drop targets,
  chests (some of them **mimics**), **loot orbs**, **shrines**, **healing wells**, **relic shards**, **gems**, pinatas,
  eggs and your own allies.
* **Rune circles** grant one of **35 runes**; 14 of them belong to an ability school and grow with your levels in it. A
  ball that picks up two runes can spell one of **12 runewords** (Fire + Storms = Plasma, Luck + Gold = Fortune's
  Favor...).
* **21 kinds of zones** and **32 floor modifiers** (Tulip Garden, Casino Night, Tumbler's Playground, Blood Moon, Gold
  Rush, Warped Space, Geysers, Minefield, Bounty, Rising Water, Darkness, Carousel...).
* **Music** is composed on the fly: 20 moods (one per branch, plus shops, rest sites, altars, events, vaults, victory,
  death, a circus waltz for the Tumbler's Playground and two title themes) played by 39 synthesized instruments. Every
  few minutes a new song is written, and Guardian and elite fights re-arrange the current song rather than switching
  tracks.
* **7–9 pockets** drawn from **37 kinds**: Free Turn, Strike, Heal, Mana, Gold, Charge, Double, Refresh, Wisdom,
  Shield, Multiball, Bomb, Freeze, Burn, Plague, Lottery, Chaos, Bank, Loot, Shrine, Relaunch, Summon, Smite, Scatter,
  Training (a permanent stat point), Delay, Gamble, Shard, Slots, Prayer, Jackpot (in vaults), and deeper down Empty,
  Void, Trap and Tax. Monsters can curse or freeze pockets.

### Monsters

120 monsters with 48 kinds of intents: besides attacking, blocking and healing they lay eggs, spin webs, blind you,
drain your next ball, charge beams you must interrupt, call down meteors you must smash, quake the board, drain your
life, dispel your protections, sunder your armor, try to execute you when you're low, warp your special pegs into
curses, create mirror images, freeze your pockets, devour pegs and open gravity wells.

* **Guardians** act every turn, often do two things at once ("summon a goblin, then attack"), telegraph their biggest
  blows with a longer countdown, change tactics as they lose health (the late ones have three phases), and become
  **enraged** (+50% damage) if a fight drags past 12 turns. A health bar across the top of the board tracks them.
* **Champions** (blue names) and **unique monsters** (gold names, like *Gorefang the Vile*) roll random affixes from 17
  — Extra Strong, Extra Fast, Stone Skin, Vampiric, Regenerating, Shielded, Teleporting, Thorny, Cursed, Mana Burn,
  Splitting, Horde, Healing Aura, Multishot, Berserker, Fire Enchanted, Cold Enchanted — and drop loot.
* **Treasure imps** never attack, but escape with their hoard after four turns. **Mimics** look just like chests.

## Getting stronger

* **Stats.** Every ball has **Strength** (ball damage), **Dexterity** (critical hits and dodging), **Intelligence** (MP,
  MP regeneration, spell and ally damage), **Vitality** (HP and healing) and **Luck** (gold, better loot, crits and
  lucky double-triggering pegs). Values above 5 give bonuses, below 5 penalties. **Every level raises a stat** according
  to your ball's growth, and **every third level you choose a stat to raise by 2.** Gems, shrines, Training pockets,
  relics and the Tumbler change them too.
* **Levels.** XP comes from kills. Every level also gives +1 base power, more HP, and a **choice of new abilities or
  upgrades**.
* **Abilities.** 155 abilities across fourteen schools: Force, Flame, Frost, Storm, Earth, Arcane, Life, Fortune,
  Shadow, Clockwork, **Blood** (paid for with HP), **Chaos**, **Summoning** and **Void**. Some balls also get innate
  abilities (breath weapons, Hurl Damnation).
* **Loot, Diablo-style.** Relics come in grades:
  * **White** — 90 regular relics.
  * **Blue (magic)** — a regular relic that rolled one or two random affixes and got a name to match, like
    *Mighty Iron Ring of the Fox* (42 affix types).
  * **Yellow (randarts)** — 2–6 properties drawn from 85, sometimes with one of 17 drawbacks, and a generated name.
  * **Orange (unique)** — 26 curated legendaries built around a school or mechanic, e.g. the *Crown of the Tempest*
    (Storm), *Heart of the Inferno* (Flame), *Voidheart* (Void), *Runemaster's Chisel* (runes), *Assassin's Mark*
    (crits), *Goblin King's Sack* (loot).
  * **Green (sets)** — 4 sets of 3 pieces (Tumbler's Motley, Gambler's Regalia, Warlord's Panoply, Archmage's
    Vestments) with bonuses at 2 and 3 pieces.

  Monsters drop **loot orbs** onto the board (hit them to grab them; leftovers are collected when the floor ends),
  three **relic shards** fuse into a relic of your choice, and **shrines** grant one of 10 blessings for the rest of a
  floor. Luck improves everything.
* **Items.** 39 kinds: potions, scrolls and **wands** (charged and aimed at a target).
* **Mutations.** 31 mutations from potions of mutation, pools of chaos, demons and gods.
* **Patrons.** At an altar you can pledge yourself to one of **17 gods**, each with likes and dislikes and **5 gifts**
  (85 in all). Invocations cost piety, so they have their own window (press **G** or click **Invoke** under your god)
  instead of taking up the 1–9 ability keys. Among them: **Arcana** deals cards from the Deck of Fates, **Ruun** trades your sacrifices for power,
  **Glub** reshapes you with slime, **the Ancestor** launches a ball of its own beside yours, **Voidmaw** bends space,
  **Aurelia** smites the unholy, **Brakka** rewards duels with the strongest, **Sifra** empowers spellcraft and
  **Tempestra** tears up the board with storms.
* **The Tumbler, Lord of Chance** is a capricious, Xom-like god with **98 tricks**: 78 things it can do between turns and
  20 it can do to a ball in mid-flight. It watches its followers, Chaos Orbs and anyone carrying chaotic trinkets, and
  has a *mood*: amused, it meddles kindly; bored, cruelly. It can heal you, smite monsters, rain bombs, rebuild the
  board into a new format or mirror it, polymorph, charm or crown monsters, summon new ones, call down meteors, drop loot
  and pinatas, swap your stats, repaint every pocket, snatch your ball mid-flight and drop it somewhere else, turn it
  into a comet or gild it, flip gravity, and more.
* **Descent Levels.** Winning unlocks harder difficulty tiers (up to 10) with bigger score multipliers.

### Exotic balls and backgrounds

Balls and backgrounds with a gold border play very differently, and vary even between runs:

* **Fiendball** (Demonspawn): grows a unique set of demonic facets as it levels — a body part, a hide, two powers and a
  capstone, or (10%) a *monstrous* set of three body parts. Upcoming facets are shown in its tooltip.
* **Drakeball** (Draconian): at XL 5 its scales take one of eight random colors, granting a trait, a breath weapon and
  its own stat growth.
* **Djinn Ball**: no MP at all; spells cost HP instead.
* **Nine-Lives Ball**: comes back from death (more lives at XL 7 and 14), but can't drink potions.
* **Changeling**: becomes a different kind of ball on every floor, and grows like its current form.
* **Chaos Orb**: random stats and random growth; it mutates as it grows and entertains the Tumbler.
* **Wanderer**: DCSS-style random start — random abilities (one of them practised), shuffled stats, random items and
  maybe a wand or relic.
* **Shapeshifter** and **Pilgrim**: a random mutation / a random god.

## Controls

| Input | Action |
|---|---|
| Mouse | Aim; click to launch |
| Right-click monster / Tab | Set / cycle focus target |
| 1–9 | Use abilities (or click them in the left panel); 0, - and = for a 10th to 12th ability |
| G | Open your god's invocations (click one to use it; G, Esc or right-click closes the window) |
| Z X C V B N | Use items (before launching; wands then ask for a target) |
| A / D or ← / → | Flippers (with Pinball Wizard) |
| Mouse wheel | Launch strength (with Precision Launcher); scroll the message log |
| Hold Space | Fast-forward ×4 |
| F | Toggle double speed |
| Esc | Pause menu (save & quit, settings, help) |
| F11 / Alt+Enter | Fullscreen |
| F12 | Screenshot (saved to `screenshots\`) |

The hints at the top of the board on the first floor appear on your first run only. To see them again, tick
"Show the tutorial hints on the next run" in Settings.

## Files next to the game

| File | What it is |
|---|---|
| `save.dat` | Autosave of the run in progress (deleted when a run ends) |
| `settings.ini` | Volume and display settings, your unlocked descent level, and whether you've seen the tutorial hints |
| `scores.txt` | Hall of Fame |
| `morgue\*.txt` | Character file for every finished run |
| `screenshots\` | F12 screenshots |

Runs saved by an older version can't be continued (the save format changed); scores and settings carry over.
