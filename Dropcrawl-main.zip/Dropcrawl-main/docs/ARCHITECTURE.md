# Source guide

[Back to the README](../README.md)

**Source layout** (`src\`):

| File | Contents |
|---|---|
| `game.h` | All game types and the rules API |
| `rules.h` | Helpers shared by the rule files |
| `content_abilities.cpp`, `content_abilities2.cpp` | Abilities (the second file holds the newer schools and innate abilities) |
| `content_divine.cpp` | Patron gifts of the newer gods and the fifth gift of the original gods |
| `content_data.cpp`, `content_data2.cpp` | Relics, items, monsters, species, backgrounds, patrons, branches, modifiers, events |
| `content_data3.cpp` | New pegs/pockets/intents text, unique and set relics, Guardian scripts, treasure imps and mimics |
| `stats.cpp` | The five stats: species/background tables, growth, stat choices, effects |
| `loot.cpp` | Magic affixes, relic rolling, champions and unique monsters, loot orbs, shards, shrines |
| `runes.cpp` | Rune circles, school runes and runewords |
| `formats.cpp` | Board formats (and rebuilding a board into another format) |
| `floor.cpp` | Player, stats, monsters, damage, board helpers |
| `floor_ball.cpp`, `floor_ball2.cpp` | Ball events: pegs, tulips, slot machine, zones, monster hits, pockets (the second file holds the newer pegs and pockets) |
| `floor_turn.cpp` | Turn flow, monster intents, allies, launching, abilities, items, level-ups |
| `physics.cpp` | Ball physics, collisions, zones, aim guide |
| `boardgen.cpp`, `setpieces.cpp` | Procedural boards, set pieces, pin layouts, pockets, floor modifiers |
| `tumbler.cpp` | The Tumbler, board transformations, Arcana's cards |
| `mutations.cpp` | Mutations, demonic facets, exotic species, draconic colors, sacrifices |
| `randart.cpp` | Randart generation and the shared property engine |
| `run.cpp` | Acts, stairs, branches, shops, rest sites, altars, rewards, scoring |
| `save.cpp` | Save / load |
| `gfx.*`, `audio.*` | Renderer and synthesizer |
| `ui_*.cpp`, `main.cpp` | Screens, panels, board rendering, input, main loop |
| `sim.*` | Bots used by the simulator and the title-screen demo |

**Adding content:** abilities go in the `content_abilities*.cpp` files (add an id to `AbId` in `game.h`); relics,
items, monsters and events go in `content_data*.cpp`; set pieces and pin layouts in `setpieces.cpp`; board formats in
`formats.cpp`. Effects hook into the game through the `Hooks` table (`stats`, `pegHit`, `monHit`, `kill`, `turnStart`,
`hurt`, and so on).
