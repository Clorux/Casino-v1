# Building and testing

[Back to the README](../README.md)

## Requirements

- 64-bit Windows 10 or Windows 11.
- An x64 **MinGW-w64** toolchain providing `g++` with C++20 support and `windres`.
- Both tools on `PATH`. [WinLibs](https://winlibs.com/) is one option.

The initial GitHub release was built with the WinLibs x86_64 UCRT POSIX toolchain, GCC 16.1.0. The project does not currently provide a Linux, macOS, MSVC, or CMake build.

Windows supplies Direct2D, DirectWrite, WIC, COM, waveOut, and the other system APIs linked by the build. There are no project dependencies to fetch.

## Build the game and simulator

Open PowerShell in the repository root:

```powershell
g++ --version
windres --version
.\build.bat
```

| Output | Purpose |
| --- | --- |
| `Dropcrawl.exe` | The graphical game, statically linked against the compiler runtime |
| `build\dropcrawl_sim.exe` | Console balance simulator |
| `build\res.o` | Compiled icon resource |

The script uses C++20, optimization, and warnings. It compiles the Windows resource before linking the game. Keep `res\dropcrawl.ico` and `res\dropcrawl.rc` together.

To play:

```powershell
.\Dropcrawl.exe
```

The game writes its data beside the executable, so use a writable folder.

## Run a simulation

```powershell
.\build\dropcrawl_sim.exe 4 1 1000
```

Arguments, in order:

| Argument | Default | Meaning |
| --- | --- | --- |
| `runs` | `4` | Number of complete automated runs |
| `smart` | `1` | `1` for the aiming bot, `0` for the simpler bot |
| `seed` | `1000` | Starting seed, incremented for each run |
| `trace` | `0` | Nonzero prints detailed progress |
| `species` | `-1` | Fixed species index, or `-1` to vary |
| `background` | `-1` | Fixed background index, or `-1` to vary |
| `candidates` | Bot default | Optional number of aiming candidates |

Use positive run counts and valid indices from `src/game.h`. Report the command and seed alongside balance findings.

## Compile the existing test tools

The tools share the rules, audio, and simulation code. The following PowerShell commands compile the content check and save/load check without the graphical frontend:

```powershell
New-Item -ItemType Directory -Force build | Out-Null
$core = Get-ChildItem src\*.cpp | Where-Object {
    $_.BaseName -notmatch '^(main|sim_main|gfx|ui_.+)$'
}

g++ -std=c++20 -O2 -Isrc $core.FullName tools\contenttest.cpp -o build\contenttest.exe -static -lwinmm
if ($LASTEXITCODE -ne 0) { throw 'Content test build failed' }
.\build\contenttest.exe
if ($LASTEXITCODE -ne 0) { throw 'Content test failed' }

g++ -std=c++20 -O2 -Isrc $core.FullName tools\savetest.cpp -o build\savetest.exe -static -lwinmm
if ($LASTEXITCODE -ne 0) { throw 'Save test build failed' }
.\build\savetest.exe build\test_save.dat
if ($LASTEXITCODE -ne 0) { throw 'Save test failed' }
```

The save test **writes** the path passed to it. Always give it a disposable path such as `build\test_save.dat`, never a player's actual save.

| Tool | Purpose |
| --- | --- |
| `contenttest.cpp` | Exercises content definitions and mechanics; reports `PROBLEMS: 0` on success |
| `savetest.cpp` | Compares a saved and reloaded run with continued simulation |
| `abiltest.cpp`, `relictest.cpp` | Ability and relic balance experiments |
| `aimtest.cpp`, `aimcmp.cpp` | Aiming effectiveness comparisons |
| `flowtest.cpp` | Shot duration, stalls, crawling, and wedged balls across board formats |
| `balltrace.cpp` | Low-level ball simulation diagnostics |

To build another tool, use the same `$core` list and replace the tool source and output filename. These are developer diagnostics; inspect each tool's `main` function for its arguments before running it.

## Render and exercise the UI

The game has built-in diagnostic modes:

```powershell
.\Dropcrawl.exe --shot build\stats.png stats
.\Dropcrawl.exe --autoplay build\autoplay 20000 1
```

- `--shot <file.png> <scenario> [n]` renders a scenario to an image. Scenarios include `toys`, `slots`, `tumbler`, `v3pegs`, `stats`, `relics`, `meteor`, `format`, `invoke`, and `tutorial`.
- `--autoplay <folder> [frames] [seed]` exercises the real UI using synthetic input.

Use a separate build or extracted copy for diagnostic runs so generated files stay separate from your normal play folder.

## Troubleshooting

- **`g++` or `windres` is not recognized:** add the toolchain's `bin` directory to `PATH` and open a new terminal.
- **Windows libraries cannot be found:** use an x64 MinGW-w64 toolchain, not a compiler targeting Linux.
- **The executable cannot be overwritten:** close the running game before rebuilding.
- **Progress does not save:** move the game to a writable folder.
- **An older save will not load:** save-format compatibility is not guaranteed across versions. Back up the previous executable and `save.dat` before upgrading.

## Release packaging

Build from the tagged source and include `Dropcrawl.exe`, `README.md`, `LICENSE`, `CHANGELOG.md`, and `docs/` in the Windows ZIP. Do not include a developer's save, scores, settings, screenshots, or morgue records. Publish the ZIP and its SHA-256 checksum as GitHub release assets. GitHub also provides source archives for each tag.
