# Contributing to Dropcrawl

Thank you for helping improve the dungeon.

## Report a bug

Open an [issue](https://github.com/mimizukes/Dropcrawl/issues) with:

- The game version and your Windows version.
- What you expected and what happened.
- Steps to reproduce, including the species, background, abilities, relics, or board involved.
- The run seed or simulator command, if available.
- A screenshot or relevant character record, if it helps.

Review any attached save, screenshot, or character record before posting it publicly. Do not attach credentials or unrelated personal files.

## Make a change

1. Fork the repository and create a branch for one focused change.
2. Follow [Building and testing](docs/BUILDING.md) to build locally.
3. Keep the existing C++ style: two-space indentation, descriptive names, and small helpers where useful.
4. Update the player guide when behavior or controls change.
5. Open a pull request explaining the change, why it helps, and how you checked it.

For gameplay changes, run the content check and a seeded simulation. For persistence changes, also run the save/load check. For visual or input changes, inspect the game or the relevant scenario render. Report any checks you could not run.

## Find the relevant code

The [source guide](docs/ARCHITECTURE.md) maps gameplay systems to files. Content is defined in C++; there is no separate content database or asset pipeline.

Avoid committing generated binaries, build products, play data, or local editor and assistant settings. Keep release binaries in GitHub Releases.

## License

By submitting a contribution, you agree that it may be distributed under this project's [MIT License](LICENSE).
