// Dropcrawl - shared UI: widgets, tooltips, icons, peg/monster rendering, effects
#include "app.h"

bool g_ghostSolid = true;  // set by drawBoard for the world being drawn

bool mouseIn(const App& a, float x, float y, float w, float h) {
  return a.in.mouse.x >= x && a.in.mouse.x < x + w && a.in.mouse.y >= y && a.in.mouse.y < y + h;
}

bool button(App& a, float x, float y, float w, float h, const std::string& label, bool enabled, uint32_t accent, float fs) {
  Gfx& g = a.g;
  bool hov = enabled && mouseIn(a, x, y, w, h);
  g.fillRRect(x, y, w, h, 6, hov ? 0x262d3d : 0x171b26, enabled ? 0.95f : 0.6f);
  g.rrect(x + 0.5f, y + 0.5f, w - 1, h - 1, 6, accent, enabled ? (hov ? 1.f : 0.55f) : 0.2f, hov ? 2.f : 1.2f);
  if (hov) g.fillRRect(x + 2, y + 2, w - 4, h * 0.45f, 5, 0xffffff, 0.04f);
  g.text(label, x, y, w, h, fs, enabled ? (hov ? 0xffffff : 0xdde3ee) : 0x6a7080, 1.f, F_UIB, AL_C, VA_M);
  if (hov && a.in.lPressed && !a.in.consumed) {
    a.in.consumed = true;
    audio::play(S_CLICK, 0.5f);
    return true;
  }
  return false;
}

void panelBox(App& a, float x, float y, float w, float h, uint32_t accent, float alpha) {
  a.g.fillRRect(x, y, w, h, 8, 0x0d1017, alpha);
  a.g.rrect(x + 0.5f, y + 0.5f, w - 1, h - 1, 8, accent, 0.35f, 1.2f);
}

void setTip(App& a, const std::string& title, const std::string& body, uint32_t col) {
  a.tip.active = true;
  a.tip.title = title;
  a.tip.body = body;
  a.tip.col = col;
}

float textH(App& a, const std::string& s, float size, float width, int font) { return a.g.measure(s, size, font, width).y; }

void drawTooltip(App& a) {
  if (!a.tip.active) return;
  Gfx& g = a.g;
  float w = a.tip.body.size() > 520 ? 400.f : 330.f;
  float th = a.tip.title.empty() ? 0 : textH(a, a.tip.title, 16, w - 20, F_UIB);
  float fs = a.tip.body.size() > 900 ? 12.f : 13.5f;
  float bh = a.tip.body.empty() ? 0 : textH(a, a.tip.body, fs, w - 20);
  float h = th + bh + 20 + (th > 0 && bh > 0 ? 6 : 0);
  float x = a.in.mouse.x + 18, y = a.in.mouse.y + 14;
  if (x + w > SCR_W - 6) x = a.in.mouse.x - w - 12;
  if (y + h > SCR_H - 6) y = SCR_H - 6 - h;
  if (y < 4) y = 4;
  if (x < 4) x = 4;
  g.fillRRect(x + 3, y + 4, w, h, 7, 0x000000, 0.45f);
  g.fillRRect(x, y, w, h, 7, 0x0b0e14, 0.97f);
  g.rrect(x + 0.5f, y + 0.5f, w - 1, h - 1, 7, a.tip.col, 0.7f, 1.3f);
  float yy = y + 10;
  if (th > 0) {
    g.text(a.tip.title, x + 10, yy, w - 20, th + 4, 16, a.tip.col, 1.f, F_UIB);
    yy += th + 6;
  }
  if (bh > 0) g.text(a.tip.body, x + 10, yy, w - 20, bh + 4, fs, 0xd4dae6, 1.f, F_UI);
}

uint32_t powerColor(int power) {
  if (power < 5) return 0xffffff;
  if (power < 10) return 0xfff2a0;
  if (power < 20) return 0xffc840;
  if (power < 40) return 0xff8a30;
  if (power < 80) return 0xff4658;
  return 0xd070ff;
}

std::string withArticle(const std::string& n) {
  if (n.rfind("The ", 0) == 0 || n.empty()) return n;
  char c = (char)tolower(n[0]);
  bool vowel = c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
  return std::string(vowel ? "an " : "a ") + n;
}

// ------------------------------------------------------------------ icons
static void star(Gfx& g, V2 c, float ro, float ri, int n, uint32_t col, float al) {
  V2 pts[16];
  n = std::min(n, 8);
  for (int i = 0; i < n * 2; ++i) pts[i] = c + fromAng(-PI / 2 + i * PI / n) * (i % 2 ? ri : ro);
  g.fillPoly(pts, n * 2, col, al);
}

void drawIcon(Gfx& g, int intent, V2 c, float s, uint32_t col, float al) {
  switch (intent) {
    case IN_ATTACK:
    case IN_HEAVY:
    case IN_MULTI: {
      V2 a0 = c + V2(-s * 0.55f, s * 0.55f), a1 = c + V2(s * 0.55f, -s * 0.55f);
      g.line(a0, a1, col, al, s * 0.22f);
      g.line(c + V2(-s * 0.55f, -s * 0.05f), c + V2(-s * 0.05f, s * 0.55f), col, al, s * 0.18f);
      g.fillCircle(a0 + V2(-s * 0.08f, s * 0.08f), s * 0.14f, col, al);
      if (intent == IN_MULTI) {
        V2 b0 = c + V2(s * 0.55f, s * 0.55f), b1 = c + V2(-s * 0.55f, -s * 0.55f);
        g.line(b0, b1, col, al * 0.8f, s * 0.18f);
      }
      break;
    }
    case IN_BLOCK:
    case IN_SHIELDALLY: {
      V2 pts[6] = {c + V2(-s * 0.55f, -s * 0.55f), c + V2(s * 0.55f, -s * 0.55f), c + V2(s * 0.55f, 0),
                   c + V2(0, s * 0.65f), c + V2(-s * 0.55f, 0), c + V2(-s * 0.55f, -s * 0.55f)};
      g.fillPoly(pts, 5, col, al * 0.85f);
      g.strokePoly(pts, 5, 0xffffff, al * 0.5f, 1.2f);
      if (intent == IN_SHIELDALLY) g.fillCircle(c + V2(s * 0.55f, s * 0.45f), s * 0.22f, 0xffffff, al);
      break;
    }
    case IN_HEAL: {
      g.fillCircle(c + V2(-s * 0.26f, -s * 0.15f), s * 0.3f, col, al);
      g.fillCircle(c + V2(s * 0.26f, -s * 0.15f), s * 0.3f, col, al);
      V2 t[3] = {c + V2(-s * 0.55f, -s * 0.05f), c + V2(s * 0.55f, -s * 0.05f), c + V2(0, s * 0.6f)};
      g.fillPoly(t, 3, col, al);
      break;
    }
    case IN_BUFF:
    case IN_ENRAGE: {
      V2 t[3] = {c + V2(0, -s * 0.65f), c + V2(s * 0.55f, 0), c + V2(-s * 0.55f, 0)};
      g.fillPoly(t, 3, col, al);
      g.fillRect(c.x - s * 0.2f, c.y, s * 0.4f, s * 0.6f, col, al);
      if (intent == IN_ENRAGE) g.circle(c, s * 0.75f, 0xff4040, al, s * 0.12f);
      break;
    }
    case IN_SUMMON:
    case IN_CALL: {
      g.circle(c, s * 0.5f, col, al, s * 0.16f);
      g.line(c + V2(0, -s * 0.28f), c + V2(0, s * 0.28f), col, al, s * 0.16f);
      g.line(c + V2(-s * 0.28f, 0), c + V2(s * 0.28f, 0), col, al, s * 0.16f);
      if (intent == IN_CALL) g.arc(c, s * 0.75f, -0.6f, 0.6f, col, al, s * 0.1f);
      break;
    }
    case IN_HEX:
    case IN_CURSEPOCKET:
    case IN_MUTATEPEGS: {
      g.arc(c, s * 0.5f, 0, PI * 1.6f, col, al, s * 0.15f);
      g.arc(c, s * 0.25f, PI, PI * 2.5f, col, al, s * 0.14f);
      if (intent == IN_MUTATEPEGS) g.fillCircle(c + V2(s * 0.5f, -s * 0.5f), s * 0.18f, 0xffffff, al);
      break;
    }
    case IN_BOMB: {
      g.fillCircle(c + V2(-s * 0.05f, s * 0.1f), s * 0.45f, col, al);
      g.line(c + V2(s * 0.2f, -s * 0.25f), c + V2(s * 0.45f, -s * 0.55f), 0xffd080, al, s * 0.12f);
      g.fillCircle(c + V2(s * 0.5f, -s * 0.6f), s * 0.12f, 0xfff0a0, al);
      break;
    }
    case IN_WALL: {
      g.fillRect(c.x - s * 0.6f, c.y - s * 0.45f, s * 1.2f, s * 0.9f, col, al * 0.85f);
      g.line(c + V2(-s * 0.6f, 0), c + V2(s * 0.6f, 0), 0x000000, al * 0.6f, 1.2f);
      g.line(c + V2(0, -s * 0.45f), c + V2(0, 0), 0x000000, al * 0.6f, 1.2f);
      g.line(c + V2(-s * 0.3f, 0), c + V2(-s * 0.3f, s * 0.45f), 0x000000, al * 0.6f, 1.2f);
      g.line(c + V2(s * 0.3f, 0), c + V2(s * 0.3f, s * 0.45f), 0x000000, al * 0.6f, 1.2f);
      break;
    }
    case IN_TELEPORT:
    case IN_BURROW:
    case IN_SWAP: {
      g.circle(c, s * 0.5f, col, al, s * 0.12f);
      g.circle(c, s * 0.25f, col, al * 0.7f, s * 0.1f);
      if (intent == IN_SWAP) {
        g.line(c + V2(-s * 0.7f, -s * 0.2f), c + V2(s * 0.7f, -s * 0.2f), col, al, s * 0.1f);
        g.line(c + V2(-s * 0.7f, s * 0.2f), c + V2(s * 0.7f, s * 0.2f), col, al, s * 0.1f);
      }
      if (intent == IN_BURROW) g.line(c + V2(-s * 0.6f, s * 0.6f), c + V2(s * 0.6f, s * 0.6f), col, al, s * 0.14f);
      break;
    }
    case IN_DRAIN:
    case IN_SLOW: {
      V2 z[4] = {c + V2(s * 0.2f, -s * 0.65f), c + V2(-s * 0.25f, 0.05f * s), c + V2(s * 0.2f, 0.05f * s), c + V2(-s * 0.2f, s * 0.65f)};
      g.strokePoly(z, 4, col, al, s * 0.16f, false);
      if (intent == IN_SLOW) g.circle(c, s * 0.7f, col, al * 0.7f, s * 0.08f);
      break;
    }
    case IN_POISON:
    case IN_ACID: {
      g.fillCircle(c + V2(0, s * 0.15f), s * 0.38f, col, al);
      V2 t[3] = {c + V2(0, -s * 0.6f), c + V2(s * 0.34f, s * 0.05f), c + V2(-s * 0.34f, s * 0.05f)};
      g.fillPoly(t, 3, col, al);
      if (intent == IN_ACID) g.fillCircle(c + V2(s * 0.45f, s * 0.45f), s * 0.18f, col, al);
      break;
    }
    case IN_WEAKEN:
    case IN_SAP: {
      V2 t[3] = {c + V2(0, s * 0.65f), c + V2(s * 0.55f, 0), c + V2(-s * 0.55f, 0)};
      g.fillPoly(t, 3, col, al);
      g.fillRect(c.x - s * 0.2f, c.y - s * 0.6f, s * 0.4f, s * 0.6f, col, al);
      break;
    }
    case IN_GROW:
    case IN_TOTEM: {
      g.fillRect(c.x - s * 0.12f, c.y - s * 0.6f, s * 0.24f, s * 1.2f, col, al);
      g.fillCircle(c + V2(0, -s * 0.45f), s * 0.3f, col, al);
      break;
    }
    case IN_EAT:
    case IN_DEVOUR: {
      g.arc(c, s * 0.5f, 0.6f, TAU - 0.6f, col, al, s * 0.2f);
      if (intent == IN_DEVOUR) g.fillCircle(c + V2(s * 0.45f, 0), s * 0.16f, 0xffffff, al);
      break;
    }
    case IN_CHARGE:
    case IN_BEAM: {
      g.circle(c, s * 0.5f, col, al, s * 0.12f);
      g.line(c, c + V2(0, -s * 0.35f), col, al, s * 0.12f);
      g.line(c, c + V2(s * 0.25f, s * 0.1f), col, al, s * 0.12f);
      if (intent == IN_BEAM) g.line(c + V2(s * 0.5f, 0), c + V2(s * 1.0f, 0), 0xffe080, al, s * 0.2f);
      break;
    }
    case IN_SHUFFLE:
    case IN_STEAL: {
      g.text("$", c.x - s, c.y - s, s * 2, s * 2, s * 1.4f, col, al, F_MONOB, AL_C, VA_M);
      break;
    }
    case IN_RISE: {
      for (int k = 0; k < 3; ++k) {
        float yy = c.y - s * 0.4f + k * s * 0.4f;
        g.line(V2(c.x - s * 0.55f, yy), V2(c.x + s * 0.55f, yy), col, al, s * 0.14f);
      }
      break;
    }
    case IN_EGGS: {
      g.fillEllipse(c + V2(-s * 0.25f, s * 0.1f), s * 0.28f, s * 0.38f, col, al);
      g.fillEllipse(c + V2(s * 0.28f, s * 0.15f), s * 0.25f, s * 0.34f, col, al * 0.8f);
      break;
    }
    case IN_WEB: {
      for (int k = 0; k < 4; ++k) g.line(c - fromAng(k * PI / 4) * s * 0.6f, c + fromAng(k * PI / 4) * s * 0.6f, col, al, s * 0.08f);
      g.circle(c, s * 0.35f, col, al, s * 0.08f);
      break;
    }
    case IN_BLIND: {
      g.fillEllipse(c, s * 0.6f, s * 0.32f, col, al * 0.8f);
      g.line(c + V2(-s * 0.6f, s * 0.5f), c + V2(s * 0.6f, -s * 0.5f), 0xffffff, al, s * 0.12f);
      break;
    }
    case IN_CURSEBALL: {
      g.circle(c, s * 0.45f, col, al, s * 0.14f);
      g.line(c + V2(-s * 0.3f, 0), c + V2(s * 0.3f, 0), col, al, s * 0.14f);
      break;
    }
    case IN_DECOY: {
      g.circle(c + V2(-s * 0.2f, 0), s * 0.4f, col, al, s * 0.1f);
      g.circle(c + V2(s * 0.2f, 0), s * 0.4f, col, al * 0.6f, s * 0.1f);
      break;
    }
    case IN_FREEZEPOCKET: {
      for (int k = 0; k < 3; ++k) g.line(c - fromAng(k * PI / 3) * s * 0.6f, c + fromAng(k * PI / 3) * s * 0.6f, col, al, s * 0.12f);
      break;
    }
    case IN_GRAVITY: {
      g.arc(c, s * 0.55f, 0.f, PI * 1.5f, col, al, s * 0.12f);
      g.arc(c, s * 0.3f, PI, PI * 2.5f, col, al, s * 0.12f);
      g.fillCircle(c, s * 0.12f, col, al);
      break;
    }
    case IN_RANDOM: {
      g.text("?", c.x - s, c.y - s, s * 2, s * 2, s * 1.5f, col, al, F_MONOB, AL_C, VA_M);
      break;
    }
    case IN_QUAKE: {
      V2 z[5] = {c + V2(-s * 0.7f, -s * 0.1f), c + V2(-s * 0.3f, s * 0.35f), c + V2(0, -s * 0.35f), c + V2(s * 0.3f, s * 0.35f),
                 c + V2(s * 0.7f, -s * 0.1f)};
      g.strokePoly(z, 5, col, al, s * 0.17f, false);
      g.line(c + V2(-s * 0.7f, s * 0.6f), c + V2(s * 0.7f, s * 0.6f), col, al * 0.7f, s * 0.12f);
      break;
    }
    case IN_LIFEDRAIN: {
      g.fillCircle(c + V2(0, s * 0.15f), s * 0.36f, col, al);
      V2 t[3] = {c + V2(0, -s * 0.62f), c + V2(s * 0.32f, s * 0.05f), c + V2(-s * 0.32f, s * 0.05f)};
      g.fillPoly(t, 3, col, al);
      g.arc(c, s * 0.72f, -PI * 0.2f, PI * 0.7f, 0xffffff, al * 0.8f, s * 0.08f);
      break;
    }
    case IN_DISPEL: {
      g.circle(c, s * 0.55f, col, al, s * 0.14f);
      g.line(c + V2(-s * 0.4f, s * 0.4f), c + V2(s * 0.4f, -s * 0.4f), col, al, s * 0.14f);
      break;
    }
    case IN_EXECUTE: {
      g.fillCircle(c + V2(0, -s * 0.1f), s * 0.45f, col, al);
      g.fillRect(c.x - s * 0.25f, c.y + s * 0.2f, s * 0.5f, s * 0.35f, col, al);
      g.fillCircle(c + V2(-s * 0.17f, -s * 0.12f), s * 0.12f, 0x000000, al);
      g.fillCircle(c + V2(s * 0.17f, -s * 0.12f), s * 0.12f, 0x000000, al);
      break;
    }
    case IN_SUNDER: {
      V2 pts[6] = {c + V2(-s * 0.55f, -s * 0.55f), c + V2(s * 0.55f, -s * 0.55f), c + V2(s * 0.55f, 0),
                   c + V2(0, s * 0.65f), c + V2(-s * 0.55f, 0), c + V2(-s * 0.55f, -s * 0.55f)};
      g.strokePoly(pts, 5, col, al, s * 0.12f);
      g.line(c + V2(-s * 0.1f, -s * 0.55f), c + V2(s * 0.12f, -s * 0.05f), col, al, s * 0.12f);
      g.line(c + V2(s * 0.12f, -s * 0.05f), c + V2(-s * 0.08f, s * 0.35f), col, al, s * 0.12f);
      break;
    }
    case IN_FLEE: {
      for (int k = 0; k < 2; ++k) {
        float x = c.x - s * 0.35f + k * s * 0.4f;
        g.line(V2(x, c.y - s * 0.45f), V2(x + s * 0.35f, c.y), col, al, s * 0.14f);
        g.line(V2(x + s * 0.35f, c.y), V2(x, c.y + s * 0.45f), col, al, s * 0.14f);
      }
      break;
    }
    case IN_METEOR: {
      g.fillCircle(c + V2(s * 0.2f, s * 0.2f), s * 0.35f, col, al);
      for (int k = 0; k < 3; ++k)
        g.line(c + V2(s * 0.05f - k * s * 0.12f, s * 0.05f + k * s * 0.12f) - V2(s * 0.1f, -s * 0.1f),
               c + V2(-s * 0.55f - k * s * 0.1f, -s * 0.55f + k * s * 0.18f), col, al * (1.f - 0.25f * k), s * 0.08f);
      break;
    }
    default: g.fillCircle(c, s * 0.25f, col, al); break;
  }
}

// ------------------------------------------------------------------ pegs
static const char* pegGlyph(int k) {
  switch (k) {
    case PK_CRIT: return "x";
    case PK_GOLD: return "$";
    case PK_HEAL: return "+";
    case PK_MANA: return "*";
    case PK_MULTI: return "2";
    case PK_FIRE: return "^";
    case PK_ICE: return "#";
    case PK_POISON: return "%";
    case PK_SPARK: return "z";
    case PK_XP: return "!";
    case PK_REFRESH: return "@";
    case PK_LIFE: return "+";
    case PK_CURSE: return "-";
    case PK_TELEPORT: return "~";
    case PK_JELLY: return "o";
    case PK_MIRROR: return "|";
    case PK_VAMPIRE: return "v";
    case PK_CHAOS: return "?";
    case PK_FREEZE: return "*";
    case PK_CLOVER: return "&";
    case PK_ANVIL: return "T";
    case PK_FEATHER: return "~";
    case PK_VOID: return "";
    case PK_SHIELD: return "[";
    case PK_SEED: return ".";
    case PK_RUNE: return "R";
    case PK_HOURGLASS: return "8";
    case PK_CANNON: return "=";
    case PK_ROD: return "z";
    case PK_COMBO: return "+";
    case PK_ECHO: return "e";
    case PK_BRAND: return "!";
  }
  return "";
}

static void allyPeg(App& a, const Peg& p, float al, const char* glyph, uint32_t col) {
  Gfx& g = a.g;
  V2 c = p.p;
  g.additive(true);
  g.glow(c, p.r * 2.6f, col, (0.3f + 0.4f * p.flash) * al);
  g.additive(false);
  g.fillCircle(c, p.r, rgbLerp(0x0c0e14, col, 0.25f), al);
  g.circle(c, p.r - 1, col, al, 2.2f);
  g.text(glyph, c.x - p.r, c.y - p.r, p.r * 2, p.r * 2, p.r * 1.25f, col, al, F_MONOB, AL_C, VA_M);
  if (p.ttl > 0) g.text(std::to_string(p.ttl), c.x - 10, c.y + p.r - 1, 20, 14, 10, 0xffffff, 0.85f * al, F_MONOB, AL_C, VA_T);
}

void drawPeg(App& a, const Peg& p, float al, uint32_t pinCol) {
  Gfx& g = a.g;
  if (p.dead || al <= 0.01f) return;
  V2 c = p.p;
  float t = a.time;
  int k = p.kind;
  if (p.flash > 0) {
    g.additive(true);
    g.glow(c, p.r * 3.5f, 0xffffff, 0.5f * p.flash * al);
    g.additive(false);
  }
  if (k == PK_PIN || (p.used && isEnchant(k))) {
    uint32_t col = p.used ? rgbLerp(pinCol, PEG_COLOR[k], 0.35f) : (p.temp ? rgbLerp(pinCol, 0xc8a070, 0.4f) : pinCol);
    g.fillCircle(c, p.r, rgbScale(col, 0.55f), al);
    g.fillCircle(c + V2(-0.4f, -0.6f), p.r * 0.82f, col, al);
    g.fillCircle(c + V2(-p.r * 0.3f, -p.r * 0.35f), p.r * 0.3f, 0xffffff, 0.55f * al);
    return;
  }
  uint32_t col = PEG_COLOR[k];
  if (isEnchant(k)) {
    float pulse = 0.75f + 0.25f * std::sin(t * 4 + p.id);
    float r = p.r + 1.5f;
    g.additive(true);
    g.glow(c, r * 3.4f, col, (k == PK_CURSE || k == PK_VOID ? 0.35f : 0.42f) * pulse * al);
    g.additive(false);
    if (k == PK_CRYSTAL) {
      V2 d[4] = {c + V2(0, -r * 1.25f), c + V2(r, 0), c + V2(0, r * 1.25f), c + V2(-r, 0)};
      g.fillPoly(d, 4, col, al);
      g.strokePoly(d, 4, 0xffffff, 0.6f * al, 1.f);
      return;
    }
    if (k == PK_VOID) {
      g.fillCircle(c, r, 0x05030a, al);
      g.arc(c, r, t * 3, t * 3 + PI * 1.3f, col, al, 1.8f);
      return;
    }
    if (k == PK_STAR) {
      star(g, c, r * 1.35f, r * 0.6f, 5, col, al);
      g.fillCircle(c, r * 0.35f, 0xffffff, 0.8f * al);
      return;
    }
    if (k == PK_MOON) {
      g.fillCircle(c, r, col, al);
      g.fillCircle(c + V2(r * 0.45f, -r * 0.3f), r * 0.85f, 0x10131a, al);
      return;
    }
    if (k == PK_DICE) {
      g.fillRRect(c.x - r, c.y - r, r * 2, r * 2, 2.5f, 0xf4f4f4, al);
      int face = 1 + (int)(std::fmod(t * 2.5f + p.id * 0.7f, 6.f));
      static const float PX[6][6][2] = {{{0, 0}},
                                        {{-0.45f, -0.45f}, {0.45f, 0.45f}},
                                        {{-0.45f, -0.45f}, {0, 0}, {0.45f, 0.45f}},
                                        {{-0.45f, -0.45f}, {0.45f, -0.45f}, {-0.45f, 0.45f}, {0.45f, 0.45f}},
                                        {{-0.45f, -0.45f}, {0.45f, -0.45f}, {0, 0}, {-0.45f, 0.45f}, {0.45f, 0.45f}},
                                        {{-0.45f, -0.5f}, {0.45f, -0.5f}, {-0.45f, 0}, {0.45f, 0}, {-0.45f, 0.5f}, {0.45f, 0.5f}}};
      for (int i = 0; i < face; ++i) g.fillCircle(c + V2(PX[face - 1][i][0] * r, PX[face - 1][i][1] * r), r * 0.17f, 0x101010, al);
      return;
    }
    if (k == PK_PRISM) {
      V2 tri[3] = {c + V2(0, -r * 1.25f), c + V2(r * 1.1f, r * 0.8f), c + V2(-r * 1.1f, r * 0.8f)};
      g.fillPoly(tri, 3, 0x40405a, al);
      g.strokePoly(tri, 3, rgbLerp(0xff8080, 0x80c0ff, 0.5f + 0.5f * std::sin(t * 3 + p.id)), al, 1.8f);
      g.line(c + V2(-r * 0.5f, r * 0.2f), c + V2(r * 0.5f, r * 0.2f), 0xffffff, 0.5f * al, 1.f);
      return;
    }
    if (k == PK_BLOOD) {
      g.fillCircle(c + V2(0, r * 0.2f), r * 0.85f, col, al);
      V2 tri[3] = {c + V2(0, -r * 1.2f), c + V2(r * 0.75f, 0), c + V2(-r * 0.75f, 0)};
      g.fillPoly(tri, 3, col, al);
      g.fillCircle(c + V2(-r * 0.3f, r * 0.1f), r * 0.2f, 0xffb0b0, 0.7f * al);
      return;
    }
    if (k == PK_SNOWBALL) {
      g.fillCircle(c, r * 1.1f, 0xe8f4ff, al);
      g.circle(c, r * 1.1f, 0x90c0e0, al, 1.2f);
      g.fillCircle(c + V2(-r * 0.3f, -r * 0.35f), r * 0.3f, 0xffffff, al);
      return;
    }
    if (k == PK_JACKPOT) {
      g.fillCircle(c, r * 1.1f, 0x5a4000, al);
      g.circle(c, r * 1.1f, col, al, 2.f);
      g.text("$", c.x - 10, c.y - 10, 20, 20, 11.5f, col, al, F_MONOB, AL_C, VA_M);
      return;
    }
    if (k == PK_CHAOS) {
      uint32_t cc = rgbLerp(0xff60ff, 0x60ffff, 0.5f + 0.5f * std::sin(t * 5 + p.id));
      g.fillCircle(c, r, rgbScale(cc, 0.6f), al);
      g.fillCircle(c, r * 0.8f, cc, al);
      g.text("?", c.x - 10, c.y - 10, 20, 20, 10.5f, 0x10131a, al, F_MONOB, AL_C, VA_M);
      return;
    }
    g.fillCircle(c, r, k == PK_CURSE ? 0x1a0826 : rgbScale(col, 0.6f), al);
    g.fillCircle(c, r * 0.8f, k == PK_CURSE ? 0x2a0a3a : col, al);
    const char* gl = pegGlyph(k);
    if (*gl) g.text(gl, c.x - 10, c.y - 10, 20, 20, 10.5f, k == PK_CURSE ? 0xff5070 : 0x10131a, al, F_MONOB, AL_C, VA_M);
    return;
  }
  switch (k) {
    case PK_BOMB: {
      float blink = std::sin(t * 9 + p.id) > 0 ? 1.f : 0.4f;
      g.fillCircle(c, p.r + 1, 0x2a1a14, al);
      g.circle(c, p.r + 1, 0xff8020, al, 1.6f);
      g.line(c + V2(p.r * 0.4f, -p.r * 0.8f), c + V2(p.r * 0.9f, -p.r * 1.5f), 0xc0a080, al, 1.5f);
      g.additive(true);
      g.glow(c + V2(p.r * 0.95f, -p.r * 1.6f), 7, 0xffc040, blink * al);
      g.additive(false);
      break;
    }
    case PK_MBOMB: {
      float pulse = 0.6f + 0.4f * std::sin(t * 7);
      bool meteor = p.r > 12;
      g.additive(true);
      g.glow(c, p.r * 3.2f, meteor ? 0xff6010 : 0xff2020, (meteor ? 0.7f : 0.5f) * pulse * al);
      g.additive(false);
      g.fillCircle(c, p.r, meteor ? 0x502008 : 0x401010, al);
      g.circle(c, p.r, meteor ? 0xffa040 : 0xff4040, al, meteor ? 3.f : 2.f);
      if (meteor) {
        g.circle(c, p.r + 6 + 3 * std::sin(t * 6), 0xff6010, 0.6f * al, 1.5f);
        for (int i = 0; i < std::max(1, p.aux); ++i) g.fillCircle(V2(c.x - (p.aux - 1) * 5.f + i * 10.f, c.y + p.r + 7), 3, 0xffc080, al);
      }
      g.text(std::to_string(p.val), c.x - 12, c.y - 12, 24, 24, meteor ? 15.f : 12.f, 0xffffff, al, F_MONOB, AL_C, VA_M);
      break;
    }
    case PK_LOOT: {
      static const uint32_t TC[4] = {0xe8e8f0, 0x6aa0ff, 0xffe060, 0xffa838};
      uint32_t lc = TC[clampv(p.val, 0, 3)];
      float pulse = 0.7f + 0.3f * std::sin(t * 5 + p.id);
      g.additive(true);
      g.glow(c, p.r * (3.f + p.val), lc, (0.45f + 0.1f * p.val) * pulse * al);
      g.additive(false);
      g.fillCircle(c, p.r, rgbScale(lc, 0.45f), al);
      g.fillCircle(c, p.r * 0.72f, lc, al);
      star(g, c, p.r * 0.55f, p.r * 0.22f, 4, 0xffffff, 0.9f * al);
      if (p.val >= 2) g.circle(c, p.r + 4 + 2 * std::sin(t * 4), lc, 0.7f * al, 1.5f);
      break;
    }
    case PK_SHRINE: {
      bool live = p.hp > 0;
      uint32_t sc = live ? 0xfff0c0 : 0x807868;
      if (live) {
        g.additive(true);
        g.glow(c, p.r * 3.4f, 0xfff0c0, (0.35f + 0.15f * std::sin(t * 2 + p.id)) * al);
        g.additive(false);
      }
      V2 ob[5] = {c + V2(0, -p.r * 1.3f), c + V2(p.r * 0.7f, -p.r * 0.5f), c + V2(p.r * 0.6f, p.r), c + V2(-p.r * 0.6f, p.r),
                  c + V2(-p.r * 0.7f, -p.r * 0.5f)};
      g.fillPoly(ob, 5, live ? 0x5a5040 : 0x3a3630, al);
      g.strokePoly(ob, 5, sc, al, 1.8f);
      if (live) star(g, c + V2(0, -p.r * 0.1f), p.r * 0.45f, p.r * 0.18f, 4, 0xffffff, al);
      break;
    }
    case PK_WELL: {
      bool live = p.hp > 0;
      g.fillCircle(c, p.r, 0x4a4a52, al);
      g.fillCircle(c, p.r * 0.72f, live ? 0x2070c0 : 0x202428, al);
      if (live) {
        g.additive(true);
        g.glow(c, p.r * 2.4f, 0x60d0ff, (0.3f + 0.15f * std::sin(t * 3)) * al);
        g.additive(false);
        g.arc(c, p.r * 0.45f, t * 2, t * 2 + PI, 0xa0e0ff, al, 1.5f);
      }
      for (int i = 0; i < p.hp; ++i) g.fillCircle(V2(c.x - (p.hp - 1) * 3.f + i * 6.f, c.y + p.r + 4), 1.8f, 0x80d0ff, al);
      break;
    }
    case PK_MIMIC: {
      // looks just like a chest... almost
      g.additive(true);
      g.glow(c, p.r * 2.6f, 0xffc040, 0.35f * al);
      g.additive(false);
      g.fillRRect(c.x - p.r, c.y - p.r * 0.75f, p.r * 2, p.r * 1.5f, 3, 0x7a4a20, al);
      g.fillRect(c.x - p.r, c.y - p.r * 0.2f, p.r * 2, p.r * 0.25f, 0xffd040, al);
      g.fillRect(c.x - 2, c.y - p.r * 0.3f, 4, p.r * 0.5f, 0xfff0a0, al);
      g.rrect(c.x - p.r, c.y - p.r * 0.75f, p.r * 2, p.r * 1.5f, 3, 0xffd040, 0.8f * al, 1.2f);
      if (std::fmod(t + p.id * 0.37f, 4.f) < 0.25f) g.fillCircle(c + V2(-p.r * 0.5f, p.r * 0.05f), 1.6f, 0xffffff, al);  // a glint of teeth
      for (int i = 0; i < p.hp; ++i) g.fillCircle(V2(c.x - (p.hp - 1) * 3.f + i * 6.f, c.y + p.r + 4), 1.8f, 0xffd040, al);
      break;
    }
    case PK_SHARD: {
      g.additive(true);
      g.glow(c, p.r * 3.f, 0xd0a0ff, (0.4f + 0.2f * std::sin(t * 4 + p.id)) * al);
      g.additive(false);
      V2 d[4] = {c + V2(0, -p.r * 1.4f), c + V2(p.r * 0.6f, -p.r * 0.1f), c + V2(0, p.r * 1.2f), c + V2(-p.r * 0.55f, 0)};
      g.fillPoly(d, 4, 0xb080ff, al);
      g.strokePoly(d, 4, 0xffffff, 0.7f * al, 1.f);
      break;
    }
    case PK_PINATA: {
      float wob = std::sin(t * 3 + p.id) * 0.12f + p.flash * 0.3f;
      g.pushXf(Xf::rotate(wob, c.x, c.y));
      static const uint32_t PC[4] = {0xff80c0, 0xffd040, 0x60e0ff, 0x80ff80};
      for (int i = 0; i < 4; ++i) g.fillRect(c.x - p.r, c.y - p.r * 0.8f + i * p.r * 0.4f, p.r * 2, p.r * 0.42f, PC[i], al);
      g.rrect(c.x - p.r, c.y - p.r * 0.8f, p.r * 2, p.r * 1.6f, 3, 0xffffff, 0.6f * al, 1.f);
      g.fillCircle(c + V2(p.r * 0.7f, -p.r * 0.9f), p.r * 0.3f, 0xff80c0, al);
      g.popXf();
      for (int i = 0; i < p.hp; ++i) g.fillCircle(V2(c.x - (p.hp - 1) * 3.f + i * 6.f, c.y + p.r + 4), 1.8f, 0xff80c0, al);
      break;
    }
    case PK_GEM: {
      uint32_t gc = STAT_COLOR[clampv(p.aux, 0, STAT_COUNT - 1)];
      g.additive(true);
      g.glow(c, p.r * 3.f, gc, (0.45f + 0.2f * std::sin(t * 5 + p.id)) * al);
      g.additive(false);
      V2 d[6] = {c + V2(-p.r * 0.6f, -p.r * 0.7f), c + V2(p.r * 0.6f, -p.r * 0.7f), c + V2(p.r, -p.r * 0.1f), c + V2(0, p.r),
                 c + V2(-p.r, -p.r * 0.1f), c + V2(-p.r * 0.6f, -p.r * 0.7f)};
      g.fillPoly(d, 5, gc, al);
      g.strokePoly(d, 5, 0xffffff, 0.8f * al, 1.f);
      g.line(c + V2(-p.r, -p.r * 0.1f), c + V2(p.r, -p.r * 0.1f), 0xffffff, 0.5f * al, 1.f);
      break;
    }
    case PK_EGG: {
      float wob = std::sin(t * (p.val <= 1 ? 12.f : 4.f) + p.id) * (p.val <= 1 ? 0.18f : 0.06f);
      g.pushXf(Xf::rotate(wob, c.x, c.y));
      g.fillEllipse(c, p.r * 0.85f, p.r * 1.1f, 0xe8dcc0, al);
      g.fillEllipse(c + V2(-p.r * 0.25f, -p.r * 0.35f), p.r * 0.2f, p.r * 0.3f, 0xffffff, 0.6f * al);
      g.fillCircle(c + V2(p.r * 0.2f, p.r * 0.25f), p.r * 0.14f, 0x9a8a70, al);
      g.popXf();
      g.text(std::to_string(p.val), c.x - 12, c.y + p.r - 2, 24, 14, 10, p.val <= 1 ? 0xff6060 : 0xe0d0a0, al, F_MONOB, AL_C, VA_T);
      break;
    }
    case PK_GLASS:
      g.fillCircle(c, p.r, 0xd0f0ff, 0.35f * al);
      g.circle(c, p.r, 0xe8f8ff, 0.9f * al, 1.3f);
      g.fillCircle(c + V2(-p.r * 0.35f, -p.r * 0.35f), p.r * 0.3f, 0xffffff, 0.8f * al);
      break;
    case PK_STONE: {
      g.fillRRect(c.x - p.r, c.y - p.r, p.r * 2, p.r * 2, 3, 0x6a645c, al);
      g.rrect(c.x - p.r, c.y - p.r, p.r * 2, p.r * 2, 3, 0xa8a098, al, 1.2f);
      if (p.hp <= 2) g.line(c + V2(-p.r * 0.6f, -p.r * 0.2f), c + V2(p.r * 0.2f, p.r * 0.5f), 0x2a2622, al, 1.3f);
      if (p.hp <= 1) g.line(c + V2(p.r * 0.5f, -p.r * 0.6f), c + V2(-p.r * 0.1f, p.r * 0.1f), 0x2a2622, al, 1.3f);
      break;
    }
    case PK_BUMPER: {
      float f = p.flash;
      g.additive(true);
      g.glow(c, p.r * 2.4f, 0xff70b0, (0.35f + 0.5f * f) * al);
      g.additive(false);
      g.fillCircle(c, p.r, 0x5a1a3a, al);
      g.circle(c, p.r - 1.5f, 0xff70b0, al, 3);
      g.fillCircle(c, p.r * 0.45f, rgbLerp(0xff70b0, 0xffffff, f), al);
      if (p.ttl > 0) g.text(std::to_string(p.ttl), c.x - 10, c.y + p.r - 2, 20, 14, 10, 0xffd0e8, 0.8f * al, F_MONOB, AL_C, VA_T);
      break;
    }
    case PK_MUSHROOM: {
      g.fillRect(c.x - p.r * 0.3f, c.y, p.r * 0.6f, p.r * 0.9f, 0xe8d8c8, al);
      g.fillEllipse(c + V2(0, -p.r * 0.1f), p.r, p.r * 0.75f, 0xa040c0, al);
      g.fillCircle(c + V2(-p.r * 0.4f, -p.r * 0.3f), p.r * 0.18f, 0xffffff, 0.8f * al);
      g.fillCircle(c + V2(p.r * 0.35f, -p.r * 0.4f), p.r * 0.14f, 0xffffff, 0.8f * al);
      if (p.flash > 0) {
        g.additive(true);
        g.glow(c, p.r * 2.4f, 0xe070ff, p.flash * al);
        g.additive(false);
      }
      break;
    }
    case PK_CHEST: {
      bool relic = p.val == 99;
      uint32_t body = relic ? 0x7a3a8a : 0x7a4a20;
      g.additive(true);
      g.glow(c, p.r * 2.6f, relic ? 0xd080ff : 0xffc040, 0.35f * al);
      g.additive(false);
      g.fillRRect(c.x - p.r, c.y - p.r * 0.75f, p.r * 2, p.r * 1.5f, 3, body, al);
      g.fillRect(c.x - p.r, c.y - p.r * 0.2f, p.r * 2, p.r * 0.25f, 0xffd040, al);
      g.fillRect(c.x - 2, c.y - p.r * 0.3f, 4, p.r * 0.5f, 0xfff0a0, al);
      g.rrect(c.x - p.r, c.y - p.r * 0.75f, p.r * 2, p.r * 1.5f, 3, 0xffd040, 0.8f * al, 1.2f);
      for (int i = 0; i < p.hp; ++i) g.fillCircle(V2(c.x - (p.hp - 1) * 3.f + i * 6.f, c.y + p.r + 4), 1.8f, 0xffd040, al);
      break;
    }
    case PK_KEY: {
      g.additive(true);
      g.glow(c, p.r * 3.f, 0xffe070, 0.5f * al);
      g.additive(false);
      g.circle(c + V2(-p.r * 0.35f, 0), p.r * 0.45f, 0xffe070, al, 2.2f);
      g.line(c + V2(0.1f, 0), c + V2(p.r, 0), 0xffe070, al, 2.2f);
      g.line(c + V2(p.r * 0.7f, 0), c + V2(p.r * 0.7f, p.r * 0.45f), 0xffe070, al, 2);
      break;
    }
    case PK_TOTEM: {
      g.fillRRect(c.x - p.r * 0.6f, c.y - p.r, p.r * 1.2f, p.r * 2, 3, 0x6a4020, al);
      g.rrect(c.x - p.r * 0.6f, c.y - p.r, p.r * 1.2f, p.r * 2, 3, 0xd09050, al, 1.2f);
      g.fillCircle(c + V2(-p.r * 0.22f, -p.r * 0.3f), 1.8f, 0xffd060, al);
      g.fillCircle(c + V2(p.r * 0.22f, -p.r * 0.3f), 1.8f, 0xffd060, al);
      g.line(c + V2(-p.r * 0.25f, p.r * 0.25f), c + V2(p.r * 0.25f, p.r * 0.25f), 0xffd060, al, 1.3f);
      break;
    }
    case PK_BONE:
    case PK_SKELETON: {
      g.fillCircle(c, p.r, 0x3a3830, al);
      g.circle(c, p.r, 0xe8e0c8, al, 2);
      if (k == PK_BONE) {
        g.line(c + V2(-p.r * 0.5f, -p.r * 0.5f), c + V2(p.r * 0.5f, p.r * 0.5f), 0xe8e0c8, al, 2.5f);
        g.line(c + V2(p.r * 0.5f, -p.r * 0.5f), c + V2(-p.r * 0.5f, p.r * 0.5f), 0xe8e0c8, al, 2.5f);
      } else {
        g.text("Z", c.x - p.r, c.y - p.r, p.r * 2, p.r * 2, p.r * 1.3f, 0xffffff, al, F_MONOB, AL_C, VA_M);
      }
      break;
    }
    case PK_THORN: {
      V2 pts[10];
      for (int i = 0; i < 10; ++i) pts[i] = c + fromAng(i * TAU / 10 + t * 0.3f) * (i % 2 ? p.r * 0.5f : p.r * 1.15f);
      g.fillPoly(pts, 10, 0x5a8a38, al);
      g.fillCircle(c, p.r * 0.4f, 0x9ad060, al);
      break;
    }
    case PK_GOLEM:
    case PK_PILLAR:
    case PK_TREE: {
      uint32_t base = k == PK_TREE ? 0x2c6a2c : (k == PK_GOLEM ? 0x6a6050 : 0x6a6258);
      uint32_t rim = k == PK_TREE ? 0x70e070 : (k == PK_GOLEM ? 0xd0c090 : 0xb0a898);
      if (p.flash > 0) {
        g.additive(true);
        g.glow(c, p.r * 2.2f, rim, p.flash * al);
        g.additive(false);
      }
      g.fillCircle(c, p.r, base, al);
      g.circle(c, p.r - 1, rim, al, 2.5f);
      if (k == PK_GOLEM) {
        g.fillCircle(c + V2(-p.r * 0.3f, -p.r * 0.15f), 2.5f, 0xffe080, al);
        g.fillCircle(c + V2(p.r * 0.3f, -p.r * 0.15f), 2.5f, 0xffe080, al);
        g.text("+" + std::to_string(p.val), c.x - 20, c.y + 1, 40, 14, 10, 0xffffff, 0.8f * al, F_MONOB, AL_C, VA_T);
      } else if (k == PK_TREE) {
        for (int i = 0; i < 5; ++i) g.fillCircle(c + fromAng(i * TAU / 5) * p.r * 0.45f, p.r * 0.3f, 0x3c8a3c, al);
      } else {
        g.circle(c, p.r * 0.55f, rim, 0.6f * al, 1.5f);
        for (int i = 0; i < p.hp; ++i) g.fillCircle(V2(c.x - (p.hp - 1) * 2.5f + i * 5.f, c.y), 1.5f, 0xffffff, al);
      }
      break;
    }
    case PK_TULIP: {
      bool open = p.aux != 0;
      g.additive(true);
      g.glow(c, p.r * 2.6f, col, (open ? 0.55f : 0.3f + 0.4f * p.flash) * al);
      g.additive(false);
      g.fillCircle(c, p.r * 0.75f, open ? 0xffb0d8 : 0xc05090, al);
      g.circle(c, p.r * 0.75f, 0xffe0f0, 0.8f * al, 1.2f);
      g.line(c + V2(0, p.r * 0.75f), c + V2(0, p.r + 6), 0x60b060, al, 2);
      break;
    }
    case PK_CHUCKER: {
      g.additive(true);
      g.glow(c, p.r * 2.8f, col, (0.35f + 0.5f * p.flash) * al);
      g.additive(false);
      g.fillRRect(c.x - p.r, c.y - p.r * 0.7f, p.r * 2, p.r * 1.4f, 3, 0x3a2a08, al);
      g.rrect(c.x - p.r, c.y - p.r * 0.7f, p.r * 2, p.r * 1.4f, 3, col, al, 1.5f);
      g.text("7", c.x - p.r, c.y - p.r, p.r * 2, p.r * 2, p.r * 1.2f, 0xff4050, al, F_MONOB, AL_C, VA_M);
      break;
    }
    case PK_TARGET: {
      bool down = p.val != 0;
      uint32_t tc = down ? 0x503020 : col;
      g.fillRRect(c.x - p.r * 0.55f, c.y - p.r, p.r * 1.1f, p.r * 2, 2, tc, down ? 0.5f * al : al);
      g.rrect(c.x - p.r * 0.55f, c.y - p.r, p.r * 1.1f, p.r * 2, 2, down ? 0x806050 : 0xffd0b0, al, 1.2f);
      if (!down) g.fillCircle(c, p.r * 0.3f, 0xffffff, 0.8f * al);
      break;
    }
    case PK_MAGNET: {
      g.additive(true);
      g.glow(c, 60, 0xa0a0ff, (0.12f + 0.06f * std::sin(t * 3)) * al);
      g.additive(false);
      g.arc(c, p.r * 0.75f, PI * 0.9f, PI * 2.1f, 0xd04040, al, p.r * 0.5f);
      g.fillRect(c.x - p.r * 0.95f, c.y - 1, p.r * 0.45f, p.r * 0.7f, 0xe0e0e0, al);
      g.fillRect(c.x + p.r * 0.5f, c.y - 1, p.r * 0.45f, p.r * 0.7f, 0xe0e0e0, al);
      break;
    }
    case PK_COINS: {
      for (int i = 0; i < std::max(1, p.hp); ++i)
        g.fillEllipse(c + V2(0, p.r * 0.5f - i * 3.f), p.r, p.r * 0.45f, i % 2 ? 0xffc840 : 0xffe070, al);
      g.fillEllipse(c + V2(0, p.r * 0.5f - (std::max(1, p.hp) - 1) * 3.f), p.r * 0.6f, p.r * 0.25f, 0xfff4b0, al);
      break;
    }
    case PK_SPRING: {
      g.fillRRect(c.x - p.r, c.y + p.r * 0.2f, p.r * 2, p.r * 0.7f, 3, 0x2a5a50, al);
      for (int i = 0; i < 3; ++i) g.arc(c + V2(0, p.r * 0.1f - i * 4.f), p.r * 0.7f, PI, TAU, col, al, 2);
      g.fillRRect(c.x - p.r * 0.8f, c.y - p.r, p.r * 1.6f, p.r * 0.4f, 2, rgbLerp(col, 0xffffff, p.flash), al);
      break;
    }
    case PK_IMP: allyPeg(a, p, al, "i", col); break;
    case PK_HOUND: allyPeg(a, p, al, "h", col); break;
    case PK_FAMILIAR: allyPeg(a, p, al, "f", col); break;
    case PK_ANGEL: allyPeg(a, p, al, "A", col); break;
    case PK_TESLA: {
      allyPeg(a, p, al, "", col);
      g.line(c + V2(-p.r * 0.4f, -p.r * 0.5f), c + V2(p.r * 0.1f, 0), 0xffffff, al, 2);
      g.line(c + V2(p.r * 0.1f, 0), c + V2(-p.r * 0.1f, p.r * 0.1f), 0xffffff, al, 2);
      g.line(c + V2(-p.r * 0.1f, p.r * 0.1f), c + V2(p.r * 0.4f, p.r * 0.6f), 0xffffff, al, 2);
      break;
    }
    case PK_FIREFLY: {
      float pulse = 0.6f + 0.4f * std::sin(t * 6 + p.id);
      g.additive(true);
      g.glow(c, p.r * 3.f, p.temp ? 0xa0ffa0 : col, 0.6f * pulse * al);
      g.additive(false);
      g.fillCircle(c, p.r * 0.7f, p.temp ? 0xd0ffd0 : 0xffffc0, al);
      break;
    }
    case PK_BELL: {
      V2 pts[6] = {c + V2(-p.r * 0.5f, -p.r * 0.7f), c + V2(p.r * 0.5f, -p.r * 0.7f), c + V2(p.r * 0.75f, p.r * 0.4f),
                   c + V2(p.r, p.r * 0.7f), c + V2(-p.r, p.r * 0.7f), c + V2(-p.r * 0.75f, p.r * 0.4f)};
      g.additive(true);
      g.glow(c, p.r * 2.4f, col, (0.25f + 0.5f * p.flash) * al);
      g.additive(false);
      g.fillPoly(pts, 6, 0xc8a040, al);
      g.strokePoly(pts, 6, col, al, 1.4f);
      g.fillCircle(c + V2(0, p.r * 0.85f), p.r * 0.2f, 0xfff0c0, al);
      break;
    }
    case PK_GHOST: {
      float ga = g_ghostSolid ? 0.9f : 0.25f;
      uint32_t gc = rgbLerp(pinCol, col, 0.6f);
      g.fillCircle(c, p.r, gc, ga * al);
      g.circle(c, p.r + 1.5f, 0xd0d8ff, (g_ghostSolid ? 0.5f : 0.3f) * al, 1);
      break;
    }
    default:
      g.fillCircle(c, p.r, col, al);
      break;
  }
}

// ------------------------------------------------------------------ monsters
void drawMonsterBody(App& a, const Monster& m, V2 pos, float al) {
  Gfx& g = a.g;
  const MonDef& d = monLook(m);
  float r = m.r;
  float bob = m.act > 0 ? std::sin(m.act * PI) * 4.f : 0.f;
  V2 c = pos + V2(0, -bob);
  if (m.boss) {
    g.additive(true);
    g.glow(c, r * 1.9f, d.color, 0.35f * al);
    g.additive(false);
  }
  if (m.enraged) {
    g.additive(true);
    g.glow(c, r * 1.7f, 0xff2020, (0.35f + 0.2f * std::sin(a.time * 8)) * al);
    g.additive(false);
  }
  g.fillCircle(c + V2(2, 3), r, 0x000000, 0.35f * al);
  g.fillCircle(c, r, rgbLerp(0x0c0e14, d.color, 0.18f), al);
  g.circle(c, r - 1.2f, m.charmed ? 0xff90ff : d.color, al, m.boss ? 3.5f : 2.4f);
  if (m.elite || m.boss) g.circle(c, r + 3, 0xffd040, 0.8f * al, 1.5f);
  if (m.champ) {
    uint32_t cc = m.champ == 2 ? 0xffc040 : 0x6aa0ff;
    g.additive(true);
    g.glow(c, r * 1.8f, cc, (0.3f + 0.12f * std::sin(a.time * 3 + m.id)) * al);
    g.additive(false);
    g.circle(c, r + 5, cc, 0.9f * al, 2.f);
    if (m.champ == 2) g.circle(c, r + 9, cc, 0.5f * al, 1.2f);
  }
  if (m.def == M_TREASURE) {
    for (int i = 0; i < 3; ++i) {
      float an = a.time * 2.5f + i * TAU / 3;
      g.fillCircle(c + fromAng(an) * (r + 7), 2.2f, 0xffe060, al);
    }
  }
  float gs = r * (strlen(d.glyph) > 1 ? 0.9f : 1.2f);
  g.text(d.glyph, c.x - r, c.y - r - 1, r * 2, r * 2, gs, d.color, al, F_MONOB, AL_C, VA_M);
  if (m.flash > 0) g.fillCircle(c, r, 0xffffff, 0.55f * m.flash * al);
  if (m.frozen > 0) {
    g.fillCircle(c, r, 0xa0e8ff, 0.3f * al);
    g.circle(c, r + 2, 0xd0f4ff, al, 2);
  } else if (m.chilled > 0) {
    g.circle(c, r + 2, 0x90d8ff, 0.6f * al, 1.3f);
  }
  if (m.shield > 0) {
    g.additive(true);
    g.circle(c, r + 5, 0x80a8ff, 0.8f * al, 2.5f);
    g.additive(false);
  }
  if (m.hexT > 0) g.arc(c, r + 8, a.time * 2, a.time * 2 + PI * 1.2f, 0xb050ff, 0.8f * al, 2);
  if (m.corruptT > 0) g.arc(c, r + 11, -a.time * 1.5f, -a.time * 1.5f + PI * 0.8f, 0x8040e0, 0.8f * al, 2.5f);
  if (m.charmed) {
    g.fillCircle(c + V2(r * 0.7f, -r * 0.7f), 6, 0xff90ff, al);
    g.text("<3", c.x + r * 0.7f - 10, c.y - r * 0.7f - 8, 20, 16, 9, 0x200820, al, F_MONOB, AL_C, VA_M);
  }
  if (m.bounty) {
    V2 bc = c + V2(-r * 0.75f, -r * 0.75f);
    V2 pts[10];
    for (int i = 0; i < 10; ++i) pts[i] = bc + fromAng(-PI / 2 + i * PI / 5) * (i % 2 ? 3.5f : 8.f);
    g.fillPoly(pts, 10, 0xffd040, al);
  }
}
