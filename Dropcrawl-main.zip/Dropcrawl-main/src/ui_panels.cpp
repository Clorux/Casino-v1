// Dropcrawl - left (character) and right (floor / log) panels
#include "app.h"

static const char* ITEM_KEYS[8] = {"Z", "X", "C", "V", "B", "N", "", ""};

// Invocations live in their own window (G), apart from the 1-9 ability slots, so learning an ability can never shift
// a hotkey onto something that spends piety.
std::vector<int> activeList(const World& w) {
  std::vector<int> v;
  for (auto& a : w.pl.abil)
    if (ABIL[a.id].timing != T_PASSIVE && ABIL[a.id].school != SCH_DIVINE) v.push_back(a.id);
  return v;
}

std::vector<int> invocationList(const World& w) {
  std::vector<int> v;
  if (w.pl.patron >= 0)
    for (int k = 0; k < 5; ++k) {
      int g = PATRON[w.pl.patron].gifts[k];
      if (ABIL[g].timing != T_PASSIVE && w.pl.piety >= PIETY_STAR[k]) v.push_back(g);
    }
  return v;
}

static bool usesCursor(int ab) { return ab == AB_NUDGE || ab == AB_BLINK || ab == AB_ROTOR || ab == AB_TEMPEST; }

void tryCast(App& a, int ab, bool fromHotkey) {
  World& w = a.w;
  std::string why;
  if (!abilityUsable(w, ab, &why)) {
    audio::play(S_DENY, 0.6f);
    fxText(w, V2(190, 470), 0xff9090, why, 14);
    return;
  }
  const AbilityDef& d = ABIL[ab];
  if (d.target != TG_NONE || (usesCursor(ab) && !fromHotkey)) {
    a.targetAb = ab;
    a.targetItem = -1;
    a.targetStage = 0;
    audio::play(S_CLICK, 0.5f, 1.1f);
    return;
  }
  if (!castAbility(w, ab, a.in.mouse, a.in.mouse, -1)) {
    audio::play(S_DENY, 0.6f);
    fxText(w, V2(190, 470), 0xff9090, "That would have no effect right now.", 14);
  }
}

void tryUseItem(App& a, int slot) {
  World& w = a.w;
  std::string why;
  if (!itemUsable(w, slot, &why)) {
    audio::play(S_DENY, 0.6f);
    fxText(w, V2(190, 700), 0xff9090, why, 14);
    return;
  }
  const ItemDef& d = ITEM[w.pl.items[slot].id];
  if (d.target == TG_MONSTER || d.target == TG_POINT) {
    a.targetItem = slot;
    a.targetAb = -1;
    a.targetStage = 0;
    audio::play(S_CLICK, 0.5f, 1.1f);
    return;
  }
  if (!useItem(w, slot, a.in.mouse, focusTarget(w))) {
    audio::play(S_DENY, 0.6f);
    fxText(w, V2(190, 700), 0xff9090, "That would have no effect.", 14);
  }
}

static void bar(Gfx& g, float x, float y, float w, float h, float frac, uint32_t col, uint32_t bg, const std::string& label,
                float fs) {
  g.fillRRect(x, y, w, h, h * 0.45f, bg, 1.f);
  if (frac > 0) g.fillRRect(x, y, std::max(h, w * clampv(frac, 0.f, 1.f)), h, h * 0.45f, col, 1.f);
  g.fillRRect(x + 2, y + 1, w - 4, h * 0.4f, h * 0.3f, 0xffffff, 0.07f);
  if (!label.empty()) g.textSh(label, x, y, w, h, fs, 0xffffff, 1.f, F_UIB, AL_C, VA_M);
}

static std::string timingTag(int t) {
  switch (t) {
    case T_AIM: return "before launch";
    case T_FLIGHT: return "during flight";
    case T_ANY: return "any time";
  }
  return "passive";
}

static std::string itemLabel(const InvItem& it) {
  const ItemDef& d = ITEM[it.id];
  std::string n = d.name;
  if (n.rfind("Potion of ", 0) == 0) n = n.substr(10) + " potion";
  else if (n.rfind("Scroll of ", 0) == 0) n = n.substr(10) + " scroll";
  else if (n.rfind("Wand of ", 0) == 0) n = n.substr(8) + " wand";
  if (d.wand) n += fmt(" (%d)", it.charges);
  return n;
}

void drawLeftPanel(App& a) {
  Gfx& g = a.g;
  World& w = a.w;
  Player& pl = w.pl;
  const SpeciesDef& sp = SPECIES[pl.species];
  panelBox(a, 8, 8, 364, 884, sp.color);
  // header
  uint32_t ballCol = pl.draconic >= 0 ? DRACO_COLOR[pl.draconic] : (pl.species == SP_CHANGELING && pl.form >= 0 ? SPECIES[pl.form].color : sp.color);
  g.additive(true);
  g.glow(V2(36, 38), 30, ballCol, 0.4f);
  g.additive(false);
  g.fillCircle(V2(36, 38), 15, ballCol, 1.f);
  g.fillCircle(V2(31, 33), 5, 0xffffff, 0.7f);
  std::string title = std::string(sp.name) + " " + BGS[pl.bg].name;
  g.text(title, 60, 16, 300, 24, title.size() > 26 ? 16.f : 19.f, 0xffffff, 1.f, F_UIB);
  std::string sub = fmt("Level %d   Depth %d (%s)", pl.xl, w.depth, locationName(w));
  if (pl.draconic >= 0) sub += fmt("   %s", DRACO_NAME[pl.draconic]);
  if (pl.species == SP_CHANGELING && pl.form >= 0) sub += std::string("   as ") + SPECIES[pl.form].name;
  g.text(sub, 60, 40, 300, 18, 13, 0xa8b0c0, 1.f);
  if (mouseIn(a, 20, 16, 340, 42)) {
    std::string b = std::string(sp.desc) + "\n\n" + BGS[pl.bg].desc;
    std::string ms = mutationSummary(w, true);
    if (ms != "No mutations.") b += "\n\n" + ms;
    setTip(a, sp.name, b, sp.color);
  }
  // bars
  float hpf = pl.hp / (float)std::max(1, w.st.maxHp);
  uint32_t hpc = hpf > 0.5f ? 0xd83a3a : (hpf > 0.25f ? 0xe06a20 : 0xff2020);
  bar(g, 20, 64, 340, 24, hpf, rgbLerp(hpc, 0xffffff, a.hpFlash * 0.6f), 0x2a1216, fmt("HP  %d / %d", pl.hp, w.st.maxHp), 14);
  if (mouseIn(a, 20, 64, 340, 24))
    setTip(a, "Hit Points", "If this reaches 0 your run is over. Monsters' attacks are reduced by your Armor. You recover some HP after each floor.", 0xff6060);
  if (w.st.hpForMp) {
    bar(g, 20, 92, 340, 17, 0.f, 0x3a70e0, 0x121a30, "No MP: spells cost HP instead", 11.5f);
    if (mouseIn(a, 20, 92, 340, 17)) setTip(a, "Essence", "You have no magic of your own. Every spell is paid for with 1 HP per MP it would cost.", 0x60c0ff);
  } else {
    bar(g, 20, 92, 340, 17, pl.mp / (float)std::max(1, w.st.maxMp), 0x3a70e0, 0x121a30, fmt("MP  %d / %d", pl.mp, w.st.maxMp), 12);
    if (mouseIn(a, 20, 92, 340, 17))
      setTip(a, "Magic Points", fmt("Spent on active abilities. You regain %d MP at the start of each turn; Mana pegs and pockets restore more.", w.st.mpRegen), 0x6090ff);
  }
  int need = xpForLevel(pl.xl);
  bar(g, 20, 113, 340, 7, pl.xp / (float)std::max(1, need), 0xa060f0, 0x1c1228, "", 10);
  if (mouseIn(a, 20, 110, 340, 12))
    setTip(a, "Experience", fmt("%d / %d XP to level %d. Each level: +1 base power, more HP, and a new ability or upgrade.", pl.xp, need, pl.xl + 1), 0xc080ff);
  // stats line
  float sx = 20, sy = 126;
  auto stat = [&](const std::string& label, const std::string& val, uint32_t col, const char* tipT, const std::string& tipB) {
    float lw = g.measure(label, 12).x, vw = g.measure(val, 15, F_UIB).x;
    g.text(label, sx, sy + 3, lw + 4, 18, 12, 0x8890a0);
    g.text(val, sx + lw + 4, sy, vw + 4, 20, 15, col, 1.f, F_UIB);
    if (mouseIn(a, sx, sy, lw + vw + 8, 20)) setTip(a, tipT, tipB, col);
    sx += lw + vw + 14;
  };
  int ep = effPower(w);
  stat("Power", std::to_string(ep), powerColor(ep), "Base Power",
       "Every ball starts with this much power, and returns to it after hitting a monster. Pins add +1 power each.");
  stat("Armor", std::to_string(w.st.armor - (pl.corrode > 0 ? 2 : 0)), 0xa0b8ff, "Armor", "Reduces the damage of each monster attack (heavy attacks ignore it).");
  stat("Gold", std::to_string(pl.gold), 0xffd84a, "Gold", "Spend it in shops, and on some abilities.");
  if (pl.block > 0) stat("Block", std::to_string(pl.block), 0xc0c8ff, "Block", "Absorbs damage during the next enemy phase.");
  if (pl.species == SP_FELID) stat("Lives", std::to_string(pl.lives), 0xffd0a0, "Extra lives", "When you would die, you lose a life instead and return with half your HP.");
  // core stats
  for (int k = 0; k < STAT_COUNT; ++k) {
    float bx = 18 + k * 69.f, by = 148;
    int v = w.st.stat[k], base = pl.stat[k];
    bool hov = mouseIn(a, bx, by, 66, 20);
    g.fillRRect(bx, by, 66, 20, 5, STAT_COLOR[k], hov ? 0.24f : 0.12f);
    g.rrect(bx, by, 66, 20, 5, STAT_COLOR[k], 0.5f, 1);
    g.text(STAT_ABBR[k], bx + 6, by, 30, 20, 11, STAT_COLOR[k], 1.f, F_UIB, AL_L, VA_M);
    uint32_t vc = v > base ? 0x90ffb0 : v < base ? 0xff9090 : 0xffffff;
    g.text(std::to_string(v), bx + 30, by, 32, 20, 14, vc, 1.f, F_UIB, AL_R, VA_M);
    if (hov) setTip(a, STAT_NAME[k], statTooltip(w, k), STAT_COLOR[k]);
  }
  if (pl.statPoints > 0) {
    g.fillCircle(V2(356, 148), 7, 0xffe070, 1.f);
    g.text("+", 349, 141, 14, 14, 12, 0x201808, 1.f, F_MONOB, AL_C, VA_M);
  }
  // statuses
  float cx = 20, cy = 172;
  auto chip = [&](const std::string& s, uint32_t col, const char* tt, const std::string& tb) {
    float tw = g.measure(s, 12, F_UIB).x + 14;
    if (cx + tw > 364) return;
    g.fillRRect(cx, cy, tw, 18, 9, col, 0.2f);
    g.rrect(cx, cy, tw, 18, 9, col, 0.7f, 1);
    g.text(s, cx, cy, tw, 18, 12, col, 1.f, F_UIB, AL_C, VA_M);
    if (mouseIn(a, cx, cy, tw, 18)) setTip(a, tt, tb, col);
    cx += tw + 5;
  };
  const Floor& f = w.fl;
  bool onFloor = w.screen == RS_FLOOR;
  if (pl.poison > 0) chip(fmt("Poison %d", pl.poison), 0x90e040, "Poisoned", fmt("You take %d damage after the next enemy phase, then it halves.", pl.poison));
  if (pl.weak > 0) chip(fmt("Weak %d", pl.weak), 0xb0a0ff, "Weakened", "Your base power is halved.");
  if (pl.sapped > 0) chip(fmt("Sapped %d", pl.sapped), 0xb0a0ff, "Sapped", "-2 base power.");
  if (pl.slowed > 0) chip(fmt("Slowed %d", pl.slowed), 0x90a0ff, "Slowed", "You regain no MP at the start of your turns.");
  if (pl.corrode > 0) chip(fmt("Corroded %d", pl.corrode), 0xa0ff40, "Corroded", "-2 armor.");
  if (pl.cursedBall) chip("Drained ball", 0xb080ff, "Drained", "Your next ball starts with half power.");
  if (pl.deathsDoor > 0) chip(fmt("Death's Door %d", pl.deathsDoor), 0xc0c0ff, "Death's Door", "You cannot drop below 1 HP.");
  if (pl.guardBlocks > 0) chip(fmt("Guardian %d", pl.guardBlocks), 0xa0e0ff, "Guardian Spirit", "Fully blocks the next monster attack(s) during this turn's enemy phase.");
  if (pl.nextShotPower > 0) chip(fmt("Charged +%d", pl.nextShotPower), 0xff9040, "Charged", "Your next ball starts with extra power.");
  if (pl.nextShotDouble || (onFloor && f.shot.doubled)) chip("x2 damage", 0xff60a0, "Double", "Your next shot deals double damage.");
  if (onFloor) {
    if (f.shot.might) chip("Might", 0xff8040, "Might", "This shot: +50% damage.");
    if (f.shot.berserk) chip("Berserk", 0xff4040, "Berserk", "This shot deals double damage.");
    if (f.shot.doubleDown) chip("Double Down", 0xffd040, "Double Down", "Double damage this shot; take damage if you hit no monster.");
    if (f.pendingFree) chip("Free turn", 0x60ffa0, "Free turn", "Monsters won't act after your next shot.");
    if (f.timeStop > 0) chip(fmt("Time Stop %d", f.timeStop), 0xc8b890, "Time Stop", "Your next shots are free turns.");
    if (f.sanctuaryT > 0) chip("Sanctuary", 0x90ffb0, "Sanctuary", "Monster attacks deal half damage.");
    if (f.freeCasts) chip("Free casts", 0xa0c0ff, "Free casts", "Your spells cost no MP this turn.");
    if (f.shot.fireball) chip("Fireball", 0xff7020, "Fireball", "Your next monster hit explodes.");
    if (f.shot.chain) chip("Chain", 0xfff080, "Chain Lightning", "Your next monster hit arcs to other monsters.");
    if (f.shot.rebounds > 0) chip(fmt("Rebound %d", f.shot.rebounds), 0x9fc0ff, "Rebound", "Balls reaching the pockets bounce back up.");
    if (f.vulnTurn) chip("Vulnerable", 0xff80a0, "Vulnerability", "Monsters take +50% damage this turn.");
    if (f.streakPower > 0) chip(fmt("Streak +%d%%", f.streakPower), 0xffd040, "Hot Streak", "Consecutive shots that hit a monster deal more damage.");
    if (f.cardPower > 0) chip(fmt("Strength +%d", f.cardPower), 0xe0c0ff, "Strength card", "Bonus base power for the rest of this floor.");
    if (f.shot.diceMul10 != 10) chip(fmt("Dice x%.1f", f.shot.diceMul10 / 10.f), 0xff60ff, "Dice Ball", "This shot's damage is multiplied.");
    if (f.shrine >= 0) chip(SHRINE_NAME[f.shrine], 0xfff0c0, SHRINE_NAME[f.shrine], SHRINE_DESC[f.shrine]);
  }

  // ---------------- active abilities
  // up to 9 in full rows; with more, up to 12 in compact rows of the same total height (keys 0, -, =)
  float y = 196;
  std::vector<int> acts = activeList(w);
  bool compact = acts.size() > 9;
  g.text("ABILITIES", 20, y, 200, 16, 12, 0x7880a0, 1.f, F_UIB);
  g.text(compact ? "click or press 1-9, 0, -, =" : "click or press 1-9", 160, y, 200, 16, 11, 0x5a6070, 1.f, F_UI, AL_R);
  y += 17;
  for (int i = 0; i < (int)acts.size() && i < MAX_ABILITY_KEYS; ++i) {
    int ab = acts[i];
    const AbilityDef& d = ABIL[ab];
    int lvl = abLevel(w, ab);
    int cd = 0;
    for (auto& o : pl.abil)
      if (o.id == ab) cd = o.cd;
    std::string why;
    bool usable = abilityUsable(w, ab, &why);
    bool rightTime = true;
    if (onFloor) {
      uint8_t ph = f.phase;
      if (d.timing == T_AIM) rightTime = ph == PH_AIM;
      if (d.timing == T_FLIGHT) rightTime = ph == PH_FLIGHT;
    } else rightTime = false;
    float rh = compact ? 22 : 30;
    bool hov = mouseIn(a, 16, y, 348, rh);
    uint32_t sc = SCHOOL_COLOR[d.school];
    bool selected = a.targetAb == ab;
    g.fillRRect(16, y, 348, rh, 6, selected ? 0x2a3050 : (hov ? 0x20263a : 0x151923), 1.f);
    g.fillRRect(16, y, 4, rh, 2, sc, usable ? 1.f : 0.35f);
    float ky = y + (rh - 19) / 2;
    g.fillRRect(26, ky, 19, 19, 4, 0x0a0c12, 1.f);
    g.text(ABILITY_KEY_LABEL[i], 26, ky, 19, 19, 12, usable ? 0xffffff : 0x606878, 1.f, F_MONOB, AL_C, VA_M);
    std::string nm = d.name;
    if (compact && lvl > 1) nm += fmt(" %d", lvl);
    g.text(nm, 52, compact ? y + 2 : y + 1, 196, 17, 13.5f, usable ? 0xffffff : (rightTime ? 0x9098a8 : 0x6a7282), 1.f, F_UIB);
    if (!compact) {
      std::string sub = d.innate ? "innate · " + timingTag(d.timing) : timingTag(d.timing);
      if (lvl > 1) sub += fmt("  lvl %d", lvl);
      g.text(sub, 52, y + 16, 196, 14, 10.5f, 0x707888);
    }
    int cost = abilityCost(w, ab, std::max(1, lvl));
    int hpc = abilityHpCost(w, ab, std::max(1, lvl));
    int gc = abilityGoldCost(w, ab, std::max(1, lvl));
    std::string cs;
    uint32_t ccol = 0x80a8ff;
    if (d.school == SCH_DIVINE) {
      cs = gc > 0 ? fmt("%d gold", gc) : fmt("%d piety", cost);
      ccol = gc > 0 ? 0xffd84a : 0xfff0c0;
    } else {
      if (gc > 0) cs = fmt("%d gold", gc), ccol = 0xffd84a;
      if (cost > 0) cs += (cs.empty() ? "" : " ") + fmt("%d MP", cost);
      if (hpc > 0) {
        cs += (cs.empty() ? "" : " ") + fmt("%d HP", hpc);
        if (cost == 0) ccol = 0xff7080;
      }
      if (cs.empty()) cs = "free";
      if (onFloor && (f.freeCasts || f.holsterFree) && cost > 0 && gc == 0 && hpc == 0) cs = "free";
    }
    if (compact) {
      // one line: cost, or how long it is still recharging
      if (cd > 0) g.text(fmt("recharging %d", cd), 228, y + 2, 128, 17, 12, 0xff9090, 1.f, F_UIB, AL_R);
      else g.text(cs, 228, y + 2, 128, 17, 12.5f, ccol, 1.f, F_UIB, AL_R);
    } else {
      g.text(cs, 248, y + 1, 108, 17, 12.5f, ccol, 1.f, F_UIB, AL_R);
      if (cd > 0) g.text(fmt("recharging %d", cd), 248, y + 16, 108, 14, 10.5f, 0xff9090, 1.f, F_UI, AL_R);
      else if (d.cooldown > 0) g.text(fmt("cooldown %d", d.cooldown), 248, y + 16, 108, 14, 10.5f, 0x606878, 1.f, F_UI, AL_R);
    }
    if (hov) {
      std::string body = abilityDesc(ab, std::max(1, lvl), false);
      body += "\n\n" + std::string(SCHOOL_NAME[d.school]) + " · " + timingTag(d.timing);
      if (d.cooldown > 0) body += fmt(" · cooldown %d", d.cooldown);
      if (!usable && !why.empty()) body += "\n(" + why + ")";
      setTip(a, std::string(d.name) + (lvl > 1 ? fmt(" (level %d)", lvl) : ""), body, sc);
      if (a.in.lPressed && !a.in.consumed) {
        a.in.consumed = true;
        if (selected) a.targetAb = -1;
        else tryCast(a, ab, false);
      }
    }
    y += rh + 2;
  }
  if (acts.empty()) {
    g.text("No active abilities yet.", 24, y + 4, 330, 18, 12, 0x5a6070);
    y += 24;
  }
  // ---------------- passives & mutations
  y += 5;
  g.text("PASSIVES & MUTATIONS", 20, y, 250, 16, 12, 0x7880a0, 1.f, F_UIB);
  y += 17;
  struct PChip {
    std::string label, title, body;
    uint32_t col;
  };
  std::vector<PChip> chips;
  for (auto& o : pl.abil)
    if (ABIL[o.id].timing == T_PASSIVE) {
      const AbilityDef& d = ABIL[o.id];
      chips.push_back({o.lvl > 1 ? fmt("%s %d", d.name, o.lvl) : std::string(d.name), std::string(d.name) + (o.lvl > 1 ? fmt(" (level %d)", o.lvl) : ""),
                       abilityDesc(d.id, o.lvl, false), SCHOOL_COLOR[d.school]});
    }
  if (pl.patron >= 0)
    for (int k = 0; k < 5; ++k) {
      int gft = PATRON[pl.patron].gifts[k];
      if (ABIL[gft].timing == T_PASSIVE && pl.piety >= PIETY_STAR[k])
        chips.push_back({ABIL[gft].name, ABIL[gft].name, abilityDesc(gft, 1, false), PATRON[pl.patron].color});
    }
  for (int m = 0; m < MUT_COUNT; ++m)
    if (pl.mut[m]) {
      const MutDef& md = MUTS[m];
      uint32_t mc = md.tier == 9 ? 0xff7070 : md.tier == 3 ? 0xffd040 : 0xe080ff;
      chips.push_back({md.maxLvl > 1 ? fmt("%s %d", md.name, pl.mut[m]) : std::string(md.name), md.name, resolveLevels(md.desc, pl.mut[m], false), mc});
    }
  for (int s = 0; s < SAC_COUNT; ++s)
    if (hasSacrifice(w, s)) chips.push_back({SACRIFICE_NAME[s] + 10,SACRIFICE_NAME[s], SACRIFICE_DESC[s], 0xe0c090});
  float px = 16, pyStart = y;
  for (size_t i = 0; i < chips.size(); ++i) {
    const PChip& c = chips[i];
    float tw = g.measure(c.label, 11.5f, F_UIB).x + 12;
    if (px + tw > 364) {
      px = 16;
      y += 21;
    }
    if (y > pyStart + 21 * 2) {
      // overflow: one chip lists the rest
      std::string rest;
      for (size_t j = i; j < chips.size(); ++j) rest += chips[j].title + ": " + chips[j].body + "\n";
      std::string lab = fmt("+%d more", (int)(chips.size() - i));
      float lw = g.measure(lab, 11.5f, F_UIB).x + 12;
      y = pyStart + 21 * 2;
      px = std::min(px, 364 - lw);
      g.fillRRect(px, y, lw, 18, 5, 0x9098a8, 0.18f);
      g.text(lab, px, y, lw, 18, 11.5f, 0xd0d8e8, 1.f, F_UIB, AL_C, VA_M);
      if (mouseIn(a, px, y, lw, 18)) setTip(a, "More passives", rest, 0xd0d8e8);
      break;
    }
    bool hov = mouseIn(a, px, y, tw, 18);
    g.fillRRect(px, y, tw, 18, 5, c.col, hov ? 0.28f : 0.14f);
    g.rrect(px, y, tw, 18, 5, c.col, 0.5f, 1);
    g.text(c.label, px, y, tw, 18, 11.5f, rgbLerp(c.col, 0xffffff, 0.5f), 1.f, F_UIB, AL_C, VA_M);
    if (hov) setTip(a, c.title, c.body, c.col);
    px += tw + 4;
  }
  if (chips.empty()) g.text("None yet.", 24, y, 330, 18, 12, 0x5a6070);
  y += 26;
  // ---------------- relics & randarts
  g.text("RELICS", 20, y, 200, 16, 12, 0x7880a0, 1.f, F_UIB);
  {
    std::string rs;
    if (!pl.randarts.empty()) rs = fmt("%d randart%s", (int)pl.randarts.size(), pl.randarts.size() > 1 ? "s" : "");
    if (pl.shards > 0) rs += (rs.empty() ? "" : "  ·  ") + fmt("shards %d/3", pl.shards);
    if (!rs.empty()) g.text(rs, 120, y, 240, 16, 11, pl.shards > 0 ? 0xd0a0ff : 0xffd060, 1.f, F_UI, AL_R);
    if (pl.shards > 0 && mouseIn(a, 200, y, 160, 16))
      setTip(a, "Relic shards", fmt("%d of 3. Three shards fuse into a relic of your choice.", pl.shards), 0xd0a0ff);
  }
  y += 17;
  float rx = 16, ryStart = y;
  int total = (int)pl.relics.size() + (int)pl.randarts.size();
  int idx = 0;
  bool clipped = false;
  auto relicSlot = [&](const char* glyph, uint32_t col, bool randart, const std::string& tt, const std::string& tb, uint32_t frame = 0) {
    if (clipped) return;
    if (rx + 30 > 364) {
      rx = 16;
      y += 31;
    }
    if (y > ryStart + 31 * 2) {
      clipped = true;
      y = ryStart + 31 * 2;
      return;
    }
    bool hov = mouseIn(a, rx, y, 28, 28);
    g.fillRRect(rx, y, 28, 28, 6, randart ? 0x1c1608 : 0x151923, 1.f);
    g.rrect(rx, y, 28, 28, 6, frame ? frame : col, hov ? 1.f : (frame ? 0.9f : 0.55f), (randart || frame) ? 2.f : 1.2f);
    if (randart) g.fillCircle(V2(rx + 24, y + 4), 2.5f, 0xffd060, 1.f);
    if (frame) g.fillCircle(V2(rx + 24, y + 4), 2.5f, frame, 1.f);
    g.text(glyph, rx, y, 28, 28, 16, col, 1.f, F_MONOB, AL_C, VA_M);
    if (hov) setTip(a, tt, tb, col);
    rx += 31;
    idx++;
  };
  for (size_t i = 0; i < pl.relics.size(); ++i) {
    const RelicDef& r = RELIC[pl.relics[i]];
    uint32_t nc = relicNameColor(w, (int)i);
    relicSlot(r.glyph, r.color, false, relicName(w, (int)i), relicTooltip(w, (int)i), nc == 0xe8e8f0 ? 0u : nc);
  }
  for (auto& ra : pl.randarts) relicSlot(randartGlyph(ra), ra.color, true, ra.name, "Randart\n" + randartDesc(ra));
  if (clipped) {
    std::string rest;
    int k = 0;
    for (size_t ri = 0; ri < pl.relics.size(); ++ri) if (k++ >= idx) rest += relicName(w, (int)ri) + "\n";
    for (auto& ra : pl.randarts) if (k++ >= idx) rest += std::string(ra.name) + "\n";
    g.text(fmt("+%d", total - idx), 330, y, 34, 28, 12, 0xd0d8e8, 1.f, F_UIB, AL_C, VA_M);
    if (mouseIn(a, 330, y, 34, 28)) setTip(a, "More relics", rest, 0xd0d8e8);
  }
  if (total == 0) g.text("None yet.", 24, y, 330, 18, 12, 0x5a6070);
  y += 34;
  // ---------------- items (two columns)
  g.text("ITEMS", 20, y, 200, 16, 12, 0x7880a0, 1.f, F_UIB);
  g.text("use before launching", 160, y, 200, 16, 11, 0x5a6070, 1.f, F_UI, AL_R);
  y += 17;
  for (int i = 0; i < (int)pl.items.size(); ++i) {
    const InvItem& it = pl.items[i];
    float ix = 16 + (i % 2) * 175, iy = y + (i / 2) * 24;
    bool hov = mouseIn(a, ix, iy, 172, 22);
    bool sel = a.targetItem == i;
    g.fillRRect(ix, iy, 172, 22, 5, sel ? 0x2a3050 : (hov && it.id >= 0 ? 0x20263a : 0x131720), 1.f);
    g.text(ITEM_KEYS[i % 8], ix + 3, iy, 14, 22, 11, 0x707888, 1.f, F_MONOB, AL_C, VA_M);
    if (it.id >= 0) {
      const ItemDef& d = ITEM[it.id];
      V2 ic(ix + 25, iy + 11);
      if (d.wand) {
        g.line(ic + V2(-5, 5), ic + V2(5, -5), d.color, 1.f, 3);
        g.fillCircle(ic + V2(5, -5), 2.5f, 0xffffff, 0.9f);
      } else {
        g.fillCircle(ic, 6, d.color, 1.f);
        if (d.potion) g.fillCircle(ic + V2(-2, -2), 2, 0xffffff, 0.7f);
        else g.rrect(ic.x - 5, ic.y - 5, 10, 10, 2, 0xffffff, 0.6f, 1);
      }
      g.text(itemLabel(it), ix + 35, iy, 134, 22, 11.5f, 0xe0e4ec, 1.f, F_UI, AL_L, VA_M);
      if (hov) {
        std::string body = d.desc;
        if (d.wand) body += fmt("\n\nWand: %d charge%s left. Aim it at a target.", it.charges, it.charges == 1 ? "" : "s");
        setTip(a, d.name, body, d.color);
        if (a.in.lPressed && !a.in.consumed) {
          a.in.consumed = true;
          if (sel) a.targetItem = -1;
          else tryUseItem(a, i);
        }
      }
    } else {
      g.text("(empty)", ix + 35, iy, 134, 22, 11, 0x464c58, 1.f, F_UI, AL_L, VA_M);
    }
  }
  y += ((int)pl.items.size() + 1) / 2 * 24;
  // ---------------- patron
  if (pl.patron >= 0) {
    const PatronDef& P = PATRON[pl.patron];
    float py = std::max(y + 6, 826.f);
    if (py > 850) py = 850;
    g.text(std::string(P.name) + " " + P.title, 20, py, 240, 18, 13.5f, P.color, 1.f, F_UIB);
    int stars = pietyStars(w);
    for (int k = 0; k < 5; ++k) {
      V2 c(272 + k * 18.f, py + 8);
      V2 pts[10];
      for (int i = 0; i < 10; ++i) pts[i] = c + fromAng(-PI / 2 + i * PI / 5) * (i % 2 ? 3.f : 7.f);
      if (k < stars) g.fillPoly(pts, 10, P.color, 1.f);
      else g.strokePoly(pts, 10, P.color, 0.5f, 1.2f);
    }
    int nextStar = stars < 5 ? PIETY_STAR[stars] : PIETY_MAX;
    const float BW = 234;
    bar(g, 20, py + 22, BW, 8, pl.piety / (float)PIETY_MAX, P.color, 0x1a1a24, "", 9);
    for (int k = 0; k < 5; ++k) {
      float xx = 20 + BW * PIETY_STAR[k] / (float)PIETY_MAX;
      g.line(V2(xx, py + 20), V2(xx, py + 32), 0xffffff, 0.5f, 1);
    }
    // the invocations window button (G)
    int ready = 0;
    std::vector<int> inv = invocationList(w);
    for (int ab : inv)
      if (pl.patron == PT_AURUM ? abilityGoldCost(w, ab, 1) <= pl.gold : abilityCost(w, ab, 1) <= pl.piety) ready++;
    float bx = 264, by = py + 16, bw = 96, bh = 20;
    bool pillHov = mouseIn(a, bx, by, bw, bh);
    g.fillRRect(bx, by, bw, bh, 6, P.color, a.invokeOpen ? 0.34f : (pillHov ? 0.26f : 0.14f));
    g.rrect(bx, by, bw, bh, 6, P.color, inv.empty() ? 0.4f : 0.85f, 1.2f);
    g.text("Invoke  G", bx + 8, by, 70, bh, 12, inv.empty() ? 0x8088a0 : rgbLerp(P.color, 0xffffff, 0.6f), 1.f, F_UIB, AL_L, VA_M);
    if (ready > 0) {
      g.fillCircle(V2(bx + bw - 12, by + bh / 2), 7.5f, P.color, 1.f);
      g.text(std::to_string(ready), bx + bw - 20, by, 16, bh, 11, 0x101010, 1.f, F_MONOB, AL_C, VA_M);
    }
    if (pillHov) {
      setTip(a, "Invocations",
             fmt("Your god's invocations have their own window, so the 1-9 ability keys never spend piety by accident. "
                 "Open it with G or this button, then click an invocation to use it.\n\n%s",
                 inv.empty() ? "You have no invocations yet: they come with piety." : fmt("%d of %d affordable right now.", ready, (int)inv.size()).c_str()),
             P.color);
      if (a.in.lPressed && !a.in.consumed) {
        a.in.consumed = true;
        a.invokeOpen = !a.invokeOpen;
        audio::play(S_CLICK, 0.5f, a.invokeOpen ? 1.15f : 0.85f);
      }
    } else if (mouseIn(a, 16, py - 2, 348, 36)) {
      std::string b = fmt("Piety %d / %d (next gift at %d)\nLikes: %s\nDislikes: %s\n\nGifts:\n", pl.piety, PIETY_MAX, nextStar, P.likes, P.dislikes);
      for (int k = 0; k < 5; ++k)
        b += fmt("%s %s (%d): %s\n", pl.piety >= PIETY_STAR[k] ? "[x]" : "[ ]", ABIL[P.gifts[k]].name, PIETY_STAR[k], abilityDesc(P.gifts[k], 1, false).c_str());
      if (pl.patron == PT_TUMBLER) b += fmt("\nThe Tumbler is %s.", tumblerMoodText(w).c_str());
      setTip(a, std::string(P.name) + " " + P.title, b, P.color);
    }
  }
}

// The invocations window: all five of your god's gifts beside the god's box, invocations usable with a click. It
// never reacts to the ability number keys; G, Esc, right-click or a click elsewhere closes it (that click is used up,
// so it can't launch a ball by accident either).
void drawInvocations(App& a) {
  Gfx& g = a.g;
  World& w = a.w;
  Player& pl = w.pl;
  if (!a.invokeOpen) return;
  if (pl.patron < 0 || w.screen != RS_FLOOR || w.dead) {
    a.invokeOpen = false;
    return;
  }
  const PatronDef& P = PATRON[pl.patron];
  const float W = 410, RH = 46, x = 378;
  const float h = 60 + 5 * (RH + 4) + 6, y = 886 - h;
  bool inside = mouseIn(a, x, y, W, h);
  g.fillRRect(x + 4, y + 6, W, h, 10, 0x000000, 0.45f);
  g.fillRRect(x, y, W, h, 10, 0x0c0e15, 0.97f);
  g.rrect(x, y, W, h, 10, P.color, 0.9f, 2);
  g.text(std::string("Invocations of ") + P.name, x + 14, y + 8, W - 28, 24, 18, P.color, 1.f, F_TITLE);
  std::string res = pl.patron == PT_AURUM ? fmt("%d gold  ·  piety %d", pl.gold, pl.piety) : fmt("Piety %d / %d", pl.piety, PIETY_MAX);
  g.text(res, x + 14, y + 34, 200, 16, 12.5f, 0xe8dcb0, 1.f, F_UIB);
  g.text("click to invoke  ·  G / Esc to close", x + W - 234, y + 34, 220, 16, 11, 0x687088, 1.f, F_UI, AL_R);
  float ry = y + 58;
  for (int k = 0; k < 5; ++k) {
    int ab = P.gifts[k];
    const AbilityDef& d = ABIL[ab];
    bool unlocked = pl.piety >= PIETY_STAR[k], passive = d.timing == T_PASSIVE;
    std::string why;
    bool usable = unlocked && !passive && abilityUsable(w, ab, &why);
    float rx = x + 8, rw = W - 16;
    bool hov = mouseIn(a, rx, ry, rw, RH);
    g.fillRRect(rx, ry, rw, RH, 7, !unlocked ? 0x0f1118 : (hov && !passive ? 0x252b40 : 0x161a26), 1.f);
    if (a.targetAb == ab) g.rrect(rx, ry, rw, RH, 7, P.color, 0.9f, 1.5f);
    g.fillRRect(rx, ry, 4, RH, 2, P.color, !unlocked ? 0.2f : (usable || passive ? 1.f : 0.45f));
    // piety star for this gift
    V2 c(rx + 22, ry + RH / 2), pts[10];
    for (int i = 0; i < 10; ++i) pts[i] = c + fromAng(-PI / 2 + i * PI / 5) * (i % 2 ? 3.5f : 8.f);
    if (unlocked) g.fillPoly(pts, 10, P.color, 1.f);
    else g.strokePoly(pts, 10, P.color, 0.45f, 1.2f);
    uint32_t nameCol = !unlocked ? 0x5a6072 : (usable || passive ? 0xffffff : 0x9aa2b2);
    g.text(d.name, rx + 40, ry + 5, 230, 18, 14, nameCol, 1.f, F_UIB);
    std::string sub = !unlocked ? fmt("unlocks at %d piety", PIETY_STAR[k]) : passive ? "blessing  ·  always active" : "invocation  ·  " + timingTag(d.timing);
    g.text(sub, rx + 40, ry + 24, 230, 16, 11, unlocked ? 0x8088a0 : 0x5a6072);
    if (!passive) {
      int gc = abilityGoldCost(w, ab, 1), cost = abilityCost(w, ab, 1);
      std::string cs = gc > 0 ? fmt("%d gold", gc) : fmt("%d piety", cost);
      bool afford = gc > 0 ? pl.gold >= gc : pl.piety >= cost;
      g.text(cs, rx + rw - 118, ry + 5, 108, 18, 13, !unlocked ? 0x5a6072 : afford ? (gc > 0 ? 0xffd84a : 0xfff0c0) : 0xff8080, 1.f, F_UIB, AL_R);
      if (unlocked && !usable && !why.empty())
        g.text(why, rx + rw - 178, ry + 24, 168, 16, 10.5f, 0xb08080, 1.f, F_UI, AL_R);
    }
    if (hov) {
      std::string body = abilityDesc(ab, 1, false);
      if (!unlocked) body += fmt("\n\nUnlocks when your piety reaches %d.", PIETY_STAR[k]);
      else if (passive) body += "\n\nA blessing: always active while you keep your god's favor.";
      else if (!usable && !why.empty()) body += "\n(" + why + ")";
      setTip(a, d.name, body, P.color);
      if (a.in.lPressed && !a.in.consumed) {
        a.in.consumed = true;
        if (usable) {
          tryCast(a, ab, false);
          a.invokeOpen = false;
        } else {
          audio::play(S_DENY, 0.6f);
          fxText(w, V2(190, 470), 0xff9090, !unlocked ? fmt("Needs %d piety.", PIETY_STAR[k]) : passive ? std::string("That blessing is always active.") : why, 14);
        }
      }
    }
    ry += RH + 4;
  }
  if (a.in.lPressed && !a.in.consumed && !inside) {
    a.in.consumed = true;
    a.invokeOpen = false;
  }
  if (a.in.rPressed) {
    a.in.rPressed = false;
    a.invokeOpen = false;
  }
}

void drawRightPanel(App& a) {
  Gfx& g = a.g;
  World& w = a.w;
  Floor& f = w.fl;
  const BiomeDef& B = BIOME[w.screen == RS_FLOOR ? f.spec.biome : (w.act == 0 ? BI_HALLS : w.act == 1 ? w.branchA : w.act == 2 ? w.branchB : BI_CORE)];
  panelBox(a, 1228, 8, 364, 884, B.accent);
  g.text(B.name, 1242, 14, 340, 28, 21, B.accent, 1.f, F_TITLE);
  std::string sub = fmt("Depth %d  ·  %s", w.depth, locationName(w));
  if (w.screen == RS_FLOOR) sub += fmt("  ·  Turn %d", f.turn);
  g.text(sub, 1242, 42, 340, 18, 13, 0xa8b0c0);
  g.text(fmt("Runes %d/2", w.runes), 1440, 14, 140, 20, 13, w.runes ? 0xffd040 : 0x606878, 1.f, F_UIB, AL_R);
  if (w.descent > 0) g.text(fmt("DL %d", w.descent), 1440, 32, 140, 18, 12, 0xff9060, 1.f, F_UIB, AL_R);
  float y = 64;
  if (tumblerWatching(w)) {
    int m = w.tumblerMood;
    uint32_t mc = rgbLerp(0x8080a0, 0xff80ff, m / 100.f);
    g.text("The Tumbler is " + tumblerMoodText(w), 1242, y, 240, 16, 12, mc, 1.f, F_UIB);
    g.fillRRect(1450, y + 4, 130, 7, 3, 0x201828, 1.f);
    g.fillRRect(1450, y + 4, 130 * m / 100.f, 7, 3, mc, 1.f);
    if (mouseIn(a, 1242, y, 340, 16))
      setTip(a, "The Tumbler's mood",
             "The Tumbler, Lord of Chance, is watching you. Big hits, kills, jackpots and close calls amuse it; boredom makes it "
             "meddle more often, and more cruelly. Its meddling can do almost anything: heal you, smite monsters, rebuild the board, "
             "summon monsters, teleport your ball mid-flight...",
             0xff80ff);
    y += 20;
  }
  if (w.screen == RS_FLOOR) {
    std::string kind;
    uint32_t kc = 0xffffff;
    if (f.spec.kind == FK_ELITE) { kind = "ELITE FLOOR"; kc = 0xffb040; }
    if (f.spec.kind == FK_BOSS) { kind = "GUARDIAN"; kc = 0xff4050; }
    if (f.isVault) { kind = fmt("TREASURE VAULT: %d shot%s left", f.vaultShots, f.vaultShots == 1 ? "" : "s"); kc = 0xffd040; }
    if (!kind.empty()) {
      g.text(kind, 1242, y, 340, 18, 13, kc, 1.f, F_UIB);
      y += 20;
    }
    {
      int fm = clampv((int)f.spec.format, 0, FORMAT_COUNT - 1);
      std::string fs = std::string(FORMAT_NAME[fm]) + " board";
      g.text(fs, 1242, y, 200, 16, 12, 0x9fc8e0, 1.f, F_UIB);
      if (mouseIn(a, 1242, y, 200, 16)) setTip(a, fs, FORMAT_DESC[fm], 0x9fc8e0);
      if (f.shrine >= 0) {
        g.text(SHRINE_NAME[f.shrine], 1400, y, 180, 16, 12, 0xfff0c0, 1.f, F_UIB, AL_R);
        if (mouseIn(a, 1400, y, 180, 16)) setTip(a, SHRINE_NAME[f.shrine], SHRINE_DESC[f.shrine], 0xfff0c0);
      }
      y += 18;
    }
    float mx = 1240;
    for (int i = 0; i < f.spec.nMods; ++i) {
      const ModDef& m = MODS[f.spec.mods[i]];
      float tw = g.measure(m.name, 12, F_UIB).x + 14;
      if (mx + tw > 1584) { mx = 1240; y += 22; }
      g.fillRRect(mx, y, tw, 19, 5, m.color, 0.16f);
      g.rrect(mx, y, tw, 19, 5, m.color, 0.6f, 1);
      g.text(m.name, mx, y, tw, 19, 12, m.color, 1.f, F_UIB, AL_C, VA_M);
      if (mouseIn(a, mx, y, tw, 19)) setTip(a, m.name, m.desc, m.color);
      mx += tw + 5;
    }
    if (f.spec.nMods) y += 26;
    if (f.lastCard >= 0) {
      g.text(std::string("Last card: ") + CARD_NAME[f.lastCard], 1242, y, 340, 16, 12, 0xe0c0ff, 1.f, F_UIB);
      if (mouseIn(a, 1242, y, 340, 16)) setTip(a, CARD_NAME[f.lastCard], CARD_DESC[f.lastCard], 0xe0c0ff);
      y += 18;
    }
    g.text("MONSTERS", 1242, y, 200, 16, 12, 0x7880a0, 1.f, F_UIB);
    g.text("right-click to focus", 1400, y, 180, 16, 11, 0x5a6070, 1.f, F_UI, AL_R);
    y += 18;
    int shown = 0;
    int focus = f.focus;
    for (int i = 0; i < (int)f.mons.size() && shown < 8; ++i) {
      const Monster& m = f.mons[i];
      if (m.dead) continue;
      const MonDef& d = monLook(m);
      float rh = 40;
      bool hov = mouseIn(a, 1236, y, 348, rh);
      g.fillRRect(1236, y, 348, rh, 6, i == focus ? 0x1c2a40 : (hov ? 0x1e2230 : 0x141720), 1.f);
      if (i == focus) g.rrect(1236, y, 348, rh, 6, 0x9fc8ff, 0.7f, 1.2f);
      if (m.charmed) g.rrect(1236, y, 348, rh, 6, 0xff90ff, 0.7f, 1.2f);
      g.fillCircle(V2(1258, y + 20), 14, rgbLerp(0x0c0e14, d.color, 0.2f), 1.f);
      g.circle(V2(1258, y + 20), 14, d.color, 1.f, 1.5f);
      g.text(d.glyph, 1244, y + 6, 28, 28, 16, d.color, 1.f, F_MONOB, AL_C, VA_M);
      std::string nm = monsterName(m);
      if (m.elite && !(d.traits & TR_ELITE)) nm = "elite " + nm;
      if (m.charmed) nm = "charmed " + nm;
      if (m.bounty) nm += " $";
      uint32_t ncol = m.champ == 2 ? 0xffc040 : m.champ == 1 ? 0x7ab0ff : m.def == M_TREASURE ? 0xffd040 : 0xffffff;
      g.text(nm, 1280, y + 1, 186, 18, nm.size() > 24 ? 11.5f : 13.f, ncol, 1.f, F_UIB);
      float frac = m.hp / (float)std::max(1, m.maxHp);
      g.fillRRect(1280, y + 20, 130, 7, 3, 0x2a1216, 1.f);
      g.fillRRect(1280, y + 20, 130 * clampv(frac, 0.f, 1.f), 7, 3, m.charmed ? 0xd060d0 : 0xd84040, 1.f);
      g.text(fmt("%d/%d", m.hp, m.maxHp), 1414, y + 17, 60, 16, 11, 0xc0c8d0);
      std::string it = m.charmed ? fmt("fights for you (%d)", m.charmT) : m.frozen ? "frozen" : intentText(w, m, false);
      bool soon = m.cd <= 1 && !m.frozen && !m.charmed;
      float ifs = g.measure(it, 10.5f, F_UI).x > 200 ? 9.5f : 10.5f;
      g.pushClip(1466, y + 1, 116, 38);
      g.text(it, 1470, y + 2, 110, 38, ifs, soon ? 0xff9090 : 0x9aa4b8, 1.f, F_UI, AL_R, VA_T);
      g.popClip();
      g.text((m.frozen || m.charmed) ? "" : (m.cd <= 1 ? "NEXT TURN" : fmt("in %d turns", m.cd)), 1280, y + 29, 130, 11, 9.5f, soon ? 0xff6060 : 0x6a7282,
             1.f, F_UIB, AL_L);
      if (hov) {
        std::string b = fmt("%s\nNext: %s", d.desc, intentText(w, m, false).c_str());
        for (int af = 0; af < AFFIX_COUNT; ++af)
          if (hasAffix(m, af)) b += fmt("\n%s: %s", AFFIX_NAME[af], AFFIX_DESC[af]);
        setTip(a, monsterName(m), b + "\n\nClick to make this your focus target.", ncol == 0xffffff ? d.color : ncol);
        if (a.in.lPressed && !a.in.consumed && !m.charmed) {
          a.in.consumed = true;
          f.focus = i;
          audio::play(S_CLICK, 0.6f, 1.3f);
        }
      }
      y += rh + 3;
      shown++;
    }
    int extra = 0;
    for (auto& m : f.mons)
      if (!m.dead) extra++;
    if (extra > shown) {
      g.text(fmt("...and %d more", extra - shown), 1242, y, 300, 16, 12, 0x8890a0);
      y += 18;
    }
    y += 6;
  }
  // message log
  float ly0 = std::max(y + 4, 420.f), ly1 = 842;
  g.text("MESSAGES", 1242, ly0, 200, 16, 12, 0x7880a0, 1.f, F_UIB);
  ly0 += 18;
  g.fillRRect(1236, ly0, 348, ly1 - ly0, 6, 0x07090d, 1.f);
  g.pushClip(1238, ly0 + 2, 344, ly1 - ly0 - 4);
  float yy = ly1 - 6;
  int start = (int)w.log.size() - 1 - (int)a.logScroll;
  for (int i = start; i >= 0 && yy > ly0; --i) {
    const LogLine& l = w.log[i];
    float h = g.measure(l.text, 12.5f, F_UI, 330).y;
    yy -= h + 2;
    float al = i == (int)w.log.size() - 1 ? 1.f : 0.85f;
    g.text(l.text, 1244, yy, 334, h + 4, 12.5f, l.col, al, F_UI);
  }
  g.popClip();
  if (mouseIn(a, 1236, ly0, 348, ly1 - ly0) && a.in.wheel != 0) {
    a.logScroll = clampv(a.logScroll + a.in.wheel * 2.f, 0.f, std::max(0.f, (float)w.log.size() - 5));
  }
  std::string sp = a.fastToggle ? "Speed x2" : "Speed x1";
  if (a.in.keyDown[KEY_SPACE]) sp = "Speed x4 (Space held)";
  g.text(sp + "   ·   F: toggle speed   ·   Esc: menu", 1236, 852, 348, 16, 11.5f, 0x6a7282, 1.f, F_UI, AL_C);
  g.text("Hold Space to fast-forward   ·   Tab: cycle focus", 1236, 868, 348, 16, 11.5f, 0x6a7282, 1.f, F_UI, AL_C);
}
