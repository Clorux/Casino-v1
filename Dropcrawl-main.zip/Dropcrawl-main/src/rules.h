// Dropcrawl - internal helpers shared by the rule files (floor*.cpp, tumbler.cpp, mutations.cpp, randart.cpp ...)
#pragma once
#include "game.h"
#include "audio.h"

#define FOR_EFF(HOOK, ...)                                   \
  do {                                                       \
    for (size_t _i = 0; _i < w.effs.size(); ++_i) {          \
      const EffRef _e = w.effs[_i];                          \
      if (_e.h->HOOK) _e.h->HOOK(w, __VA_ARGS__, _e.lvl);    \
    }                                                        \
  } while (0)
#define FOR_EFF0(HOOK)                                       \
  do {                                                       \
    for (size_t _i = 0; _i < w.effs.size(); ++_i) {          \
      const EffRef _e = w.effs[_i];                          \
      if (_e.h->HOOK) _e.h->HOOK(w, _e.lvl);                 \
    }                                                        \
  } while (0)

constexpr int MAX_MONS = 60, MAX_PEGS = 1500, MAX_SEGS = 300, MAX_BALLS = 40, MAX_ZONES = 60;

// floor.cpp
std::string withArt(const char* n);
std::string The(const MonDef& d);            // "The goblin" (bosses keep their names)
std::string TheM(const Monster& m);          // uses the monster's disguise
void setIntent(World& w, Monster& m, int pos, int extraDelay);
int numPhases(const MonDef& d);
void spawnBallDeferred(World& w, const Ball& b);
Fx& pushFx(World& w, int kind);
bool isHostile(const World& w, int mi);      // alive and not an ally
int summonedAlive(const World& w);
int hitMonstersInRadius(World& w, V2 p, float r, int dmg, int src, int exclude = -1);
int pickRandomHostile(World& w);
void floorWon(World& w);
void startEnemyPhase(World& w);
void thawAndReset(World& w);                 // turn-start board bookkeeping
int pietyStarsFor(int piety);
bool isUndeadOrDemon(const Monster& m);
void noteDamageDealt(World& w, int dealt);   // hot streak / tumbler excitement bookkeeping
float allyDamageMul(const World& w);
void conductSpell(World& w, int ab, int mpCost);

// floor_ball.cpp
void processSlots(World& w, float dt);
void flushSlots(World& w);                   // resolve every queued spin immediately
void closeTulips(World& w);
void allBallsPower(World& w, int amt);       // balls in flight, or the next shot
void onBlackHole(World& w, int bi, int zi);

// floor_turn.cpp
void enemyStep(World& w);
void ensureCapacity(World& w);               // keeps references into floor vectors valid

// tumbler.cpp
void tumblerEndShot(World& w);

// mutations.cpp
const Hooks* sacrificeHooks();

// randart / magic-affix properties (randart.cpp; shared with loot.cpp)
enum RandProp : uint8_t {
  RP_POWER, RP_ARMOR, RP_MAXHP, RP_MAXMP, RP_MPREGEN, RP_HPREGEN, RP_LOWGRAV, RP_BOUNCE, RP_BIGBALL, RP_PREVIEW,
  RP_GOLD, RP_XP, RP_DAMAGE, RP_ELITE, RP_CRIT, RP_HEALMUL, RP_SHOP, RP_SLOT, RP_OFFER, RP_SPECIAL,
  RP_BURN, RP_POISON, RP_CHILLFIRST, RP_FLAT, RP_LIFESTEAL, RP_GOLDHIT, RP_ZAP, RP_KILLHEAL, RP_KILLMP, RP_KILLGOLD,
  RP_KILLBLAST, RP_TURNBLOCK, RP_THORNS, RP_REFLECT, RP_FIRSTBLOCK, RP_POISONRES, RP_FIRSTFREE, RP_FULLHP, RP_LOWHP, RP_CHAOS,
  RP_BLEED, RP_EXPLOSION, RP_ALLY, RP_BUMPER, RP_TULIP, RP_VOID, RP_WALL, RP_PORTAL,
  // v3
  RP_STR, RP_DEX, RP_INT, RP_VIT, RP_LCK, RP_ALLSTATS, RP_CRITCHANCE, RP_CRITDMG, RP_DODGE, RP_SPELLDMG,
  RP_MAGICFIND, RP_SCHOOLCOST, RP_STARTBLOCK, RP_POTIONMUL, RP_KILLPOWER, RP_EXECUTE, RP_FIRSTSTRIKE, RP_OVERKILL,
  RP_HOLY, RP_ALLYTURNS, RP_HOMING, RP_MANASHIELD, RP_SECONDCHANCE, RP_PIERCE, RP_DISCHARGE, RP_STRIKEWIDE, RP_FREEWIDE,
  RP_RUNES, RP_SHRINE, RP_WELL, RP_STARS, RP_GEMS, RP_BURNMUL, RP_CHILLVULN, RP_CRITBLEED, RP_TUMBLERKIND, RP_LOOT,
  RP_GOOD_COUNT,
  RP_NEG_HP = 120, RP_NEG_ARMOR, RP_NEG_MONDMG, RP_NEG_GOLD, RP_NEG_NOISY, RP_NEG_CURSED, RP_NEG_HEAVY, RP_NEG_POWER, RP_NEG_HEAL,
  RP_NEG_STR, RP_NEG_DEX, RP_NEG_INT, RP_NEG_VIT, RP_NEG_LCK, RP_NEG_FRAGILE, RP_NEG_MPREGEN, RP_NEG_BOSS,
  RP_NEG_END
};
std::string randPropText(int prop, int val, int aux);
int randPropRoll(Rng& R, int prop, int depth);
float randPropWeight(int prop);
int randPropAux(Rng& R, int prop);
bool anyAffixes(const World& w);            // randarts or magic relics present
int propTotal(const World& w, int prop);    // sum of a property over randarts and magic relics

// stats.cpp / loot.cpp / floor_ball2.cpp internals
void initStatTables();
void initV3Content();                        // content_data3.cpp: text tables, uniques, sets, monsters
int relicSetCount(const World& w, int set);  // owned pieces of a relic set
bool isUniqueRelic(int rl);
bool isSetRelic(int rl);
void lootPegTick(World& w);                  // enemy phase bookkeeping for loot orbs
extern Hooks SET_HOOKS;                      // relic set bonuses (content_data3.cpp)
int setPieceByName(const char* name);        // setpieces.cpp
void pushRelicOffersN(World& w, int n, bool boss, bool allowUnique);  // loot.cpp: fill w.relicOffers
int scaledMonsterValue(const World& w, int v);  // floor.cpp: monster damage scaling for bombs & meteors
void tumblerRune(World& w, int bi);            // runes.cpp: the Tumbler hands a ball a random rune
int setPieceCount();                           // setpieces.cpp
