// Dropcrawl - Direct2D / DirectWrite renderer wrapper
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d2d1.h>
#include <d2d1_1.h>
#include <d2d1helper.h>
#include <dwrite.h>
#include <wincodec.h>
#include "gfx.h"

template <class T> static void safeRelease(T*& p) {
  if (p) { p->Release(); p = nullptr; }
}

std::wstring widen(const std::string& s) {
  if (s.empty()) return std::wstring();
  int n = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
  std::wstring w(n, L'\0');
  MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), &w[0], n);
  return w;
}

static D2D1_COLOR_F colF(uint32_t c, float a) {
  return D2D1::ColorF(((c >> 16) & 255) / 255.f, ((c >> 8) & 255) / 255.f, (c & 255) / 255.f, clampv(a, 0.f, 1.f));
}

bool Gfx::initFactories() {
  if (factory) return true;
  HRESULT hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, __uuidof(ID2D1Factory), nullptr, (void**)&factory);
  if (FAILED(hr)) return false;
  hr = DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), (IUnknown**)&dw);
  if (FAILED(hr)) return false;
  hr = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&wic));
  if (FAILED(hr)) wic = nullptr;
  D2D1_STROKE_STYLE_PROPERTIES sp = D2D1::StrokeStyleProperties(D2D1_CAP_STYLE_ROUND, D2D1_CAP_STYLE_ROUND, D2D1_CAP_STYLE_ROUND,
                                                                D2D1_LINE_JOIN_ROUND, 10.f, D2D1_DASH_STYLE_SOLID, 0.f);
  factory->CreateStrokeStyle(sp, nullptr, 0, &roundStroke);
  return true;
}

bool Gfx::initWindow(HWND h) {
  hwnd = h;
  if (!initFactories()) return false;
  RECT rc;
  GetClientRect(hwnd, &rc);
  pixW = std::max(1L, rc.right - rc.left);
  pixH = std::max(1L, rc.bottom - rc.top);
  return createDeviceResources();
}

bool Gfx::initOffscreen(int w, int h) {
  if (!initFactories()) return false;
  if (!wic) return false;
  pixW = w;
  pixH = h;
  return createDeviceResources();
}

bool Gfx::createDeviceResources() {
  if (rt) return true;
  HRESULT hr;
  if (hwnd) {
    D2D1_RENDER_TARGET_PROPERTIES rtp = D2D1::RenderTargetProperties(
        D2D1_RENDER_TARGET_TYPE_DEFAULT, D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_IGNORE), 96.f, 96.f);
    D2D1_HWND_RENDER_TARGET_PROPERTIES hp =
        D2D1::HwndRenderTargetProperties(hwnd, D2D1::SizeU(pixW, pixH), D2D1_PRESENT_OPTIONS_NONE);
    hr = factory->CreateHwndRenderTarget(rtp, hp, &hrt);
    if (FAILED(hr)) return false;
    rt = hrt;
    rt->AddRef();
  } else {
    hr = wic->CreateBitmap(pixW, pixH, GUID_WICPixelFormat32bppPBGRA, WICBitmapCacheOnLoad, &wicBmp);
    if (FAILED(hr)) return false;
    D2D1_RENDER_TARGET_PROPERTIES rtp = D2D1::RenderTargetProperties(
        D2D1_RENDER_TARGET_TYPE_DEFAULT, D2D1::PixelFormat(DXGI_FORMAT_B8G8R8A8_UNORM, D2D1_ALPHA_MODE_PREMULTIPLIED), 96.f, 96.f);
    hr = factory->CreateWicBitmapRenderTarget(wicBmp, rtp, &rt);
    if (FAILED(hr)) return false;
  }
  rt->SetDpi(96.f, 96.f);
  rt->SetTextAntialiasMode(D2D1_TEXT_ANTIALIAS_MODE_GRAYSCALE);
  if (FAILED(rt->QueryInterface(__uuidof(ID2D1DeviceContext), (void**)&dc))) dc = nullptr;
  rt->CreateSolidColorBrush(D2D1::ColorF(1, 1, 1, 1), &brush);
  return true;
}

void Gfx::releaseDeviceResources() {
  for (auto& kv : glows) kv.second->Release();
  glows.clear();
  for (auto& kv : lins) kv.second->Release();
  lins.clear();
  safeRelease(brush);
  safeRelease(dc);
  safeRelease(hrt);
  safeRelease(rt);
  safeRelease(wicBmp);
}

void Gfx::shutdown() {
  releaseDeviceResources();
  for (auto& row : formats)
    for (auto& f : row) safeRelease(f);
  safeRelease(roundStroke);
  safeRelease(wic);
  safeRelease(dw);
  safeRelease(factory);
}

void Gfx::resize(int w, int h) {
  pixW = std::max(1, w);
  pixH = std::max(1, h);
  if (hrt) hrt->Resize(D2D1::SizeU(pixW, pixH));
}

bool Gfx::beginFrame() {
  if (!rt && !createDeviceResources()) return false;
  viewScale = std::min(pixW / logicalW, pixH / logicalH);
  viewX = (pixW - logicalW * viewScale) * 0.5f;
  viewY = (pixH - logicalH * viewScale) * 0.5f;
  rt->BeginDraw();
  inFrame = true;
  rt->SetTransform(D2D1::Matrix3x2F::Identity());
  rt->Clear(D2D1::ColorF(0.02f, 0.02f, 0.03f, 1.f));
  xstack.clear();
  cur = Xf();
  cur.m11 = cur.m22 = viewScale;
  cur.dx = viewX;
  cur.dy = viewY;
  applyXf();
  clipDepth = 0;
  return true;
}

void Gfx::endFrame() {
  if (!inFrame) return;
  while (clipDepth > 0) popClip();
  additive(false);
  HRESULT hr = rt->EndDraw();
  inFrame = false;
  if (hr == (HRESULT)D2DERR_RECREATE_TARGET) releaseDeviceResources();
}

bool Gfx::savePng(const std::wstring& path) {
  if (!wicBmp || !wic) return false;
  IWICStream* stream = nullptr;
  IWICBitmapEncoder* enc = nullptr;
  IWICBitmapFrameEncode* frame = nullptr;
  bool ok = false;
  if (SUCCEEDED(wic->CreateStream(&stream)) && SUCCEEDED(stream->InitializeFromFilename(path.c_str(), GENERIC_WRITE)) &&
      SUCCEEDED(wic->CreateEncoder(GUID_ContainerFormatPng, nullptr, &enc)) &&
      SUCCEEDED(enc->Initialize(stream, WICBitmapEncoderNoCache)) && SUCCEEDED(enc->CreateNewFrame(&frame, nullptr)) &&
      SUCCEEDED(frame->Initialize(nullptr))) {
    UINT w, h;
    wicBmp->GetSize(&w, &h);
    frame->SetSize(w, h);
    WICPixelFormatGUID fmtG = GUID_WICPixelFormat32bppBGRA;
    frame->SetPixelFormat(&fmtG);
    if (SUCCEEDED(frame->WriteSource(wicBmp, nullptr)) && SUCCEEDED(frame->Commit()) && SUCCEEDED(enc->Commit())) ok = true;
  }
  safeRelease(frame);
  safeRelease(enc);
  safeRelease(stream);
  return ok;
}

void Gfx::applyXf() {
  D2D1_MATRIX_3X2_F m;
  m._11 = cur.m11; m._12 = cur.m12; m._21 = cur.m21; m._22 = cur.m22; m._31 = cur.dx; m._32 = cur.dy;
  rt->SetTransform(m);
}
void Gfx::pushXf(const Xf& local) {
  xstack.push_back(cur);
  cur = local * cur;
  applyXf();
}
void Gfx::popXf() {
  if (xstack.empty()) return;
  cur = xstack.back();
  xstack.pop_back();
  applyXf();
}
void Gfx::pushClip(float x, float y, float w, float h) {
  rt->PushAxisAlignedClip(D2D1::RectF(x, y, x + w, y + h), D2D1_ANTIALIAS_MODE_ALIASED);
  clipDepth++;
}
void Gfx::popClip() {
  if (clipDepth <= 0) return;
  rt->PopAxisAlignedClip();
  clipDepth--;
}
void Gfx::additive(bool on) {
  if (dc) dc->SetPrimitiveBlend(on ? D2D1_PRIMITIVE_BLEND_ADD : D2D1_PRIMITIVE_BLEND_SOURCE_OVER);
}

void Gfx::clear(uint32_t col) { rt->Clear(colF(col, 1)); }

void Gfx::fillRect(float x, float y, float w, float h, uint32_t col, float a) {
  if (a <= 0) return;
  brush->SetColor(colF(col, a));
  rt->FillRectangle(D2D1::RectF(x, y, x + w, y + h), brush);
}
void Gfx::rect(float x, float y, float w, float h, uint32_t col, float a, float width) {
  if (a <= 0) return;
  brush->SetColor(colF(col, a));
  rt->DrawRectangle(D2D1::RectF(x, y, x + w, y + h), brush, width);
}
void Gfx::fillRRect(float x, float y, float w, float h, float r, uint32_t col, float a) {
  if (a <= 0) return;
  brush->SetColor(colF(col, a));
  rt->FillRoundedRectangle(D2D1::RoundedRect(D2D1::RectF(x, y, x + w, y + h), r, r), brush);
}
void Gfx::rrect(float x, float y, float w, float h, float r, uint32_t col, float a, float width) {
  if (a <= 0) return;
  brush->SetColor(colF(col, a));
  rt->DrawRoundedRectangle(D2D1::RoundedRect(D2D1::RectF(x, y, x + w, y + h), r, r), brush, width);
}
void Gfx::fillCircle(V2 c, float r, uint32_t col, float a) {
  if (a <= 0 || r <= 0) return;
  brush->SetColor(colF(col, a));
  rt->FillEllipse(D2D1::Ellipse(D2D1::Point2F(c.x, c.y), r, r), brush);
}
void Gfx::fillEllipse(V2 c, float rx, float ry, uint32_t col, float a) {
  if (a <= 0) return;
  brush->SetColor(colF(col, a));
  rt->FillEllipse(D2D1::Ellipse(D2D1::Point2F(c.x, c.y), rx, ry), brush);
}
void Gfx::circle(V2 c, float r, uint32_t col, float a, float width) {
  if (a <= 0 || r <= 0) return;
  brush->SetColor(colF(col, a));
  rt->DrawEllipse(D2D1::Ellipse(D2D1::Point2F(c.x, c.y), r, r), brush, width);
}
void Gfx::line(V2 p0, V2 p1, uint32_t col, float a, float width, bool round) {
  if (a <= 0) return;
  brush->SetColor(colF(col, a));
  rt->DrawLine(D2D1::Point2F(p0.x, p0.y), D2D1::Point2F(p1.x, p1.y), brush, width, round ? roundStroke : nullptr);
}
void Gfx::glow(V2 c, float r, uint32_t col, float a) {
  if (a <= 0 || r <= 0) return;
  ID2D1RadialGradientBrush* gb = nullptr;
  auto it = glows.find(col);
  if (it == glows.end()) {
    float rr = ((col >> 16) & 255) / 255.f, gg = ((col >> 8) & 255) / 255.f, bb = (col & 255) / 255.f;
    D2D1_GRADIENT_STOP stops[3] = {{0.f, D2D1::ColorF(rr, gg, bb, 1.f)},
                                   {0.35f, D2D1::ColorF(rr, gg, bb, 0.4f)},
                                   {1.f, D2D1::ColorF(rr, gg, bb, 0.f)}};
    ID2D1GradientStopCollection* coll = nullptr;
    if (FAILED(rt->CreateGradientStopCollection(stops, 3, D2D1_GAMMA_2_2, D2D1_EXTEND_MODE_CLAMP, &coll))) return;
    rt->CreateRadialGradientBrush(
        D2D1::RadialGradientBrushProperties(D2D1::Point2F(0, 0), D2D1::Point2F(0, 0), 1.f, 1.f), coll, &gb);
    coll->Release();
    if (!gb) return;
    glows[col] = gb;
  } else {
    gb = it->second;
  }
  gb->SetCenter(D2D1::Point2F(c.x, c.y));
  gb->SetRadiusX(r);
  gb->SetRadiusY(r);
  gb->SetOpacity(clampv(a, 0.f, 1.f));
  rt->FillEllipse(D2D1::Ellipse(D2D1::Point2F(c.x, c.y), r, r), gb);
}

void Gfx::fillPoly(const V2* pts, int n, uint32_t col, float a) {
  if (n < 3 || a <= 0) return;
  ID2D1PathGeometry* geo = nullptr;
  if (FAILED(factory->CreatePathGeometry(&geo))) return;
  ID2D1GeometrySink* sink = nullptr;
  if (SUCCEEDED(geo->Open(&sink))) {
    sink->BeginFigure(D2D1::Point2F(pts[0].x, pts[0].y), D2D1_FIGURE_BEGIN_FILLED);
    for (int i = 1; i < n; ++i) sink->AddLine(D2D1::Point2F(pts[i].x, pts[i].y));
    sink->EndFigure(D2D1_FIGURE_END_CLOSED);
    sink->Close();
    sink->Release();
    brush->SetColor(colF(col, a));
    rt->FillGeometry(geo, brush);
  }
  geo->Release();
}

void Gfx::strokePoly(const V2* pts, int n, uint32_t col, float a, float width, bool closed) {
  if (n < 2 || a <= 0) return;
  ID2D1PathGeometry* geo = nullptr;
  if (FAILED(factory->CreatePathGeometry(&geo))) return;
  ID2D1GeometrySink* sink = nullptr;
  if (SUCCEEDED(geo->Open(&sink))) {
    sink->BeginFigure(D2D1::Point2F(pts[0].x, pts[0].y), D2D1_FIGURE_BEGIN_HOLLOW);
    for (int i = 1; i < n; ++i) sink->AddLine(D2D1::Point2F(pts[i].x, pts[i].y));
    sink->EndFigure(closed ? D2D1_FIGURE_END_CLOSED : D2D1_FIGURE_END_OPEN);
    sink->Close();
    sink->Release();
    brush->SetColor(colF(col, a));
    rt->DrawGeometry(geo, brush, width, roundStroke);
  }
  geo->Release();
}

void Gfx::arc(V2 c, float r, float a0, float a1, uint32_t col, float a, float width) {
  if (a <= 0) return;
  float sweep = a1 - a0;
  if (std::fabs(sweep) >= TAU - 0.001f) { circle(c, r, col, a, width); return; }
  if (std::fabs(sweep) < 0.001f) return;
  ID2D1PathGeometry* geo = nullptr;
  if (FAILED(factory->CreatePathGeometry(&geo))) return;
  ID2D1GeometrySink* sink = nullptr;
  if (SUCCEEDED(geo->Open(&sink))) {
    V2 p0 = c + fromAng(a0) * r, p1 = c + fromAng(a1) * r;
    sink->BeginFigure(D2D1::Point2F(p0.x, p0.y), D2D1_FIGURE_BEGIN_HOLLOW);
    sink->AddArc(D2D1::ArcSegment(D2D1::Point2F(p1.x, p1.y), D2D1::SizeF(r, r), 0.f,
                                  sweep > 0 ? D2D1_SWEEP_DIRECTION_CLOCKWISE : D2D1_SWEEP_DIRECTION_COUNTER_CLOCKWISE,
                                  std::fabs(sweep) > PI ? D2D1_ARC_SIZE_LARGE : D2D1_ARC_SIZE_SMALL));
    sink->EndFigure(D2D1_FIGURE_END_OPEN);
    sink->Close();
    sink->Release();
    brush->SetColor(colF(col, a));
    rt->DrawGeometry(geo, brush, width, roundStroke);
  }
  geo->Release();
}

void Gfx::vgrad(float x, float y, float w, float h, uint32_t top, uint32_t bot, float a) {
  uint64_t key = ((uint64_t)top << 32) | bot;
  ID2D1LinearGradientBrush* lb = nullptr;
  auto it = lins.find(key);
  if (it == lins.end()) {
    D2D1_GRADIENT_STOP stops[2] = {{0.f, colF(top, 1)}, {1.f, colF(bot, 1)}};
    ID2D1GradientStopCollection* coll = nullptr;
    if (FAILED(rt->CreateGradientStopCollection(stops, 2, D2D1_GAMMA_2_2, D2D1_EXTEND_MODE_CLAMP, &coll))) return;
    rt->CreateLinearGradientBrush(D2D1::LinearGradientBrushProperties(D2D1::Point2F(0, 0), D2D1::Point2F(0, 1)), coll, &lb);
    coll->Release();
    if (!lb) return;
    lins[key] = lb;
  } else {
    lb = it->second;
  }
  lb->SetStartPoint(D2D1::Point2F(x, y));
  lb->SetEndPoint(D2D1::Point2F(x, y + h));
  lb->SetOpacity(a);
  rt->FillRectangle(D2D1::RectF(x, y, x + w, y + h), lb);
}

IDWriteTextFormat* Gfx::fmtFor(int font, float size) {
  int bucket = clampv((int)std::lround(size), 6, 69) - 6;
  IDWriteTextFormat*& f = formats[font][bucket];
  if (!f) {
    const wchar_t* fam = L"Segoe UI";
    DWRITE_FONT_WEIGHT wt = DWRITE_FONT_WEIGHT_NORMAL;
    switch (font) {
      case F_UIB: fam = L"Segoe UI"; wt = DWRITE_FONT_WEIGHT_SEMI_BOLD; break;
      case F_MONO: fam = L"Consolas"; break;
      case F_MONOB: fam = L"Consolas"; wt = DWRITE_FONT_WEIGHT_BOLD; break;
      case F_SYM: fam = L"Segoe UI Symbol"; break;
      case F_TITLE: fam = L"Georgia"; wt = DWRITE_FONT_WEIGHT_BOLD; break;
      default: break;
    }
    dw->CreateTextFormat(fam, nullptr, wt, DWRITE_FONT_STYLE_NORMAL, DWRITE_FONT_STRETCH_NORMAL, (float)(bucket + 6),
                         L"en-us", &f);
  }
  return f;
}

void Gfx::text(const std::string& s, float x, float y, float w, float h, float size, uint32_t col, float a, int font,
               int align, int valign) {
  if (s.empty() || a <= 0) return;
  IDWriteTextFormat* f = fmtFor(font, size);
  if (!f) return;
  f->SetTextAlignment(align == AL_C ? DWRITE_TEXT_ALIGNMENT_CENTER
                                    : (align == AL_R ? DWRITE_TEXT_ALIGNMENT_TRAILING : DWRITE_TEXT_ALIGNMENT_LEADING));
  f->SetParagraphAlignment(valign == VA_M ? DWRITE_PARAGRAPH_ALIGNMENT_CENTER
                                          : (valign == VA_B ? DWRITE_PARAGRAPH_ALIGNMENT_FAR : DWRITE_PARAGRAPH_ALIGNMENT_NEAR));
  std::wstring ws = widen(s);
  brush->SetColor(colF(col, a));
  rt->DrawText(ws.c_str(), (UINT32)ws.size(), f, D2D1::RectF(x, y, x + w, y + h), brush, D2D1_DRAW_TEXT_OPTIONS_NONE);
}

void Gfx::textSh(const std::string& s, float x, float y, float w, float h, float size, uint32_t col, float a, int font,
                 int align, int valign) {
  float o = std::max(1.f, size * 0.08f);
  text(s, x + o, y + o, w, h, size, 0x000000, a * 0.8f, font, align, valign);
  text(s, x, y, w, h, size, col, a, font, align, valign);
}

V2 Gfx::measure(const std::string& s, float size, int font, float maxW) {
  if (s.empty()) return {0, size * 1.3f};
  IDWriteTextFormat* f = fmtFor(font, size);
  if (!f) return {0, 0};
  f->SetTextAlignment(DWRITE_TEXT_ALIGNMENT_LEADING);
  f->SetParagraphAlignment(DWRITE_PARAGRAPH_ALIGNMENT_NEAR);
  std::wstring ws = widen(s);
  IDWriteTextLayout* lay = nullptr;
  if (FAILED(dw->CreateTextLayout(ws.c_str(), (UINT32)ws.size(), f, maxW, 10000.f, &lay))) return {0, 0};
  DWRITE_TEXT_METRICS m;
  lay->GetMetrics(&m);
  lay->Release();
  return {m.widthIncludingTrailingWhitespace, m.height};
}
