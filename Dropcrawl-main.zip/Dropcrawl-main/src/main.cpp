// Dropcrawl - entry point, window, main loop, persistence
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif
#include <windows.h>
#include <windowsx.h>
#include <objbase.h>
#include <shellapi.h>
#include <fstream>
#include <filesystem>
#include <ctime>
#include "app.h"
#include "sim.h"

static App* G = nullptr;
static HWND g_hwnd = nullptr;
static WINDOWPLACEMENT g_wpPrev = {sizeof(WINDOWPLACEMENT)};
static bool g_isFullscreen = false;

uint64_t tickCount() { return GetTickCount64(); }

static std::wstring exeDir() {
  wchar_t buf[MAX_PATH];
  GetModuleFileNameW(nullptr, buf, MAX_PATH);
  std::wstring s(buf);
  size_t p = s.find_last_of(L"\\/");
  return p == std::wstring::npos ? L"." : s.substr(0, p);
}

static std::wstring savePath(App& a) { return a.baseDir + L"\\save.dat"; }

// ------------------------------------------------------------------ settings
void saveSettings(App& a) {
  std::ofstream f(std::filesystem::path(a.baseDir + L"\\settings.ini"));
  f << "master=" << a.set.master << "\nsfx=" << a.set.sfx << "\nmusic=" << a.set.music << "\nshake=" << (a.set.shake ? 1 : 0)
    << "\nnumbers=" << (a.set.numbers ? 1 : 0) << "\nfullscreen=" << (a.set.fullscreen ? 1 : 0) << "\nspeed=" << a.set.speed << "\nmaxDescent=" << a.set.maxDescent
    << "\ntutorial=" << (a.set.tutorialDone ? 1 : 0) << "\n";
}

// anyone with a finished, abandoned or saved run has already been through the first-floor hints
static bool hasPlayedBefore(App& a) {
  std::ifstream sc(std::filesystem::path(a.baseDir + L"\\scores.txt"));
  std::string line;
  if (std::getline(sc, line) && !line.empty()) return true;
  return GetFileAttributesW((a.baseDir + L"\\morgue").c_str()) != INVALID_FILE_ATTRIBUTES ||
         GetFileAttributesW(savePath(a).c_str()) != INVALID_FILE_ATTRIBUTES;
}

static void loadSettings(App& a) {
  std::ifstream f(std::filesystem::path(a.baseDir + L"\\settings.ini"));
  std::string line;
  bool sawTutorial = false;
  while (std::getline(f, line)) {
    size_t p = line.find('=');
    if (p == std::string::npos) continue;
    std::string k = line.substr(0, p);
    float v = (float)atof(line.c_str() + p + 1);
    if (k == "master") a.set.master = clampv(v, 0.f, 1.f);
    else if (k == "sfx") a.set.sfx = clampv(v, 0.f, 1.f);
    else if (k == "music") a.set.music = clampv(v, 0.f, 1.f);
    else if (k == "shake") a.set.shake = v != 0;
    else if (k == "numbers") a.set.numbers = v != 0;
    else if (k == "fullscreen") a.set.fullscreen = v != 0;
    else if (k == "speed") a.set.speed = (int)v >= 2 ? 2 : 1;
    else if (k == "maxDescent") a.set.maxDescent = clampv((int)v, 0, MAX_DESCENT);
    else if (k == "tutorial") {
      a.set.tutorialDone = v != 0;
      sawTutorial = true;
    }
  }
  // settings written before the flag existed
  if (!sawTutorial) a.set.tutorialDone = hasPlayedBefore(a);
}

void applySettings(App& a) { audio::setVolumes(a.set.master, a.set.sfx, a.set.music); }

void setFullscreen(App& a, bool on) {
  a.set.fullscreen = on;
  if (!g_hwnd || on == g_isFullscreen) return;
  DWORD style = GetWindowLongW(g_hwnd, GWL_STYLE);
  if (on) {
    MONITORINFO mi = {sizeof(mi)};
    if (GetWindowPlacement(g_hwnd, &g_wpPrev) && GetMonitorInfoW(MonitorFromWindow(g_hwnd, MONITOR_DEFAULTTOPRIMARY), &mi)) {
      SetWindowLongW(g_hwnd, GWL_STYLE, style & ~WS_OVERLAPPEDWINDOW);
      SetWindowPos(g_hwnd, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, mi.rcMonitor.right - mi.rcMonitor.left,
                   mi.rcMonitor.bottom - mi.rcMonitor.top, SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
    }
  } else {
    SetWindowLongW(g_hwnd, GWL_STYLE, style | WS_OVERLAPPEDWINDOW);
    SetWindowPlacement(g_hwnd, &g_wpPrev);
    SetWindowPos(g_hwnd, nullptr, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_NOOWNERZORDER | SWP_FRAMECHANGED);
  }
  g_isFullscreen = on;
}

// ------------------------------------------------------------------ saves / morgue
void writeSave(App& a) {
  if (a.ui != UI_GAME && a.ui != UI_SETTINGS && a.ui != UI_HELP) return;
  if (a.w.dead || a.w.won || a.w.screen == RS_DEATH || a.w.screen == RS_VICTORY) return;
  if (saveRun(a.w, savePath(a))) a.hasSave = true;
}

void deleteSave(App& a) {
  _wremove(savePath(a).c_str());
  a.hasSave = false;
}

bool tryContinue(App& a) {
  if (!loadRun(a.w, savePath(a))) {
    a.hasSave = false;
    return false;
  }
  clearPresentation(a);
  a.paused = false;
  a.deathT = 0;
  a.deathHandled = false;
  a.lastMorgue.clear();
  a.logScroll = 0;
  a.targetAb = a.targetItem = -1;
  a.fastToggle = a.set.speed >= 2;
  logMsg(a.w, 0xa0c0ff, "Welcome back.");
  return true;
}

void recordRunEnd(App& a) {
  if (a.deathHandled) return;
  a.deathHandled = true;
  World& w = a.w;
  std::string m = morgueText(w);
  a.lastMorgue = m;
  CreateDirectoryW((a.baseDir + L"\\morgue").c_str(), nullptr);
  time_t t = time(nullptr);
  tm lt;
  localtime_s(&lt, &t);
  char name[128];
  snprintf(name, sizeof(name), "\\morgue\\%04d%02d%02d-%02d%02d%02d-%s.txt", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday, lt.tm_hour,
           lt.tm_min, lt.tm_sec, w.won ? "win" : "death");
  std::ofstream f(std::filesystem::path(a.baseDir + widen(name)));
  f << m;
  std::ofstream sc(std::filesystem::path(a.baseDir + L"\\scores.txt"), std::ios::app);
  char date[32];
  snprintf(date, sizeof(date), "%04d-%02d-%02d", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday);
  if (w.won && w.descent >= a.set.maxDescent && a.set.maxDescent < MAX_DESCENT) {
    a.set.maxDescent = w.descent + 1;
    saveSettings(a);
  }
  sc << runScore(w) << "|" << SPECIES[w.pl.species].name << " " << BGS[w.pl.bg].name << " (XL " << w.pl.xl << (w.descent ? ", DL " + std::to_string(w.descent) : std::string()) << ") - "
     << (w.won ? std::string("escaped with the Orb!") : ("killed by " + w.rs.killer + " on " + locationName(w))) << " - " << date
     << "\n";
  deleteSave(a);
}

// ------------------------------------------------------------------ per-frame game logic
static void updateGame(App& a, float dt) {
  World& w = a.w;
  Input& in = a.in;
  bool onFloor = w.screen == RS_FLOOR;
  bool targeting = a.targetAb >= 0 || a.targetItem >= 0;
  if (!onFloor) a.invokeOpen = false;
  if (in.keyPressed[KEY_ESC] && a.invokeOpen && !a.paused) {
    a.invokeOpen = false;
    in.keyPressed[KEY_ESC] = false;
  }
  if (in.keyPressed[KEY_ESC] && !targeting && w.screen != RS_DEATH && w.screen != RS_VICTORY) {
    a.paused = !a.paused;
    a.confirmAbandon = false;
    in.keyPressed[KEY_ESC] = false;
  }
  if (a.paused) {
    updatePresentation(a, dt);
    return;
  }
  bool modal = !w.offers.empty() || !w.relicOffers.empty();
  if (onFloor && !modal) {
    std::vector<int> acts = activeList(w);
    for (int i = 0; i < MAX_ABILITY_KEYS && i < (int)acts.size(); ++i)
      if (in.keyPressed[ABILITY_KEY_VK[i]]) tryCast(a, acts[i], true);
    if (in.keyPressed['G'] && w.pl.patron >= 0) {
      a.invokeOpen = !a.invokeOpen;
      audio::play(S_CLICK, 0.5f, a.invokeOpen ? 1.15f : 0.85f);
    }
    static const int IK[6] = {'Z', 'X', 'C', 'V', 'B', 'N'};
    for (int i = 0; i < 6 && i < (int)w.pl.items.size(); ++i)
      if (in.keyPressed[IK[i]] && w.pl.items[i].id >= 0) tryUseItem(a, i);
    if (in.keyPressed[KEY_TAB]) {
      std::vector<int> alive;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (!w.fl.mons[i].dead && !w.fl.mons[i].charmed) alive.push_back(i);
      if (!alive.empty()) {
        int cur = focusTarget(w);
        size_t k = 0;
        for (size_t j = 0; j < alive.size(); ++j)
          if (alive[j] == cur) k = j;
        w.fl.focus = alive[(k + 1) % alive.size()];
        audio::play(S_CLICK, 0.5f, 1.3f);
      }
    }
    bool l = in.keyDown['A'] || in.keyDown[KEY_LEFT], r = in.keyDown['D'] || in.keyDown[KEY_RIGHT];
    if (in.keyPressed['A'] || in.keyPressed[KEY_LEFT]) flipperPress(w, 0, true);
    if (in.keyPressed['D'] || in.keyPressed[KEY_RIGHT]) flipperPress(w, 1, true);
    if (!l && w.fl.flipKey[0]) flipperPress(w, 0, false);
    if (!r && w.fl.flipKey[1]) flipperPress(w, 1, false);
  }
  if (in.keyPressed['F']) a.fastToggle = !a.fastToggle;
  if (onFloor) {
    float speed = (a.fastToggle ? 2.f : 1.f) * (in.keyDown[KEY_SPACE] ? 4.f : 1.f);
    if (w.fl.shot.slowT > 0) speed *= 0.35f;
    if (modal && w.fl.phase == PH_AIM) speed = 1.f;
    a.simAcc += dt * speed;
    int steps = 0;
    while (a.simAcc >= TICK && steps < 64) {
      floorUpdate(w, TICK);
      a.simAcc -= TICK;
      steps++;
      if (w.screen != RS_FLOOR) break;
    }
    if (steps >= 64) a.simAcc = 0;
    if (w.fl.phase == PH_CLEARED && w.fl.clearT > 1.5f && w.offers.empty()) {
      clearPresentation(a);
      floorCleared(w);
    }
    if (w.fl.phase == PH_DEAD || w.dead) {
      a.deathT += dt;
      if (a.deathT > 2.4f) {
        w.screen = RS_DEATH;
        recordRunEnd(a);
      }
    }
  }
  if (w.screen == RS_VICTORY) recordRunEnd(a);
  playFx(a, w, true);
  updatePresentation(a, dt);
  if (onFloor) computePreview(a);
  if (w.autosaveWanted && !w.dead && !w.won) {
    if (w.screen != RS_FLOOR || w.fl.phase == PH_AIM) {
      writeSave(a);
      w.autosaveWanted = false;
    }
  }
}

static void updateMusic(App& a) {
  // the title theme alternates between two songs from one launch to the next
  static const int titleMood = (GetTickCount() & 1) ? 19 : 0;
  if (a.ui != UI_GAME) {
    audio::setMusic(titleMood, 0.f);
    return;
  }
  World& w = a.w;
  int actBiome = w.act == 0 ? BI_HALLS : w.act == 1 ? w.branchA : w.act == 2 ? w.branchB : BI_CORE;
  switch (w.screen) {
    case RS_DEATH: audio::setMusic(17, 0.f); break;
    case RS_VICTORY: audio::setMusic(16, 0.f); break;
    case RS_SHOP: audio::setMusic(9, 0.f); break;
    case RS_REST: audio::setMusic(12, 0.f); break;
    case RS_ALTAR: audio::setMusic(13, 0.f); break;
    case RS_EVENT: audio::setMusic(14, 0.f); break;
    case RS_FLOOR: {
      const Floor& f = w.fl;
      float inten = f.spec.kind == FK_BOSS ? 1.f : f.spec.kind == FK_ELITE ? 0.5f : 0.f;
      if (f.isVault) audio::setMusic(15, 0.f);
      else if (hasMod(w, MOD_PLAYGROUND)) audio::setMusic(18, inten);
      else audio::setMusic(BIOME[f.spec.biome].mood, inten);
      break;
    }
    default: audio::setMusic(BIOME[actBiome].mood, 0.f); break;
  }
}

static void drawAll(App& a) {
  switch (a.ui) {
    case UI_TITLE: drawTitle(a); break;
    case UI_NEWRUN: drawNewRun(a); break;
    case UI_GAME: drawGame(a); break;
    case UI_HALL: drawHall(a); break;
    case UI_HELP: drawHelp(a); break;
    case UI_SETTINGS: drawSettings(a); break;
  }
  drawTooltip(a);
}

static void takeScreenshot(App& a, const std::wstring& path) {
  Gfx off;
  if (!off.initOffscreen(1600, 900)) return;
  std::swap(a.g, off);
  if (a.g.beginFrame()) {
    Input saved = a.in;
    a.in.lPressed = a.in.rPressed = false;
    a.in.consumed = true;
    drawAll(a);
    a.in = saved;
    a.g.endFrame();
    a.g.savePng(path);
  }
  std::swap(a.g, off);
  off.shutdown();
}

static void frame(App& a, float dt) {
  a.time += dt;
  a.tip = Tooltip();
  if (a.in.keyPressed[KEY_F11]) setFullscreen(a, !g_isFullscreen);
  if (a.ui == UI_GAME) updateGame(a, dt);
  else {
    if (a.in.keyPressed[KEY_ESC]) {
      if (a.ui == UI_SETTINGS || a.ui == UI_HELP) a.ui = a.settingsReturn;
      else if (a.ui != UI_TITLE) a.ui = UI_TITLE;
    }
    updatePresentation(a, dt);
  }
  updateMusic(a);
  if (a.g.beginFrame()) {
    drawAll(a);
    a.g.endFrame();
  }
  if (a.in.keyPressed[KEY_F12]) {
    CreateDirectoryW((a.baseDir + L"\\screenshots").c_str(), nullptr);
    time_t t = time(nullptr);
    tm lt;
    localtime_s(&lt, &t);
    wchar_t name[128];
    swprintf(name, 128, L"\\screenshots\\dropcrawl-%04d%02d%02d-%02d%02d%02d.png", lt.tm_year + 1900, lt.tm_mon + 1, lt.tm_mday,
             lt.tm_hour, lt.tm_min, lt.tm_sec);
    takeScreenshot(a, a.baseDir + name);
    audio::play(S_CLICK, 0.8f, 0.6f);
  }
  a.in.endFrame();
}

// ------------------------------------------------------------------ window
static LRESULT CALLBACK wndProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
  App* a = G;
  switch (msg) {
    case WM_SIZE:
      if (a && wp != SIZE_MINIMIZED) a->g.resize(LOWORD(lp), HIWORD(lp));
      return 0;
    case WM_MOUSEMOVE:
      if (a) a->in.mouse = a->g.toLogical((float)GET_X_LPARAM(lp), (float)GET_Y_LPARAM(lp));
      return 0;
    case WM_LBUTTONDOWN:
      if (a) {
        a->in.lDown = true;
        a->in.lPressed = true;
        a->in.mouse = a->g.toLogical((float)GET_X_LPARAM(lp), (float)GET_Y_LPARAM(lp));
      }
      SetCapture(h);
      return 0;
    case WM_LBUTTONUP:
      if (a) {
        a->in.lDown = false;
        a->in.lReleased = true;
      }
      ReleaseCapture();
      return 0;
    case WM_RBUTTONDOWN:
      if (a) {
        a->in.rDown = true;
        a->in.rPressed = true;
      }
      return 0;
    case WM_RBUTTONUP:
      if (a) a->in.rDown = false;
      return 0;
    case WM_MOUSEWHEEL:
      if (a) a->in.wheel += GET_WHEEL_DELTA_WPARAM(wp) / 120.f;
      return 0;
    case WM_KEYDOWN:
    case WM_SYSKEYDOWN:
      if (a && wp < 256) {
        if (!(lp & (1 << 30))) a->in.keyPressed[wp] = true;
        a->in.keyDown[wp] = true;
        if (wp == VK_RETURN && (GetKeyState(VK_MENU) & 0x8000)) {
          setFullscreen(*a, !g_isFullscreen);
          return 0;
        }
        if (wp == VK_F10 || wp == VK_MENU) return 0;
      }
      break;
    case WM_KEYUP:
    case WM_SYSKEYUP:
      if (a && wp < 256) a->in.keyDown[wp] = false;
      break;
    case WM_CHAR:
      if (a && wp >= 32 && wp < 127) a->in.chars += (char)wp;
      return 0;
    case WM_KILLFOCUS:
      if (a) {
        for (auto& k : a->in.keyDown) k = false;
        a->in.lDown = a->in.rDown = false;
      }
      return 0;
    case WM_GETMINMAXINFO: {
      MINMAXINFO* mm = (MINMAXINFO*)lp;
      mm->ptMinTrackSize.x = 820;
      mm->ptMinTrackSize.y = 500;
      return 0;
    }
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: ValidateRect(h, nullptr); return 0;
    case WM_CLOSE:
      if (a) a->quit = true;
      return 0;
    case WM_DESTROY: PostQuitMessage(0); return 0;
  }
  return DefWindowProcW(h, msg, wp, lp);
}

static void enableDpiAwareness() {
  HMODULE u = GetModuleHandleW(L"user32.dll");
  typedef BOOL(WINAPI * SetCtx)(HANDLE);
  SetCtx f = u ? (SetCtx)(void*)GetProcAddress(u, "SetProcessDpiAwarenessContext") : nullptr;
  if (f) f((HANDLE)-4);  // DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
  else SetProcessDPIAware();
}

// ------------------------------------------------------------------ command-line screenshot scenarios (for testing)
static void clearAllMonsters(World& w) {
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (!w.fl.mons[i].dead) killMonster(w, i, DS_SPELL);
}

int setPieceCount();
static int runScenario(App& a, const std::wstring& out, const std::string& scen, int arg) {
  if (!a.g.initOffscreen(1600, 900)) return 2;
  a.set.shake = false;
  uint64_t seed = 1000 + (uint64_t)arg;
  auto newGame = [&](int sp, int bg) {
    a.selSpecies = sp;
    a.selBg = bg;
    newRun(a.w, seed, sp, bg);
    a.ui = UI_GAME;
    clearPresentation(a);
  };
  auto step = [&](int ticks) {
    for (int i = 0; i < ticks; ++i) {
      floorUpdate(a.w, TICK);
      if (i % 2 == 0) {
        playFx(a, a.w, false);
        updatePresentation(a, TICK * 2);
      }
    }
  };
  int frames = 1;
  if (scen == "title") {
    a.ui = UI_TITLE;
    frames = 240;
  } else if (scen == "newrun") {
    a.ui = UI_NEWRUN;
    a.selSpecies = 2;
    a.selBg = 4;
  } else if (scen == "floor" || scen == "flight" || scen == "enemy" || scen == "levelup" || scen == "hover") {
    newGame(arg % SP_COUNT, (arg * 3) % BG_COUNT);
    a.aimAngle = 1.2f;
    a.in.mouse = V2(700, 300);
    if (scen == "flight") {
      launch(a.w, 1.25f, a.w.fl.launchSpeed);
      step(110);
    } else if (scen == "enemy") {
      launch(a.w, 1.4f, a.w.fl.launchSpeed);
      int g = 0;
      while (a.w.fl.phase == PH_FLIGHT && g++ < 20000) step(1);
      step(40);
    } else if (scen == "levelup") {
      a.w.pendingLevels = 1;
      a.w.pl.xl = 2;
      generateOffers(a.w);
    } else if (scen == "hover") {
      for (auto& m : a.w.fl.mons)
        if (!m.dead) {
          a.in.mouse = m.p;
          break;
        }
    }
    computePreview(a);
  } else if (scen == "toys" || scen == "tumbler" || scen == "slots") {
    newGame(arg % SP_COUNT, (arg * 5) % BG_COUNT);
    int bi = arg % BI_COUNT;
    a.w.act = bi == BI_HALLS ? 0 : (bi == BI_CORE ? 3 : ((bi <= BI_MINES || bi == BI_SLIME) ? 1 : 2));
    a.w.depth = 6 + a.w.act * 5;
    FloorSpec s = makeFloorSpec(a.w, FK_NORMAL, bi, a.w.act, 3, arg);
    s.nMods = 1;
    s.mods[0] = (uint8_t)(scen == "slots" ? MOD_CASINO : scen == "tumbler" ? MOD_PLAYGROUND : (int)(MOD_TULIPS + arg % 15));
    floorBegin(a.w, s);
    for (int k = 0; k < 3; ++k) placeNamedSetPiece(a.w, (arg * 7 + k * 11) % setPieceCount(), V2(-1, -1));
    if (scen == "tumbler") {
      a.w.pl.patron = PT_TUMBLER;
      a.w.pl.piety = 150;
      recalcStats(a.w);
      a.w.tumblerMood = 80;
    }
    if (scen == "slots") {
      queueSlotSpin(a.w);
      queueSlotSpin(a.w);
    }
    for (int k = 0; k < 4; ++k) gainRandart(a.w, newRandartSeed(a.w));
    a.aimAngle = 1.3f + 0.1f * (arg % 5);
    a.in.mouse = V2(700, 300);
    computePreview(a);
    if (scen != "toys") {
      launch(a.w, a.aimAngle, a.w.fl.launchSpeed);
      step(scen == "slots" ? 100 : 150);
    }
  } else if (scen == "biome" || scen == "boss" || scen == "elite" || scen == "vault") {
    newGame(arg % SP_COUNT, 1);
    int bi = arg % BI_COUNT;
    a.w.act = bi == BI_HALLS ? 0 : (bi == BI_CORE ? 3 : ((bi <= BI_MINES || bi == BI_SLIME) ? 1 : 2));
    a.w.depth = 4 + a.w.act * 6;
    int kind = scen == "boss" ? FK_BOSS : scen == "elite" ? FK_ELITE : scen == "vault" ? FK_VAULT : FK_NORMAL;
    FloorSpec s = makeFloorSpec(a.w, kind, bi, a.w.act, 3, arg);
    if (scen == "biome" && s.nMods == 0) {
      s.mods[0] = (uint8_t)(arg % MOD_COUNT);
      s.nMods = 1;
    }
    floorBegin(a.w, s);
    a.aimAngle = 1.9f;
    computePreview(a);
    launch(a.w, 1.9f, a.w.fl.launchSpeed);
    step(70);
  } else if (scen == "stairs" || scen == "reward" || scen == "shop" || scen == "rest" || scen == "altar" || scen == "event" ||
             scen == "death" || scen == "victory") {
    newGame(arg % SP_COUNT, 2);
    for (int k = 0; k < 3; ++k) gainRelic(a.w, k * 7 + arg);
    learnAbility(a.w, AB_FIREBALL);
    learnAbility(a.w, AB_CRITPEGS);
    a.w.pl.gold = 260;
    clearAllMonsters(a.w);
    a.w.fx.clear();
    floorCleared(a.w);
    if (scen != "reward") {
      finishReward(a.w);
      if (scen == "shop" || scen == "rest" || scen == "altar" || scen == "event") {
        StairOpt o;
        o.kind = scen == "shop" ? ST_SHOP : scen == "rest" ? ST_REST : scen == "altar" ? ST_ALTAR : ST_EVENT;
        a.w.stairs.clear();
        a.w.stairs.push_back(o);
        enterStairs(a.w, 0);
        if (scen == "event") a.w.eventId = arg % NUM_EVENTS;
      } else if (scen == "death" || scen == "victory") {
        a.w.dead = scen == "death";
        a.w.won = scen == "victory";
        a.w.rs.killer = "an orc";
        a.w.screen = scen == "death" ? RS_DEATH : RS_VICTORY;
      }
    }
    a.w.fx.clear();
  } else if (scen == "v3pegs" || scen == "format" || scen == "stats" || scen == "relics" || scen == "meteor") {
    newGame(arg % SP_COUNT, (arg * 7) % BG_COUNT);
    int bi = arg % BI_COUNT;
    a.w.act = bi == BI_HALLS ? 0 : (bi == BI_CORE ? 3 : ((bi <= BI_MINES || bi == BI_SLIME) ? 1 : 2));
    a.w.depth = 6 + a.w.act * 5;
    int kind = scen == "meteor" ? FK_BOSS : FK_NORMAL;
    if (scen == "meteor") bi = BI_CORE, a.w.act = 3, a.w.depth = 26;
    FloorSpec s = makeFloorSpec(a.w, kind, bi, a.w.act, 3, arg);
    if (scen == "format") s.format = (uint8_t)(arg % FORMAT_COUNT);
    floorBegin(a.w, s);
    a.aimAngle = 1.3f;
    a.in.mouse = V2(700, 300);
    if (scen == "v3pegs") {
      int k = PK_LOOT, n = 0;
      for (int row = 0; row < 4 && k < PK_COUNT; ++row)
        for (int col = 0; col < 5 && k < PK_COUNT; ++col, ++k) {
          V2 p(PX0 + 110 + col * 150.f, 190 + row * 150.f);
          for (auto& q : a.w.fl.pegs)
            if (!q.dead && dist(q.p, p) < 30) q.dead = true;
          int pi = addPeg(a.w, k, p, (k == PK_SHRINE || k == PK_MIMIC || k == PK_WELL) ? 15.f : (isEnchant(k) ? PIN_R + 1.f : 10.f));
          if (pi >= 0) {
            a.w.fl.pegs[pi].val = n % 4;
            a.w.fl.pegs[pi].aux = n % 5;
            if (k == PK_SHRINE) a.w.fl.pegs[pi].hp = 1;
          }
          n++;
        }
      for (int i = 0, c = 0; i < (int)a.w.fl.mons.size() && c < 2; ++i)
        if (!a.w.fl.mons[i].dead) makeChampion(a.w, i, c++ == 1);
      int cl = freeClearing(a.w, V2(-1, -1), true);
      if (cl >= 0) {
        int ti = spawnMonster(a.w, M_TREASURE, cl, false);
        if (ti >= 0) a.w.fl.mons[ti].escapeT = 4;
      }
      a.w.pl.shards = 2;
      activateShrine(a.w, 0, V2(800, 300));
      a.w.fx.clear();
    } else if (scen == "stats") {
      a.w.pl.xl = 3;
      a.w.pl.statPoints = 1;
      generateOffers(a.w);
    } else if (scen == "relics") {
      a.w.relicOffers.clear();
      Offer o;
      o.type = 1;
      o.id = RL_IRONRING;
      o.seed = newAffixSeed(a.w);
      a.w.relicOffers.push_back(o);
      o.id = RL_FIRST_UNIQUE + arg % 26;
      o.seed = 0;
      a.w.relicOffers.push_back(o);
      o.id = RL_FIRST_SET + arg % 12;
      a.w.relicOffers.push_back(o);
      o.type = 2;
      o.id = (int)newRandartSeed(a.w);
      a.w.relicOffers.push_back(o);
      for (int k = 0; k < 4; ++k) gainRelic(a.w, RL_FIRST_UNIQUE + (arg + k * 5) % 26, 0);
      for (int k = 0; k < 4; ++k) gainRelic(a.w, (arg * 3 + k * 9) % RL_FIRST_UNIQUE, newAffixSeed(a.w));
    } else if (scen == "meteor") {
      for (int t = 0; t < 3; ++t) {
        int pi = addPeg(a.w, PK_MBOMB, V2(600 + t * 200.f, 600), 16);
        if (pi >= 0) {
          a.w.fl.pegs[pi].hp = 40;
          a.w.fl.pegs[pi].val = 2;
          a.w.fl.pegs[pi].aux = 3 - t;
        }
      }
      a.w.fl.bossTurns = 9;
    }
    computePreview(a);
  } else if (scen == "help") {
    a.ui = UI_HELP;
    a.helpPage = arg % 7;
  } else if (scen == "settings") {
    a.ui = UI_SETTINGS;
  } else if (scen == "invoke") {
    // the invocations window: arg picks the god; piety at the third gift, hovering the first gift
    newGame(arg % SP_COUNT, (arg * 3) % BG_COUNT);
    a.w.pl.patron = arg % PT_COUNT;
    a.w.pl.piety = 100;
    recalcStats(a.w);
    a.w.pl.abil.push_back({AB_HASTE, 1, 0});
    if (arg >= 100) {
      // a long run's worth of castable abilities: the list switches to compact rows
      for (int ab = 0; ab < AB_FIRST_DIVINE && (int)a.w.pl.abil.size() < 11; ++ab)
        if (ABIL[ab].timing == T_AIM && !ABIL[ab].innate && ab != AB_HASTE) a.w.pl.abil.push_back({(uint16_t)ab, (uint8_t)(1 + ab % 2), 0});
      a.w.pl.abil[3].cd = 2;
    }
    a.invokeOpen = arg < 100;
    a.in.mouse = V2(560, 886 - (60 + 5 * 50 + 6) + 58 + 20);
    computePreview(a);
  } else if (scen == "tutorial") {
    // first-floor hints. arg 0: as settings.ini next to the exe says; 1: the first run ever; 2: the run after it.
    // Settings and saves go next to the output image, never into the game folder.
    std::wstring dir = std::filesystem::path(out).parent_path().wstring();
    a.baseDir = dir.empty() ? L"." : dir;
    if (arg >= 1) a.set.tutorialDone = false;
    if (arg == 2) startNewRun(a, seed);
    startNewRun(a, seed);
    computePreview(a);
  } else if (scen == "hall") {
    loadScores(a);
    a.ui = UI_HALL;
  } else {
    return 3;
  }
  for (int f = 0; f < frames; ++f) {
    a.time += 1.f / 60.f;
    a.tip = Tooltip();
    if (!a.g.beginFrame()) return 4;
    drawAll(a);
    a.g.endFrame();
    a.in.endFrame();
  }
  return a.g.savePng(out) ? 0 : 5;
}

// ------------------------------------------------------------------ monkey test: real UI loop, synthetic input
static int runAutoplay(App& a, const std::wstring& outDir, int frames, int seed) {
  if (!a.g.initOffscreen(1600, 900)) return 2;
  CreateDirectoryW(outDir.c_str(), nullptr);
  a.baseDir = outDir;  // keep saves / morgue / scores out of the real game folder
  std::ofstream log(std::filesystem::path(outDir + L"/autoplay.txt"));
  Rng r((uint64_t)seed * 7919 + 1);
  const float dt = 1.f / 30.f;
  int runs = 0, shots = 0, deaths = 0, wins = 0, maxDepth = 0;
  int endWait = 0;
  for (int fr = 0; fr < frames; ++fr) {
    if (fr % 15 == 0) a.in.mouse = V2(r.rangef(BOARD_X0 + 20, BOARD_X1 - 20), r.rangef(80, 850));
    if (a.ui != UI_GAME) {
      a.selSpecies = r.range(0, SP_COUNT - 1);
      a.selBg = r.range(0, BG_COUNT - 1);
      startNewRun(a, (r.next() % 1000000) + 1);
      runs++;
      log << "run " << runs << ": " << SPECIES[a.selSpecies].name << " " << BGS[a.selBg].name << " seed " << a.w.seed << std::endl;
    } else {
      World& w = a.w;
      if (w.screen == RS_DEATH || w.screen == RS_VICTORY) {
        if (++endWait > 60) {
          endWait = 0;
          if (w.won) wins++;
          else deaths++;
          log << "  ended: " << (w.won ? "WON" : "died") << " depth " << w.depth << " killer " << w.rs.killer << std::endl;
          a.ui = UI_TITLE;
        }
      } else if (w.screen == RS_FLOOR) {
        Floor& f = w.fl;
        maxDepth = std::max(maxDepth, w.depth);
        if (!w.offers.empty()) {
          if (r.chance(0.1f)) chooseOffer(w, r.range(-1, (int)w.offers.size() - 1));
        } else if (!w.relicOffers.empty()) {
          if (r.chance(0.1f)) chooseRelicOffer(w, r.range(0, (int)w.relicOffers.size() - 1));
        } else if (a.targetAb >= 0 || a.targetItem >= 0) {
          int alive = -1;
          for (int i = 0; i < (int)f.mons.size(); ++i)
            if (!f.mons[i].dead) alive = i;
          if (alive >= 0 && r.chance(0.6f)) a.in.mouse = f.mons[alive].p;
          else a.in.mouse = V2(r.rangef(450, 1150), r.rangef(160, 780));
          if (r.chance(0.5f)) a.in.lPressed = true;
          else if (r.chance(0.1f)) a.in.rPressed = true;
        } else if (f.phase == PH_AIM) {
          if (r.chance(0.03f)) a.in.keyPressed['1' + r.range(0, 5)] = true;
          if (r.chance(0.01f)) a.in.keyPressed[(int)"ZXCVBN"[r.range(0, 5)]] = true;
          if (r.chance(0.02f)) a.in.keyPressed['G'] = true;  // invocations window
          if (a.invokeOpen && r.chance(0.3f)) a.in.mouse = V2(r.rangef(390, 780), r.rangef(620, 880));
          if (r.chance(0.01f)) a.in.keyPressed[KEY_TAB] = true;
          if (r.chance(0.01f)) a.in.rPressed = true;
          if (r.chance(0.04f)) {
            a.in.mouse = V2(r.rangef(420, 1180), r.rangef(140, 800));
            a.in.lPressed = true;
            shots++;
          }
        } else if (f.phase == PH_FLIGHT) {
          a.in.keyDown[KEY_SPACE] = r.chance(0.9f);
          if (r.chance(0.01f)) a.in.keyPressed['1' + r.range(0, 5)] = true;
          if (r.chance(0.02f)) {
            int k = r.chance(0.5f) ? 'A' : 'D';
            a.in.keyPressed[k] = true;
            a.in.keyDown[k] = true;
          }
        } else if (f.phase == PH_REDIRECT || f.phase == PH_RELAUNCH) {
          a.in.mouse = V2(r.rangef(450, 1150), r.rangef(300, 700));
          a.in.lPressed = true;
        } else {
          a.in.keyDown[KEY_SPACE] = true;
        }
        if (r.chance(0.002f)) a.in.keyPressed[KEY_ESC] = true;  // pause
        if (a.paused && r.chance(0.2f)) a.paused = false;
      } else {
        if (fr % 8 == 0) botScreenStep(w, r, nullptr);
      }
    }
    frame(a, dt);
    for (int k : {(int)'A', (int)'D', (int)KEY_SPACE}) a.in.keyDown[k] = false;
    if (fr % 900 == 0) {
      wchar_t name[64];
      swprintf(name, 64, L"/auto_%05d.png", fr / 900);
      a.g.savePng(outDir + name);
      log << "frame " << fr << " ui " << a.ui << " screen " << (int)a.w.screen << " depth " << a.w.depth << " phase "
          << (int)a.w.fl.phase << std::endl;
    }
  }
  log << "done: runs " << runs << " shots " << shots << " deaths " << deaths << " wins " << wins << " maxDepth " << maxDepth << std::endl;
  return 0;
}

// ------------------------------------------------------------------ entry
int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int nShow) {
  enableDpiAwareness();
  CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
  initContent();
  std::string err;
  if (!validateContent(err)) {
    MessageBoxA(nullptr, err.c_str(), "Dropcrawl content error", MB_ICONERROR);
    return 1;
  }
  static App app;
  G = &app;
  App& a = app;
  a.baseDir = exeDir();
  a.demoRng.reseed(GetTickCount64() ^ 0x9e3779b97f4a7c15ull);
  loadSettings(a);
  a.fastToggle = a.set.speed >= 2;

  int argc = 0;
  LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
  if (argc >= 3 && std::wstring(argv[1]) == L"--autoplay") {
    int frames = argc >= 4 ? _wtoi(argv[3]) : 20000;
    int seed = argc >= 5 ? _wtoi(argv[4]) : 1;
    int rc = runAutoplay(a, argv[2], frames, seed);
    a.g.shutdown();
    CoUninitialize();
    return rc;
  }
  if (argc >= 4 && std::wstring(argv[1]) == L"--shot") {
    std::wstring out = argv[2];
    std::wstring scw = argv[3];
    std::string scen(scw.begin(), scw.end());
    int arg = argc >= 5 ? _wtoi(argv[4]) : 0;
    int rc = runScenario(a, out, scen, arg);
    a.g.shutdown();
    CoUninitialize();
    return rc;
  }

  audio::init();
  applySettings(a);
  a.hasSave = GetFileAttributesW(savePath(a).c_str()) != INVALID_FILE_ATTRIBUTES;

  WNDCLASSEXW wc = {sizeof(wc)};
  wc.style = CS_HREDRAW | CS_VREDRAW;
  wc.lpfnWndProc = wndProc;
  wc.hInstance = hInst;
  wc.hCursor = LoadCursor(nullptr, IDC_ARROW);
  wc.hIcon = LoadIconW(hInst, MAKEINTRESOURCEW(1));
  if (!wc.hIcon) wc.hIcon = LoadIcon(nullptr, IDI_APPLICATION);
  wc.hIconSm = wc.hIcon;
  wc.lpszClassName = L"DropcrawlWindow";
  RegisterClassExW(&wc);
  RECT work;
  SystemParametersInfoW(SPI_GETWORKAREA, 0, &work, 0);
  int ww = work.right - work.left, wh = work.bottom - work.top;
  float sc = std::min(ww * 0.92f / 1600.f, wh * 0.9f / 900.f);
  int cw = (int)(1600 * sc), ch = (int)(900 * sc);
  RECT r = {0, 0, cw, ch};
  AdjustWindowRectEx(&r, WS_OVERLAPPEDWINDOW, FALSE, 0);
  int winW = r.right - r.left, winH = r.bottom - r.top;
  g_hwnd = CreateWindowExW(0, wc.lpszClassName, L"Dropcrawl", WS_OVERLAPPEDWINDOW, work.left + (ww - winW) / 2,
                           work.top + std::max(0, (wh - winH) / 2), winW, winH, nullptr, nullptr, hInst, nullptr);
  if (!g_hwnd || !a.g.initWindow(g_hwnd)) {
    MessageBoxA(nullptr, "Could not initialize Direct2D.", "Dropcrawl", MB_ICONERROR);
    return 1;
  }
  ShowWindow(g_hwnd, nShow);
  UpdateWindow(g_hwnd);
  if (a.set.fullscreen) {
    a.set.fullscreen = false;
    setFullscreen(a, true);
  }
  LARGE_INTEGER freq, last, now;
  QueryPerformanceFrequency(&freq);
  QueryPerformanceCounter(&last);
  MSG msg;
  while (!a.quit) {
    while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
      if (msg.message == WM_QUIT) a.quit = true;
      TranslateMessage(&msg);
      DispatchMessageW(&msg);
    }
    if (a.quit) break;
    QueryPerformanceCounter(&now);
    float dt = (float)((now.QuadPart - last.QuadPart) / (double)freq.QuadPart);
    last = now;
    dt = clampv(dt, 0.f, 0.1f);
    if (IsIconic(g_hwnd)) {
      Sleep(30);
      continue;
    }
    frame(a, dt);
  }
  if (a.ui == UI_GAME) writeSave(a);
  saveSettings(a);
  audio::shutdown();
  a.g.shutdown();
  DestroyWindow(g_hwnd);
  CoUninitialize();
  return 0;
}
