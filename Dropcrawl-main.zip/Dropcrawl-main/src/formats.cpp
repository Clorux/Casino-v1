// Dropcrawl - board formats: the large-scale shape of a floor (walls, shelves, funnels, rock, machines) that the
// pins, set pieces and monsters are then laid out around. The Tumbler can rebuild a live board into another format.
#include "rules.h"

enum FormatId {
  FMT_CLASSIC, FMT_FUNNEL, FMT_SPLIT, FMT_TIERS, FMT_PLINKO, FMT_ARENA, FMT_HOURGLASS, FMT_CAVERN, FMT_ZIGZAG,
  FMT_ISLANDS, FMT_BOWL, FMT_CARNIVAL, FMT_PACHISLOT, FMT_TEMPLE
};
static_assert(FMT_TEMPLE + 1 == FORMAT_COUNT, "format count");

const char* FORMAT_NAME[FORMAT_COUNT] = {"Classic", "Funnel",  "Split",      "Tiers",    "Plinko",    "Arena",    "Hourglass",
                                         "Cavern",  "Zigzag",  "Islands",    "Bumper Bowl", "Carnival", "Pachislot", "Temple"};
const char* FORMAT_DESC[FORMAT_COUNT] = {
    "An open board of pins.",
    "Two long walls funnel every ball toward the middle.",
    "A divider splits the board: every ball goes left or right.",
    "Shelves with gaps: balls rattle down level by level.",
    "A dense triangle grid of pins, like a Galton board.",
    "The monsters stand in a ring around the middle.",
    "Two stone wedges pinch the board into a narrow waist.",
    "Rocky walls close in from both sides.",
    "Long ramps send balls zig-zagging down the board.",
    "Islands of pins between open water and wind.",
    "Few pins, lots of bumpers and kickers.",
    "Everything moves: gears, pendulums and windmills.",
    "A big slot machine in the middle, with tulip lanes.",
    "A symmetric temple with a shrine, rune circles and stars."};

// ---------------------------------------------------------------- helpers
static const int WALL_TAG = -20;

static bool wallClear(const World& w, V2 a, V2 b) {
  const Floor& f = w.fl;
  for (auto& c : f.clearings)
    if (dist(closestOnSeg(c.p, a, b), c.p) < c.r + 18) return false;
  for (auto& m : f.mons)
    if (!m.dead && dist(closestOnSeg(m.p, a, b), m.p) < m.r + 18) return false;
  for (auto& bl : f.balls)
    if (bl.alive && dist(closestOnSeg(bl.p, a, b), bl.p) < bl.r + 14) return false;
  return true;
}

static void wall(World& w, V2 a, V2 b, float th = 5.f) {
  if (!wallClear(w, a, b)) return;
  int si = addSeg(w, SK_WALL, a, b, th);
  if (si < 0) return;
  w.fl.segs[si].link = WALL_TAG;
  w.fl.segs[si].rest = 0.55f;
}

static void rock(World& w, V2 p, float r) {
  Clearing k;
  k.p = p;
  k.r = r;
  k.mon = WALL_TAG;
  w.fl.keepOut.push_back(k);
}

// fill the triangle a-b-c with keep-out circles so nothing spawns inside solid rock
static void rockTriangle(World& w, V2 a, V2 b, V2 c) {
  for (float u = 0.05f; u < 1.f; u += 0.12f)
    for (float v = 0.05f; u + v < 1.f; v += 0.12f) {
      V2 p = a + (b - a) * u + (c - a) * v;
      rock(w, p, 22);
    }
}

static void bumper(World& w, V2 p, float r = 13) {
  if (spotFree(w, p, r, 4)) addPeg(w, PK_BUMPER, p, r);
}

// ---------------------------------------------------------------- choosing a format
int pickFormat(World& w, const FloorSpec& s, Rng& R) {
  (void)w;
  if (s.depth <= 1) return FMT_CLASSIC;
  float wt[FORMAT_COUNT];
  for (int i = 0; i < FORMAT_COUNT; ++i) wt[i] = 1.f;
  wt[FMT_CLASSIC] = 2.5f;
  if (s.kind == FK_VAULT) {
    for (int i = 0; i < FORMAT_COUNT; ++i) wt[i] = 0;
    wt[FMT_CLASSIC] = 2;
    wt[FMT_PACHISLOT] = 2;
    wt[FMT_PLINKO] = 1.5f;
    wt[FMT_CARNIVAL] = 1;
    wt[FMT_BOWL] = 1;
  } else if (s.kind == FK_BOSS) {
    for (int i = 0; i < FORMAT_COUNT; ++i) wt[i] = 0.3f;
    wt[FMT_CLASSIC] = 2.5f;
    wt[FMT_ARENA] = 2.5f;
    wt[FMT_TEMPLE] = 1.2f;
    wt[FMT_HOURGLASS] = 0.5f;
    wt[FMT_CAVERN] = 0.5f;
    wt[FMT_TIERS] = wt[FMT_ZIGZAG] = wt[FMT_SPLIT] = 0.f;  // a boss needs room to stand
  } else {
    switch (s.biome) {
      case BI_HALLS: wt[FMT_CLASSIC] += 1; wt[FMT_PLINKO] += 0.5f; wt[FMT_FUNNEL] += 0.5f; break;
      case BI_LAIR: wt[FMT_ISLANDS] += 1.5f; wt[FMT_CAVERN] += 1.5f; break;
      case BI_DROWNED: wt[FMT_ISLANDS] += 2; wt[FMT_HOURGLASS] += 1; break;
      case BI_MINES: wt[FMT_TIERS] += 1.5f; wt[FMT_ZIGZAG] += 1.5f; wt[FMT_CARNIVAL] += 1; break;
      case BI_CRYPT: wt[FMT_TEMPLE] += 1.5f; wt[FMT_SPLIT] += 1; wt[FMT_CAVERN] += 0.5f; break;
      case BI_FORGE: wt[FMT_FUNNEL] += 1.5f; wt[FMT_BOWL] += 1.5f; break;
      case BI_FROZEN: wt[FMT_PLINKO] += 1.5f; wt[FMT_HOURGLASS] += 1.5f; break;
      case BI_CORE: wt[FMT_PACHISLOT] += 2; wt[FMT_CARNIVAL] += 1.5f; wt[FMT_TEMPLE] += 1; break;
      case BI_SLIME: wt[FMT_CAVERN] += 2; wt[FMT_ISLANDS] += 1; break;
      case BI_ABYSS: wt[FMT_CAVERN] += 1; wt[FMT_TEMPLE] += 1; wt[FMT_ZIGZAG] += 1; wt[FMT_SPLIT] += 1; break;
    }
    for (int i = 0; i < s.nMods; ++i) {
      if (s.mods[i] == MOD_CASINO) wt[FMT_PACHISLOT] += 3;
      if (s.mods[i] == MOD_GEARWORKS) wt[FMT_CARNIVAL] += 3;
      if (s.mods[i] == MOD_BOUNCY) wt[FMT_BOWL] += 2;
      if (s.mods[i] == MOD_RISINGWATER) wt[FMT_TIERS] = wt[FMT_ZIGZAG] = 0.2f;  // rising water hides low shelves
    }
  }
  std::vector<float> v(wt, wt + FORMAT_COUNT);
  int k = R.weighted(v);
  return k < 0 ? FMT_CLASSIC : k;
}

// ---------------------------------------------------------------- structure
static void buildFunnel(World& w, Rng& R) {
  float yTop = R.rangef(300, 400), yBot = yTop + R.rangef(140, 200), gap = R.rangef(64, 90);
  float cx = 800 + R.rangef(-60, 60);
  wall(w, V2(PX0 + 4, yTop), V2(cx - gap, yBot));
  wall(w, V2(PX1 - 4, yTop), V2(cx + gap, yBot));
  bumper(w, V2(cx, yBot + 70), 13);
}

static void buildSplit(World& w, Rng& R) {
  float y0 = R.rangef(220, 260), y1 = R.rangef(520, 600);
  float x = 800 + R.rangef(-20, 20);
  wall(w, V2(x, y0), V2(x, y1), 6);
  bumper(w, V2(x, y0 - 18), 12);
  if (R.chance(0.6f)) {
    wall(w, V2(x, y1), V2(x - 46, y1 + 42));
    wall(w, V2(x, y1), V2(x + 46, y1 + 42));
  }
}

static void buildTiers(World& w, Rng& R) {
  int shelves = R.range(2, 3);
  float span = 470.f / shelves;
  // shelves slope about 16 degrees toward their gaps, as far as the room to the shelf below allows
  float maxRise = span - 80;
  auto rise = [&](float run) { return clampv(run * 0.29f, 18.f, maxRise); };
  for (int s = 0; s < shelves; ++s) {
    float y = 270 + s * span + R.rangef(-10, 10);
    // two or three gaps, never lined up with the shelf above
    int ng = R.range(2, 3);
    std::vector<float> gaps;
    for (int t = 0; t < 200 && (int)gaps.size() < ng; ++t) {
      float g = R.rangef(PX0 + 60, PX1 - 60);
      bool ok = true;
      for (float o : gaps)
        if (std::fabs(o - g) < 230) ok = false;
      if (ok) gaps.push_back(g);
    }
    std::sort(gaps.begin(), gaps.end());
    const float hg = 52;  // half gap width
    float x = PX0 + 4;
    for (size_t i = 0; i <= gaps.size(); ++i) {
      float xe = i < gaps.size() ? gaps[i] - hg : PX1 - 4;
      if (xe - x > 30) {
        bool leftGap = i > 0, rightGap = i < gaps.size();
        if (leftGap && rightGap) {
          // a roof so balls roll off to either gap
          float mid = (x + xe) * 0.5f, h = rise(mid - x);
          wall(w, V2(x, y + h), V2(mid, y));
          wall(w, V2(mid, y), V2(xe, y + h));
        } else if (rightGap) {
          wall(w, V2(x, y), V2(xe, y + rise(xe - x)));
        } else {
          wall(w, V2(x, y + rise(xe - x)), V2(xe, y));
        }
      }
      if (i < gaps.size()) x = gaps[i] + hg;
    }
  }
}

static void buildHourglass(World& w, Rng& R) {
  float waist = R.rangef(420, 500), half = R.rangef(80, 110);
  float top = waist - R.rangef(170, 210), bot = waist + R.rangef(170, 210);
  V2 L0(PX0 + 2, top), L1(800 - half, waist), L2(PX0 + 2, bot);
  V2 Rr0(PX1 - 2, top), R1(800 + half, waist), R2(PX1 - 2, bot);
  wall(w, L0, L1);
  wall(w, L1, L2);
  wall(w, Rr0, R1);
  wall(w, R1, R2);
  rockTriangle(w, L0, L1, L2);
  rockTriangle(w, Rr0, R1, R2);
}

static void buildCavern(World& w, Rng& R) {
  for (int side = 0; side < 2; ++side) {
    float edge = side == 0 ? PX0 + 2 : PX1 - 2;
    float dir = side == 0 ? 1.f : -1.f;
    int n = R.range(5, 7);
    std::vector<V2> pts;
    pts.push_back(V2(edge, R.rangef(170, 220)));
    for (int i = 1; i < n - 1; ++i) {
      float y = 200 + (560.f * i) / (n - 1) + R.rangef(-25, 25);
      float d = R.rangef(20, 110);
      pts.push_back(V2(edge + dir * d, y));
    }
    pts.push_back(V2(edge, R.rangef(740, 780)));
    for (size_t i = 0; i + 1 < pts.size(); ++i) {
      wall(w, pts[i], pts[i + 1]);
      rockTriangle(w, pts[i], pts[i + 1], V2(edge, (pts[i].y + pts[i + 1].y) * 0.5f));
    }
  }
}

static void buildZigzag(World& w, Rng& R) {
  // ramps of 15-20 degrees from alternating walls; with three they are shorter and overlap in the middle.
  // Each ramp starts far enough below the one above that a ball rolling off it drops onto it.
  bool fromLeft = R.chance(0.5f);
  int n = R.range(2, 3);
  const float W = PX1 - PX0 - 8;
  float run = n == 3 ? R.rangef(470, 520) : W - R.rangef(130, 160);
  float drop[3];
  for (int i = 0; i < n; ++i) drop[i] = run * R.rangef(0.27f, 0.36f);
  float y = R.rangef(230, 260);
  for (int i = 0; i < n; ++i) {
    float x0 = fromLeft ? PX0 + 4 : PX1 - 4, dir = fromLeft ? 1.f : -1.f;
    wall(w, V2(x0, y), V2(x0 + dir * run, y + drop[i]));
    if (i + 1 < n) {
      // where this ramp's balls drop, the next ramp (coming from the other wall) is this far down its slope
      float at = (W - run) / run * drop[i + 1];
      y = y + drop[i] + 62 - at;
    }
    fromLeft = !fromLeft;
  }
}

static void buildPachislot(World& w, Rng& R) {
  V2 c(800 + R.rangef(-30, 30), R.rangef(400, 450));
  // a cup that guides balls into the central chucker
  wall(w, c + V2(-110, -100), c + V2(-26, -30));
  wall(w, c + V2(110, -100), c + V2(26, -30));
  for (auto& p : w.fl.pegs)
    if (!p.dead && dist2(p.p, c) < 60 * 60) p.dead = true;
  addTulip(w, c, true);
  rock(w, c, 40);
  static const V2 LANES[] = {V2(-250, 150), V2(250, 150), V2(-160, 250), V2(160, 250)};
  for (auto& o : LANES) {
    V2 p = c + o;
    if (p.y > FIELD_Y1 - 30 || !spotFree(w, p, 20, 6)) continue;
    addTulip(w, p, false);
    rock(w, p, 30);
  }
  for (int k = 0; k < 4; ++k) {
    V2 p = c + V2(R.chance(0.5f) ? R.rangef(-330, -180) : R.rangef(180, 330), R.rangef(-160, 40));
    if (spotFree(w, p, 10, 8)) addPeg(w, PK_COINS, p, 9);
  }
}

static void buildTemple(World& w, Rng& R) {
  Floor& f = w.fl;
  V2 s(800, R.rangef(240, 280));
  int si = addPeg(w, PK_SHRINE, s, 15);
  if (si >= 0) {
    f.pegs[si].hp = 1;
    f.pegs[si].aux = R.range(0, SHRINE_COUNT - 1);
  }
  rock(w, s, 34);
  float ry = R.rangef(430, 480), rx = R.rangef(220, 270);
  for (int side = -1; side <= 1; side += 2) {
    V2 p(800 + side * rx, ry);
    addZone(w, ZK_RUNE, p, V2(38, 0), true);
    rock(w, p, 44);
    for (int k = 0; k < 2; ++k) {
      V2 q(800 + side * (110.f + 90.f * k), s.y + 60 + 40 * k);
      if (spotFree(w, q, 12, 6)) {
        int pi = addPeg(w, PK_PILLAR, q, 12);
        if (pi >= 0) f.pegs[pi].val = 3;
      }
    }
  }
  static const V2 STARS[] = {V2(0, 150), V2(-70, 200), V2(70, 200), V2(0, 250)};
  for (auto& o : STARS) {
    V2 p = V2(800, ry) + o;
    if (p.y < FIELD_Y1 - 20 && spotFree(w, p, 8, 6)) addPeg(w, PK_STAR, p, PIN_R + 1);
  }
}

void buildFormat(World& w) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  switch (f.spec.format) {
    case FMT_FUNNEL: buildFunnel(w, R); break;
    case FMT_SPLIT: buildSplit(w, R); break;
    case FMT_TIERS: buildTiers(w, R); break;
    case FMT_HOURGLASS: buildHourglass(w, R); break;
    case FMT_CAVERN: buildCavern(w, R); break;
    case FMT_ZIGZAG: buildZigzag(w, R); break;
    case FMT_PACHISLOT: buildPachislot(w, R); break;
    case FMT_TEMPLE: buildTemple(w, R); break;
    case FMT_ISLANDS: {
      int n = R.range(1, 2);
      for (int k = 0; k < n; ++k) {
        V2 p(R.rangef(PX0 + 140, PX1 - 140), R.rangef(300, 700));
        if (R.chance(0.5f)) {
          addZone(w, ZK_WATER, p, V2(R.rangef(80, 130), R.rangef(40, 70)), false);
        } else {
          int zi = addZone(w, ZK_WIND, p, V2(R.rangef(120, 180), R.rangef(40, 60)), false);
          if (zi >= 0) {
            f.zones[zi].dir = V2(R.chance(0.5f) ? 1.f : -1.f, 0);
            f.zones[zi].str = R.rangef(260, 380);
          }
        }
      }
      break;
    }
    case FMT_BOWL: {
      int n = R.range(8, 11);
      for (int k = 0; k < n; ++k) {
        V2 p = randomFieldSpot(w, 16, 30, FIELD_Y0 + 100, FIELD_Y1 - 60);
        if (p.x >= 0) addPeg(w, PK_BUMPER, p, R.rangef(12, 16));
      }
      for (int k = 0; k < 2; ++k) {
        V2 p = randomFieldSpot(w, 40, 30, 300, FIELD_Y1 - 60);
        if (p.x < 0) continue;
        float s = R.chance(0.5f) ? 1.f : -1.f;
        int si = addSeg(w, SK_KICKER, p + V2(-30 * s, -26), p + V2(30 * s, 20), 5);
        if (si >= 0) f.segs[si].link = WALL_TAG;
      }
      break;
    }
    default: break;
  }
}

bool formatClearings(World& w, int count, bool boss, float bossR) {
  Floor& f = w.fl;
  if (f.spec.format != FMT_ARENA) return false;
  Rng& R = f.rng;
  f.clearings.clear();
  V2 c(800, R.rangef(420, 460));
  if (boss) {
    Clearing b;
    b.p = c;
    b.r = bossR + 22;
    f.clearings.push_back(b);
  } else {
    // a bumper and bell ring hold the middle
    addPeg(w, PK_BELL, c, 12);
    for (int k = 0; k < 3; ++k) addPeg(w, PK_BUMPER, c + fromAng(k * TAU / 3 - PI / 2) * 46, 12);
    rock(w, c, 70);
  }
  int ring = boss ? count - 1 : count;
  float rad = boss ? bossR + 140 : 230;
  float a0 = R.rangef(0, TAU);
  for (int k = 0; k < ring; ++k) {
    Clearing q;
    q.r = 40;
    float a = a0 + k * TAU / ring;
    q.p = c + V2(std::cos(a) * rad * 1.35f, std::sin(a) * rad * 0.95f);
    q.p.x = clampv(q.p.x, PX0 + 60, PX1 - 60);
    q.p.y = clampv(q.p.y, FIELD_Y0 + 110, FIELD_Y1 - 50);
    bool ok = true;
    for (auto& o : f.clearings)
      if (dist(o.p, q.p) < o.r + q.r + 30) ok = false;
    if (ok) f.clearings.push_back(q);
  }
  return true;
}

int formatPinPattern(World& w) {
  Rng& R = w.fl.rng;
  switch (w.fl.spec.format) {
    case FMT_PLINKO: return 13;
    case FMT_ISLANDS: return 12;
    case FMT_BOWL: return 3;
    case FMT_TEMPLE: return R.chance(0.5f) ? 7 : 17;
    case FMT_TIERS: return R.chance(0.5f) ? 2 : 0;
    case FMT_ZIGZAG: return R.chance(0.5f) ? 0 : 1;
    case FMT_ARENA: return R.chance(0.5f) ? 4 : 14;
    default: return -1;
  }
}

void reformatBoard(World& w, int fmt) {
  Floor& f = w.fl;
  if (f.phase == PH_FLIGHT || fmt < 0 || fmt >= FORMAT_COUNT) return;
  for (auto& s : f.segs)
    if (!s.dead && s.link == WALL_TAG) s.dead = true;
  std::vector<Clearing> keep;
  for (auto& k : f.keepOut)
    if (k.mon != WALL_TAG) keep.push_back(k);
  f.keepOut = keep;
  f.spec.format = (uint8_t)fmt;
  // plain pins make way for the new shape
  for (auto& p : f.pegs)
    if (!p.dead && !p.motion && (p.kind == PK_PIN || (isEnchant(p.kind) && !p.used))) p.dead = true;
  if (fmt != FMT_ARENA) buildFormat(w);
  addPinPattern(w, formatPinPattern(w));
  clearWedges(w);
  refreshSpecials(w);
  fxShake(w, 14);
  fxSound(w, S_WHOOSH, 1.f, 0.5f);
}
