// Dropcrawl - ball physics: integration, collisions, zones, preview
#include "rules.h"

static const float CELL = 48.f;
static const int GW = 18, GH = 19;
static const float CATCH_Y = 818.f;

static void pegPhys(int kind, float& rest, float& kick) {
  rest = 0.62f;
  kick = 0;
  switch (kind) {
    case PK_BUMPER: rest = 1.0f; kick = 560; break;
    case PK_MUSHROOM: rest = 0.95f; kick = 430; break;
    case PK_BONE: rest = 0.8f; kick = 330; break;
    case PK_GOLEM: case PK_TREE: case PK_SKELETON: rest = 0.85f; kick = 380; break;
    case PK_IMP: case PK_HOUND: case PK_FAMILIAR: case PK_ANGEL: case PK_TESLA: rest = 0.85f; kick = 320; break;
    case PK_BELL: rest = 0.85f; kick = 260; break;
    case PK_THORN: rest = 0.7f; break;
    case PK_STONE: case PK_PILLAR: case PK_TARGET: rest = 0.55f; break;
    case PK_CHEST: case PK_TOTEM: case PK_EGG: rest = 0.5f; break;
    case PK_JELLY: rest = 0.15f; break;
    case PK_MAGNET: rest = 0.7f; break;
    case PK_FIREFLY: rest = 0.75f; break;
    case PK_COINS: rest = 0.6f; break;
  }
}

bool flipperSolid(const Seg& s) { return std::fabs(s.ang - s.restAng) > 0.04f || std::fabs(s.angVel) > 0.5f; }

bool pegSolid(const World& w, const Peg& p) {
  if (p.dead) return false;
  switch (p.kind) {
    case PK_TULIP: case PK_CHUCKER: return false;   // sensors
    case PK_TARGET: return p.val == 0;              // knocked-down targets
    case PK_GHOST: return w.fl.ghostSolid;
  }
  return true;
}

static bool isSensor(int k) { return k == PK_TULIP || k == PK_CHUCKER; }

void rebuildPegGrid(World& w) {
  Floor& f = w.fl;
  f.gridHead.assign(GW * GH, -1);
  f.gridNext.assign(f.pegs.size(), -1);
  for (int i = 0; i < (int)f.pegs.size(); ++i) {
    const Peg& p = f.pegs[i];
    if (p.dead) continue;
    int cx = clampv((int)((p.p.x - PX0) / CELL), 0, GW - 1);
    int cy = clampv((int)(p.p.y / CELL), 0, GH - 1);
    int c = cy * GW + cx;
    f.gridNext[i] = f.gridHead[c];
    f.gridHead[c] = i;
  }
}

void animateBoard(World& w, float dt) {
  Floor& f = w.fl;
  if (dt <= 0) return;
  for (auto& p : f.pegs) {
    if (p.dead || !p.motion) {
      p.vel = V2(0, 0);
      continue;
    }
    V2 old = p.p;
    float ph = p.mPhase + f.time * p.mSpeed;
    switch (p.motion) {
      case 1: p.p = p.anchor + fromAng(ph) * p.mA; break;
      case 2: p.p = V2(p.anchor.x + std::sin(ph) * p.mA, p.anchor.y); break;
      case 3: p.p = V2(p.anchor.x, p.anchor.y + std::sin(ph) * p.mA); break;
      case 4: p.p = p.anchor + V2(std::sin(ph) * p.mA, std::sin(ph * 2.f) * p.mA * 0.5f); break;  // figure eight
    }
    p.vel = (p.p - old) / dt;
  }
  for (int si = 0; si < (int)f.segs.size(); ++si) {
    Seg& s = f.segs[si];
    if (s.dead) continue;
    if (s.kind == SK_SPINNER) {
      s.ang += s.angVel * dt;
      V2 d = fromAng(s.ang) * s.len;
      s.a = s.c - d;
      s.b = s.c + d;
    } else if (s.kind == SK_PENDULUM) {
      // swings around its pivot; angVel holds the frequency, kick the instantaneous angular velocity
      float t = f.time * s.angVel + s.phase;
      float na = s.restAng + s.upAng * std::sin(t);
      s.kick = s.upAng * s.angVel * std::cos(t);
      s.ang = na;
      s.a = s.c;
      s.b = s.c + fromAng(na) * (s.len * 2.f);
    } else if (s.kind == SK_FLIPPER) {
      int side = s.link;
      bool held = side >= 0 && side < 2 && f.flipKey[side];
      if (held) {
        f.flipHeldT[side] += dt;
        if (f.flipHeldT[side] > 0.45f) f.flipKey[side] = false;
      }
      float target = held ? s.upAng : s.restAng;
      float prev = s.ang;
      s.ang = approach(s.ang, target, (held ? 24.f : 10.f) * dt);
      s.angVel = (s.ang - prev) / dt;
      s.a = s.c;
      s.b = s.c + fromAng(s.ang) * s.len;
    }
  }
  if (f.hasCatcher) f.catcherX = LAUNCH_X + 330.f * std::sin(f.time * 0.6f);
  for (auto& z : f.zones) z.anim += dt;
}

static bool zoneInside(const Zone& z, V2 p) {
  return z.circle ? dist2(p, z.p) < z.half.x * z.half.x : (std::fabs(p.x - z.p.x) < z.half.x && std::fabs(p.y - z.p.y) < z.half.y);
}

bool geyserActive(const World& w, const Zone& z) { return std::fmod(w.fl.time + z.phase, 3.2f) < 0.75f; }

// portals and rifts carry a ball at most a few times, so a board that funnels balls into one can't loop them forever
static const int MAX_PORTAL_TRIPS = 2;

static bool mayTeleport(const Floor& f, int bi) {
  return bi >= (int)f.watch.size() || f.watch[bi].id != f.balls[bi].id || f.watch[bi].portals < MAX_PORTAL_TRIPS;
}

static void countTeleport(Floor& f, int bi) {
  if (bi < (int)f.watch.size() && f.watch[bi].id == f.balls[bi].id) f.watch[bi].portals++;
}

static void applyZones(World& w, int bi, float h, float g) {
  Floor& f = w.fl;
  for (int zi = 0; zi < (int)f.zones.size(); ++zi) {
    Ball& b = f.balls[bi];
    if (!b.alive) return;
    Zone& z = f.zones[zi];
    uint64_t bit = zi < 64 ? (1ull << zi) : 0;
    if (z.dead) {
      b.zoneMask &= ~bit;
      continue;
    }
    bool inside = zoneInside(z, b.p);
    if (!inside) {
      b.zoneMask &= ~bit;
      continue;
    }
    if (bit && !(b.zoneMask & bit)) {
      b.zoneMask |= bit;
      onZoneEnter(w, bi, zi);
      if (!f.balls[bi].alive) return;
    }
    Ball& bb = f.balls[bi];
    switch (z.kind) {
      case ZK_WATER:
        if (w.st.waterImmune) break;
        bb.v *= std::max(0.f, 1.f - 1.5f * h);
        bb.v.y -= g * 0.45f * h;
        break;
      case ZK_WIND: if (!w.st.windImmune) bb.v += z.dir * z.str * h; break;
      case ZK_WELL: {
        V2 d = z.p - bb.p;
        float dl = len(d);
        float k = clampv(1.f - dl / z.half.x, 0.f, 1.f);
        V2 n = norm(d);
        bb.v += (n * z.str + perp(n) * (z.str * 0.6f)) * (k * h);
        break;
      }
      case ZK_REPULSE: bb.v += norm(bb.p - z.p) * z.str * h; break;
      case ZK_LAVA:
        if (w.pl.species != SP_EMBER && !(w.pl.species == SP_CHANGELING && w.pl.form == SP_EMBER) && !w.st.lavaImmune) {
          bb.lavaAcc += h;
          while (bb.lavaAcc > 0.1f) {
            bb.lavaAcc -= 0.1f;
            if (bb.power > 0) bb.power--;
          }
        }
        break;
      case ZK_BOOST: bb.v = z.dir * std::max(len(bb.v), z.str); break;
      case ZK_PORTAL:
        if (z.link >= 0 && z.link < (int)f.zones.size() && !f.zones[z.link].dead && bb.portalCd <= 0 && mayTeleport(f, bi)) {
          countTeleport(f, bi);
          fxBurst(w, bb.p, 0x60c0ff, 12, 160);
          bb.p = f.zones[z.link].p;
          bb.portalCd = 0.5f;
          bb.stuckRef = bb.p;
          bb.power += w.st.portalBonus;
          fxBurst(w, bb.p, 0xffa040, 12, 160);
          fxSound(w, S_PORTAL, 0.5f, 1.3f, bb.p.x);
          if (w.pl.patron == PT_MIRRA) gainPiety(w, 1);
        }
        break;
      case ZK_RIFT:
        if (z.link >= 0 && z.link < (int)f.zones.size() && !f.zones[z.link].dead && bb.portalCd <= 0 && mayTeleport(f, bi)) {
          countTeleport(f, bi);
          fxBurst(w, bb.p, 0xb060ff, 14, 170);
          bb.p = f.zones[z.link].p + norm(bb.v) * 6.f;
          bb.portalCd = 0.6f;
          bb.stuckRef = bb.p;
          int bonus = z.dmg + w.st.portalBonus;
          bb.power += bonus;
          if (zi < 64 && z.link < 64) bb.zoneMask |= (1ull << z.link);
          fxBurst(w, bb.p, 0xb060ff, 14, 170);
          if (bonus > 0) fxText(w, bb.p + V2(0, -16), 0xc090ff, fmt("+%d", bonus), 12);
          fxSound(w, S_PORTAL, 0.5f, 0.9f, bb.p.x);
          if (w.pl.patron == PT_MIRRA) gainPiety(w, 1);
        }
        break;
      case ZK_CONVEYOR:
        if (w.st.windImmune) break;
        bb.v.x = lerpf(bb.v.x, z.dir.x * z.str, std::min(1.f, 4.f * h));
        break;
      case ZK_ANTIGRAV: bb.v.y -= g * 1.6f * h; break;
      case ZK_HASTE: {
        float sp = len(bb.v);
        if (sp < 1500) bb.v *= 1.f + 1.3f * h;
        break;
      }
      case ZK_CHARGE:
        bb.zoneAcc += h;
        while (bb.zoneAcc >= 0.15f) {
          bb.zoneAcc -= 0.15f;
          bb.power += 1;
        }
        break;
      case ZK_BLACKHOLE: {
        V2 d = z.p - bb.p;
        float dl = len(d);
        if (dl < 15.f) {
          onBlackHole(w, bi, zi);
          return;
        }
        float k = clampv(1.f - dl / z.half.x, 0.f, 1.f);
        bb.v += norm(d) * (z.str * (0.35f + k)) * h;
        break;
      }
      case ZK_WEB: bb.v *= std::max(0.f, 1.f - 3.2f * h); break;
      case ZK_GEYSER:
        if (geyserActive(w, z)) bb.v.y -= 2900.f * h;
        break;
      default: break;
    }
  }
}

static void collidePegs(World& w, int bi) {
  Floor& f = w.fl;
  Ball& b0 = f.balls[bi];
  int cx = (int)((b0.p.x - PX0) / CELL), cy = (int)(b0.p.y / CELL);
  bool phasing = f.shot.phaseT > 0;
  for (int dy = -1; dy <= 1; ++dy) {
    int yy = cy + dy;
    if (yy < 0 || yy >= GH) continue;
    for (int dx = -1; dx <= 1; ++dx) {
      int xx = cx + dx;
      if (xx < 0 || xx >= GW) continue;
      for (int pi = f.gridHead[yy * GW + xx]; pi >= 0; pi = f.gridNext[pi]) {
        if (pi >= (int)f.pegs.size()) break;
        Ball& b = f.balls[bi];
        if (!b.alive) return;
        Peg& p = f.pegs[pi];
        if (p.dead) continue;
        if (isSensor(p.kind)) {
          if (dist2(b.p, p.p) < (p.r + 7) * (p.r + 7)) onSensor(w, bi, pi);
          continue;
        }
        if (phasing || !pegSolid(w, p)) continue;
        V2 d = b.p - p.p;
        float rr = b.r + p.r;
        float d2 = len2(d);
        if (d2 >= rr * rr) continue;
        float dd = std::sqrt(d2);
        V2 n = dd > 1e-4f ? d / dd : V2(0, -1);
        b.p = p.p + n * rr;
        V2 vrel = b.v - p.vel;
        float vn = dot(vrel, n);
        if (vn >= 0) continue;
        float rest, kick;
        pegPhys(p.kind, rest, kick);
        float restBonus = w.st.restBonus + (f.bouncy ? 0.15f : 0.f) - ((b.flags & BF_BOULDER) ? 0.2f : 0.f);
        rest = clampv(rest + (p.kind == PK_JELLY ? 0.f : restBonus), 0.1f, 1.1f);
        vrel -= n * (vn * (1.f + rest));
        V2 vt = vrel - n * dot(vrel, n);
        vrel -= vt * (p.kind == PK_JELLY ? 0.6f : 0.03f);
        float vn2 = dot(vrel, n);
        if (kick > 0 && vn2 < kick) vrel += n * (kick - vn2);
        b.v = vrel + p.vel;
        if (b.pegHits > 0 || b.monHits > 0) b.v += perp(n) * f.rng.rangef(-10.f, 10.f);
        float impact = -vn;
        if (impact > 40.f || kick > 0) {
          if (!(p.lastHitBall == b.id && f.time - p.lastHitT < 0.07f)) {
            p.lastHitBall = b.id;
            p.lastHitT = f.time;
            onPegHit(w, bi, pi, impact);
            if (!f.balls[bi].alive) return;
          }
        }
      }
    }
  }
}

// Rolling: a ball resting on a solid surface that faces up (not bouncing off it) loses little speed and always keeps
// rolling downhill at a decent pace, so shallow ramps and shelves - even against the wind - can't leave it crawling.
static const float ROLL_VN = 60.f;         // coming in slower than this = rolling contact, not a bounce
static const float ROLL_FRICTION = 0.35f;  // share of rolling speed lost per second
static const float ROLL_MIN = 200.f;       // minimum downhill rolling speed
static const float ROLL_ACC = 1500.f;      // how quickly a slow ball is brought up to it

static bool rollSurface(int kind) {
  switch (kind) {
    case SK_WALL: case SK_RAMP: case SK_GATE: case SK_BARRIER: case SK_ICEWALL: case SK_KICKER: return true;
  }
  return false;  // flippers (cradling), spinners, pendulums, petals and pocket dividers keep plain contact
}

static void collideSegs(World& w, int bi, float h) {
  Floor& f = w.fl;
  for (int si = 0; si < (int)f.segs.size(); ++si) {
    Ball& b = f.balls[bi];
    if (!b.alive) return;
    Seg& s = f.segs[si];
    if (s.dead) continue;
    if (s.kind == SK_GATE && s.open) continue;
    if (s.kind == SK_FLIPPER && !flipperSolid(s)) continue;
    V2 cp = closestOnSeg(b.p, s.a, s.b);
    V2 d = b.p - cp;
    float rr = b.r + s.th;
    float d2 = len2(d);
    if (d2 >= rr * rr) continue;
    float dd = std::sqrt(d2);
    V2 n = dd > 1e-4f ? d / dd : norm(perp(s.b - s.a));
    b.p = cp + n * rr;
    V2 sv(0, 0);
    if (s.kind == SK_SPINNER || s.kind == SK_FLIPPER) sv = perp(cp - s.c) * s.angVel;
    if (s.kind == SK_PENDULUM) sv = perp(cp - s.c) * s.kick;
    V2 vrel = b.v - sv;
    float vn = dot(vrel, n);
    if (vn >= 0) continue;
    float rest = clampv(s.rest + w.st.restBonus + (f.bouncy ? 0.15f : 0.f), 0.2f, 1.1f);
    vrel -= n * (vn * (1.f + rest));
    V2 ab = s.b - s.a;
    float ab2 = len2(ab);
    float u = ab2 > 1e-6f ? dot(cp - s.a, ab) / ab2 : 0.f;
    if (-vn < ROLL_VN && n.y < -0.25f && u > 0.001f && u < 0.999f && rollSurface(s.kind)) {
      V2 dirAB = ab / std::sqrt(ab2);
      V2 t = dirAB.y < 0 ? dirAB * -1.f : dirAB;  // downhill
      float vt = dot(vrel, t);
      if (t.y < 0.035f) {
        // level: keep rolling the way it was going, or off the nearer end
        if (std::fabs(vt) > 5.f) t = vt < 0 ? t * -1.f : t;
        else t = u < 0.5f ? dirAB * -1.f : dirAB;
      }
      vrel -= (vrel - n * dot(vrel, n)) * std::min(1.f, ROLL_FRICTION * h);
      vt = dot(vrel, t);
      if (vt < ROLL_MIN) vrel += t * std::min(ROLL_MIN - vt, ROLL_ACC * h);
    } else {
      vrel -= (vrel - n * dot(vrel, n)) * 0.02f;
    }
    if (s.kind == SK_KICKER && -vn > 60.f) {
      float out = dot(vrel, n);
      float kk = s.kick + (w.st.kickerBonus > 0 ? 60.f : 0.f);
      if (out < kk) vrel += n * (kk - out);
    }
    b.v = vrel + sv;
    if (-vn > 50.f) onSegHit(w, bi, si, -vn);
  }
}

static void collideMonsters(World& w, int bi) {
  Floor& f = w.fl;
  for (int mi = 0; mi < (int)f.mons.size(); ++mi) {
    Ball& b = f.balls[bi];
    if (!b.alive) return;
    Monster& m = f.mons[mi];
    if (m.dead) continue;
    V2 d = b.p - m.p;
    float rr = b.r + m.r;
    float d2 = len2(d);
    if (d2 >= rr * rr) continue;
    const MonDef& md = MON[m.def];
    if ((md.traits & TR_PHASING) && b.power < md.tval) continue;
    if (b.pierceMon == m.id && f.time - b.pierceT < 0.35f) continue;
    float dd = std::sqrt(d2);
    V2 n = dd > 1e-4f ? d / dd : V2(0, -1);
    float vn = dot(b.v, n);
    bool counted = (b.lastMon != m.id || f.time - b.lastMonT > 0.15f) && (vn < -15.f || b.lastMon != m.id);
    bool pass = false;
    if (counted) {
      b.lastMon = m.id;
      b.lastMonT = f.time;
      int mid = m.id;
      pass = onMonsterHit(w, bi, mi);
      if (pass) {
        Ball& bb = f.balls[bi];
        bb.pierceMon = mid;
        bb.pierceT = f.time;
        continue;
      }
    }
    Ball& bb = f.balls[bi];
    Monster& mm = f.mons[mi];
    if (mm.dead || !bb.alive) continue;
    bb.p = mm.p + n * (bb.r + mm.r);
    float vn1 = dot(bb.v, n);
    if (vn1 < 0) bb.v -= n * (vn1 * 1.72f);
    float vn2 = dot(bb.v, n);
    if (vn2 < 260.f) bb.v += n * (260.f - vn2);
    // a ball landing squarely on a monster is nudged sideways, harder each time it bounces without
    // touching a peg, so it can't juggle on a monster (especially a boss right under the launcher)
    if (counted && std::fabs(n.x) < 0.6f) {
      float side = bb.p.x - mm.p.x;
      float sgn = side > 2.f ? 1.f : side < -2.f ? -1.f : (f.rng.chance(0.5f) ? 1.f : -1.f);
      bb.v.x += sgn * (80.f + 90.f * std::min(3, bb.staleHits));
    }
    // one that keeps hitting it from the side (wedged against a wall, say) is no longer thrown upward either,
    // so it slides down past the monster instead of juggling on its shoulder
    if (counted && bb.staleHits >= 2 && bb.v.y < 0) bb.v.y *= 0.25f;
  }
}

// Anti-stall: a ball that goes a while without getting any deeper or hitting anything slowly gets heavier, so no
// mix of ramps, wind, antigravity, magnets or wells can leave it crawling or hovering. Player steering is exempt.
static const float IDLE_GRACE = 2.2f;  // seconds before it starts
static const float IDLE_RAMP = 1.2f;   // extra gravity per second after that
static const float IDLE_MAX = 2.5f;    // at most +250%

static float idleGravity(const Floor& f, int bi) {
  if (bi >= (int)f.watch.size() || f.watch[bi].id != f.balls[bi].id) return 1.f;
  float t = f.watch[bi].idleT - IDLE_GRACE;
  return t > 0 ? 1.f + std::min(IDLE_MAX, t * IDLE_RAMP) : 1.f;
}

static void watchBalls(Floor& f, float dt) {
  if (f.watch.size() < f.balls.size()) f.watch.resize(f.balls.size());
  bool steered = f.shot.levitateT > 0 || f.shot.gravWarpT > 0 || f.shot.teleT > 0 || f.shot.sideGravT > 0;
  for (size_t i = 0; i < f.balls.size(); ++i) {
    const Ball& b = f.balls[i];
    BallWatch& k = f.watch[i];
    // new pegs count as progress (not the same one or two again and again, like a bumper kicking a ball back up
    // onto the shelf it rolled off); monster hits count until they go stale (no pegs in between)
    bool pegHit = false;
    if (b.pegHits != k.pegs && k.id == b.id) {
      int pid = -1;
      float last = -1;
      for (auto& pg : f.pegs)
        if (pg.lastHitBall == b.id && pg.lastHitT > last) last = pg.lastHitT, pid = pg.id;
      pegHit = pid < 0 || (pid != k.lastPeg && pid != k.prevPeg);
      if (pid >= 0 && pid != k.lastPeg) {
        k.prevPeg = k.lastPeg;
        k.lastPeg = pid;
      }
    }
    bool hit = pegHit || (b.monHits != k.mons && b.staleHits < 2);
    if (k.id != b.id) {
      k = BallWatch();
      k.id = b.id;
      k.deepY = b.p.y;
    } else if (b.p.y < k.prevY - 60.f) {  // sent back up (portal, catcher, teleport)
      k.deepY = b.p.y;
      k.idleT = 0;
    } else if (b.p.y > k.deepY + 20.f) {
      k.deepY = b.p.y;
      k.idleT = 0;
    } else if (hit || steered || b.floatT > 0 || !b.alive) {
      k.idleT = 0;
    } else {
      k.idleT += dt;
    }
    k.pegs = b.pegHits;
    k.mons = b.monHits;
    k.prevY = b.p.y;
  }
}

static void stepBall(World& w, int bi, float h, float g) {
  Floor& f = w.fl;
  {
    Ball& b = f.balls[bi];
    float gs = b.gravScale * idleGravity(f, bi);
    if (b.floatT > 0) {
      b.floatT -= h;
      gs *= 0.3f;
    }
    if (w.st.kite && b.power >= 20) gs *= 0.85f;
    if (f.shot.gravWarpT > 0) {
      V2 dir = norm(f.cursor - b.p);
      b.v += dir * (g * gs * h);
    } else {
      b.v.y += g * gs * h;
    }
    if (f.shot.sideGravT > 0) b.v += f.shot.sideGravDir * (520.f * h);
    if (f.shot.teleT > 0) {
      V2 dir = norm(f.cursor - b.p);
      b.v += dir * (1150.f * h);
      b.v *= 1.f - 0.6f * h;
    }
    if (w.st.homing > 0 && b.power >= 5 && !(b.flags & BF_PHANTOM)) {
      int mi = nearestMonster(w, b.p);
      if (mi >= 0) b.v += norm(f.mons[mi].p - b.p) * ((float)w.st.homing * h);
    }
    // magnet pegs pull nearby balls
    for (int pi = 0; pi < (int)f.pegs.size(); ++pi) {
      const Peg& p = f.pegs[pi];
      if (p.dead || p.kind != PK_MAGNET) continue;
      V2 d = p.p - b.p;
      float dl2 = len2(d);
      if (dl2 > 125.f * 125.f || dl2 < 1.f) continue;
      float dl = std::sqrt(dl2);
      float k = 1.f - dl / 125.f;
      float str = w.pl.species == SP_MAGNET ? 1300.f : 900.f;
      b.v += d / dl * (str * k * h);
    }
  }
  applyZones(w, bi, h, g);
  {
    Ball& b = f.balls[bi];
    if (!b.alive) return;
    float sp = len(b.v);
    if (sp > 1900.f) b.v *= 1900.f / sp;
    b.p += b.v * h;
    float rest = clampv(0.72f + w.st.restBonus + (f.bouncy ? 0.15f : 0.f), 0.3f, 1.05f);
    if (b.p.x - b.r < PX0) {
      b.p.x = PX0 + b.r;
      if (b.v.x < 0) {
        float imp = -b.v.x;
        b.v.x = imp * rest;
        if (imp > 60) onWallBounce(w, bi, imp);
      }
    }
    Ball& b2 = f.balls[bi];
    if (b2.p.x + b2.r > PX1) {
      b2.p.x = PX1 - b2.r;
      if (b2.v.x > 0) {
        float imp = b2.v.x;
        b2.v.x = -imp * rest;
        if (imp > 60) onWallBounce(w, bi, imp);
      }
    }
    Ball& b3 = f.balls[bi];
    if (b3.p.y - b3.r < CEIL_Y) {
      b3.p.y = CEIL_Y + b3.r;
      if (b3.v.y < 0) b3.v.y = -b3.v.y * rest;
    }
  }
  collidePegs(w, bi);
  if (!f.balls[bi].alive) return;
  collideSegs(w, bi, h);
  if (!f.balls[bi].alive) return;
  collideMonsters(w, bi);
  Ball& b = f.balls[bi];
  if (!b.alive) return;
  // catcher
  if (f.hasCatcher && f.shot.catchesLeft > 0 && !(b.flags & BF_PHANTOM) && b.v.y > 0 &&
      std::fabs(b.p.x - f.catcherX) < 34.f && b.p.y > CATCH_Y - 8 && b.p.y < CATCH_Y + 10) {
    catchBall(w, bi);
    return;
  }
  // rebound
  if (f.shot.rebounds > 0 && !(b.flags & BF_PHANTOM) && b.p.y > POCKET_TOP - 6 && b.v.y > 0) {
    f.shot.rebounds--;
    b.v.y = -std::max(820.f, std::fabs(b.v.y));
    b.p.y = POCKET_TOP - 8;
    b.flags |= BF_REBOUNDED;
    if (bi < (int)f.watch.size()) f.watch[bi].idleT = 0;
    fxRing(w, b.p, 40, 0x9fc0ff);
    fxSound(w, S_BUMP, 0.7f, 0.8f, b.p.x);
    return;
  }
  if (b.p.y > DRAIN_Y) onBallPocket(w, bi);
}

void physicsStep(World& w, float dt) {
  Floor& f = w.fl;
  f.shotTime += dt;
  rebuildPegGrid(w);
  float g = GRAVITY * w.st.gravMul * f.gravNow * f.shot.shotGrav;
  if (f.shot.levitateT > 0) {
    f.shot.levitateT -= dt;
    g *= -0.35f;
  }
  float maxSp = 0;
  for (auto& b : f.balls)
    if (b.alive) maxSp = std::max(maxSp, len(b.v));
  int n = clampv((int)std::ceil(maxSp * dt / 3.0f), 1, 16);
  float h = dt / n;
  int nb = (int)f.balls.size();
  for (int s = 0; s < n; ++s)
    for (int bi = 0; bi < nb; ++bi)
      if (f.balls[bi].alive) stepBall(w, bi, h, g);
  watchBalls(f, dt);
  if (f.shot.teleT > 0) f.shot.teleT -= dt;
  if (f.shot.gravWarpT > 0) f.shot.gravWarpT -= dt;
  if (f.shot.sideGravT > 0) f.shot.sideGravT -= dt;
  if (f.shot.phaseT > 0) f.shot.phaseT -= dt;
  for (int bi = 0; bi < nb; ++bi) {
    Ball& b = f.balls[bi];
    if (!b.alive) continue;
    b.age += dt;
    b.portalCd -= dt;
    if (b.sensorCd > 0) b.sensorCd -= dt;
    if (b.stormT > 0) {
      b.stormT -= dt;
      b.zapT += dt;
      if (b.zapT >= 0.4f) {
        b.zapT = 0;
        int t = nearestMonster(w, b.p);
        if (t >= 0) {
          fxZap(w, b.p, f.mons[t].p, 0xfff080);
          damageMonster(w, t, 2 + b.power / 10, DS_ZAP);
        }
      }
    }
    Ball& b2 = f.balls[bi];
    if (dist2(b2.p, b2.stuckRef) > 12 * 12) {
      b2.stuckRef = b2.p;
      b2.stuckT = 0;
    } else {
      b2.stuckT += dt;
    }
    if (b2.stuckT > 1.0f) {
      b2.stuckT = 0;
      b2.stuckCount++;
      b2.v = V2(f.rng.rangef(-240.f, 240.f), -280.f);
      if (b2.stuckCount >= 3) {
        // wedged for good: lift it out to the nearest open spot instead of shaking it in place
        V2 q = freeSpotNear(w, b2.p, b2.r);
        if (q.x >= 0) {
          fxBurst(w, b2.p, 0x9fc0ff, 8, 120);
          b2.p = q;
          b2.v = V2(f.rng.rangef(-60.f, 60.f), 120.f);
          b2.stuckRef = q;
        } else {
          b2.p.y += 14;
        }
      }
      if (b2.stuckCount >= 6) {
        endBall(w, bi, -1);
        continue;
      }
    }
    if (b2.age > 45.f) {
      fxText(w, b2.p, 0xa0a0a0, "fizzle", 12);
      endBall(w, bi, -1);
    }
  }
  FOR_EFF(tick, dt);
  for (auto& b : f.newBalls)
    if ((int)f.balls.size() < 48) f.balls.push_back(b);
  f.newBalls.clear();
}

// ================================================================ aim preview
void previewPath(const World& w, float angle, float speed, int bounces, std::vector<V2>& out, V2 origin) {
  out.clear();
  const Floor& f = w.fl;
  V2 p = origin + fromAng(angle) * 26, v = fromAng(angle) * speed;
  float scale = f.shot.ballScale * (f.shot.heroism ? 1.2f : 1.f) * (f.shot.beast ? 1.25f : 1.f);
  float r = f.shot.boulder ? std::max(w.st.ballR * scale, 15.f) : w.st.ballR * scale;
  float g = GRAVITY * w.st.gravMul * f.gravNow * f.shot.shotGrav * (f.shot.boulder ? 1.2f : 1.f);
  const float h = 1.f / 240.f;
  int power = effPower(w) + w.pl.nextShotPower + f.shot.mightBonus;
  int hits = 0;
  int lastHit = -99999;
  out.push_back(p);
  float restBonus = w.st.restBonus + (f.bouncy ? 0.15f : 0.f);
  for (int step = 0; step < 240 * 5; ++step) {
    v.y += g * h;
    p += v * h;
    int hitId = -99999;
    float wr = clampv(0.72f + restBonus, 0.3f, 1.05f);
    if (p.x - r < PX0 && v.x < 0) { p.x = PX0 + r; v.x = -v.x * wr; hitId = -1; }
    if (p.x + r > PX1 && v.x > 0) { p.x = PX1 - r; v.x = -v.x * wr; hitId = -2; }
    if (p.y - r < CEIL_Y && v.y < 0) { p.y = CEIL_Y + r; v.y = -v.y * wr; hitId = -3; }
    for (const Peg& pg : f.pegs) {
      if (!pegSolid(w, pg)) continue;
      V2 d = p - pg.p;
      if (std::fabs(d.x) > 40 || std::fabs(d.y) > 40) continue;
      float rr = r + pg.r;
      float d2 = len2(d);
      if (d2 >= rr * rr) continue;
      float dd = std::sqrt(d2);
      V2 n = dd > 1e-4f ? d / dd : V2(0, -1);
      p = pg.p + n * rr;
      float vn = dot(v, n);
      if (vn < 0) {
        float rest, kick;
        pegPhys(pg.kind, rest, kick);
        rest = clampv(rest + (pg.kind == PK_JELLY ? 0.f : restBonus), 0.1f, 1.1f);
        v -= n * (vn * (1.f + rest));
        v -= (v - n * dot(v, n)) * (pg.kind == PK_JELLY ? 0.6f : 0.03f);
        float vn2 = dot(v, n);
        if (kick > 0 && vn2 < kick) v += n * (kick - vn2);
        hitId = pg.id;
      }
    }
    for (const Seg& s : f.segs) {
      if (s.dead || (s.kind == SK_GATE && s.open) || (s.kind == SK_FLIPPER && !flipperSolid(s))) continue;
      V2 cp = closestOnSeg(p, s.a, s.b);
      V2 d = p - cp;
      float rr = r + s.th;
      float d2 = len2(d);
      if (d2 >= rr * rr) continue;
      float dd = std::sqrt(d2);
      V2 n = dd > 1e-4f ? d / dd : norm(perp(s.b - s.a));
      p = cp + n * rr;
      float vn = dot(v, n);
      if (vn < 0) {
        v -= n * (vn * (1.f + s.rest + restBonus));
        if (s.kind == SK_KICKER && -vn > 60.f) {
          float o = dot(v, n);
          if (o < s.kick) v += n * (s.kick - o);
        }
        hitId = s.id;
      }
    }
    for (const Monster& m : f.mons) {
      if (m.dead) continue;
      const MonDef& md = MON[m.def];
      if ((md.traits & TR_PHASING) && power < md.tval) continue;
      V2 d = p - m.p;
      float rr = r + m.r;
      float d2 = len2(d);
      if (d2 >= rr * rr) continue;
      float dd = std::sqrt(d2);
      V2 n = dd > 1e-4f ? d / dd : V2(0, -1);
      p = m.p + n * rr;
      float vn = dot(v, n);
      if (vn < 0) v -= n * (vn * 1.72f);
      float vn2 = dot(v, n);
      if (vn2 < 260) v += n * (260 - vn2);
      hitId = m.id + 1000000;
    }
    if (hitId != -99999 && hitId != lastHit) {
      lastHit = hitId;
      hits++;
      out.push_back(p);
      if (hits > bounces) return;
    }
    if (p.y > POCKET_TOP) break;
    if (step % 5 == 0) out.push_back(p);
  }
  out.push_back(p);
}
