// Dropcrawl - mutations (demonic facets and random mutations), exotic species behaviour, draconic colors,
// and Ruun's sacrifices.
#include "rules.h"

MutDef MUTS[MUT_COUNT];

#define L3(a, b, c) ((lvl) <= 1 ? (a) : (lvl) == 2 ? (b) : (c))

static MutDef& MU(int id, const char* name, int tier, int maxLvl, const char* desc) {
  MutDef& m = MUTS[id];
  m.id = (uint8_t)id;
  m.name = name;
  m.tier = (uint8_t)tier;
  m.maxLvl = (uint8_t)maxLvl;
  m.desc = desc;
  m.h = Hooks();
  return m;
}

void initMutations() {
  // ---------------- tier 0: body
  MU(MUT_HORNS, "Horns", 0, 3, "+[1|2|3] damage on every ball hit.").h.stats = [](World& w, int lvl) { w.st.flatHit += lvl; };
  MU(MUT_SPIKES, "Spiny", 0, 3, "Monsters that attack you take [2|4|6] damage.").h.stats = [](World& w, int lvl) {
    w.st.thornsDmg += 2 * lvl;
  };
  MU(MUT_CLAWS, "Claws", 0, 3, "+[1|2|3] base power.").h.stats = [](World& w, int lvl) { w.st.basePower += lvl; };
  MU(MUT_STINGER, "Stinger", 0, 3, "Ball hits apply [1|2|3] Poison.").h.monDamaged = [](World& w, int, int mi, int dmg, int lvl) {
    if (dmg > 0) applyPoison(w, mi, lvl);
  };
  MU(MUT_WINGS, "Wings", 0, 2, "Gravity -[10|20]%.").h.stats = [](World& w, int lvl) { w.st.gravMul *= 1.f - 0.1f * lvl; };
  MU(MUT_DEMONTOUCH, "Hellish Touch", 0, 3, "Ball hits apply [1|2|3] Bleed.").h.monDamaged = [](World& w, int, int mi, int dmg, int lvl) {
    if (dmg > 0) applyBleed(w, mi, lvl);
  };
  // ---------------- tier 1: hide
  MU(MUT_IRONSCALES, "Iron Scales", 1, 3, "+[1|2|3] armor.").h.stats = [](World& w, int lvl) { w.st.armor += lvl; };
  {
    auto& m = MU(MUT_MOLTENSCALES, "Molten Scales", 1, 3,
                 "+[0|1|1] armor. Lava can't drain your balls. Monsters that attack you gain [2|3|4] Burn.");
    m.h.stats = [](World& w, int lvl) {
      w.st.armor += L3(0, 1, 1);
      w.st.lavaImmune = true;
    };
    m.h.attacked = [](World& w, int mi, int&, int lvl) { applyBurn(w, mi, L3(2, 3, 4)); };
  }
  {
    auto& m = MU(MUT_ICYSCALES, "Icy Scales", 1, 3, "+[0|1|1] armor. Monsters that attack you have a [15|25|35]% chance to be Chilled.");
    m.h.stats = [](World& w, int lvl) { w.st.armor += L3(0, 1, 1); };
    m.h.attacked = [](World& w, int mi, int&, int lvl) {
      if (w.fl.rng.chance(L3(0.15f, 0.25f, 0.35f))) applyChill(w, mi, 1);
    };
  }
  MU(MUT_SANGUINE, "Sanguine Armor", 1, 3, "While below half HP, monster attacks deal [2|3|4] less damage.").h.attacked =
      [](World& w, int, int& dmg, int lvl) {
        if (w.pl.hp * 2 < w.st.maxHp) dmg = std::max(0, dmg - L3(2, 3, 4));
      };
  MU(MUT_STURDY, "Sturdy Frame", 1, 3, "+[6|12|18] max HP.").h.stats = [](World& w, int lvl) { w.st.maxHp += 6 * lvl; };
  MU(MUT_SLIMY, "Gelatinous Body", 1, 3, "+[4|8|12] max HP and +[3|5|7]% bounce.").h.stats = [](World& w, int lvl) {
    w.st.maxHp += 4 * lvl;
    w.st.restBonus += L3(0.03f, 0.05f, 0.07f);
  };
  // ---------------- tier 2: powers
  MU(MUT_DEATHPOWER, "Powered by Death", 2, 2, "+1 base power per kill on the current floor (max +[4|8]).").h.stats =
      [](World& w, int lvl) { w.st.basePower += std::min(4 * lvl, w.fl.kills); };
  MU(MUT_PAINPOWER, "Powered by Pain", 2, 2, "When you lose HP, regain [25|40]% of it as MP.").h.hurt = [](World& w, int dmg, int lvl) {
    int mp = (int)(dmg * (lvl <= 1 ? 0.25f : 0.4f));
    if (mp > 0) gainMp(w, mp);
  };
  MU(MUT_MANALINK, "Mana Link", 2, 2, "+[1|2] MP regeneration.").h.stats = [](World& w, int lvl) { w.st.mpRegen += lvl; };
  MU(MUT_GUARDIAN, "Guardian Spirit", 2, 2, "A [15|25]% chance to fully block each monster attack.");
  MU(MUT_STENCH, "Foul Stench", 2, 2, "Monsters that attack you gain [3|5] Poison.").h.attacked = [](World& w, int mi, int&, int lvl) {
    applyPoison(w, mi, lvl <= 1 ? 3 : 5);
  };
  MU(MUT_HELLFIRE, "Hellfire Aura", 2, 2, "At the end of every enemy phase, each monster takes [2|4] fire damage.").h.enemyPhaseEnd =
      [](World& w, int lvl) {
        for (int i = 0; i < (int)w.fl.mons.size(); ++i)
          if (isHostile(w, i)) damageMonster(w, i, 2 * lvl, DS_BURN);
      };
  MU(MUT_DAMNATION, "Hurl Damnation", 2, 1, "You can hurl bolts of Damnation (an innate ability that grows with you).");
  MU(MUT_BLACKMARK, "Black Mark", 2, 2, "Ball hits have a [20|35]% chance to Hex the monster (+30% damage taken for a turn).").h.monDamaged =
      [](World& w, int, int mi, int dmg, int lvl) {
        if (dmg <= 0 || w.fl.mons[mi].dead) return;
        if (w.fl.rng.chance(lvl <= 1 ? 0.2f : 0.35f)) {
          Monster& m = w.fl.mons[mi];
          m.hexT = std::max(m.hexT, 1);
          m.hexPct = std::max(m.hexPct, 30);
        }
      };
  // ---------------- tier 3: capstones
  MU(MUT_DEMONWILL, "Demonic Will", 3, 1, "+2 armor. You are immune to Weaken, Sap, Slow and Drain.").h.stats = [](World& w, int) {
    w.st.armor += 2;
  };
  MU(MUT_ROBUST, "Robust", 3, 1, "+20% max HP.").h.stats = [](World& w, int) { w.st.maxHp = (int)(w.st.maxHp * 1.2f); };
  MU(MUT_WORDCHAOS, "Word of Chaos", 3, 1, "The Tumbler watches you (20% chance to meddle each turn), and its meddling is kind.").h.stats =
      [](World& w, int) {
        w.st.tumblerWatch += 0.2f;
        w.st.tumblerKind = true;
      };
  MU(MUT_AUGMENT, "Augmentation", 3, 1, "+2 base power and +15% damage.").h.stats = [](World& w, int) {
    w.st.basePower += 2;
    w.st.dmgMul *= 1.15f;
  };
  MU(MUT_CORRUPT, "Corrupting Presence", 3, 1, "Monsters begin every floor Corrupted: +2 damage taken from every source for 3 turns.").h.floorStart =
      [](World& w, int) {
        for (int i = 0; i < (int)w.fl.mons.size(); ++i)
          if (isHostile(w, i)) applyCorrupt(w, i, 2, 3);
      };
  // ---------------- negative
  MU(MUT_FRAIL, "Frail", 9, 2, "-[10|20]% max HP.").h.stats = [](World& w, int lvl) { w.st.maxHp = (int)(w.st.maxHp * (1.f - 0.1f * lvl)); };
  MU(MUT_CLUMSY, "Clumsy", 9, 2, "-[1|2] base power.").h.stats = [](World& w, int lvl) { w.st.basePower -= lvl; };
  MU(MUT_LEAKY, "Leaky Mind", 9, 2, "-[2|4] max MP.").h.stats = [](World& w, int lvl) { w.st.maxMp -= 2 * lvl; };
  MU(MUT_HEAVYBONES, "Heavy Bones", 9, 2, "Gravity +[10|20]%.").h.stats = [](World& w, int lvl) { w.st.gravMul *= 1.f + 0.1f * lvl; };
  MU(MUT_DEFORMED, "Deformed Body", 9, 2, "-[1|2] armor.").h.stats = [](World& w, int lvl) { w.st.armor -= lvl; };
  MU(MUT_CURSEDBLOOD, "Cursed Blood", 9, 2, "[1|2] Curse peg(s) appear each turn.").h.stats = [](World& w, int lvl) {
    w.st.specials[PK_CURSE] += lvl;
  };
}

// ================================================================ gaining mutations
void gainMutation(World& w, int mut, bool silent) {
  if (mut < 0 || mut >= MUT_COUNT) return;
  const MutDef& d = MUTS[mut];
  Player& pl = w.pl;
  if (pl.mut[mut] >= d.maxLvl) return;
  pl.mut[mut]++;
  if (mut == MUT_DAMNATION) learnAbility(w, AB_DAMNATION);
  recalcStats(w);
  if (!silent) {
    uint32_t col = d.tier == 9 ? 0xff8080 : d.tier == 3 ? 0xffd040 : 0xe080ff;
    if (pl.mut[mut] == 1) logMsg(w, col, "You mutate: %s! (%s)", d.name, resolveLevels(d.desc, 1, false).c_str());
    else logMsg(w, col, "Your %s grows stronger (level %d).", d.name, pl.mut[mut]);
    fxBanner(w, pl.mut[mut] == 1 ? std::string("Mutation: ") + d.name : fmt("%s %d", d.name, pl.mut[mut]), col);
    fxSound(w, S_CAST, 0.8f, 0.6f);
  }
}

int randomMutation(World& w, bool allowBad, bool onlyGood) {
  std::vector<int> c;
  for (int m = 0; m < MUT_COUNT; ++m) {
    const MutDef& d = MUTS[m];
    if (w.pl.mut[m] >= d.maxLvl) continue;
    if (d.tier == 3) continue;               // capstones only come from facets
    if (m == MUT_DAMNATION && w.pl.species != SP_FIEND) continue;
    bool bad = d.tier == 9;
    if (bad && (!allowBad || onlyGood)) continue;
    if (!bad && !onlyGood && allowBad && w.rng.chance(0.3f)) continue;  // bias toward bad when bad is allowed
    c.push_back(m);
  }
  if (c.empty()) return -1;
  return c[w.rng.range(0, (int)c.size() - 1)];
}

// Fiendball: roll demonic facets the way DCSS demonspawn do - one facet per tier (body, hide, two powers,
// capstone), or a "monstrous" set (three body facets, no hide). Facet levels arrive at set XLs, early tiers first.
void rollDemonspawn(World& w) {
  Player& pl = w.pl;
  Rng& R = w.rng;
  pl.dsMonstrous = R.chance(0.1f);
  int want[4] = {1, 1, 2, 1};
  if (pl.dsMonstrous) {
    want[0] = 3;
    want[1] = 0;
  }
  std::vector<int> tierPool[4];
  for (int m = 0; m < MUT_COUNT; ++m)
    if (MUTS[m].tier <= 3) tierPool[MUTS[m].tier].push_back(m);
  std::vector<std::pair<int, int>> levels;  // (sort key, mutation)
  for (int t = 0; t < 4; ++t) {
    R.shuffle(tierPool[t]);
    for (int k = 0; k < want[t] && k < (int)tierPool[t].size(); ++k) {
      int m = tierPool[t][k];
      for (int l = 0; l < MUTS[m].maxLvl; ++l) {
        int tierKey = t <= 1 ? 0 : t;
        levels.push_back({tierKey * 1000 + l * 100 + R.range(0, 99), m});
      }
    }
  }
  std::sort(levels.begin(), levels.end());
  pl.dsSchedN = 0;
  bool first = true;
  int xl = 2;
  for (auto& lv : levels) {
    if (first) {
      gainMutation(w, lv.second, true);  // the first facet is there from the start
      first = false;
      continue;
    }
    if (pl.dsSchedN >= 16) break;
    if (MUTS[lv.second].tier == 3) xl = std::max(xl, 12);
    pl.dsSchedMut[pl.dsSchedN] = (uint8_t)lv.second;
    pl.dsSchedXL[pl.dsSchedN] = (uint8_t)xl;
    pl.dsSchedN++;
    xl += (xl < 8) ? 1 : 2;
  }
}

static const int BREATH[DRACO_COUNT] = {AB_BREATH_FIRE,  AB_BREATH_FROST, AB_BREATH_VENOM, AB_BREATH_ACID,
                                        AB_BREATH_STORM, AB_BREATH_MAGIC, AB_BREATH_STEAM, AB_BREATH_SHADOW};

void speciesLevelUp(World& w) {
  Player& pl = w.pl;
  switch (pl.species) {
    case SP_FIEND:
      for (int i = 0; i < pl.dsSchedN; ++i)
        if (pl.dsSchedXL[i] == pl.xl) gainMutation(w, pl.dsSchedMut[i], false);
      break;
    case SP_DRAKE:
      if (pl.xl == 5 && pl.draconic < 0) {
        pl.draconic = w.rng.range(0, DRACO_COUNT - 1);
        recalcStats(w);
        logMsg(w, DRACO_COLOR[pl.draconic], "Your scales harden and turn %s! (%s)", DRACO_NAME[pl.draconic], DRACO_DESC[pl.draconic]);
        fxBanner(w, fmt("You are a %s Drakeball!", DRACO_NAME[pl.draconic]), DRACO_COLOR[pl.draconic]);
        learnAbility(w, BREATH[pl.draconic]);
      } else if ((pl.xl == 11 || pl.xl == 17) && pl.draconic >= 0) {
        learnAbility(w, BREATH[pl.draconic]);
      }
      break;
    case SP_FELID:
      if ((pl.xl == 7 || pl.xl == 14) && pl.lives < 3) {
        pl.lives++;
        logMsg(w, 0xffd0a0, "You feel more resilient. (%d extra %s)", pl.lives, pl.lives == 1 ? "life" : "lives");
        fxBanner(w, "+1 life!", 0xffd0a0);
      }
      break;
    case SP_CHAOS:
      if (pl.xl % 4 == 0) {
        int m = randomMutation(w, true, w.rng.chance(0.7f));
        if (m >= 0) gainMutation(w, m, false);
      }
      break;
  }
}

void speciesFloorStart(World& w) {
  Player& pl = w.pl;
  if (pl.species != SP_CHANGELING) return;
  static const int FORMS[] = {SP_IRON, SP_GLASS, SP_LEAD, SP_WISP, SP_GILDED, SP_BONE, SP_EMBER, SP_MOSS,
                              SP_RUBBER, SP_CRYSTAL, SP_MAGNET, SP_SLIME};
  int nf = sizeof(FORMS) / sizeof(FORMS[0]);
  int f = FORMS[w.rng.range(0, nf - 1)];
  if (f == pl.form) f = FORMS[w.rng.range(0, nf - 1)];
  pl.form = f;
  recalcStats(w);
  pl.hp = std::min(pl.hp, w.st.maxHp);
  logMsg(w, SPECIES[f].color, "Your body ripples and reshapes: you take the form of a %s.", SPECIES[f].name);
}

// ---------------------------------------------------------------- species hook tables
static Hooks H_MAGNET;

const Hooks* speciesHooks(int sp) {
  static bool init = false;
  if (!init) {
    init = true;
    H_MAGNET.floorStart = [](World& w, int) {
      if (w.fl.isVault) return;
      V2 p = randomFieldSpot(w, 11, 16, FIELD_Y0 + 80, FIELD_Y1 - 60);
      if (p.x >= 0) addPeg(w, PK_MAGNET, p, 11);
    };
  }
  if (sp == SP_MAGNET) return &H_MAGNET;
  return nullptr;
}

static Hooks H_DRACO[DRACO_COUNT];
const Hooks* dracoHooks(int color) {
  static bool init = false;
  if (!init) {
    init = true;
    H_DRACO[0].monDamaged = [](World& w, int, int mi, int dmg, int) {
      if (dmg > 0) applyBurn(w, mi, 1);
    };
    H_DRACO[1].stats = [](World& w, int) { w.st.armor += 1; };
    H_DRACO[2].stats = [](World& w, int) { w.st.poisonRes = true; };
    H_DRACO[3].stats = [](World& w, int) { w.st.flatHit += 2; };
    H_DRACO[4].stats = [](World& w, int) { w.st.specials[PK_SPARK] += 2; };
    H_DRACO[5].stats = [](World& w, int) {
      w.st.maxMp += 2;
      w.st.mpRegen += 1;
    };
    H_DRACO[6].stats = [](World& w, int) { w.st.armor += 1; };
    H_DRACO[7].stats = [](World& w, int) {
      w.st.maxHp += 15;
      w.st.armor += 1;
    };
  }
  if (color < 0 || color >= DRACO_COUNT) return nullptr;
  return &H_DRACO[color];
}

std::string mutationSummary(const World& w, bool future) {
  const Player& pl = w.pl;
  std::string s;
  for (int m = 0; m < MUT_COUNT; ++m) {
    if (!pl.mut[m]) continue;
    const MutDef& d = MUTS[m];
    s += fmt("%s%s%s: %s\n", d.name, d.maxLvl > 1 ? fmt(" %d", pl.mut[m]).c_str() : "", d.tier == 9 ? " (bad)" : "",
             resolveLevels(d.desc, pl.mut[m], false).c_str());
  }
  if (future && pl.species == SP_FIEND) {
    bool any = false;
    for (int i = 0; i < pl.dsSchedN; ++i) {
      if (pl.dsSchedXL[i] <= pl.xl) continue;
      if (!any) s += pl.dsMonstrous ? "\nMonstrous demonic heritage. Future facets:\n" : "\nFuture demonic facets:\n";
      any = true;
      int m = pl.dsSchedMut[i];
      s += fmt("  XL %d: %s\n", pl.dsSchedXL[i], MUTS[m].name);
    }
  }
  if (future && pl.species == SP_DRAKE && pl.draconic < 0) s += "\nAt XL 5 your scales will take on a random color, granting a trait and a breath weapon.\n";
  if (pl.species == SP_DRAKE && pl.draconic >= 0) s += fmt("%s scales: %s\n", DRACO_NAME[pl.draconic], DRACO_DESC[pl.draconic]);
  if (pl.species == SP_FELID) s += fmt("Extra lives: %d%s\n", pl.lives, future && pl.xl < 14 ? " (more at XL 7 and 14)" : "");
  if (pl.species == SP_CHANGELING && pl.form >= 0) s += fmt("Current form: %s\n", SPECIES[pl.form].name);
  if (s.empty()) s = "No mutations.";
  return s;
}

// ================================================================ Ruun's sacrifices
Hooks SACRIFICE_HOOKS;

bool hasSacrifice(const World& w, int sac) { return (w.pl.sacrifices >> sac) & 1u; }
int sacrificeCount(const World& w) {
  int n = 0;
  for (int i = 0; i < SAC_COUNT; ++i)
    if (hasSacrifice(w, i)) n++;
  return n;
}

static void initSacrificeHooks() {
  static bool init = false;
  if (init) return;
  init = true;
  SACRIFICE_HOOKS.stats = [](World& w, int) {
    if (hasSacrifice(w, SAC_HEALTH)) w.st.maxHp = (int)(w.st.maxHp * 0.85f);
    if (hasSacrifice(w, SAC_MAGIC)) w.st.maxMp -= 3;
    if (hasSacrifice(w, SAC_ITEMS)) w.st.slots -= 1;
    if (hasSacrifice(w, SAC_SIGHT)) w.st.hideGuide = true;
    if (hasSacrifice(w, SAC_LUCK)) w.st.noRecall = true;
    if (hasSacrifice(w, SAC_GOLD)) w.st.goldMul *= 0.6f;
    if (hasSacrifice(w, SAC_ARMOR)) w.st.armor -= 2;
    if (hasSacrifice(w, SAC_POWER)) w.st.basePower -= 2;
    if (hasSacrifice(w, SAC_HEALING)) w.st.healMul *= 0.5f;
  };
  SACRIFICE_HOOKS.floorStart = [](World& w, int) {
    if (!hasSacrifice(w, SAC_TIME)) return;
    for (auto& m : w.fl.mons)
      if (!m.dead) m.cd = std::max(1, m.cd - 1);
  };
}

const Hooks* sacrificeHooks() {
  initSacrificeHooks();
  return &SACRIFICE_HOOKS;
}

void offerSacrifices(World& w) {
  std::vector<int> c;
  for (int i = 0; i < SAC_COUNT; ++i) {
    if (hasSacrifice(w, i)) continue;
    if (i == SAC_ITEMS && w.st.slots <= 2) continue;
    if (i == SAC_MAGIC && w.st.maxMp <= 3) continue;
    c.push_back(i);
  }
  w.rng.shuffle(c);
  w.relicOffers.clear();
  for (int i = 0; i < 3 && i < (int)c.size(); ++i) {
    Offer o;
    o.type = 3;
    o.id = c[i];
    w.relicOffers.push_back(o);
  }
}

void chooseSacrifice(World& w, int sac) {
  if (sac < 0 || sac >= SAC_COUNT || hasSacrifice(w, sac)) return;
  w.pl.sacrifices |= 1u << sac;
  logMsg(w, 0xe0c090, "Ruun accepts your sacrifice: %s. (%s)", SACRIFICE_NAME[sac], SACRIFICE_DESC[sac]);
  fxBanner(w, SACRIFICE_NAME[sac], 0xe0c090);
  fxSound(w, S_LEVEL, 1.f, 0.5f);
  recalcStats(w);
  if (w.pl.patron == PT_RUUN) gainPiety(w, 55);
  recalcStats(w);
  w.pl.hp = std::min(w.pl.hp, w.st.maxHp);
  w.pl.mp = std::min(w.pl.mp, w.st.maxMp);
}
