// Dropcrawl - The Tumbler, Lord of Chance (a capricious, Xom-like god), board transformations, and Arcana's cards
#include "rules.h"

static const uint32_t TCOL = 0xff80ff;

// ================================================================ mood
bool tumblerWatching(const World& w) {
  return w.pl.patron == PT_TUMBLER || w.st.tumblerWatch > 0 || (w.screen == RS_FLOOR && hasMod(w, MOD_PLAYGROUND));
}

void tumblerExcite(World& w, int amt) {
  if (!tumblerWatching(w)) return;
  w.tumblerMood = clampv(w.tumblerMood + amt, 0, 100);
}

std::string tumblerMoodText(const World& w) {
  int m = w.tumblerMood;
  if (m < 20) return "bored stiff";
  if (m < 40) return "restless";
  if (m < 60) return "watching";
  if (m < 80) return "amused";
  return "delighted";
}

// ================================================================ board transformations
void regenLayout(World& w, bool corrupt) {
  Floor& f = w.fl;
  if (f.phase == PH_FLIGHT) return;
  for (auto& p : f.pegs) {
    if (p.dead || p.motion) continue;
    if (p.kind == PK_PIN || (isEnchant(p.kind) && !p.used)) p.dead = true;
  }
  addPinPattern(w, -1);
  clearWedges(w);
  if (corrupt) {
    convertPins(w, PK_VOID, 5);
    V2 a = randomFieldSpot(w, 26, 20, FIELD_Y0 + 60, 460), b = randomFieldSpot(w, 26, 20, 460, FIELD_Y1 - 40);
    if (a.x >= 0 && b.x >= 0) placeRift(w, a, b, 3);
  }
  refreshSpecials(w);
  fxShake(w, 12);
  fxSound(w, S_WHOOSH, 1.f, 0.6f);
}

void mirrorBoard(World& w) {
  Floor& f = w.fl;
  if (f.phase == PH_FLIGHT) return;
  const float cx = (PX0 + PX1) * 0.5f;
  auto mx = [&](V2 p) { return V2(2 * cx - p.x, p.y); };
  for (auto& p : f.pegs) {
    if (p.dead) continue;
    p.p = mx(p.p);
    p.anchor = mx(p.anchor);
    if (p.motion == 1 || p.motion == 4) {
      p.mSpeed = -p.mSpeed;
      p.mPhase = PI - p.mPhase;
    }
    if (p.motion == 2) p.mPhase = PI + p.mPhase;
  }
  for (auto& s : f.segs) {
    if (s.dead || s.kind == SK_DIVIDER || s.kind == SK_FLIPPER) continue;
    s.a = mx(s.a);
    s.b = mx(s.b);
    s.c = mx(s.c);
    s.ang = PI - s.ang;
    if (s.kind == SK_SPINNER) s.angVel = -s.angVel;
    if (s.kind == SK_PENDULUM) {
      s.restAng = PI - s.restAng;
      s.upAng = -s.upAng;
    }
    if (s.kind == SK_PETAL) {
      s.restAng = PI - s.restAng;
      s.upAng = PI - s.upAng;
    }
  }
  for (auto& z : f.zones) {
    if (z.dead || z.link == -7 || z.link == -8) continue;
    z.p = mx(z.p);
    z.dir.x = -z.dir.x;
  }
  for (auto& c : f.clearings) c.p = mx(c.p);
  for (auto& k : f.keepOut) k.p = mx(k.p);
  for (auto& m : f.mons) {
    if (m.dead) continue;
    m.moveFrom = m.p;
    m.p = mx(m.p);
    m.moveT = w.quiet ? 1.f : 0.f;
  }
  fxSound(w, S_SHATTER, 0.9f, 0.7f);
  fxShake(w, 6);
}

// ================================================================ acts
enum { CAT_GOOD, CAT_NEUTRAL, CAT_BAD };

static void say(World& w, const char* msg) {
  logMsg(w, TCOL, "%s", msg);
  fxText(w, V2(800, 250), TCOL, msg, 15);
}

static int randomNonBoss(World& w) {
  std::vector<int> c;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i) && !w.fl.mons[i].boss && !(MON[w.fl.mons[i].def].traits & TR_DECOY)) c.push_back(i);
  if (c.empty()) return -1;
  return c[w.fl.rng.range(0, (int)c.size() - 1)];
}

static bool inFlight(const World& w) { return w.fl.phase == PH_FLIGHT; }

typedef bool (*ActFn)(World&);
struct Act {
  int cat;
  float wt;
  ActFn fn;
};

// ---------------- good
static bool gHeal(World& w) {
  if (w.pl.hp >= w.st.maxHp) return false;
  healPlayer(w, std::max(4, w.st.maxHp / 4));
  say(w, "The Tumbler mends your wounds, humming.");
  return true;
}
static bool gMana(World& w) {
  if (w.st.maxMp <= 0 || w.pl.mp >= w.st.maxMp) return false;
  gainMp(w, w.st.maxMp);
  say(w, "The Tumbler fills you to the brim with magic.");
  return true;
}
static bool gGold(World& w) {
  gainGold(w, 30 + 3 * w.depth, V2(800, 400));
  say(w, "Gold rains from the ceiling!");
  return true;
}
static bool gBombs(World& w) {
  if (!convertPins(w, PK_BOMB, 6)) return false;
  say(w, "The Tumbler scatters bombs across the board!");
  return true;
}
static bool gCrits(World& w) {
  if (!convertPins(w, PK_CRIT, 6)) return false;
  say(w, "The Tumbler sharpens six pins into Crit pegs!");
  return true;
}
static bool gFree(World& w) {
  if (inFlight(w)) w.fl.shot.freeTurn = true;
  else if (!w.fl.pendingFree) w.fl.pendingFree = true;
  else return false;
  say(w, "The Tumbler stops the clock: this shot is a free turn!");
  return true;
}
static bool gChill(World& w) {
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i)) applyChill(w, i, 1);
  say(w, "The Tumbler chills the monsters' blood.");
  return true;
}
static bool gPower(World& w) {
  allBallsPower(w, 15);
  say(w, "The Tumbler charges your ball with +15 power!");
  return true;
}
static bool gLightning(World& w) {
  int d = 6 + w.depth;
  bool any = false;
  for (int k = 0; k < 4; ++k) {
    int t = pickRandomHostile(w);
    if (t < 0) break;
    fxZap(w, V2(w.fl.mons[t].p.x + w.fl.rng.rangef(-60, 60), 0), w.fl.mons[t].p, 0xffb0ff);
    damageMonster(w, t, d, DS_ZAP);
    any = true;
  }
  if (!any) return false;
  fxSound(w, S_ZAP, 1.f, 0.6f);
  say(w, "The Tumbler hurls lightning at the monsters, giggling.");
  return true;
}
static bool gSmite(World& w) {
  int t = highestHpMonster(w);
  if (t < 0) return false;
  Monster& m = w.fl.mons[t];
  int d = std::max(3, (int)(m.maxHp * (m.boss ? 0.08f : 0.15f)));
  fxBurst(w, m.p, TCOL, 30, 260);
  say(w, "A giant pink hand smacks the biggest monster!");
  damageMonster(w, t, d, DS_SPELL);
  return true;
}
static bool gPolyWeak(World& w) {
  int t = randomNonBoss(w);
  if (t < 0) return false;
  polymorphMonster(w, t, randomRosterMonster(w, -1));
  say(w, "The Tumbler turns a monster into something... smaller.");
  return true;
}
static bool gImp(World& w) {
  if (placeAlly(w, PK_IMP, V2(-1, -1), 4 + w.depth / 2, 3) < 0) return false;
  say(w, "An imp tumbles out of thin air to help you!");
  return true;
}
static bool gItem(World& w) {
  static const int L[] = {IT_HEALING, IT_MANA, IT_MIGHT, IT_LUCK, IT_WONDER, IT_W_FLAME, IT_W_LIGHTNING, IT_W_POLYMORPH,
                          IT_AMBROSIA, IT_BUTTERFLIES, IT_UPHEAVAL, IT_BRILLIANCE};
  int it = L[w.fl.rng.range(0, 11)];
  if (!gainItem(w, it)) return false;
  logMsg(w, TCOL, "A %s drops into your pack. The Tumbler winks.", ITEM[it].name);
  fxText(w, V2(800, 250), ITEM[it].color, ITEM[it].name, 15);
  return true;
}
static bool gRandart(World& w) {
  uint32_t seed = newRandartSeed(w);
  gainRandart(w, seed);
  say(w, "The Tumbler tosses you a trinket it found somewhere.");
  return true;
}
static bool gUpgrade(World& w) {
  std::vector<int> up;
  for (int i = 0; i < (int)w.pl.abil.size(); ++i)
    if (w.pl.abil[i].lvl < ABIL[w.pl.abil[i].id].maxLvl && !isInnate(w.pl.abil[i].id)) up.push_back(i);
  if (up.empty()) return false;
  learnAbility(w, w.pl.abil[up[w.fl.rng.range(0, (int)up.size() - 1)]].id);
  say(w, "The Tumbler pokes one of your powers until it grows.");
  return true;
}
static bool gDouble(World& w) {
  if (w.pl.nextShotDouble) return false;
  w.pl.nextShotDouble = true;
  say(w, "The Tumbler blows on your next ball for luck: double damage!");
  return true;
}
static bool gStrip(World& w) {
  bool any = false;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i)) {
      w.fl.mons[i].shield = 0;
      damageMonster(w, i, 5, DS_SPELL);
      any = true;
    }
  if (!any) return false;
  say(w, "The Tumbler tickles the monsters until their guard drops.");
  return true;
}
static bool gConfetti(World& w) {
  static const int K[] = {PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_MULTI, PK_FIRE, PK_ICE, PK_SPARK, PK_CRYSTAL, PK_CLOVER,
                          PK_CHAOS, PK_FEATHER, PK_VAMPIRE, PK_SHIELD, PK_RUNE};
  int n = 0;
  for (int k = 0; k < 10; ++k) n += convertPins(w, K[w.fl.rng.range(0, 14)], 1);
  if (!n) return false;
  say(w, "Confetti! Ten pins burst into colorful special pegs.");
  return true;
}
static bool gBlock(World& w) {
  addBlock(w, 10 + w.depth / 2);
  say(w, "The Tumbler wraps you in a bouncy bubble. (+Block)");
  return true;
}
static bool gChest(World& w) {
  V2 p = randomFieldSpot(w, 15, 8, FIELD_Y0 + 60, FIELD_Y1 - 40);
  if (p.x < 0) return false;
  addPeg(w, PK_CHEST, p, 15);
  say(w, "A treasure chest falls from the sky. Thunk.");
  return true;
}
static bool gMutation(World& w) {
  int m = randomMutation(w, false, true);
  if (m < 0) return false;
  gainMutation(w, m, false);
  say(w, "The Tumbler reshapes you in a flattering way.");
  return true;
}
// ---------------- neutral
static bool nRegen(World& w) {
  if (inFlight(w)) return false;
  regenLayout(w, false);
  say(w, "The Tumbler scoops up the pins and throws them back down!");
  return true;
}
static bool nMirror(World& w) {
  if (inFlight(w)) return false;
  mirrorBoard(w);
  say(w, "The Tumbler flips the whole board over like a pancake!");
  return true;
}
static bool nShuffleMons(World& w) {
  bool any = false;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i) && !w.fl.mons[i].boss) {
      teleportMonster(w, i);
      any = true;
    }
  if (!any) return false;
  say(w, "The Tumbler plays musical chairs with the monsters.");
  return true;
}
static bool nShufflePockets(World& w) {
  Floor& f = w.fl;
  std::vector<Pocket> k = f.pockets;
  f.rng.shuffle(k);
  for (int i = 0; i < (int)f.pockets.size(); ++i) {
    f.pockets[i].kind = k[i].kind;
    f.pockets[i].orig = k[i].orig;
    f.pockets[i].val = k[i].val;
    f.pockets[i].flash = 1.f;
  }
  layoutPockets(w);
  say(w, "The Tumbler shuffles the pockets!");
  return true;
}
static bool nRotate(World& w) {
  rotatePockets(w, w.fl.rng.chance(0.5f) ? 1 : -1);
  say(w, "The Tumbler giggles and spins the pockets.");
  return true;
}
static bool nGravLight(World& w) {
  w.fl.gravNow = 0.6f;
  say(w, "The Tumbler makes everything feel light and floaty.");
  return true;
}
static bool nGravHeavy(World& w) {
  w.fl.gravNow = 1.35f;
  say(w, "The Tumbler makes everything feel very, very heavy.");
  return true;
}
static bool nWind(World& w) {
  int zi = addZone(w, ZK_WIND, V2((PX0 + PX1) * 0.5f, (FIELD_Y0 + FIELD_Y1) * 0.5f), V2((PX1 - PX0) * 0.5f, (FIELD_Y1 - FIELD_Y0) * 0.5f), false);
  if (zi < 0) return false;
  w.fl.zones[zi].dir = V2(w.fl.rng.chance(0.5f) ? 1.f : -1.f, 0);
  w.fl.zones[zi].str = 200;
  w.fl.zones[zi].ttl = 2;
  say(w, "The Tumbler blows a gust across the board.");
  return true;
}
static bool nGiant(World& w) {
  if (inFlight(w)) {
    for (auto& b : w.fl.balls)
      if (b.alive) b.r = std::min(20.f, b.r * 1.5f);
  } else {
    w.fl.shot.ballScale = 1.6f;
  }
  say(w, "The Tumbler inflates your ball to enormous size!");
  return true;
}
static bool nTiny(World& w) {
  if (inFlight(w)) {
    for (auto& b : w.fl.balls)
      if (b.alive) b.r = std::max(5.f, b.r * 0.65f);
  } else {
    w.fl.shot.ballScale = 0.65f;
    w.pl.nextShotPower += 5;
  }
  say(w, "The Tumbler shrinks your ball to a tiny pip. (+5 power)");
  return true;
}
static bool nReroll(World& w) {
  static const int K[] = {PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_MULTI, PK_FIRE, PK_ICE, PK_POISON, PK_SPARK, PK_CRYSTAL,
                          PK_TELEPORT, PK_JELLY, PK_MIRROR, PK_VAMPIRE, PK_CHAOS, PK_FREEZE, PK_CLOVER, PK_ANVIL, PK_FEATHER,
                          PK_SHIELD, PK_SEED, PK_RUNE, PK_CURSE, PK_VOID};
  int n = 0;
  for (auto& p : w.fl.pegs)
    if (!p.dead && !p.used && isEnchant(p.kind)) {
      p.kind = (uint8_t)K[w.fl.rng.range(0, 23)];
      p.flash = 1.f;
      n++;
    }
  if (!n) return false;
  say(w, "The Tumbler repaints every special peg on the board.");
  return true;
}
static bool nBouncy(World& w) {
  w.fl.bouncy = !w.fl.bouncy;
  say(w, w.fl.bouncy ? "Boing! Everything is bouncier now." : "The board loses its bounce.");
  return true;
}
static bool nSetPiece(World& w) {
  int id = w.fl.rng.range(0, setPieceCount() - 1);
  if (!placeNamedSetPiece(w, id, V2(-1, -1))) return false;
  say(w, "The Tumbler builds a little toy on the board.");
  return true;
}
static bool nSprout(World& w) {
  growPins(w, 15, V2(-1, -1), 0, false);
  say(w, "Pins sprout everywhere like mushrooms.");
  return true;
}
static bool nScramble(World& w) {
  bool any = false;
  for (auto& m : w.fl.mons) {
    if (m.dead || m.charmed) continue;
    int n = 0;
    monsterScript(m, &n);
    if (n <= 1) continue;
    setIntent(w, m, w.fl.rng.range(0, n - 1), 0);
    any = true;
  }
  if (!any) return false;
  say(w, "The Tumbler scrambles the monsters' plans.");
  return true;
}
static bool nRift(World& w) {
  V2 a = randomFieldSpot(w, 26, 20, FIELD_Y0 + 40, 420), b = randomFieldSpot(w, 26, 20, 420, FIELD_Y1 - 30);
  if (a.x < 0 || b.x < 0) return false;
  placeRift(w, a, b, 3);
  say(w, "The Tumbler tears a hole in space, just to see what happens.");
  return true;
}
// ---------------- bad
static bool bSpawn(World& w) {
  int n = w.depth >= 8 && w.fl.rng.chance(0.5f) ? 2 : 1;
  int made = 0;
  for (int k = 0; k < n; ++k) {
    int cl = freeClearing(w, V2(-1, -1), true);
    if (cl < 0) break;
    int def = randomRosterMonster(w, w.depth < 4 ? -1 : 0);
    if (spawnMonster(w, def, cl, false) >= 0) made++;
  }
  if (!made) return false;
  say(w, "The Tumbler thinks this fight needs more monsters!");
  fxSound(w, S_SPAWN, 0.9f, 0.8f);
  return true;
}
static bool bPolyStrong(World& w) {
  int t = randomNonBoss(w);
  if (t < 0) return false;
  polymorphMonster(w, t, randomRosterMonster(w, 1));
  say(w, "The Tumbler turns a monster into something much nastier.");
  return true;
}
static bool bHealMons(World& w) {
  bool any = false;
  for (auto& m : w.fl.mons)
    if (!m.dead && !m.charmed && m.hp < m.maxHp) {
      m.hp = std::min(m.maxHp, m.hp + m.maxHp / 5);
      any = true;
    }
  if (!any) return false;
  say(w, "The Tumbler thinks the monsters look tired, and heals them.");
  return true;
}
static bool bCurse(World& w) {
  if (!convertPins(w, PK_CURSE, 5)) return false;
  say(w, "The Tumbler doodles curses on five pins.");
  return true;
}
static bool bCursePocket(World& w) {
  Floor& f = w.fl;
  std::vector<int> good;
  int cursed = 0;
  for (int i = 0; i < (int)f.pockets.size(); ++i) {
    if (f.pockets[i].kind == PO_CURSED) cursed++;
    else if (f.pockets[i].kind != PO_FROZEN) good.push_back(i);
  }
  if (cursed >= 2 || good.empty()) return false;
  int i = good[f.rng.range(0, (int)good.size() - 1)];
  f.pockets[i].orig = f.pockets[i].kind;
  f.pockets[i].kind = PO_CURSED;
  f.pockets[i].flash = 1.f;
  layoutPockets(w);
  say(w, "The Tumbler curses a pocket, then forgets which one.");
  return true;
}
static bool bBlock(World& w) {
  for (auto& m : w.fl.mons)
    if (!m.dead && !m.charmed) m.shield += 6 + w.depth;
  say(w, "The Tumbler gives the monsters a helping hand. (+Block)");
  return true;
}
static bool bDrainMp(World& w) {
  if (w.pl.mp <= 1) return false;
  w.pl.mp = 0;
  say(w, "The Tumbler drinks all your magic. Slurp.");
  return true;
}
static bool bPoke(World& w) {
  if (w.pl.hp <= 5) return false;
  selfDamage(w, std::max(2, w.pl.hp / 10), nullptr);
  say(w, "The Tumbler pokes you. Hard.");
  return true;
}
static bool bHasten(World& w) {
  bool any = false;
  for (auto& m : w.fl.mons)
    if (!m.dead && !m.charmed && m.cd > 1) {
      m.cd--;
      any = true;
    }
  if (!any) return false;
  say(w, "The Tumbler hurries the monsters along.");
  return true;
}
static bool bRally(World& w) {
  for (auto& m : w.fl.mons)
    if (!m.dead && !m.charmed) m.atkBonus += 1;
  say(w, "The Tumbler cheers for the monsters! (+1 damage)");
  return true;
}
static bool bCrumble(World& w) {
  Floor& f = w.fl;
  std::vector<int> c;
  for (int k = 0; k < (int)f.pegs.size(); ++k)
    if (!f.pegs[k].dead && f.pegs[k].kind == PK_PIN && !f.pegs[k].motion) c.push_back(k);
  if (c.size() < 20) return false;
  f.rng.shuffle(c);
  for (int k = 0; k < 12; ++k) {
    f.pegs[c[k]].dead = true;
    fxBurst(w, f.pegs[c[k]].p, 0xa08060, 6, 90);
  }
  say(w, "The Tumbler eats a dozen pins. Crunch.");
  return true;
}
static bool bDrain(World& w) {
  if (inFlight(w) || w.pl.cursedBall) return false;
  w.pl.cursedBall = true;
  say(w, "The Tumbler lets the air out of your next ball. (Half power)");
  return true;
}


// ---------------- v3: more good
static bool gStatBoost(World& w) {
  int s = w.fl.rng.range(0, STAT_COUNT - 1);
  addTempStat(w, s, 2, nullptr);
  logMsg(w, TCOL, "The Tumbler puffs you up: %s +2 for this floor!", STAT_NAME[s]);
  fxText(w, V2(800, 250), STAT_COLOR[s], fmt("%s +2", STAT_NAME[s]), 16);
  return true;
}
static bool gLootOrb(World& w) {
  V2 p = randomFieldSpot(w, 12, 10, FIELD_Y0 + 60, FIELD_Y1 - 60);
  if (p.x < 0) return false;
  dropLoot(w, p, 1);
  say(w, "The Tumbler drops something shiny on the board. Go get it!");
  return true;
}
static bool gCharm(World& w) {
  int t = randomNonBoss(w);
  if (t < 0) return false;
  Monster& m = w.fl.mons[t];
  m.charmed = true;
  m.charmT = 3;
  fxRing(w, m.p, m.r * 2, TCOL);
  say(w, "The Tumbler tells a monster a joke. It decides to fight for you!");
  return true;
}
static bool gShrinkAll(World& w) {
  bool any = false;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i)) {
      Monster& m = w.fl.mons[i];
      damageMonster(w, i, std::max(1, (int)(m.hp * (m.boss ? 0.06f : 0.12f))), DS_SPELL);
      any = true;
    }
  if (!any) return false;
  say(w, "The Tumbler squeezes every monster like a stress ball.");
  return true;
}
static bool gCoins(World& w) {
  if (!convertPins(w, PK_COINS, 6)) return false;
  say(w, "The Tumbler turns six pins into little stacks of coins.");
  return true;
}
static bool gJackpot(World& w) {
  if (!convertPins(w, PK_JACKPOT, 1)) return false;
  say(w, "The Tumbler hides a Jackpot peg on the board!");
  return true;
}
static bool gCooldowns(World& w) {
  bool any = false;
  for (auto& a : w.pl.abil)
    if (a.cd > 0) {
      a.cd = 0;
      any = true;
    }
  if (!any) return false;
  gainMp(w, 1);
  say(w, "The Tumbler winds up all your powers again.");
  return true;
}
static bool gShard(World& w) {
  gainShard(w, 1);
  say(w, "The Tumbler hands you a glittering relic shard.");
  return true;
}
static bool gPinata(World& w) {
  V2 p = randomFieldSpot(w, 14, 10, FIELD_Y0 + 60, FIELD_Y1 - 80);
  if (p.x < 0) return false;
  int pi = addPeg(w, PK_PINATA, p, 13);
  if (pi < 0) return false;
  say(w, "A pinata appears! The Tumbler wants you to smack it.");
  return true;
}
static bool gFreezeAll(World& w) {
  bool any = false;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i) && !w.fl.mons[i].boss) {
      freezeMonster(w, i);
      any = true;
    }
  if (!any) return false;
  say(w, "The Tumbler breathes on the monsters. They freeze solid!");
  return true;
}
static bool gGems(World& w) {
  int n = 0;
  for (int k = 0; k < 2; ++k) {
    V2 p = randomFieldSpot(w, 9, 10, FIELD_Y0 + 60, FIELD_Y1 - 60);
    if (p.x < 0) continue;
    placeGem(w, p);
    n++;
  }
  if (!n) return false;
  say(w, "The Tumbler scatters gemstones across the board.");
  return true;
}
static bool gShrine(World& w) {
  activateShrine(w, w.fl.rng.range(0, SHRINE_COUNT - 1), V2(800, 300));
  say(w, "The Tumbler blesses you on a whim.");
  return true;
}
// ---------------- v3: more neutral
static bool nReformat(World& w) {
  if (inFlight(w)) return false;
  int cur = w.fl.spec.format, f = cur;
  for (int t = 0; t < 10 && f == cur; ++t) f = w.fl.rng.range(1, FORMAT_COUNT - 1);
  if (f == cur || f == 5) f = 3;  // arena needs fresh clearings; build shelves instead
  reformatBoard(w, f);
  logMsg(w, TCOL, "The Tumbler rebuilds the board into a %s! (%s)", FORMAT_NAME[f], FORMAT_DESC[f]);
  fxBanner(w, std::string("The Tumbler remodels: ") + FORMAT_NAME[f] + "!", TCOL);
  return true;
}
static bool nPegParty(World& w) {
  static const int K[] = {PK_STAR, PK_MOON, PK_DICE, PK_PRISM, PK_BRAND, PK_COMBO, PK_SNOWBALL, PK_ECHO, PK_HOURGLASS,
                          PK_BLOOD, PK_ROD, PK_CANNON, PK_CRIT, PK_GOLD, PK_CHAOS};
  int n = 0;
  for (int k = 0; k < 10; ++k) n += convertPins(w, K[w.fl.rng.range(0, 14)], 1);
  if (!n) return false;
  say(w, "Peg party! Ten pins turn into strange new specials.");
  return true;
}
static bool nPocketsSame(World& w) {
  Floor& f = w.fl;
  static const int K[] = {PO_GOLD, PO_HEAL, PO_MANA, PO_POWER, PO_LOTTERY, PO_CHAOS, PO_BOMB, PO_GAMBLE, PO_LOOT, PO_EMPTY};
  int k = K[f.rng.range(0, 9)];
  int n = 0;
  for (auto& p : f.pockets)
    if (p.kind != PO_STRIKE && p.kind != PO_RECALL && p.kind != PO_FROZEN) {
      p.kind = p.orig = (uint8_t)k;
      p.flash = 1.f;
      n++;
    }
  if (!n) return false;
  layoutPockets(w);
  logMsg(w, TCOL, "The Tumbler repaints the pockets: they are all %s now!", POCKET_NAME[k]);
  fxText(w, V2(800, 250), TCOL, fmt("All %s!", POCKET_NAME[k]), 15);
  return true;
}
static bool nSwapHp(World& w) {
  Floor& f = w.fl;
  int a = -1, b = -1;
  for (int i = 0; i < (int)f.mons.size(); ++i) {
    if (!isHostile(w, i) || f.mons[i].boss) continue;
    float fr = f.mons[i].hp / (float)f.mons[i].maxHp;
    if (a < 0 || fr > f.mons[a].hp / (float)f.mons[a].maxHp) a = i;
    if (b < 0 || fr < f.mons[b].hp / (float)f.mons[b].maxHp) b = i;
  }
  if (a < 0 || b < 0 || a == b) return false;
  float fa = f.mons[a].hp / (float)f.mons[a].maxHp, fb = f.mons[b].hp / (float)f.mons[b].maxHp;
  f.mons[a].hp = std::max(1, (int)(f.mons[a].maxHp * fb));
  f.mons[b].hp = std::max(1, (int)(f.mons[b].maxHp * fa));
  fxZap(w, f.mons[a].p, f.mons[b].p, TCOL);
  say(w, "The Tumbler swaps the health of the healthiest and the most battered monsters.");
  return true;
}
static bool nSwapStats(World& w) {
  int a = w.fl.rng.range(0, STAT_COUNT - 1), b = w.fl.rng.range(0, STAT_COUNT - 2);
  if (b >= a) b++;
  int va = w.st.stat[a], vb = w.st.stat[b];
  if (va == vb) return false;
  w.fl.tempStat[a] += vb - va;
  w.fl.tempStat[b] += va - vb;
  recalcStats(w);
  logMsg(w, TCOL, "The Tumbler swaps your %s and %s for this floor!", STAT_NAME[a], STAT_NAME[b]);
  fxText(w, V2(800, 250), TCOL, fmt("%s <-> %s", STAT_ABBR[a], STAT_ABBR[b]), 16);
  return true;
}
static bool nSpinners(World& w) {
  int made = 0;
  for (int k = 0; k < 3; ++k) {
    V2 p = randomFieldSpot(w, 40, 10, FIELD_Y0 + 80, FIELD_Y1 - 80);
    if (p.x < 0) continue;
    int si = addSeg(w, SK_SPINNER, p, p, 4);
    if (si < 0) break;
    Seg& sg = w.fl.segs[si];
    sg.c = p;
    sg.len = 32;
    sg.angVel = (k % 2 ? -1.f : 1.f) * 3.f;
    sg.rest = 0.8f;
    made++;
  }
  if (!made) return false;
  say(w, "Whirr! The Tumbler installs some spinners.");
  return true;
}
static bool nRuneRoad(World& w) {
  int id = setPieceByName("rune road");
  if (id < 0 || !placeNamedSetPiece(w, id, V2(-1, -1))) return false;
  say(w, "The Tumbler carves a road of runes. Spell something!");
  return true;
}
static bool nConstellation(World& w) {
  int id = setPieceByName("constellation");
  if (id < 0 || !placeNamedSetPiece(w, id, V2(-1, -1))) return false;
  say(w, "The Tumbler hangs a few stars on the board.");
  return true;
}
static bool nDice(World& w) {
  int roll = w.fl.rng.range(1, 6);
  switch (roll) {
    case 1: selfDamage(w, std::max(1, w.pl.hp / 10), nullptr); break;
    case 2: for (auto& m : w.fl.mons) if (!m.dead && !m.charmed) m.shield += 5 + w.depth / 2; break;
    case 3: gainGold(w, 15 + w.depth, V2(800, 400)); break;
    case 4: healPlayer(w, 5 + w.depth / 2); break;
    case 5: allBallsPower(w, 10); break;
    default: {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) damageMonster(w, i, 6 + w.depth / 2, DS_SPELL);
      break;
    }
  }
  static const char* R[] = {"", "a 1: you stub your toe.", "a 2: the monsters get shields.", "a 3: gold!",
                            "a 4: healing.", "a 5: +10 power!", "a 6: everything takes a hit!"};
  logMsg(w, TCOL, "The Tumbler rolls a die... %s", R[roll]);
  fxText(w, V2(800, 250), TCOL, fmt("The Tumbler rolls %d!", roll), 16);
  return true;
}
// ---------------- v3: more bad
static bool bChampion(World& w) {
  int t = randomNonBoss(w);
  if (t < 0 || w.fl.mons[t].champ) return false;
  makeChampion(w, t, false);
  Monster& m = w.fl.mons[t];
  std::string af;
  for (int a = 0; a < AFFIX_COUNT; ++a)
    if (hasAffix(m, a)) af = AFFIX_NAME[a];
  logMsg(w, TCOL, "The Tumbler crowns %s a champion! (%s)", monsterName(m).c_str(), af.c_str());
  fxRing(w, m.p, m.r * 2.2f, 0x6aa0ff);
  return true;
}
static bool bCurseStat(World& w) {
  int s = w.fl.rng.range(0, STAT_COUNT - 1);
  if (w.st.stat[s] <= 2) return false;
  addTempStat(w, s, -2, nullptr);
  logMsg(w, TCOL, "The Tumbler borrows some of your %s for this floor. (-2)", STAT_NAME[s]);
  return true;
}
static bool bBombs(World& w) {
  Floor& f = w.fl;
  int made = 0;
  for (int k = 0; k < 2; ++k)
    for (int t = 0; t < 60; ++t) {
      V2 p(f.rng.rangef(PX0 + 60, PX1 - 60), f.rng.rangef(FIELD_Y0 + 100, FIELD_Y1 - 60));
      if (!spotFree(w, p, 10, 10)) continue;
      int pi = addPeg(w, PK_MBOMB, p, 10);
      if (pi >= 0) {
        f.pegs[pi].hp = 6 + w.depth / 2;
        f.pegs[pi].val = 3;
        made++;
      }
      break;
    }
  if (!made) return false;
  say(w, "The Tumbler plants a couple of bombs. Tick, tock!");
  return true;
}
static bool bEggs(World& w) {
  Floor& f = w.fl;
  int t = randomNonBoss(w);
  if (t < 0) return false;
  int def = randomRosterMonster(w, -1);
  int laid = 0;
  for (int k = 0; k < 2; ++k)
    for (int tries = 0; tries < 60; ++tries) {
      V2 p = f.mons[t].p + fromAng(f.rng.rangef(0, TAU)) * f.rng.rangef(f.mons[t].r + 26, f.mons[t].r + 120);
      if (!spotFree(w, p, 9, 8)) continue;
      int pi = addPeg(w, PK_EGG, p, 9);
      if (pi >= 0) {
        f.pegs[pi].val = 3;
        f.pegs[pi].aux = def;
        laid++;
      }
      break;
    }
  if (!laid) return false;
  say(w, "The Tumbler leaves some eggs lying around. What could they be?");
  return true;
}
static bool bFog(World& w) {
  int n = 0;
  for (int k = 0; k < 2; ++k) {
    V2 p = randomFieldSpot(w, 60, 10, FIELD_Y0 + 100, FIELD_Y1 - 80);
    if (p.x < 0) continue;
    int zi = addZone(w, ZK_FOG, p, V2(w.fl.rng.rangef(70, 100), 0), true);
    if (zi >= 0) {
      w.fl.zones[zi].ttl = 3;
      n++;
    }
  }
  if (!n) return false;
  say(w, "The Tumbler blows fog across the board.");
  return true;
}
static bool bMimic(World& w) {
  Floor& f = w.fl;
  for (auto& p : f.pegs)
    if (!p.dead && p.kind == PK_CHEST) {
      p.kind = PK_MIMIC;
      say(w, "The Tumbler whispers something to a treasure chest. It grins.");
      return true;
    }
  V2 p = randomFieldSpot(w, 15, 10, FIELD_Y0 + 80, FIELD_Y1 - 60);
  if (p.x < 0) return false;
  int pi = addPeg(w, PK_MIMIC, p, 15);
  if (pi < 0) return false;
  say(w, "A treasure chest falls from the sky. Thunk. (It looks... hungry.)");
  return true;
}
static bool bLockPocket(World& w) {
  Floor& f = w.fl;
  for (int i = 0; i < (int)f.pockets.size(); ++i)
    if (f.pockets[i].kind == PO_RECALL || f.pockets[i].kind == PO_STRIKE) {
      f.pockets[i].orig = f.pockets[i].kind;
      f.pockets[i].kind = PO_FROZEN;
      f.pockets[i].val = 2;
      f.pockets[i].flash = 1.f;
      layoutPockets(w);
      say(w, "The Tumbler freezes one of your best pockets. Brr!");
      return true;
    }
  return false;
}
static bool bMeteor(World& w) {
  Floor& f = w.fl;
  for (int t = 0; t < 80; ++t) {
    V2 p(f.rng.rangef(PX0 + 60, PX1 - 60), f.rng.rangef(FIELD_Y0 + 120, FIELD_Y1 - 80));
    if (!spotFree(w, p, 17, 10)) continue;
    int pi = addPeg(w, PK_MBOMB, p, 16);
    if (pi < 0) return false;
    f.pegs[pi].hp = 10 + w.depth;
    f.pegs[pi].val = 3;
    f.pegs[pi].aux = 3;
    say(w, "The Tumbler calls down a meteor! Smash the marker before it lands.");
    return true;
  }
  return false;
}

static const Act ACTS[] = {
    {CAT_GOOD, 1.2f, gHeal},       {CAT_GOOD, 0.8f, gMana},        {CAT_GOOD, 1.0f, gGold},     {CAT_GOOD, 1.0f, gBombs},
    {CAT_GOOD, 1.0f, gCrits},      {CAT_GOOD, 0.7f, gFree},        {CAT_GOOD, 0.8f, gChill},    {CAT_GOOD, 1.0f, gPower},
    {CAT_GOOD, 1.1f, gLightning},  {CAT_GOOD, 0.8f, gSmite},       {CAT_GOOD, 0.6f, gPolyWeak}, {CAT_GOOD, 0.7f, gImp},
    {CAT_GOOD, 0.7f, gItem},       {CAT_GOOD, 0.15f, gRandart},    {CAT_GOOD, 0.3f, gUpgrade},  {CAT_GOOD, 0.8f, gDouble},
    {CAT_GOOD, 0.8f, gStrip},      {CAT_GOOD, 1.0f, gConfetti},    {CAT_GOOD, 0.8f, gBlock},    {CAT_GOOD, 0.5f, gChest},
    {CAT_GOOD, 0.15f, gMutation},
    {CAT_NEUTRAL, 1.0f, nRegen},   {CAT_NEUTRAL, 0.8f, nMirror},   {CAT_NEUTRAL, 1.0f, nShuffleMons},
    {CAT_NEUTRAL, 0.8f, nShufflePockets}, {CAT_NEUTRAL, 0.6f, nRotate}, {CAT_NEUTRAL, 0.6f, nGravLight},
    {CAT_NEUTRAL, 0.5f, nGravHeavy}, {CAT_NEUTRAL, 0.7f, nWind},   {CAT_NEUTRAL, 0.7f, nGiant}, {CAT_NEUTRAL, 0.6f, nTiny},
    {CAT_NEUTRAL, 0.9f, nReroll},  {CAT_NEUTRAL, 0.4f, nBouncy},   {CAT_NEUTRAL, 0.9f, nSetPiece}, {CAT_NEUTRAL, 0.7f, nSprout},
    {CAT_NEUTRAL, 0.7f, nScramble}, {CAT_NEUTRAL, 0.6f, nRift},
    {CAT_BAD, 0.9f, bSpawn},       {CAT_BAD, 0.6f, bPolyStrong},   {CAT_BAD, 0.8f, bHealMons},  {CAT_BAD, 0.8f, bCurse},
    {CAT_BAD, 0.5f, bCursePocket}, {CAT_BAD, 0.8f, bBlock},        {CAT_BAD, 0.6f, bDrainMp},   {CAT_BAD, 0.7f, bPoke},
    {CAT_BAD, 0.7f, bHasten},      {CAT_BAD, 0.6f, bRally},        {CAT_BAD, 0.6f, bCrumble},   {CAT_BAD, 0.6f, bDrain},
    // v3
    {CAT_GOOD, 0.8f, gStatBoost},  {CAT_GOOD, 0.5f, gLootOrb},     {CAT_GOOD, 0.6f, gCharm},    {CAT_GOOD, 0.8f, gShrinkAll},
    {CAT_GOOD, 0.7f, gCoins},      {CAT_GOOD, 0.5f, gJackpot},     {CAT_GOOD, 0.6f, gCooldowns}, {CAT_GOOD, 0.3f, gShard},
    {CAT_GOOD, 0.6f, gPinata},     {CAT_GOOD, 0.35f, gFreezeAll},  {CAT_GOOD, 0.6f, gGems},     {CAT_GOOD, 0.5f, gShrine},
    {CAT_NEUTRAL, 1.0f, nReformat}, {CAT_NEUTRAL, 0.8f, nPegParty}, {CAT_NEUTRAL, 0.5f, nPocketsSame},
    {CAT_NEUTRAL, 0.5f, nSwapHp},  {CAT_NEUTRAL, 0.5f, nSwapStats}, {CAT_NEUTRAL, 0.6f, nSpinners},
    {CAT_NEUTRAL, 0.5f, nRuneRoad}, {CAT_NEUTRAL, 0.5f, nConstellation}, {CAT_NEUTRAL, 0.7f, nDice},
    {CAT_BAD, 0.6f, bChampion},    {CAT_BAD, 0.6f, bCurseStat},    {CAT_BAD, 0.6f, bBombs},     {CAT_BAD, 0.5f, bEggs},
    {CAT_BAD, 0.5f, bFog},         {CAT_BAD, 0.5f, bMimic},        {CAT_BAD, 0.4f, bLockPocket}, {CAT_BAD, 0.5f, bMeteor},
};
static const int NACTS = sizeof(ACTS) / sizeof(ACTS[0]);

static void doAct(World& w, int kindness) {
  Floor& f = w.fl;
  if (w.screen != RS_FLOOR || f.phase == PH_CLEARED || f.phase == PH_DEAD || w.dead) return;
  float good, neutral, bad;
  switch (clampv(kindness, 0, 3)) {
    case 0: good = 40; neutral = 35; bad = 25; break;
    case 1: good = 55; neutral = 33; bad = 12; break;
    case 2: good = 68; neutral = 27; bad = 5; break;
    default: good = 80; neutral = 20; bad = 0; break;
  }
  if (w.tumblerMood < 25 && kindness < 3) {
    good -= 10;
    bad += 10;
  } else if (w.tumblerMood > 70) {
    float d = std::min(8.f, bad);
    bad -= d;
    good += d;
  }
  std::vector<float> cw = {good, neutral, bad};
  for (int attempt = 0; attempt < 8; ++attempt) {
    int cat = f.rng.weighted(cw);
    std::vector<float> wt(NACTS);
    for (int i = 0; i < NACTS; ++i) wt[i] = ACTS[i].cat == cat ? ACTS[i].wt : 0.f;
    int a = f.rng.weighted(wt);
    if (a < 0) continue;
    if (ACTS[a].fn(w)) {
      f.shot.tumblerActs++;
      w.pl.tumbleCount++;
      w.rs.tumbles++;
      if (hasRelic(w, RL_U_JESTER)) gainGold(w, 8, V2(800, 300));
      if (relicSetCount(w, 0) >= 3) allBallsPower(w, 5);
      fxBanner(w, cat == CAT_GOOD ? "The Tumbler meddles!" : cat == CAT_NEUTRAL ? "The Tumbler plays with the board!" : "The Tumbler is mischievous!", TCOL);
      fxSound(w, S_CAST, 0.9f, cat == CAT_BAD ? 0.7f : 1.4f);
      // meddling entertains the Tumbler
      if (tumblerWatching(w)) w.tumblerMood = clampv(w.tumblerMood + (cat == CAT_BAD ? 12 : 6), 0, 100);
      return;
    }
  }
}

void tumblerAct(World& w, bool invoked) {
  int k = invoked ? 2 : 0;
  if (!invoked) {
    if (w.pl.patron == PT_TUMBLER) k = abLevel(w, AB_P_GIFTS) ? 1 : 0;
    if (w.st.tumblerKind) k = std::max(k, 1);
  }
  doAct(w, k);
}

void tumblerInvoke(World& w, int kindness) { doAct(w, kindness); }

void tumblerTurn(World& w) {
  Floor& f = w.fl;
  if (!tumblerWatching(w) || f.isVault) return;
  w.tumblerMood = std::max(0, w.tumblerMood - 6);
  float chance = 0;
  if (w.pl.patron == PT_TUMBLER) chance = abLevel(w, AB_P_GIFTS) ? 0.3f : 0.2f;
  chance = std::max(chance, w.st.tumblerWatch);
  if (w.tumblerMood < 25) chance *= 1.5f;
  if (hasMod(w, MOD_PLAYGROUND)) chance = 1.f;
  if (f.rng.chance(chance)) tumblerAct(w, false);
  else if (w.tumblerMood < 15 && f.rng.chance(0.3f)) logMsg(w, TCOL, "You feel the Tumbler's boredom pressing on you.");
}

void tumblerFlightAct(World& w) {
  Floor& f = w.fl;
  if (!tumblerWatching(w) || f.isVault || f.shot.tumblerActs >= 1) return;
  if (f.shotTime - f.shot.tumbleClock < 0.5f) return;
  f.shot.tumbleClock = f.shotTime;
  if (f.shotTime < 0.6f) return;
  float chance = 0;
  if (w.pl.patron == PT_TUMBLER) chance = w.tumblerMood < 25 ? 0.06f : 0.035f;
  chance = std::max(chance, w.st.tumblerWatch * 0.15f);
  if (hasMod(w, MOD_PLAYGROUND)) chance = std::max(chance, 0.06f);
  if (!f.rng.chance(chance)) return;
  std::vector<int> alive;
  for (int i = 0; i < (int)f.balls.size(); ++i)
    if (f.balls[i].alive && !(f.balls[i].flags & BF_PHANTOM)) alive.push_back(i);
  if (alive.empty()) return;
  int bi = alive[f.rng.range(0, (int)alive.size() - 1)];
  bool kind = w.pl.patron == PT_TUMBLER && abLevel(w, AB_P_GIFTS);
  int r = f.rng.range(0, 19);
  if (!kind && w.tumblerMood < 25 && f.rng.chance(0.3f)) r = 5;
  Ball& b = f.balls[bi];
  const char* msg = nullptr;
  switch (r) {
    case 0: {
      V2 np = randomFieldSpot(w, b.r + 4, 4, FIELD_Y0, FIELD_Y1 - 60);
      if (np.x < 0) return;
      fxBurst(w, b.p, TCOL, 16, 200);
      b.p = np;
      b.stuckRef = np;
      fxBurst(w, np, TCOL, 16, 200);
      msg = "The Tumbler snatches your ball and drops it somewhere else!";
      break;
    }
    case 1: {
      int t = lowestHpMonster(w);
      if (t < 0) return;
      V2 np = f.mons[t].p + V2(f.rng.rangef(-20, 20), -f.mons[t].r - 70);
      np.x = clampv(np.x, PX0 + b.r + 4, PX1 - b.r - 4);
      np.y = std::max(np.y, CEIL_Y + b.r + 4);
      fxBurst(w, b.p, TCOL, 16, 200);
      b.p = np;
      b.v = V2(0, 300);
      b.stuckRef = np;
      b.pegsSinceMon = 1;
      msg = "The Tumbler helpfully places your ball right above a monster!";
      break;
    }
    case 2: b.v = -b.v; msg = "The Tumbler flicks your ball backwards!"; break;
    case 3: splitBall(w, bi, 1.f); msg = "The Tumbler thinks one ball is not enough."; break;
    case 4:
      for (auto& o : f.balls)
        if (o.alive) o.power += 10;
      msg = "The Tumbler cheers your ball on! (+10 power)";
      break;
    case 5: b.power /= 2; msg = "The Tumbler steals half your ball's power. Tee-hee."; break;
    case 6:
      f.shot.sideGravT = 1.5f;
      f.shot.sideGravDir = V2(f.rng.chance(0.5f) ? 1.f : -1.f, 0);
      msg = "The Tumbler tilts the board sideways!";
      break;
    case 7:
      for (auto& o : f.balls)
        if (o.alive) o.r = f.rng.chance(0.5f) ? std::min(20.f, o.r * 1.4f) : std::max(5.f, o.r * 0.7f);
      msg = "The Tumbler squishes your balls into new sizes.";
      break;
    case 8: {
      bool any = false;
      for (int k = 0; k < 3; ++k) {
        int t = pickRandomHostile(w);
        if (t < 0) break;
        fxZap(w, b.p, f.mons[t].p, 0xffb0ff);
        damageMonster(w, t, 5 + w.depth / 2, DS_ZAP);
        any = true;
      }
      if (!any) return;
      msg = "Lightning leaps from your ball at the Tumbler's whim!";
      break;
    }
    case 9:
      for (int k = 0; k < 3; ++k)
        spawnBall(w, V2(f.rng.rangef(PX0 + 60, PX1 - 60), 24), V2(f.rng.rangef(-80, 80), 80), 5, BF_PHANTOM);
      msg = "It's raining balls!";
      break;
    case 10: f.shot.levitateT = std::max(f.shot.levitateT, 0.8f); msg = "The Tumbler turns gravity off for a moment."; break;
    case 12:
      tumblerRune(w, bi);
      msg = "The Tumbler scribbles a rune on your ball.";
      break;
    case 13:
      f.balls[bi].flags |= BF_GOLDEN;
      msg = "The Tumbler gilds your ball. Every peg pays out!";
      break;
    case 14:
      f.balls[bi].flags |= BF_COMET;
      f.balls[bi].power += 8;
      f.balls[bi].gravScale = std::min(1.6f, f.balls[bi].gravScale * 1.4f);
      msg = "Your ball becomes a blazing comet! (+8 power)";
      break;
    case 15: {
      V2 p = f.balls[bi].p + V2(f.rng.rangef(-60, 60), 90);
      if (p.y > FIELD_Y1 - 40) p.y = FIELD_Y1 - 40;
      dropLoot(w, p, 0);
      msg = "The Tumbler drops some loot in your ball's path.";
      break;
    }
    case 16:
      growPins(w, 6, f.balls[bi].p + V2(0, 90), 70, true);
      msg = "Pins sprout right under your ball!";
      break;
    case 17: {
      int n = (int)f.pockets.size();
      if (n < 2) return;
      int a = f.rng.range(0, n - 1), c = f.rng.range(0, n - 2);
      if (c >= a) c++;
      std::swap(f.pockets[a].kind, f.pockets[c].kind);
      std::swap(f.pockets[a].orig, f.pockets[c].orig);
      f.pockets[a].flash = f.pockets[c].flash = 1.f;
      layoutPockets(w);
      msg = "The Tumbler swaps two pockets while you're not looking!";
      break;
    }
    case 18:
      f.balls[bi].flags |= BF_CRITNEXT;
      msg = "The Tumbler whispers a weak spot to your ball. (next hit is critical)";
      break;
    case 19:
      f.balls[bi].v.y = -std::fabs(f.balls[bi].v.y) * 1.1f - 150.f;
      msg = "The Tumbler flips gravity for a heartbeat!";
      break;
    default: {
      int made = 0;
      for (int k = 0; k < 3; ++k) {
        V2 p = b.p + fromAng(f.rng.rangef(0, TAU)) * f.rng.rangef(60, 140);
        if (p.x < PX0 + 30 || p.x > PX1 - 30 || p.y < FIELD_Y0 || p.y > FIELD_Y1) continue;
        if (!spotFree(w, p, 13, 6)) continue;
        int pi = addPeg(w, PK_BUMPER, p, 13);
        if (pi >= 0) {
          f.pegs[pi].ttl = 1;
          f.pegs[pi].temp = true;
          made++;
        }
      }
      if (!made) return;
      msg = "Bumpers pop up around your ball!";
      break;
    }
  }
  f.shot.tumblerActs++;
  w.rs.tumbles++;
  fxSound(w, S_PORTAL, 0.8f, 1.5f);
  if (msg) say(w, msg);
  w.tumblerMood = clampv(w.tumblerMood + 5, 0, 100);
}

void tumblerEndShot(World& w) {
  Floor& f = w.fl;
  if (!tumblerWatching(w)) return;
  if (f.shot.pegHits >= 40) tumblerExcite(w, 3);
  if (f.shot.damage >= 100) tumblerExcite(w, 4);
  if (f.shot.kills >= 2) tumblerExcite(w, 4);
}

// ================================================================ Arcana's Deck of Fates
const char* CARD_NAME[19] = {"The Sun",  "The Moon",    "The Star",  "The Comet",  "The Hanged Man", "Death",   "The Fool",
                             "The Wheel", "Strength",   "The Tower", "Temperance", "The Lovers",     "The Magician",
                             "Judgement", "The Devil",  "The Hermit", "The Chariot", "The Plague",   "The Storm"};
const char* CARD_DESC[19] = {"Heal 30% of your max HP.",
                             "Restore all MP.",
                             "Eight pins become Crit pegs.",
                             "A comet strikes the strongest monster.",
                             "Lose 6 HP, but your next ball gains +12 power.",
                             "The weakest monster dies if it is below 40% HP; otherwise it takes 25 damage.",
                             "The pockets shuffle.",
                             "The Tumbler meddles.",
                             "+3 base power for the rest of this floor.",
                             "The board is torn down and rebuilt, and every monster takes 8 damage.",
                             "Cure your ailments and gain 10 Block.",
                             "An imp and a hound join you for 3 turns.",
                             "All cooldowns reset and +2 MP.",
                             "Every monster loses 10% of its max HP (5% for bosses).",
                             "A random monster grows stronger, but you gain 40 gold.",
                             "Your next shot is a free turn.",
                             "Your next ball gains +20 power.",
                             "Every monster gains 6 Poison.",
                             "Five bolts of lightning strike random monsters."};

static bool badCard(int c) { return c == 4 || c == 6 || c == 14; }

static void playCard(World& w, int c) {
  Floor& f = w.fl;
  switch (c) {
    case 0: healPlayer(w, w.st.maxHp * 3 / 10); break;
    case 1: gainMp(w, std::max(1, w.st.maxMp)); break;
    case 2: convertPins(w, PK_CRIT, 8); break;
    case 3: {
      int t = highestHpMonster(w);
      if (t >= 0) {
        fxZap(w, V2(f.mons[t].p.x, 0), f.mons[t].p, 0xffe0a0);
        fxBurst(w, f.mons[t].p, 0xffe0a0, 30, 260);
        damageMonster(w, t, 20 + 2 * w.depth, DS_SPELL);
      }
      break;
    }
    case 4:
      selfDamage(w, 6, nullptr);
      w.pl.nextShotPower += 12;
      break;
    case 5: {
      int t = -1;
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i) && (t < 0 || f.mons[i].hp < f.mons[t].hp)) t = i;
      if (t < 0) break;
      Monster& m = f.mons[t];
      if (!m.boss && m.hp * 10 < m.maxHp * 4) {
        fxBurst(w, m.p, 0x202020, 30, 200);
        killMonster(w, t, DS_SPELL);
      } else damageMonster(w, t, 25, DS_SPELL);
      break;
    }
    case 6: nShufflePockets(w); break;
    case 7: tumblerAct(w, false); break;
    case 8: f.cardPower += 3; break;
    case 9:
      if (f.phase != PH_FLIGHT) regenLayout(w, false);
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) damageMonster(w, i, 8, DS_SPELL);
      break;
    case 10:
      w.pl.poison = w.pl.weak = w.pl.corrode = w.pl.slowed = w.pl.sapped = 0;
      w.pl.cursedBall = false;
      addBlock(w, 10);
      break;
    case 11:
      placeAlly(w, PK_IMP, V2(-1, -1), 4 + w.depth / 2, 3);
      placeAlly(w, PK_HOUND, V2(-1, -1), 5 + w.depth / 2, 3);
      break;
    case 12:
      for (auto& a : w.pl.abil) a.cd = 0;
      gainMp(w, 2);
      break;
    case 13:
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) damageMonster(w, i, std::max(1, (int)(f.mons[i].maxHp * (f.mons[i].boss ? 0.05f : 0.1f))), DS_SPELL);
      break;
    case 14: {
      int t = pickRandomHostile(w);
      if (t >= 0) f.mons[t].atkBonus += 3;
      gainGold(w, 40, V2(800, 400));
      break;
    }
    case 15: f.pendingFree = true; break;
    case 16: w.pl.nextShotPower += 20; break;
    case 17:
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) applyPoison(w, i, 6);
      break;
    default:
      for (int k = 0; k < 5; ++k) {
        int t = pickRandomHostile(w);
        if (t < 0) break;
        fxZap(w, V2(f.mons[t].p.x + f.rng.rangef(-40, 40), 0), f.mons[t].p, 0xfff4a0);
        damageMonster(w, t, 6, DS_ZAP);
      }
      break;
  }
}

void drawCard(World& w, bool stacked) {
  Floor& f = w.fl;
  int c = f.rng.range(0, 18);
  if (stacked && badCard(c)) {
    logMsg(w, 0xe0c0ff, "The stacked deck discards %s.", CARD_NAME[c]);
    c = f.rng.range(0, 18);
  }
  f.cardsDrawn++;
  f.lastCard = c;
  w.rs.cards++;
  logMsg(w, 0xe0c0ff, "You draw %s: %s", CARD_NAME[c], CARD_DESC[c]);
  fxBanner(w, std::string("Card: ") + CARD_NAME[c], badCard(c) ? 0xff80a0 : 0xe0c0ff);
  fxSound(w, S_FLIP, 0.9f, 1.3f);
  playCard(w, c);
}
