// Dropcrawl - v3 ball events: loot orbs, shrines, wells, mimics, shards, pinatas, gems, the new special pegs, and the
// new pockets.
#include "rules.h"

// ================================================================ board objects (not consumed back into pins)
bool newPegHit(World& w, int bi, int pi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Peg& p = f.pegs[pi];
  V2 pp = p.p;
  float pan = pp.x;
  switch (p.kind) {
    case PK_LOOT:
      b.power += 2;
      f.shot.specialHits++;
      collectLoot(w, pi, false);
      return true;
    case PK_SHRINE:
      b.power += 2;
      if (p.hp > 0) {
        p.hp = 0;
        p.flash = 1.f;
        f.shot.specialHits++;
        activateShrine(w, p.aux, pp);
      } else fxSound(w, S_WALL, 0.4f, 0.9f, pan);
      return true;
    case PK_WELL:
      b.power += 1;
      if (p.hp > 0) {
        p.hp--;
        int h = 4 + w.depth / 3 + w.st.wellBonus;
        healPlayer(w, h, true);
        gainMp(w, 1);
        fxRing(w, pp, p.r + 16, 0x60d0ff);
        fxSound(w, S_HEAL, 0.6f, 1.1f, pan);
        if (p.hp == 0) fxText(w, pp + V2(0, -18), 0x80a0b0, "the well runs dry", 12);
      } else fxSound(w, S_WALL, 0.4f, 1.2f, pan);
      return true;
    case PK_MIMIC:
      b.power += 1;
      spawnMimic(w, pi);
      return true;
    case PK_SHARD:
      b.power += 2;
      p.dead = true;
      fxBurst(w, pp, 0xd0a0ff, 18, 160, 3);
      fxSound(w, S_CHEST, 0.6f, 1.7f, pan);
      gainShard(w, 1);
      return true;
    case PK_PINATA:
      b.power += 2;
      p.flash = 1.f;
      if (--p.hp <= 0) {
        p.dead = true;
        b.power += 4;
        gainGold(w, 10 + 2 * w.depth, pp);
        fxBurst(w, pp, 0xff80c0, 40, 260, 4);
        fxBurst(w, pp, 0xffd040, 20, 200, 3);
        fxText(w, pp + V2(0, -18), 0xff80c0, "Pinata!", 16);
        fxSound(w, S_CHEST, 0.9f, 1.4f, pan);
        if (f.rng.chance(0.35f)) {
          static const int L[] = {IT_HEALING, IT_MANA, IT_MIGHT, IT_LUCK, IT_ENCHANT, IT_AMBROSIA, IT_BRAND, IT_W_BUMPERS};
          int it = L[f.rng.range(0, 7)];
          if (gainItem(w, it)) {
            logMsg(w, ITEM[it].color, "The pinata drops a %s!", ITEM[it].name);
            w.rewardItems.push_back(it);
          }
        }
      } else {
        fxSound(w, S_BUMP, 0.5f, 1.6f, pan);
        fxBurst(w, pp, 0xff80c0, 8, 120, 2);
      }
      return true;
    case PK_GEM: {
      b.power += 2;
      p.dead = true;
      int s = clampv(p.aux, 0, STAT_COUNT - 1);
      static const char* GEMN[STAT_COUNT] = {"A ruby", "An emerald", "A sapphire", "A garnet", "A topaz"};
      fxBurst(w, pp, STAT_COLOR[s], 20, 180, 3);
      fxSound(w, S_COIN, 0.6f, 1.9f, pan);
      addTempStat(w, s, 1 + w.st.gemBonus, GEMN[s]);
      return true;
    }
  }
  return false;
}

void placeGem(World& w, V2 p) {
  int pi = addPeg(w, PK_GEM, p, 8);
  if (pi >= 0) w.fl.pegs[pi].aux = w.fl.rng.range(0, STAT_COUNT - 1);
}

void spawnMimic(World& w, int pi) {
  Floor& f = w.fl;
  V2 pos = f.pegs[pi].p;
  f.pegs[pi].dead = true;
  int cl = -1;
  if ((int)f.clearings.size() < 30) {
    for (auto& q : f.pegs)
      if (!q.dead && (q.kind == PK_PIN || isEnchant(q.kind)) && dist2(q.p, pos) < 34 * 34) q.dead = true;
    Clearing c;
    c.p = pos;
    c.r = 30;
    f.clearings.push_back(c);
    cl = (int)f.clearings.size() - 1;
  }
  if (cl < 0) cl = freeClearing(w, pos, false);
  logMsg(w, 0xffa040, "The chest was a mimic!");
  fxText(w, pos + V2(0, -24), 0xffa040, "It's a mimic!", 18);
  fxSound(w, S_GROWL, 0.9f, 1.2f, pos.x);
  fxShake(w, 8);
  int mi = cl >= 0 ? spawnMonster(w, M_MIMIC, cl, false) : -1;
  if (mi < 0) {
    damagePlayer(w, 5 + w.depth / 2, -1, false, "a mimic");
    dropLoot(w, pos, 1);
    return;
  }
  f.mons[mi].moveFrom = pos;
  f.mons[mi].moveT = 1.f;
}

// ================================================================ consumable specials
bool newPegTrigger(World& w, int bi, int pi, bool echo) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Peg& p = f.pegs[pi];
  V2 pp = p.p;
  float pan = pp.x;
  switch (p.kind) {
    case PK_PRISM: {
      b.power += 2;
      if (!echo && b.gen < 2 && !(b.flags & BF_PHANTOM)) {
        int half = std::max(1, b.power / 2);
        spawnBall(w, b.p, rot(b.v, 0.45f), half, BF_PHANTOM | BF_FIRE, b.gen + 1);
        spawnBall(w, b.p, rot(b.v, -0.45f), half, BF_PHANTOM | BF_FROST, b.gen + 1);
        fxText(w, pp + V2(0, -14), 0xe0e0ff, "prism!", 13);
      }
      fxBurst(w, pp, 0xff8080, 6, 140, 2);
      fxBurst(w, pp, 0x80ff80, 6, 140, 2);
      fxBurst(w, pp, 0x8080ff, 6, 140, 2);
      fxSound(w, S_SHATTER, 0.4f, 1.9f, pan);
      return true;
    }
    case PK_DICE: {
      int roll = f.rng.range(1, 6);
      if (w.st.diceLoaded) roll = std::max(3, roll);
      switch (roll) {
        case 1: b.power = std::max(1, b.power - 3); break;
        case 2: b.power += 2; break;
        case 3: b.power += 4; break;
        case 4: gainGold(w, 5 + w.depth / 2, pp); break;
        case 5: b.power = (int)std::ceil(b.power * 1.5f); break;
        default: b.power *= 2; break;
      }
      static const char* R[] = {"", "rolled 1...", "rolled 2", "rolled 3", "rolled 4: gold", "rolled 5: x1.5", "rolled 6! x2"};
      fxText(w, pp + V2(0, -14), roll >= 5 ? 0xffe040 : roll == 1 ? 0xa0a0a0 : 0xffffff, R[roll], roll == 6 ? 16 : 13);
      fxSound(w, roll == 6 ? S_CRIT : S_FLIP, 0.5f, 1.3f, pan);
      return true;
    }
    case PK_STAR: {
      b.power += 2 + w.st.starBonus;
      f.shot.starsHit++;
      fxBurst(w, pp, 0xfff4a0, 10, 160, 2.5f);
      fxSound(w, S_PEG_SPECIAL, 0.4f, 2.f, pan);
      if (f.shot.starsHit >= 3 && !f.shot.constellation) {
        f.shot.constellation = true;
        int dmg = 8 + w.depth / 2;
        if (hasRelic(w, RL_U_STARFALL)) dmg *= 2;
        fxBanner(w, "Constellation!", 0xfff4a0);
        for (int i = 0; i < (int)f.mons.size(); ++i)
          if (isHostile(w, i)) {
            fxZap(w, V2(f.mons[i].p.x + f.rng.rangef(-30, 30), 0), f.mons[i].p, 0xfff4a0);
            damageMonster(w, i, dmg, DS_SPELL);
          }
        fxSound(w, S_LEVEL, 0.8f, 1.6f);
      }
      return true;
    }
    case PK_MOON:
      b.power += 2;
      b.flags |= BF_MOON;
      b.floatT = std::max(b.floatT, 0.8f);
      fxText(w, pp + V2(0, -14), 0xc0d0ff, "moonlit", 12);
      fxSound(w, S_WHOOSH, 0.4f, 1.8f, pan);
      return true;
    case PK_HOURGLASS: {
      int t = -1;
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i) && !f.mons[i].boss && (t < 0 || f.mons[i].cd < f.mons[t].cd)) t = i;
      if (t < 0)
        for (int i = 0; i < (int)f.mons.size(); ++i)
          if (isHostile(w, i) && (t < 0 || f.mons[i].cd < f.mons[t].cd)) t = i;
      if (t >= 0) {
        f.mons[t].cd += 1;
        fxZap(w, pp, f.mons[t].p, 0xe0c080);
        fxText(w, f.mons[t].p + V2(0, -f.mons[t].r - 16), 0xe0c080, "delayed", 13);
      }
      b.power += 1;
      fxSound(w, S_TICK, 0.6f, 0.8f, pan);
      return true;
    }
    case PK_BLOOD:
      if (!echo) selfDamage(w, 1, nullptr);
      b.power += 7;
      fxBurst(w, pp, 0xd02040, 10, 140, 2.5f);
      fxSound(w, S_HURT, 0.3f, 1.6f, pan);
      return true;
    case PK_CANNON: {
      b.power += 3;
      int t = focusTarget(w);
      if (t >= 0 && !echo) {
        V2 dir = norm(f.mons[t].p - b.p);
        b.v = dir * 980.f;
        b.p += dir * 4.f;
        f.shot.cannonShots++;
        fxText(w, pp + V2(0, -14), 0xc0c0d0, "FIRE!", 14);
      }
      fxSound(w, S_BOOM, 0.5f, 1.4f, pan);
      fxBurst(w, pp, 0xffa040, 12, 200, 3);
      return true;
    }
    case PK_ROD: {
      int t = focusTarget(w);
      if (t >= 0) {
        int dmg = std::max(1, b.power / 2);
        fxZap(w, V2(f.mons[t].p.x, 0), f.mons[t].p, 0xfff060);
        fxZap(w, pp, f.mons[t].p, 0xffffff);
        damageMonster(w, t, dmg, DS_ZAP);
      }
      fxSound(w, S_ZAP, 0.8f, 0.9f, pan);
      return true;
    }
    case PK_COMBO: {
      int add = 2 * b.specialsHit;
      b.power += add;
      fxText(w, pp + V2(0, -14), 0xff9040, fmt("combo +%d", add), 13);
      fxSound(w, S_PEG_SPECIAL, 0.5f, 1.2f + 0.05f * std::min(10, (int)b.specialsHit), pan);
      return true;
    }
    case PK_SNOWBALL:
      b.r = std::min(b.r * 1.25f, 18.f);
      b.power += 3;
      fxBurst(w, pp, 0xf0f8ff, 12, 140, 3);
      fxSound(w, S_FREEZE, 0.4f, 1.6f, pan);
      return true;
    case PK_ECHO: {
      int last = f.shot.lastSpecial;
      if (!echo && last >= 0 && last != PK_ECHO && last != PK_VOID && last != PK_TELEPORT && isEnchant(last)) {
        f.pegs[pi].kind = (uint8_t)last;
        fxText(w, pp + V2(0, -14), 0xc080ff, fmt("echo: %s", PEG_NAME[last]), 12);
        pegTriggerEffect(w, bi, pi, true);
        f.pegs[pi].kind = PK_ECHO;
      } else f.balls[bi].power += 2;
      fxSound(w, S_CAST, 0.4f, 1.9f, pan);
      return true;
    }
    case PK_BRAND:
      b.power += 2;
      b.flags |= BF_FIRE | BF_FROST | BF_VENOM;
      fxBurst(w, pp, 0xff60a0, 10, 150, 2.5f);
      fxSound(w, S_FIRE, 0.4f, 1.5f, pan);
      return true;
    case PK_JACKPOT:
      b.power = std::max(3, b.power * 3);
      fxText(w, pp + V2(0, -16), 0xffd700, "x3!", 18);
      fxRing(w, pp, 40, 0xffd700);
      fxSound(w, S_CRIT, 0.7f, 1.2f, pan);
      tumblerExcite(w, 3);
      return true;
  }
  return false;
}

// ================================================================ pockets
// returns 0 = not a v3 pocket, 1 = handled (the ball ends), 2 = handled and the ball keeps going
bool newPocket(World& w, int bi, int pi, int mul, V2 at) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Pocket& P = f.pockets[pi];
  switch (P.kind) {
    case PO_LOOT:
      for (int k = 0; k < mul; ++k) dropLoot(w, V2(-999, -999), 0);
      return true;
    case PO_SHRINE: activateShrine(w, f.rng.range(0, SHRINE_COUNT - 1), at); return true;
    case PO_RELAUNCH:
      // handled in onBallPocket (the ball keeps flying)
      return true;
    case PO_SUMMON:
      for (int k = 0; k < mul; ++k) placeAlly(w, PK_IMP, V2(-1, -1), 4 + w.depth / 2, 3);
      fxText(w, at + V2(0, -20), POCKET_COLOR[PO_SUMMON], "An imp answers!", 14);
      return true;
    case PO_SMITE: {
      int t = highestHpMonster(w);
      if (t >= 0 && b.power > 0) {
        int dmg = std::max(1, b.power * 3 / 2) * mul;
        fxZap(w, V2(f.mons[t].p.x, 0), f.mons[t].p, 0xfff0a0);
        fxRing(w, f.mons[t].p, f.mons[t].r * 2.2f, 0xfff0a0);
        damageMonster(w, t, dmg, DS_HOLY);
      }
      f.balls[bi].power = 0;
      return true;
    }
    case PO_SCATTER: {
      int pw = b.power;
      if (pw > 0)
        for (int i = 0; i < (int)f.mons.size(); ++i)
          if (isHostile(w, i)) {
            fxZap(w, at, f.mons[i].p, 0x80c0ff);
            damageMonster(w, i, std::max(1, pw * 4 * mul / 10), DS_DISCHARGE);
          }
      f.balls[bi].power = 0;
      return true;
    }
    case PO_TRAINING:
      if (!f.trainingUsed) {
        f.trainingUsed = 1;
        int s = f.rng.range(0, STAT_COUNT - 1);
        w.pl.stat[s] = (uint8_t)std::min(60, w.pl.stat[s] + 1);
        recalcStats(w);
        fxBanner(w, fmt("Training: %s +1", STAT_NAME[s]), STAT_COLOR[s]);
        logMsg(w, STAT_COLOR[s], "Training pays off: %s +1 (now %d).", STAT_NAME[s], w.st.stat[s]);
      } else fxText(w, at + V2(0, -20), 0x98a0b0, "already trained this floor", 13);
      return true;
    case PO_DELAY:
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) f.mons[i].cd += 1;
      fxText(w, at + V2(0, -20), POCKET_COLOR[PO_DELAY], "The monsters hesitate...", 14);
      fxSound(w, S_TICK, 0.8f, 0.6f, at.x);
      return true;
    case PO_GAMBLE:
      if (f.rng.chance(w.st.lucky ? 0.6f : 0.5f)) {
        f.balls[bi].flags |= BF_STRIKE;
        f.balls[bi].power *= 3;
        fxBanner(w, "Gamble won: x3!", POCKET_COLOR[PO_GAMBLE]);
        fxSound(w, S_COIN, 0.9f, 1.4f, at.x);
      } else {
        f.balls[bi].power = 0;
        fxText(w, at + V2(0, -20), 0xa0a0a0, "Gamble lost!", 15);
        fxSound(w, S_DENY, 0.6f, 1.f, at.x);
      }
      return true;
    case PO_SHARD: gainShard(w, mul); return true;
    case PO_SLOTS:
      for (int k = 0; k < mul; ++k) queueSlotSpin(w);
      return true;
    case PO_PRAYER:
      if (w.pl.patron >= 0) gainPiety(w, 6 * mul);
      else gainXp(w, (4 + w.depth) * mul);
      fxText(w, at + V2(0, -20), POCKET_COLOR[PO_PRAYER], w.pl.patron >= 0 ? "+piety" : "+XP", 14);
      return true;
    case PO_TRAP:
      if (w.st.warded) fxText(w, at + V2(0, -20), 0xe0e0ff, "warded", 14);
      else damagePlayer(w, 4 + w.depth / 3, -1, true, "a trap");
      return true;
    case PO_TAX: {
      int g = w.pl.gold * 8 / 100;
      w.pl.gold -= g;
      fxText(w, at + V2(0, -20), 0xa09070, fmt("Tax: -%d gold", g), 14);
      return true;
    }
  }
  return false;
}
