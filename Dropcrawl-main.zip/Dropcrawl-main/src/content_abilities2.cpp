// Dropcrawl - expansion abilities: more of every school, plus Blood, Chaos, Summoning and Void, and innate abilities
#include "rules.h"

#define L3(a, b, c) ((lvl) <= 1 ? (a) : (lvl) == 2 ? (b) : (c))

static AbilityDef& DEF(int id, const char* name, int school, int timing, int target, int rarity, int maxLvl,
                       std::initializer_list<int> cost, int cd, const char* desc) {
  AbilityDef& a = ABIL[id];
  a.id = (uint16_t)id;
  a.name = name;
  a.school = (uint8_t)school;
  a.timing = (uint8_t)timing;
  a.target = (uint8_t)target;
  a.rarity = (uint8_t)rarity;
  a.maxLvl = (uint8_t)maxLvl;
  int i = 0;
  for (int c : cost)
    if (i < 5) a.cost[i++] = (int8_t)c;
  for (; i < 5; ++i) a.cost[i] = i > 0 ? a.cost[i - 1] : 0;
  a.cooldown = (uint8_t)cd;
  a.goldCost = 0;
  a.desc = desc;
  a.cast = nullptr;
  a.h = Hooks();
  a.hpCost[0] = a.hpCost[1] = a.hpCost[2] = 0;
  a.innate = false;
  return a;
}

static void HP(AbilityDef& a, int h0, int h1, int h2) {
  a.hpCost[0] = (int8_t)h0;
  a.hpCost[1] = (int8_t)h1;
  a.hpCost[2] = (int8_t)h2;
}

static int lowestBall(World& w) {
  int best = -1;
  for (int i = 0; i < (int)w.fl.balls.size(); ++i)
    if (w.fl.balls[i].alive && (best < 0 || w.fl.balls[i].p.y > w.fl.balls[best].p.y)) best = i;
  return best;
}

static bool breathArea(World& w, V2 pt, float rad, int dmg, int kind) {
  bool any = false;
  fxRing(w, pt, rad, DRACO_COLOR[kind]);
  fxBurst(w, pt, DRACO_COLOR[kind], 40, 300, 4);
  fxZap(w, launcherPos(), pt, DRACO_COLOR[kind]);
  for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
    if (!isHostile(w, i)) continue;
    if (dist(w.fl.mons[i].p, pt) - w.fl.mons[i].r > rad) continue;
    any = true;
    damageMonster(w, i, dmg, DS_SPELL);
    if (w.fl.mons[i].dead) continue;
    switch (kind) {
      case 0: applyBurn(w, i, 5); break;
      case 1: applyChill(w, i, 1); break;
      case 2: applyPoison(w, i, 8 + 2 * (dmg / 6)); break;
      case 3: w.fl.mons[i].armor = std::max(0, w.fl.mons[i].armor - 2); break;
    }
  }
  return any;
}

void initAbilities2() {
  // =========================================================== FORCE
  {
    auto& a = DEF(AB_BANKSHOT, "Bank Shot", SCH_FORCE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "The first time each shot a ball bounces off a wall, it gains +[4|6|8] power and its next monster hit deals "
                  "+[25|40|55]% damage.");
    a.h.wallHit = [](World& w, int bi, int lvl) {
      if (w.fl.shot.bankShotUsed) return;
      w.fl.shot.bankShotUsed = true;
      Ball& b = w.fl.balls[bi];
      b.power += L3(4, 6, 8);
      b.flags |= BF_BANKED;
      fxText(w, b.p + V2(0, -16), 0x9fc0ff, "Bank shot!", 13);
    };
  }
  {
    auto& a = DEF(AB_TELEKINESIS, "Telekinesis", SCH_FORCE, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {2, 2, 2}, 0,
                  "For [1.5|2|2.5] seconds your balls are pulled toward the cursor.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.teleT = std::max(w.fl.shot.teleT, (float)L3(1.5f, 2.f, 2.5f));
      fxSound(w, S_CAST, 0.6f, 1.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SHOCKWAVE, "Shockwave", SCH_FORCE, T_FLIGHT, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "Every ball releases a shockwave: monsters within [120|150|180] px take [4|6|8] damage plus half the "
                  "ball's power.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      bool any = false;
      float rad = (float)L3(120, 150, 180);
      for (int bi = 0; bi < (int)w.fl.balls.size(); ++bi) {
        if (!w.fl.balls[bi].alive) continue;
        V2 bp = w.fl.balls[bi].p;
        int d = L3(4, 6, 8) + w.fl.balls[bi].power / 2;
        fxRing(w, bp, rad, 0xa0c8ff);
        if (hitMonstersInRadius(w, bp, rad, d, DS_SPELL) > 0) any = true;
      }
      fxSound(w, S_BOOM, 0.7f, 1.4f);
      return any || true;
    };
  }
  {
    auto& a = DEF(AB_SCATTER, "Scatter Shot", SCH_FORCE, T_AIM, TG_NONE, R_UNCOMMON, 3, {3, 4, 4}, 2,
                  "Your next launch fires [1|2|3] extra ball(s) in a fan. Extra balls carry [40|45|50]% of your power and can "
                  "land in pockets.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.scatter > 0) return false;
      w.fl.shot.scatter = L3(1, 2, 3);
      fxSound(w, S_CAST, 0.6f, 1.2f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_MARKSMAN, "Marksman", SCH_FORCE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Your aiming guide shows +[1|1|2] bounce(s), and the first monster hit of each shot deals +[20|35|50]% damage.");
    a.h.stats = [](World& w, int lvl) { w.st.preview += L3(1, 1, 2); };
    a.h.monHit = [](World& w, HitCtx& c, int lvl) {
      if (c.first) c.mult *= 1.f + L3(0.2f, 0.35f, 0.5f);
    };
  }
  // =========================================================== FLAME
  {
    auto& a = DEF(AB_METEOR, "Meteor", SCH_FLAME, T_AIM, TG_POINT, R_RARE, 3, {5, 5, 5}, 2,
                  "Call down a meteor: [16|24|32] damage (+1 per depth) and 5 Burn to monsters within 110 px of a spot, and "
                  "the pins there become Fire pegs.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int d = L3(16, 24, 32) + w.depth;
      fxZap(w, V2(pt.x - 120, 0), pt, 0xff9040);
      fxBurst(w, pt, 0xff7020, 60, 360, 5);
      fxRing(w, pt, 110, 0xff7020);
      fxShake(w, 14);
      fxSound(w, S_BOOM, 1.f, 0.7f, pt.x);
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (!isHostile(w, i) || dist(w.fl.mons[i].p, pt) - w.fl.mons[i].r > 110) continue;
        damageMonster(w, i, d, DS_SPELL);
        applyBurn(w, i, 5);
      }
      convertPins(w, PK_FIRE, 6, pt, 110);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SUNSPOT, "Sunspot", SCH_FLAME, T_AIM, TG_POINT, R_UNCOMMON, 3, {2, 2, 2}, 0,
                  "Place a sunspot for [2|3|4] turns: balls inside gain +1 power every 0.15 s and ignite (their next hit Burns).");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int zi = addZone(w, ZK_CHARGE, pt, V2(52, 0), true);
      if (zi < 0) return false;
      w.fl.zones[zi].ttl = L3(2, 3, 4);
      w.fl.zones[zi].dmg = 1;
      fxRing(w, pt, 52, 0xffa040);
      fxSound(w, S_FIRE, 0.7f, 1.3f, pt.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_PYRE, "Pyre", SCH_FLAME, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Burning monsters take +[1|2|3] damage from your balls, and when one dies [3|4|5] nearby pins ignite into "
                  "Fire pegs.");
    a.h.monHit = [](World& w, HitCtx& c, int lvl) {
      if (w.fl.mons[c.mon].burn > 0) c.flat += L3(1, 2, 3);
    };
    a.h.kill = [](World& w, int mi, int lvl) {
      if (w.fl.mons[mi].burn > 0) convertPins(w, PK_FIRE, L3(3, 4, 5), w.fl.mons[mi].p, 120);
    };
  }
  {
    auto& a = DEF(AB_FLASHPOINT, "Flashpoint", SCH_FLAME, T_AIM, TG_NONE, R_COMMON, 3, {1, 1, 1}, 0,
                  "This shot, the first [4|6|8] pins your ball hits burst into flame: +2 power each, and the nearest monster "
                  "gains 1 Burn.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.flashHits > 0) return false;
      w.fl.shot.flashHits = L3(4, 6, 8);
      fxSound(w, S_FIRE, 0.6f, 1.5f);
      return true;
    };
  }
  // =========================================================== FROST
  {
    auto& a = DEF(AB_BLIZZARD, "Blizzard", SCH_FROST, T_AIM, TG_NONE, R_UNCOMMON, 3, {4, 4, 4}, 2,
                  "A blizzard: every monster takes [3|5|7] damage and is Chilled, and [4|6|8] pins become Frost pegs.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (!isHostile(w, i)) continue;
        applyChill(w, i, 1);
        damageMonster(w, i, L3(3, 5, 7), DS_SPELL);
      }
      convertPins(w, PK_FREEZE, L3(4, 6, 8));
      fxSound(w, S_FREEZE, 1.f, 0.7f);
      fxShake(w, 5);
      return true;
    };
  }
  {
    auto& a = DEF(AB_ICEWALL, "Ice Wall", SCH_FROST, T_AIM, TG_TWO_POINTS, R_COMMON, 3, {2, 2, 2}, 0,
                  "Raise a wall of ice between two points (up to 170 px) for [2|3|4] turns. Balls bouncing off it gain +3 "
                  "power and frost (their next hit Chills). It shatters after [3|4|5] hits.");
    a.cast = [](World& w, int lvl, V2 p1, V2 p2, int) {
      if (dist(p1, p2) < 30) return false;
      if (dist(p1, p2) > 170) p2 = p1 + norm(p2 - p1) * 170.f;
      int si = addSeg(w, SK_ICEWALL, p1, p2, 5);
      if (si < 0) return false;
      Seg& s = w.fl.segs[si];
      s.hp = L3(3, 4, 5);
      s.ttl = L3(2, 3, 4);
      s.rest = 0.75f;
      fxSound(w, S_FREEZE, 0.8f, 0.9f, s.c.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_FROZENHEART, "Frozen Heart", SCH_FROST, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Chilled and frozen monsters deal [25|35|50]% less damage to you, and Ice pegs grant +[2|3|4] extra power.");
    a.h.attacked = [](World& w, int mi, int& dmg, int lvl) {
      const Monster& m = w.fl.mons[mi];
      if (m.chilled > 0 || m.frozen > 0) dmg = (int)(dmg * (1.f - L3(0.25f, 0.35f, 0.5f)));
    };
    a.h.pegHit = [](World& w, int bi, int, int lvl) {
      if (w.fl.lastTrig == PK_ICE) w.fl.balls[bi].power += L3(2, 3, 4);
    };
  }
  {
    auto& a = DEF(AB_GLACIATE, "Glaciate", SCH_FROST, T_AIM, TG_MONSTER, R_RARE, 3, {4, 4, 4}, 3,
                  "Encase a monster in ice: it is Frozen (skipping its next action, even if it was frozen recently) and takes "
                  "+[30|45|60]% damage this turn.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      Monster& m = w.fl.mons[mon];
      m.frozen = std::max(m.frozen, 1);
      m.freezeImmune = 0;
      m.hexT = std::max(m.hexT, 1);
      m.hexPct = std::max(m.hexPct, L3(30, 45, 60));
      fxBurst(w, m.p, 0xc0f0ff, 30, 220, 4);
      fxText(w, m.p + V2(0, -m.r - 16), 0xc0f0ff, "GLACIATED", 16);
      fxSound(w, S_FREEZE, 1.f, 0.6f, m.p.x);
      return true;
    };
  }
  // =========================================================== STORM
  {
    auto& a = DEF(AB_STORMBALL, "Storm Ball", SCH_STORM, T_AIM, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Your next ball crackles with lightning for [3|4|5] s, zapping the nearest monster every 0.4 s for 2 + 10% of "
                  "its power.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.stormBallT > 0) return false;
      w.fl.shot.stormBallT = (float)L3(3, 4, 5);
      fxSound(w, S_ZAP, 0.7f, 1.3f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_CONDUCTIVE, "Conductive", SCH_STORM, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Every zap deals +[2|3|4] damage, and Spark pegs arc to [0|1|2] extra monster(s).");
    a.h.stats = [](World& w, int lvl) {
      w.st.zapBonus += L3(2, 3, 4);
      w.st.sparkExtra += L3(0, 1, 2);
    };
  }
  {
    auto& a = DEF(AB_TEMPEST, "Tempest", SCH_STORM, T_AIM, TG_NONE, R_RARE, 3, {5, 5, 5}, 3,
                  "Call a tempest: [3|4|5] bolts strike random monsters for 8 (+1 per depth), and a gale pushes this shot "
                  "toward the side the cursor is on.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int n = L3(3, 4, 5);
      for (int k = 0; k < n; ++k) {
        int t = pickRandomHostile(w);
        if (t < 0) break;
        fxZap(w, V2(w.fl.mons[t].p.x + w.fl.rng.rangef(-50, 50), 0), w.fl.mons[t].p, 0xfff4a0);
        damageMonster(w, t, 8 + w.depth, DS_SPELL);
      }
      w.fl.shot.sideGravT = 2.5f;
      w.fl.shot.sideGravDir = V2(pt.x < LAUNCH_X ? -1.f : 1.f, 0);
      fxSound(w, S_ZAP, 1.f, 0.6f);
      fxShake(w, 8);
      return true;
    };
  }
  {
    auto& a = DEF(AB_IONIZE, "Ionize", SCH_STORM, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Every [8|6|5] peg hits, a ball becomes ionized: its next monster hit arcs to the nearest other monster for "
                  "half damage.");
    a.h.pegHit = [](World& w, int bi, int, int lvl) {
      if (++w.fl.shot.ionCount % L3(8, 6, 5) == 0) w.fl.balls[bi].flags |= BF_IONIZED;
    };
    a.h.monDamaged = [](World& w, int bi, int mi, int dmg, int) {
      Ball& b = w.fl.balls[bi];
      if (!(b.flags & BF_IONIZED) || dmg <= 0) return;
      b.flags &= ~BF_IONIZED;
      V2 from = w.fl.mons[mi].p;
      int o = nearestMonster(w, from, mi);
      if (o < 0) return;
      fxZap(w, from, w.fl.mons[o].p, 0xfff080);
      damageMonster(w, o, std::max(1, dmg / 2), DS_ZAP);
    };
  }
  // =========================================================== EARTH
  {
    auto& a = DEF(AB_LANDSLIDE, "Landslide", SCH_EARTH, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Boulders tumble from the top of the board: [3|4|5] heavy phantom balls with [6|8|10] power each.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int n = L3(3, 4, 5);
      for (int k = 0; k < n; ++k) {
        float x = PX0 + 60 + (PX1 - PX0 - 120) * (k + 0.5f) / n + w.fl.rng.rangef(-30, 30);
        spawnBall(w, V2(x, 26), V2(w.fl.rng.rangef(-60, 60), 100), L3(6, 8, 10), BF_PHANTOM | BF_BOULDER);
      }
      for (auto& nb : w.fl.newBalls)
        if (nb.flags & BF_BOULDER) {
          nb.r = 14.f;
          nb.gravScale = 1.2f;
        }
      fxShake(w, 8);
      fxSound(w, S_BOOM, 0.7f, 0.5f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_BEDROCK, "Bedrock", SCH_EARTH, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "+[1|1|2] armor, and stone blocks, pillars and golems grant +[2|3|4] extra power.");
    a.h.stats = [](World& w, int lvl) { w.st.armor += L3(1, 1, 2); };
    a.h.pegHit = [](World& w, int bi, int pi, int lvl) {
      int k = w.fl.pegs[pi].kind;
      if (k == PK_STONE || k == PK_PILLAR || k == PK_GOLEM) w.fl.balls[bi].power += L3(2, 3, 4);
    };
  }
  {
    auto& a = DEF(AB_GEODE, "Geode", SCH_EARTH, T_AIM, TG_POINT, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Grow a geode at a spot: a stone block ringed by [4|5|6] Crystal pegs (+4 power each).");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      if (!spotFree(w, pt, 40, 0)) return false;
      addPeg(w, PK_STONE, pt, 10);
      int n = L3(4, 5, 6);
      for (int k = 0; k < n; ++k) {
        V2 p = pt + fromAng(k * TAU / n) * 30.f;
        if (spotFree(w, p, PIN_R, 4)) addPeg(w, PK_CRYSTAL, p, PIN_R);
      }
      fxSound(w, S_SHATTER, 0.6f, 0.8f, pt.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SINKHOLE, "Sinkhole", SCH_EARTH, T_AIM, TG_POINT, R_RARE, 3, {4, 4, 4}, 2,
                  "Open a sinkhole for 2 turns: it drags balls toward it, and monsters within its pull take [6|9|12] (+1 per 2 "
                  "depth) damage at the start of each enemy phase.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int zi = addZone(w, ZK_WELL, pt, V2(100, 0), true);
      if (zi < 0) return false;
      Zone& z = w.fl.zones[zi];
      z.str = 800;
      z.ttl = 2;
      z.link = -9;
      z.dmg = L3(6, 9, 12) + w.depth / 2;
      fxRing(w, pt, 100, 0xc8a070);
      fxSound(w, S_BOOM, 0.7f, 0.4f, pt.x);
      return true;
    };
  }
  // =========================================================== ARCANE
  {
    auto& a = DEF(AB_PHASE, "Phase Shift", SCH_ARCANE, T_FLIGHT, TG_NONE, R_COMMON, 3, {1, 1, 1}, 0,
                  "Your balls turn ethereal for [0.5|0.8|1.1] s and pass straight through pegs.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.phaseT = std::max(w.fl.shot.phaseT, (float)L3(0.5f, 0.8f, 1.1f));
      fxSound(w, S_PORTAL, 0.6f, 1.8f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_ARCMISSILES, "Arcane Barrage", SCH_ARCANE, T_AIM, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Fire [3|4|5] magic missiles at random monsters for [3|4|5] damage each.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int n = L3(3, 4, 5);
      bool any = false;
      for (int k = 0; k < n; ++k) {
        int t = pickRandomHostile(w);
        if (t < 0) break;
        fxZap(w, launcherPos(), w.fl.mons[t].p, 0xc080ff);
        damageMonster(w, t, L3(3, 4, 5), DS_SPELL);
        any = true;
      }
      fxSound(w, S_CAST, 0.8f, 1.5f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_MANASURGE, "Mana Surge", SCH_ARCANE, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
                  "Each shot starts with +1 power per MP you have (max +[5|8|12]).");
    a.h.shotStart = [](World& w, int lvl) {
      for (auto& b : w.fl.balls)
        if (b.alive && !(b.flags & BF_PHANTOM)) {
          b.power += std::min(w.pl.mp, L3(5, 8, 12));
          break;
        }
    };
  }
  // =========================================================== LIFE
  {
    auto& a = DEF(AB_RENEWAL, "Renewal", SCH_LIFE, T_AIM, TG_NONE, R_COMMON, 3, {2, 2, 2}, 1,
                  "Cure poison, weakness, corrosion, slowing and sapping, and heal [3|5|7] HP.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      Player& p = w.pl;
      bool any = p.poison || p.weak || p.corrode || p.slowed || p.sapped || p.hp < w.st.maxHp;
      if (!any) return false;
      p.poison = p.weak = p.corrode = p.slowed = p.sapped = 0;
      healPlayer(w, L3(3, 5, 7));
      fxSound(w, S_HEAL, 0.8f, 1.3f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SANCTUARY, "Sanctuary", SCH_LIFE, T_AIM, TG_NONE, R_RARE, 3, {5, 5, 5}, 4,
                  "For the next [1|2|2] enemy phase(s), monster attacks deal half damage. [||At level 3 you also gain 8 Block.]");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.sanctuaryT = std::max(w.fl.sanctuaryT, L3(1, 2, 2));
      if (lvl >= 3) addBlock(w, 8);
      fxRing(w, V2(800, 450), 400, 0x90ffb0);
      fxSound(w, S_HEAL, 1.f, 0.7f);
      return true;
    };
  }
  DEF(AB_LIFELINK, "Lifelink", SCH_LIFE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
      "Whenever you heal, the nearest monster takes [50|75|100]% of the amount as damage.");
  // =========================================================== FORTUNE
  DEF(AB_HOTSTREAK, "Hot Streak", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
      "Each consecutive shot that hits a monster adds +[10|15|20]% damage (max +[50|75|100]%). A shot that hits nothing resets it.");
  {
    auto& a = DEF(AB_LOADEDDICE, "Loaded Dice", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Crit pegs have a [25|35|50]% chance not to be used up, chance effects (Lottery pockets, slot machines, Chaos "
                  "pegs) are luckier, and [1|1|2] extra Crit peg(s) appear each turn.");
    a.h.stats = [](World& w, int lvl) {
      w.st.lucky = true;
      w.st.specials[PK_CRIT] += L3(1, 1, 2);
    };
  }
  {
    auto& a = DEF(AB_GOLDENBALL, "Golden Ball", SCH_FORTUNE, T_AIM, TG_NONE, R_UNCOMMON, 3, {2, 2, 2}, 0,
                  "Pay 10 gold: your next ball is golden. Each peg it hits grants 1 gold (up to 40), and its hits deal +1 damage "
                  "per [10|8|6] gold you carry (max +[8|12|16]).");
    a.goldCost = 10;
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.golden) return false;
      w.fl.shot.golden = true;
      fxSound(w, S_COIN, 1.f, 1.1f);
      return true;
    };
  }
  // =========================================================== SHADOW
  {
    auto& a = DEF(AB_SHADOWSTEP, "Shadow Step", SCH_SHADOW, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {2, 2, 2}, 0,
                  "Your lowest ball vanishes and reappears just above the monster with the lowest HP, with +[2|4|6] power.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int bi = lowestBall(w);
      int t = lowestHpMonster(w);
      if (bi < 0 || t < 0) return false;
      Ball& b = w.fl.balls[bi];
      Monster& m = w.fl.mons[t];
      V2 np = m.p + V2(w.fl.rng.rangef(-12, 12), -m.r - b.r - 50);
      np.x = clampv(np.x, PX0 + b.r + 4, PX1 - b.r - 4);
      np.y = std::max(np.y, CEIL_Y + b.r + 4);
      fxBurst(w, b.p, 0x6040a0, 16, 180);
      b.p = np;
      b.v = V2(0, 260);
      b.stuckRef = np;
      b.power += L3(2, 4, 6);
      b.pegsSinceMon = 1;
      fxBurst(w, np, 0x6040a0, 16, 180);
      fxSound(w, S_PORTAL, 0.7f, 0.7f, np.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_CORRUPTION, "Corruption", SCH_SHADOW, T_AIM, TG_MONSTER, R_COMMON, 3, {2, 2, 2}, 0,
                  "Corrupt a monster for 3 turns: it takes +[2|3|4] damage from every source and cannot heal.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      applyCorrupt(w, mon, L3(2, 3, 4), 3);
      fxSound(w, S_CAST, 0.7f, 0.5f, w.fl.mons[mon].p.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SOULBURN, "Soulburn", SCH_SHADOW, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
                  "When a monster dies, [30|45|60]% of its max HP (up to 60 + 5 per depth) is dealt to the nearest other monster "
                  "as soul fire.");
    a.h.kill = [](World& w, int mi, int lvl) {
      const Monster& m = w.fl.mons[mi];
      if (m.summoned) return;
      V2 pos = m.p;
      int d = std::min((int)(m.maxHp * L3(0.3f, 0.45f, 0.6f)), 60 + 5 * w.depth);
      int t = nearestMonster(w, pos, mi);
      if (t < 0 || d <= 0) return;
      fxZap(w, pos, w.fl.mons[t].p, 0x9060ff);
      damageMonster(w, t, d, DS_SPELL);
    };
  }
  // =========================================================== CLOCKWORK
  {
    auto& a = DEF(AB_TESLACOIL, "Tesla Coil", SCH_CLOCKWORK, T_AIM, TG_POINT, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Build a tesla coil near a spot for [3|4|5] turns. After each of your shots it zaps the two nearest monsters "
                  "for [3|4|5] (+1 per 3 depth). Ball hits on it grant +3 power.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      return placeAlly(w, PK_TESLA, pt, L3(3, 4, 5) + w.depth / 3, L3(3, 4, 5)) >= 0;
    };
  }
  {
    auto& a = DEF(AB_AUTOLOADER, "Autoloader", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
                  "Every [4th|3rd|3rd] shot fires an extra real ball alongside yours with [50|50|75]% of your power.");
    a.h.shotStart = [](World& w, int lvl) {
      if (w.fl.shotsFired % L3(4, 3, 3) != 0 || w.fl.balls.empty()) return;
      const Ball& b0 = w.fl.balls[0];
      V2 v = rot(b0.v, 0.12f);
      spawnBall(w, b0.p, v, std::max(1, (int)(b0.power * L3(0.5f, 0.5f, 0.75f))), 0, 1);
      fxText(w, launcherPos() + V2(0, 40), 0xe0b070, "Autoload!", 13);
    };
  }
  {
    auto& a = DEF(AB_GEARBOX, "Gearbox", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Spinners, kickers and pendulums grant +[2|3|4] power, and [1|1|2] extra spinner(s) appear on every floor.");
    a.h.stats = [](World& w, int lvl) { w.st.kickerBonus += L3(2, 3, 4); };
    a.h.floorStart = [](World& w, int lvl) {
      int n = L3(1, 1, 2);
      for (int k = 0; k < n; ++k) {
        V2 p = randomFieldSpot(w, 46, 6, FIELD_Y0 + 60, FIELD_Y1 - 60);
        if (p.x < 0) continue;
        for (auto& pg : w.fl.pegs)
          if (!pg.dead && pg.kind == PK_PIN && dist2(pg.p, p) < 50 * 50) pg.dead = true;
        int si = addSeg(w, SK_SPINNER, p, p, 5);
        if (si < 0) continue;
        Seg& s = w.fl.segs[si];
        s.c = p;
        s.len = 40;
        s.angVel = (w.fl.rng.chance(0.5f) ? 1.f : -1.f) * 3.f;
        s.rest = 0.8f;
      }
    };
  }
  // =========================================================== BLOOD
  {
    auto& a = DEF(AB_BLOODRITE, "Blood Rite", SCH_BLOOD, T_AIM, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Spill 3 HP: your next ball starts with +[6|9|12] power and its hits apply [1|2|3] Bleed.");
    HP(a, 3, 3, 3);
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.bleedOnHit > 0) return false;
      w.fl.shot.mightBonus += L3(6, 9, 12);
      w.fl.shot.bleedOnHit = L3(1, 2, 3);
      fxSound(w, S_HURT, 0.6f, 1.4f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_HEMORRHAGE, "Hemorrhage", SCH_BLOOD, T_AIM, TG_MONSTER, R_UNCOMMON, 3, {0}, 0,
                  "Spill 4 HP: a monster gains [6|9|12] Bleed. If it was already bleeding, the old wounds tear open and deal "
                  "their damage at once.");
    HP(a, 4, 4, 4);
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      Monster& m = w.fl.mons[mon];
      int old = m.bleed;
      fxBurst(w, m.p, 0xe03848, 24, 200);
      fxSound(w, S_HIT, 0.8f, 0.6f, m.p.x);
      applyBleed(w, mon, L3(6, 9, 12));
      if (old > 0) damageMonster(w, mon, old, DS_BLEED);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SANGUINE, "Sanguine Fury", SCH_BLOOD, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Whenever you lose HP, your next ball gains +1 power per HP lost (up to +[8|12|16] stored).");
    a.h.hurt = [](World& w, int dmg, int lvl) {
      int cap = L3(8, 12, 16);
      if (w.pl.nextShotPower < cap) w.pl.nextShotPower = std::min(cap, w.pl.nextShotPower + dmg);
    };
  }
  {
    auto& a = DEF(AB_BLOODPACT, "Blood Pact", SCH_BLOOD, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
                  "While below half HP you deal +[20|30|40]% damage, and kills heal [1|2|3] HP.");
    a.h.stats = [](World& w, int lvl) {
      w.st.lowHpDmg += L3(0.2f, 0.3f, 0.4f);
      w.st.killHeal += L3(1, 2, 3);
    };
  }
  {
    auto& a = DEF(AB_EXSANGUINATE, "Exsanguinate", SCH_BLOOD, T_AIM, TG_NONE, R_RARE, 3, {0}, 3,
                  "Spill 5 HP: every bleeding monster takes [2|2.5|3]x its Bleed as damage, and you heal half the total.");
    HP(a, 5, 5, 5);
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int total = 0;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (!isHostile(w, i) || w.fl.mons[i].bleed <= 0) continue;
        int d = (int)(w.fl.mons[i].bleed * L3(2.f, 2.5f, 3.f));
        fxZap(w, w.fl.mons[i].p, V2(200, 118), 0xe03848);
        total += damageMonster(w, i, d, DS_BLEED);
      }
      if (total <= 0) return false;
      healPlayer(w, total / 2);
      fxSound(w, S_CAST, 1.f, 0.4f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_BLOODBOIL, "Blood Boil", SCH_BLOOD, T_AIM, TG_NONE, R_UNCOMMON, 3, {0}, 1,
                  "Spill 4 HP: every monster takes [4|7|10] damage and gains 3 Bleed.");
    HP(a, 4, 4, 4);
    a.cast = [](World& w, int lvl, V2, V2, int) {
      bool any = false;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (!isHostile(w, i)) continue;
        any = true;
        fxBurst(w, w.fl.mons[i].p, 0xe03848, 16, 180);
        damageMonster(w, i, L3(4, 7, 10), DS_SPELL);
        applyBleed(w, i, 3);
      }
      fxSound(w, S_FIRE, 0.8f, 0.5f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_BEASTFORM, "Beast Form", SCH_BLOOD, T_AIM, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 2,
                  "Take a bestial form for one shot: your ball is 25% bigger, deals +[30|45|60]% damage, and each hit applies 2 "
                  "Bleed.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.beast) return false;
      w.fl.shot.beast = true;
      w.fl.shot.beastLvl = lvl;
      fxSound(w, S_GROWL, 1.f, 0.9f);
      return true;
    };
  }
  // =========================================================== CHAOS
  {
    auto& a = DEF(AB_CHAOSBOLT, "Chaos Bolt", SCH_CHAOS, T_AIM, TG_MONSTER, R_COMMON, 3, {2, 2, 2}, 0,
                  "Hurl raw chaos: [6|9|12] damage plus a random effect - Burn, Poison, Chill, Bleed, a Hex, a teleport, or "
                  "(rarely) a polymorph.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      V2 mp = w.fl.mons[mon].p;
      fxZap(w, launcherPos(), mp, 0xff60ff);
      fxSound(w, S_CAST, 0.8f, 1.7f, mp.x);
      damageMonster(w, mon, L3(6, 9, 12), DS_SPELL);
      if (w.fl.mons[mon].dead) return true;
      int r = w.fl.rng.range(0, 9);
      switch (r) {
        case 0: case 1: applyBurn(w, mon, 6); break;
        case 2: case 3: applyPoison(w, mon, 6); break;
        case 4: applyChill(w, mon, 1); break;
        case 5: applyBleed(w, mon, 5); break;
        case 6: w.fl.mons[mon].hexT = std::max(w.fl.mons[mon].hexT, 2); w.fl.mons[mon].hexPct = std::max(w.fl.mons[mon].hexPct, 50); break;
        case 7: case 8: teleportMonster(w, mon); break;
        default:
          if (!w.fl.mons[mon].boss) polymorphMonster(w, mon, randomRosterMonster(w, 0));
          else applyBurn(w, mon, 6);
          break;
      }
      return true;
    };
  }
  DEF(AB_WILDSURGE, "Wild Magic", SCH_CHAOS, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
      "Whenever you cast a spell there is a [20|30|40]% chance of a wild surge: a random boon (MP, power, special pegs, healing "
      "or a bolt).");
  {
    auto& a = DEF(AB_POLYMORPH, "Polymorph", SCH_CHAOS, T_AIM, TG_MONSTER, R_RARE, 3, {4, 4, 4}, 3,
                  "Polymorph a non-boss monster into a random monster of this floor ([50|65|80]% chance it becomes a weaker one).");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0 || w.fl.mons[mon].boss) return false;
      bool weak = w.fl.rng.chance(L3(0.5f, 0.65f, 0.8f));
      polymorphMonster(w, mon, randomRosterMonster(w, weak ? -1 : 0));
      return true;
    };
  }
  {
    auto& a = DEF(AB_ENTROPY, "Entropy", SCH_CHAOS, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "At the start of each turn, [2|3|4] random pins become random special pegs, but [1|1|0] special peg turns into "
                  "a Curse peg.");
    a.h.turnStart = [](World& w, int lvl) {
      static const int K[] = {PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_MULTI, PK_FIRE, PK_ICE, PK_POISON, PK_SPARK, PK_CRYSTAL,
                              PK_CHAOS, PK_CLOVER, PK_FEATHER, PK_VAMPIRE, PK_TELEPORT, PK_MIRROR};
      int n = L3(2, 3, 4);
      for (int k = 0; k < n; ++k) convertPins(w, K[w.fl.rng.range(0, 15)], 1);
      int c = L3(1, 1, 0);
      if (c > 0) {
        std::vector<int> sp;
        for (int i = 0; i < (int)w.fl.pegs.size(); ++i)
          if (!w.fl.pegs[i].dead && !w.fl.pegs[i].used && isEnchant(w.fl.pegs[i].kind) && w.fl.pegs[i].kind != PK_CURSE) sp.push_back(i);
        if (!sp.empty()) w.fl.pegs[sp[w.fl.rng.range(0, (int)sp.size() - 1)]].kind = PK_CURSE;
      }
    };
  }
  {
    auto& a = DEF(AB_DICEBALL, "Dice Ball", SCH_CHAOS, T_AIM, TG_NONE, R_COMMON, 3, {1, 1, 1}, 0,
                  "Roll the dice: this shot deals between x[0.5|0.7|0.9] and x2.5 damage.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.diceMul10 != 10) return false;
      w.fl.shot.diceMul10 = w.fl.rng.range(L3(5, 7, 9), 25);
      if (w.fl.shot.diceMul10 == 10) w.fl.shot.diceMul10 = 11;
      fxText(w, launcherPos() + V2(0, 60), 0xff60ff, fmt("x%.1f", w.fl.shot.diceMul10 / 10.f), 20);
      fxSound(w, S_COIN, 0.8f, 0.8f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_CHAOSGATE, "Chaos Gate", SCH_CHAOS, T_AIM, TG_NONE, R_RARE, 3, {5, 5, 5}, 3,
                  "Open a gate to the Tumbler's realm: it meddles on your behalf, [kindly|very kindly|with great kindness].");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      tumblerInvoke(w, L3(1, 2, 3));
      return true;
    };
  }
  // =========================================================== SUMMONING
  {
    auto& a = DEF(AB_SUMMONIMP, "Summon Imp", SCH_SUMMON, T_AIM, TG_POINT, R_COMMON, 3, {3, 3, 3}, 0,
                  "Summon an imp near a spot for [3|4|5] turns: after each enemy phase it firebolts a random monster for "
                  "[3|4|5] (+1 per 3 depth) and 1 Burn. Ball hits on it grant +2 power.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) { return placeAlly(w, PK_IMP, pt, L3(3, 4, 5) + w.depth / 3, L3(3, 4, 5)) >= 0; };
  }
  {
    auto& a = DEF(AB_HOUND, "Spectral Hound", SCH_SUMMON, T_AIM, TG_POINT, R_COMMON, 3, {3, 3, 3}, 0,
                  "Summon a spectral hound near a spot for [3|4|5] turns: after each enemy phase it bites the nearest monster "
                  "for [5|7|9] (+1 per 3 depth) and 2 Bleed. Ball hits on it grant +4 power.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) { return placeAlly(w, PK_HOUND, pt, L3(5, 7, 9) + w.depth / 3, L3(3, 4, 5)) >= 0; };
  }
  {
    auto& a = DEF(AB_GUARDIAN, "Guardian Spirit", SCH_SUMMON, T_AIM, TG_NONE, R_UNCOMMON, 3, {5, 5, 5}, 4,
                  "A guardian spirit fully blocks the next [1|1|2] monster attack(s) against you during this turn's enemy "
                  "phase[| and grants 5 Block|]. Save it for the big hits!");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.pl.guardBlocks = std::max(w.pl.guardBlocks, L3(1, 1, 2));
      if (lvl == 2) addBlock(w, 5);
      fxRing(w, V2(200, 118), 60, 0xa0e0ff);
      fxSound(w, S_BLOCK, 1.f, 1.2f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SWARMCALL, "Firefly Swarm", SCH_SUMMON, T_AIM, TG_NONE, R_UNCOMMON, 3, {4, 4, 4}, 2,
                  "Summon [3|4|5] fireflies for the rest of the floor. They drift around the board (+2 power per hit) and each "
                  "stings a random monster for 2 after every enemy phase.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int n = L3(3, 4, 5), made = 0;
      for (int k = 0; k < n; ++k) {
        V2 c = randomFieldSpot(w, 30, 6, FIELD_Y0 + 60, FIELD_Y1 - 80);
        if (c.x < 0) continue;
        int pi = addPeg(w, PK_FIREFLY, c, 7);
        if (pi < 0) break;
        Peg& p = w.fl.pegs[pi];
        p.motion = 4;
        p.anchor = c;
        p.mA = w.fl.rng.rangef(20, 34);
        p.mSpeed = w.fl.rng.rangef(0.5f, 0.9f);
        p.mPhase = w.fl.rng.rangef(0, TAU);
        p.val = 2;
        p.temp = true;
        made++;
      }
      fxSound(w, S_SPAWN, 0.7f, 1.6f);
      return made > 0;
    };
  }
  {
    auto& a = DEF(AB_BONDMASTER, "Bondmaster", SCH_SUMMON, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
                  "Your summons deal +[30|50|70]% damage and last +[1|1|2] turn(s).");
    a.h.stats = [](World& w, int lvl) {
      w.st.allyDmgMul *= 1.f + L3(0.3f, 0.5f, 0.7f);
      w.st.allyTurns += L3(1, 1, 2);
    };
  }
  {
    auto& a = DEF(AB_FAMILIAR, "Familiar", SCH_SUMMON, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "A familiar joins you on every floor: after each enemy phase it strikes your focus target for [3|5|7] (+1 per 3 "
                  "depth). Ball hits on it grant +2 power.");
    a.h.floorStart = [](World& w, int lvl) {
      if (w.fl.isVault) return;
      placeAlly(w, PK_FAMILIAR, V2(-1, -1), L3(3, 5, 7) + w.depth / 3, 0);
    };
  }
  // =========================================================== VOID
  {
    auto& a = DEF(AB_BANISH, "Banish", SCH_VOID, T_AIM, TG_MONSTER, R_RARE, 3, {5, 5, 5}, 4,
                  "Banish a non-boss monster with at most [30|40|50]% HP into the void. You gain half its XP.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      Monster& m = w.fl.mons[mon];
      if (m.boss || m.hp * 100 > m.maxHp * L3(30, 40, 50)) return false;
      if (!m.summoned) gainXp(w, MON[m.def].xp / 2);
      fxBurst(w, m.p, 0x6030c0, 40, 260, 4);
      fxRing(w, m.p, m.r * 2.5f, 0x6030c0);
      fxSound(w, S_PORTAL, 1.f, 0.4f, m.p.x);
      w.fl.mons[mon].summoned = true;
      killMonster(w, mon, DS_SPELL);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SINGULARITY, "Singularity", SCH_VOID, T_AIM, TG_POINT, R_UNCOMMON, 3, {4, 4, 4}, 2,
                  "Create a singularity at a spot for [1|2|2] turn(s): it pulls balls in, and a swallowed ball discharges "
                  "[150|175|200]% of its power into your focus target.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int zi = addZone(w, ZK_BLACKHOLE, pt, V2(80, 0), true);
      if (zi < 0) return false;
      Zone& z = w.fl.zones[zi];
      z.ttl = L3(1, 2, 2);
      z.str = 900;
      z.dmg = L3(150, 175, 200);
      fxRing(w, pt, 80, 0x8040e0);
      fxSound(w, S_PORTAL, 0.9f, 0.4f, pt.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_WARPGRAVITY, "Warp Gravity", SCH_VOID, T_FLIGHT, TG_NONE, R_COMMON, 3, {3, 3, 3}, 2,
                  "For [1|1.5|2] s, gravity pulls your balls toward the cursor instead of down.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.gravWarpT = std::max(w.fl.shot.gravWarpT, (float)L3(1.f, 1.5f, 2.f));
      fxSound(w, S_PORTAL, 0.7f, 0.7f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_VOIDTOUCH, "Void Touch", SCH_VOID, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "[1|1|2] Void peg(s) appear each turn, and swallowed balls discharge +[25|50|75]% more.");
    a.h.stats = [](World& w, int lvl) {
      w.st.specials[PK_VOID] += L3(1, 1, 2);
      w.st.voidMul += L3(0.25f, 0.5f, 0.75f);
    };
  }
  DEF(AB_DIMDOOR, "Dimension Door", SCH_VOID, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
      "Once per shot, a ball about to fall into a pocket other than Strike, Free Turn, Jackpot or Double is instead teleported "
      "high up the board with +[3|5|7] power.");
  {
    auto& a = DEF(AB_RIFT, "Rift", SCH_VOID, T_AIM, TG_TWO_POINTS, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Tear a two-way rift between two points for [2|3|4] turns: balls entering either end emerge from the other with "
                  "+[2|3|4] power.");
    a.cast = [](World& w, int lvl, V2 p1, V2 p2, int) {
      if (dist(p1, p2) < 60) return false;
      int n0 = (int)w.fl.zones.size();
      placeRift(w, p1, p2, L3(2, 3, 4));
      for (int i = n0; i < (int)w.fl.zones.size(); ++i) w.fl.zones[i].dmg = L3(2, 3, 4);
      fxSound(w, S_PORTAL, 0.9f, 0.6f);
      return (int)w.fl.zones.size() > n0;
    };
  }
  // =========================================================== INNATE (racial / mutation)
  {
    auto& a = DEF(AB_DAMNATION, "Hurl Damnation", SCH_SHADOW, T_AIM, TG_MONSTER, R_RARE, 3, {3, 3, 3}, 1,
                  "Hurl a bolt of Damnation: [10|15|20] (+1 per depth) damage to a monster, and 4 Burn to every monster within "
                  "100 px of it.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      V2 mp = w.fl.mons[mon].p;
      fxZap(w, launcherPos(), mp, 0xff3020);
      fxBurst(w, mp, 0xff3020, 40, 280, 4);
      fxRing(w, mp, 100, 0xff3020);
      fxSound(w, S_FIRE, 1.f, 0.5f, mp.x);
      damageMonster(w, mon, L3(10, 15, 20) + w.depth, DS_SPELL);
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i) && dist(w.fl.mons[i].p, mp) - w.fl.mons[i].r < 100) applyBurn(w, i, 4);
      return true;
    };
  }
  {
    auto& a = DEF(AB_BREATH_FIRE, "Fire Breath", SCH_FLAME, T_AIM, TG_POINT, R_RARE, 3, {2, 2, 2}, 2,
                  "Breathe fire at a spot: monsters within 110 px take [6|10|14] (+1 per 2 XL) damage and 5 Burn.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      fxSound(w, S_FIRE, 1.f, 0.6f, pt.x);
      return breathArea(w, pt, 110, L3(6, 10, 14) + w.pl.xl / 2, 0);
    };
  }
  {
    auto& a = DEF(AB_BREATH_FROST, "Frost Breath", SCH_FROST, T_AIM, TG_POINT, R_RARE, 3, {2, 2, 2}, 2,
                  "Breathe frost at a spot: monsters within 110 px take [5|8|11] (+1 per 2 XL) damage and are Chilled.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      fxSound(w, S_FREEZE, 1.f, 0.6f, pt.x);
      return breathArea(w, pt, 110, L3(5, 8, 11) + w.pl.xl / 2, 1);
    };
  }
  {
    auto& a = DEF(AB_BREATH_VENOM, "Venom Breath", SCH_SHADOW, T_AIM, TG_POINT, R_RARE, 3, {2, 2, 2}, 2,
                  "Breathe venom at a spot: monsters within 110 px take [4|6|8] damage and gain heavy Poison.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      fxSound(w, S_POISON, 1.f, 0.6f, pt.x);
      return breathArea(w, pt, 110, L3(4, 6, 8) + w.pl.xl / 3, 2);
    };
  }
  {
    auto& a = DEF(AB_BREATH_ACID, "Acid Breath", SCH_EARTH, T_AIM, TG_POINT, R_RARE, 3, {2, 2, 2}, 2,
                  "Spit acid at a spot: monsters within 110 px take [6|9|12] (+1 per 2 XL) damage and lose 2 armor, and the pins "
                  "there dissolve.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      for (auto& p : w.fl.pegs)
        if (!p.dead && p.kind == PK_PIN && !p.motion && dist2(p.p, pt) < 90 * 90) p.dead = true;
      fxSound(w, S_POISON, 1.f, 0.4f, pt.x);
      breathArea(w, pt, 110, L3(6, 9, 12) + w.pl.xl / 2, 3);
      return true;
    };
  }
  {
    auto& a = DEF(AB_BREATH_STORM, "Storm Breath", SCH_STORM, T_AIM, TG_POINT, R_RARE, 3, {2, 2, 2}, 2,
                  "Breathe lightning: the monster nearest a spot takes [8|12|16] (+1 per 2 XL) damage, arcing to 3 others for 60%.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int t = nearestMonster(w, pt);
      if (t < 0) return false;
      int d = L3(8, 12, 16) + w.pl.xl / 2;
      V2 from = launcherPos();
      fxZap(w, from, w.fl.mons[t].p, 0xfff080);
      V2 at = w.fl.mons[t].p;
      damageMonster(w, t, d, DS_ZAP);
      int last = t;
      for (int k = 0; k < 3; ++k) {
        int o = nearestMonster(w, at, last);
        if (o < 0) break;
        fxZap(w, at, w.fl.mons[o].p, 0xfff080);
        at = w.fl.mons[o].p;
        damageMonster(w, o, d * 6 / 10, DS_ZAP);
        last = o;
      }
      fxSound(w, S_ZAP, 1.f, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_BREATH_MAGIC, "Magic Breath", SCH_ARCANE, T_AIM, TG_MONSTER, R_RARE, 3, {2, 2, 2}, 2,
                  "Breathe a focused beam of raw magic: [10|16|22] (+1 per 2 XL) damage to a monster, stripping its Block first.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      w.fl.mons[mon].shield = 0;
      fxZap(w, launcherPos(), w.fl.mons[mon].p, 0xb060ff);
      fxSound(w, S_CAST, 1.f, 0.8f);
      damageMonster(w, mon, L3(10, 16, 22) + w.pl.xl / 2, DS_SPELL);
      return true;
    };
  }
  {
    auto& a = DEF(AB_BREATH_STEAM, "Steam Breath", SCH_FROST, T_AIM, TG_POINT, R_RARE, 3, {2, 2, 2}, 2,
                  "Exhale scalding steam: monsters within 150 px of a spot take [4|6|8] (+1 per 3 XL) damage, and you gain "
                  "[4|6|8] Block.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      fxSound(w, S_WHOOSH, 1.f, 0.6f, pt.x);
      breathArea(w, pt, 150, L3(4, 6, 8) + w.pl.xl / 3, 6);
      addBlock(w, L3(4, 6, 8));
      return true;
    };
  }
  {
    auto& a = DEF(AB_BREATH_SHADOW, "Tail Slam", SCH_FORCE, T_AIM, TG_NONE, R_RARE, 3, {2, 2, 2}, 1,
                  "Wind up a crushing tail slam: your next ball is a heavy boulder with +[8|12|16] power.");
    a.innate = true;
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.boulder) return false;
      w.fl.shot.boulder = true;
      w.fl.shot.mightBonus += L3(8, 12, 16);
      fxSound(w, S_BLOCK, 0.9f, 0.5f);
      return true;
    };
  }
}
