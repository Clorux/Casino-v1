// Dropcrawl - core game types
#pragma once
#include "common.h"

// ============================================================ layout
constexpr float SCR_W = 1600, SCR_H = 900;
constexpr float BOARD_X0 = 380, BOARD_X1 = 1220;  // board panel
constexpr float PX0 = 392, PX1 = 1208;            // inner walls (ball collides here)
constexpr float CEIL_Y = 8;
constexpr float LAUNCH_X = 800, LAUNCH_Y = 52;
constexpr float FIELD_Y0 = 118, FIELD_Y1 = 800;
constexpr float POCKET_TOP = 842;  // divider tops
constexpr float DRAIN_Y = 882;     // ball resolves here
constexpr float BALL_R = 9;
constexpr float PIN_R = 6;
constexpr float GRAVITY = 1000;
constexpr float BASE_LAUNCH = 620;
constexpr int MAX_POCKETS = 10;
constexpr int MAX_ACTIVES = 6;
constexpr float TICK = 1.f / 120.f;

// ============================================================ enums
enum School : uint8_t {
  SCH_FORCE, SCH_FLAME, SCH_FROST, SCH_STORM, SCH_EARTH, SCH_ARCANE, SCH_LIFE, SCH_FORTUNE, SCH_SHADOW,
  SCH_CLOCKWORK, SCH_BLOOD, SCH_CHAOS, SCH_SUMMON, SCH_VOID, SCH_DIVINE, SCH_COUNT
};
enum Timing : uint8_t { T_PASSIVE, T_AIM, T_FLIGHT, T_ANY };
enum Targeting : uint8_t { TG_NONE, TG_MONSTER, TG_POINT, TG_TWO_POINTS };
enum Rarity : uint8_t { R_COMMON, R_UNCOMMON, R_RARE };

enum PegKind : uint8_t {
  PK_PIN, PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_BOMB, PK_MULTI, PK_FIRE, PK_ICE, PK_POISON, PK_SPARK,
  PK_CRYSTAL, PK_GLASS, PK_STONE, PK_BUMPER, PK_CHEST, PK_KEY, PK_CURSE, PK_TOTEM, PK_BONE, PK_XP,
  PK_REFRESH, PK_LIFE, PK_MBOMB, PK_THORN, PK_MUSHROOM, PK_GOLEM, PK_PILLAR, PK_TREE, PK_SKELETON,
  // --- expansion
  PK_TULIP, PK_CHUCKER, PK_TARGET, PK_MAGNET, PK_TELEPORT, PK_JELLY, PK_MIRROR, PK_VAMPIRE, PK_CHAOS,
  PK_FREEZE, PK_CLOVER, PK_ANVIL, PK_FEATHER, PK_VOID, PK_SHIELD, PK_SEED, PK_COINS, PK_SPRING, PK_EGG,
  PK_IMP, PK_HOUND, PK_TESLA, PK_FAMILIAR, PK_FIREFLY, PK_ANGEL, PK_BELL, PK_RUNE, PK_GHOST,
  // --- v3: loot, shrines & new specials
  PK_LOOT, PK_SHRINE, PK_WELL, PK_MIMIC, PK_SHARD, PK_PINATA, PK_PRISM, PK_DICE, PK_STAR, PK_MOON,
  PK_HOURGLASS, PK_BLOOD, PK_CANNON, PK_ROD, PK_COMBO, PK_SNOWBALL, PK_ECHO, PK_BRAND, PK_JACKPOT, PK_GEM,
  PK_COUNT
};
enum SegKind : uint8_t {
  SK_WALL, SK_SPINNER, SK_GATE, SK_BARRIER, SK_DIVIDER, SK_FLIPPER, SK_RAMP,
  SK_KICKER, SK_PENDULUM, SK_PETAL, SK_ICEWALL
};
enum ZoneKind : uint8_t {
  ZK_WATER, ZK_WIND, ZK_WELL, ZK_REPULSE, ZK_LAVA, ZK_BOOST, ZK_PORTAL,
  ZK_CONVEYOR, ZK_ANTIGRAV, ZK_HASTE, ZK_CHARGE, ZK_MIST, ZK_SPRING, ZK_BLACKHOLE, ZK_MIRROR, ZK_RUNE,
  ZK_WEB, ZK_GEYSER, ZK_ROLLOVER, ZK_FOG, ZK_RIFT, ZK_COUNT
};
enum PocketKind : uint8_t {
  PO_EMPTY, PO_RECALL, PO_MANA, PO_HEAL, PO_GOLD, PO_POWER, PO_STRIKE, PO_CURSED, PO_JACKPOT,
  PO_DOUBLE, PO_REFRESH, PO_XP, PO_SHIELD, PO_MULTI, PO_BOMB, PO_FREEZE, PO_BURN, PO_POISON, PO_LOTTERY,
  PO_CHAOS, PO_BANK, PO_VOID, PO_FROZEN,
  // --- v3
  PO_LOOT, PO_SHRINE, PO_RELAUNCH, PO_SUMMON, PO_SMITE, PO_SCATTER, PO_TRAINING, PO_DELAY, PO_GAMBLE, PO_SHARD,
  PO_SLOTS, PO_PRAYER, PO_TRAP, PO_TAX,
  PO_COUNT
};

enum IntentKind : uint8_t {
  IN_NONE, IN_ATTACK, IN_HEAVY, IN_MULTI, IN_BLOCK, IN_HEAL, IN_BUFF, IN_SUMMON, IN_HEX, IN_BOMB, IN_WALL,
  IN_TELEPORT, IN_DRAIN, IN_POISON, IN_WEAKEN, IN_GROW, IN_EAT, IN_TOTEM, IN_CURSEPOCKET, IN_STEAL, IN_CHARGE,
  IN_SHUFFLE, IN_RISE,
  // --- expansion
  IN_EGGS, IN_WEB, IN_BLIND, IN_CURSEBALL, IN_SHIELDALLY, IN_ENRAGE, IN_BURROW, IN_BEAM, IN_ACID, IN_MUTATEPEGS,
  IN_SWAP, IN_DECOY, IN_FREEZEPOCKET, IN_DEVOUR, IN_GRAVITY, IN_RANDOM, IN_SLOW, IN_SAP, IN_CALL,
  // --- v3: boss moves & treasure imps
  IN_QUAKE, IN_LIFEDRAIN, IN_DISPEL, IN_EXECUTE, IN_SUNDER, IN_FLEE, IN_METEOR,
  IN_COUNT
};
enum MonTrait : uint32_t {
  TR_FLYING = 1u << 0, TR_PHASING = 1u << 1, TR_REGEN = 1u << 2, TR_SPLIT = 1u << 3, TR_VOLATILE = 1u << 4,
  TR_EVASIVE = 1u << 5, TR_THORNS = 1u << 6, TR_UNDYING = 1u << 7, TR_REFLECT = 1u << 8, TR_BOSS = 1u << 9,
  TR_ELITE = 1u << 10, TR_STATIONARY = 1u << 11, TR_LIFESTEAL = 1u << 12, TR_ENRAGE = 1u << 13,
  TR_SWARM = 1u << 14, TR_HARDENED = 1u << 15, TR_MAGNETIC = 1u << 16, TR_ALLY = 1u << 17,
  TR_SPLITHIT = 1u << 18,   // splits in two when a single hit deals 25%+ of its max HP
  TR_ACIDIC = 1u << 19,     // your ball loses tval power when it hits this monster
  TR_BLINKER = 1u << 20,    // teleports away once when it drops below half HP
  TR_AURA = 1u << 21,       // heals every other monster tval per turn
  TR_DECOY = 1u << 22,      // an illusion: dies in one hit, gives nothing
  TR_UNDEAD = 1u << 23,
  TR_DEMONIC = 1u << 24,
  TR_SLIMY = 1u << 25,
};

enum Phase : uint8_t { PH_AIM, PH_TARGET, PH_FLIGHT, PH_REDIRECT, PH_RELAUNCH, PH_ENEMY, PH_CLEARED, PH_DEAD };
enum RunScreen : uint8_t { RS_FLOOR, RS_REWARD, RS_STAIRS, RS_SHOP, RS_REST, RS_ALTAR, RS_EVENT, RS_VICTORY, RS_DEATH };
enum FloorKind : uint8_t { FK_NORMAL, FK_ELITE, FK_BOSS, FK_VAULT };
enum StairKind : uint8_t { ST_FLOOR, ST_ELITE, ST_BOSS, ST_SHOP, ST_REST, ST_TREASURE, ST_ALTAR, ST_EVENT, ST_BRANCH };
enum Biome : uint8_t {
  BI_HALLS, BI_LAIR, BI_DROWNED, BI_MINES, BI_CRYPT, BI_FORGE, BI_FROZEN, BI_CORE, BI_SLIME, BI_ABYSS, BI_COUNT
};

// core character stats (v3)
enum StatId : uint8_t { STAT_STR, STAT_DEX, STAT_INT, STAT_VIT, STAT_LCK, STAT_COUNT };
constexpr int STAT_BASE = 5;       // stats above this give bonuses, below it penalties
constexpr int FORMAT_COUNT = 14;   // board formats (formats.cpp)
constexpr int SHRINE_COUNT = 10;   // shrine blessings (loot.cpp)
constexpr int AFFIX_COUNT = 17;    // champion monster affixes (loot.cpp)
constexpr int RUNE_COUNT = 35;     // rune circle outcomes (runes.cpp)
constexpr int RUNEWORD_COUNT = 12;

enum DmgSrc : uint8_t {
  DS_BALL, DS_SPELL, DS_BURN, DS_POISON, DS_EXPLOSION, DS_ZAP, DS_THORNS, DS_ALLY, DS_POCKET, DS_DISCHARGE, DS_BLEED,
  DS_HOLY
};

// ball flags
enum : uint32_t {
  BF_FIRE = 1u << 0,      // next monster hit applies burn
  BF_FROST = 1u << 1,     // next monster hit chills
  BF_VENOM = 1u << 2,     // next monster hit poisons
  BF_BOULDER = 1u << 3,
  BF_PHANTOM = 1u << 4,   // hailstone / temp ball (no pocket effects)
  BF_CAUGHT = 1u << 5,    // was caught by catcher at least once
  BF_REBOUNDED = 1u << 6,
  BF_SLAM = 1u << 7,
  BF_STRIKE = 1u << 8,    // landed in a Strike pocket: full discharge
  BF_ECHO = 1u << 9,      // Twin Launcher echo ball: half damage
  BF_LUCKY = 1u << 10,    // clover: next pocket effect doubled
  BF_ANCESTOR = 1u << 11, // the Ancestor's ball
  BF_GOLDEN = 1u << 12,   // every peg hit grants gold
  BF_VOIDED = 1u << 13,   // swallowed by the void: discharge x1.5
  BF_BEAST = 1u << 14,    // beast form: hits bleed
  BF_ELEMENTAL = 1u << 15,
  BF_SLIMESPLIT = 1u << 16,  // slime ball already split this shot
  BF_BANKED = 1u << 17,      // bank shot: next monster hit bonus
  BF_IONIZED = 1u << 18,     // ionize: next monster hit arcs
  BF_HOLY = 1u << 19,        // blessed ball
  BF_SCATTER = 1u << 20,     // extra scatter-shot ball
  BF_CRITNEXT = 1u << 21,    // next monster hit is a guaranteed critical hit
  BF_GEARED = 1u << 22,      // rune of gears: wall bounces grant power
  BF_MOON = 1u << 23,        // moonlit: next monster hit +50%
  BF_COMET = 1u << 24,       // tumbler comet: heavy, +power per peg
  BF_RELAUNCHED = 1u << 25,  // already sent back up by a Relaunch pocket
};
// once-per-floor flags (Floor::onceFlags)
enum : uint32_t { OF_UNBREAK = 1u << 0, OF_BOUNTY = 1u << 1, OF_FATEDRAW = 1u << 2, OF_NEARDEATH = 1u << 3 };

// ============================================================ ids of content
enum AbId : uint16_t {
  // FORCE
  AB_NUDGE, AB_LEVITATE, AB_SLAM, AB_HEAVY, AB_FEATHER, AB_MOMENTUM, AB_RICOCHET, AB_REBOUND, AB_KINETIC,
  AB_SECONDWIND, AB_PINBALL, AB_JUGGERNAUT,
  // FLAME
  AB_KINDLE, AB_FIREBALL, AB_FLAMEPEGS, AB_EMBERTRAIL, AB_COMBUSTION, AB_INFERNO, AB_PHOENIX, AB_HEATSHIMMER,
  // FROST
  AB_FROSTBITE, AB_ICEPEGS, AB_GLACIAL, AB_ICELANCE, AB_SHATTER, AB_COLDSNAP, AB_HAIL, AB_PERMAFROST,
  // STORM
  AB_STATIC, AB_CHAIN, AB_SPARKPEGS, AB_THUNDERCLAP, AB_OVERCHARGE, AB_CALLLIGHTNING, AB_MAGNETISM, AB_CAPACITOR,
  // EARTH
  AB_STONESKIN, AB_BOULDER, AB_RAISEEARTH, AB_QUAKE, AB_CRYSTAL, AB_AFTERSHOCK, AB_GOLEM, AB_PILLAR,
  // ARCANE
  AB_MISSILE, AB_BLINK, AB_WORMHOLE, AB_ECHO, AB_MANAFONT, AB_STASIS, AB_DUPLICATE, AB_SCRYING, AB_SPELLWEAVE,
  AB_DISPEL, AB_TIMEWARP, AB_HASTE,
  // LIFE
  AB_REGEN, AB_HEALWOUNDS, AB_VAMPIRIC, AB_OVERGROWTH, AB_HEALPEGS, AB_BLOOM, AB_THORNS, AB_VITALITY,
  // FORTUNE
  AB_MIDAS, AB_RHYTHM, AB_CRITPEGS, AB_JACKPOT, AB_INTEREST, AB_BOUNTY, AB_BRIBE, AB_COINTOSS, AB_DOUBLEDOWN,
  AB_TREASURE,
  // SHADOW
  AB_VENOM, AB_PLAGUE, AB_SIPHON, AB_BONEHARVEST, AB_HEX, AB_DRAIN, AB_CURSEEATER, AB_DEATHMARK, AB_RAISEDEAD,
  AB_NIGHTSHADE,
  // CLOCKWORK
  AB_BUMPERKIT, AB_SPINNER, AB_TURRET, AB_TWIN, AB_CATCHER, AB_OVERCLOCK, AB_GYRO, AB_DEMOLITION, AB_ROTOR,
  AB_LAUNCHER,
  // --- expansion: more of every school
  AB_BANKSHOT, AB_TELEKINESIS, AB_SHOCKWAVE, AB_SCATTER, AB_MARKSMAN,
  AB_METEOR, AB_SUNSPOT, AB_PYRE, AB_FLASHPOINT,
  AB_BLIZZARD, AB_ICEWALL, AB_FROZENHEART, AB_GLACIATE,
  AB_STORMBALL, AB_CONDUCTIVE, AB_TEMPEST, AB_IONIZE,
  AB_LANDSLIDE, AB_BEDROCK, AB_GEODE, AB_SINKHOLE,
  AB_PHASE, AB_ARCMISSILES, AB_MANASURGE,
  AB_RENEWAL, AB_SANCTUARY, AB_LIFELINK,
  AB_HOTSTREAK, AB_LOADEDDICE, AB_GOLDENBALL,
  AB_SHADOWSTEP, AB_CORRUPTION, AB_SOULBURN,
  AB_TESLACOIL, AB_AUTOLOADER, AB_GEARBOX,
  // BLOOD
  AB_BLOODRITE, AB_HEMORRHAGE, AB_SANGUINE, AB_BLOODPACT, AB_EXSANGUINATE, AB_BLOODBOIL, AB_BEASTFORM,
  // CHAOS
  AB_CHAOSBOLT, AB_WILDSURGE, AB_POLYMORPH, AB_ENTROPY, AB_DICEBALL, AB_CHAOSGATE,
  // SUMMONING
  AB_SUMMONIMP, AB_HOUND, AB_GUARDIAN, AB_SWARMCALL, AB_BONDMASTER, AB_FAMILIAR,
  // VOID
  AB_BANISH, AB_SINGULARITY, AB_WARPGRAVITY, AB_VOIDTOUCH, AB_DIMDOOR, AB_RIFT,
  // --- innate (racial / mutation) abilities: never offered at level-up
  AB_DAMNATION, AB_BREATH_FIRE, AB_BREATH_FROST, AB_BREATH_VENOM, AB_BREATH_ACID, AB_BREATH_STORM,
  AB_BREATH_MAGIC, AB_BREATH_STEAM, AB_BREATH_SHADOW,
  // DIVINE (patron gifts)
  AB_P_BERSERK, AB_P_IRONHIDE, AB_P_TROPHY, AB_P_WRATH, AB_P_UNBREAKABLE,
  AB_P_TOLL, AB_P_GILDED, AB_P_GOLDTOUCH, AB_P_BUYOUT, AB_P_GOLDSTORM,
  AB_P_LUCKY, AB_P_GIFTS, AB_P_DICE, AB_P_FAVOR, AB_P_CHAOSSTORM,
  AB_P_SPROUT, AB_P_GREEN, AB_P_BRAMBLE, AB_P_WORLDTREE, AB_P_EVERGREEN,
  AB_P_STALL, AB_P_PATIENCE, AB_P_BORROWED, AB_P_REWIND, AB_P_TIMESTOP,
  AB_P_SKELETON, AB_P_HARVEST, AB_P_SOULREND, AB_P_DEATHSDOOR, AB_P_ARMY,
  AB_P_FIRESTORM, AB_P_KINDLING, AB_P_IMMOLATE, AB_P_APOCALYPSE, AB_P_RAINFIRE,
  AB_P_MIRRORBALL, AB_P_REFLECTION, AB_P_SHATTERGLASS, AB_P_KALEIDO, AB_P_MIRRORHALL,
  AB_P_DRAW, AB_P_STACKED, AB_P_TRIPLEDRAW, AB_P_FATEDRAW, AB_P_WHEEL,
  AB_P_RUUNPOWER, AB_P_RECKONING, AB_P_POWERLEAP, AB_P_UNBURDENED, AB_P_RUUNEND,
  AB_P_JELLYPEGS, AB_P_OOZE, AB_P_MUTATE, AB_P_ACIDRAIN, AB_P_SLIMETIDE,
  AB_P_STORMAURA, AB_P_UPHEAVAL, AB_P_EYESTORM, AB_P_ELEMENTAL, AB_P_DISASTER,
  AB_P_DIVSHIELD, AB_P_HALO, AB_P_CLEANSE, AB_P_BLESSEDBALL, AB_P_ANGEL,
  AB_P_ANCESTOR, AB_P_ANCBLESS, AB_P_IDEALIZE, AB_P_ANCBOND, AB_P_ANCWRATH,
  AB_P_BENDSPACE, AB_P_BANISH, AB_P_CORRUPT, AB_P_ENTERVOID, AB_P_HUNGER,
  AB_P_HEROISM, AB_P_FINESSE, AB_P_DUEL, AB_P_SPOILS, AB_P_UNSTOPPABLE,
  AB_P_CHANNEL, AB_P_DIVKNOW, AB_P_SCHOLAR, AB_P_SPELLECHO, AB_P_FLOOD,
  AB_COUNT
};
constexpr int AB_FIRST_DIVINE = AB_P_BERSERK;
constexpr int AB_FIRST_INNATE = AB_DAMNATION;

enum RelicId : uint16_t {
  RL_IRONRING, RL_PROTECTION, RL_VIGOR, RL_MANACRYSTAL, RL_LUCKYCOIN, RL_LENS, RL_WHETSTONE, RL_SPIKED,
  RL_FEATHER, RL_ANVIL, RL_HOURGLASS, RL_TOME, RL_PURSE, RL_SALVE, RL_BLOODSTONE, RL_VENOMGLAND, RL_EMBERCORE,
  RL_STORMROD, RL_FROSTBAND, RL_GLASSCANNON, RL_BAG, RL_SEAL, RL_RUBBER, RL_KEENEYE, RL_RECALLRUNE,
  RL_MIDASCOIN, RL_BONECHARM, RL_DEMONHORN, RL_HOLSTER, RL_SOULGEM, RL_THORNCOLLAR, RL_DICE, RL_COMPASS,
  RL_SCHOLAR, RL_AEGIS, RL_PRISM, RL_LODESTONE, RL_CLOCKHEART, RL_PHILOSOPHER, RL_IDOL, RL_KEYSTONE,
  RL_SHARPENER, RL_TROLLBLOOD, RL_POCKETWATCH, RL_KNUCKLES, RL_LANTERN,
  // --- expansion
  RL_TULIPSEED, RL_SLOTTOKEN, RL_SLINGCAP, RL_TROPHY, RL_ROSE, RL_STORMJAR, RL_LAVALAMP, RL_DIVINGBELL,
  RL_CHAIN, RL_ECHOSHELL, RL_FANG, RL_HYDRASCALE, RL_BRIMSTONE, RL_FROZENTEAR, RL_THUNDEREGG, RL_RATSKULL,
  RL_SALAMANDER, RL_ORACLE, RL_RABBITFOOT, RL_PHILCOIN, RL_MAGERING, RL_CHALICE, RL_HORN, RL_CHAOSDICE,
  RL_VOIDPEARL, RL_CLOCKKEY, RL_MOUNTAIN, RL_MONOCLE, RL_BEARING, RL_THORNCROWN, RL_JESTERBELL, RL_ANCHOR,
  RL_KITE, RL_SLIPPER, RL_MAIDEN, RL_PACKTOTEM, RL_MERCHANT, RL_AGES, RL_CANDLE, RL_WARDING, RL_DEPTHMAP,
  RL_MEDAL, RL_FEATHERCAP, RL_GRIMOIRE,
  // --- v3 uniques: curated legendaries built around a school or mechanic
  RL_U_STORMCROWN, RL_U_INFERNO, RL_U_GLACIER, RL_U_GAIA, RL_U_ARCANUM, RL_U_WORLDSEED, RL_U_MIDAS, RL_U_NIGHTVEIL,
  RL_U_GEARHEART, RL_U_CHALICE, RL_U_JESTER, RL_U_SUMMONBELL, RL_U_VOIDHEART, RL_U_ENGINE, RL_U_CROOKEDDIE,
  RL_U_STARFALL, RL_U_MOONSTONE, RL_U_ASSASSIN, RL_U_TITANGRIP, RL_U_SAGELENS, RL_U_IRONBARK, RL_U_FOURLEAF,
  RL_U_CENSER, RL_U_CHISEL, RL_U_GOBLINSACK, RL_U_WELLSPRING,
  // --- v3 sets (3 pieces each)
  RL_S_JESTERCAP, RL_S_JESTERSHOES, RL_S_JESTERSCEPTER,
  RL_S_DICECUP, RL_S_VISOR, RL_S_CHIPS,
  RL_S_WARHELM, RL_S_WARPLATE, RL_S_WARBANNER,
  RL_S_ROBE, RL_S_STAFF, RL_S_CIRCLET,
  RL_COUNT
};
constexpr int RL_FIRST_UNIQUE = RL_U_STORMCROWN;
constexpr int RL_FIRST_SET = RL_S_JESTERCAP;
constexpr int SET_COUNT_RELIC = 4;
extern const char* RELIC_SET_NAME[SET_COUNT_RELIC];

enum ItemId : uint8_t {
  IT_HEALING, IT_MANA, IT_MIGHT, IT_HASTE, IT_RESIST, IT_EXPERIENCE, IT_BERSERK, IT_AMBROSIA,
  IT_TELEPORT, IT_FEAR, IT_IMMOLATION, IT_ENCHANT, IT_ACQUIRE, IT_REMOVECURSE, IT_VULN, IT_SILENCE, IT_BRAND,
  IT_SUMMON, IT_REVEAL,
  // --- expansion: potions
  IT_CANCEL, IT_LUCK, IT_FLIGHT, IT_BRILLIANCE, IT_MUTATION,
  // scrolls
  IT_UPHEAVAL, IT_TORMENT, IT_BUTTERFLIES, IT_POISONSCROLL, IT_WONDER,
  // wands (charges)
  IT_W_FLAME, IT_W_ICE, IT_W_LIGHTNING, IT_W_DIGGING, IT_W_POLYMORPH, IT_W_CHARMING, IT_W_ACID, IT_W_BUMPERS,
  IT_W_PARALYSIS, IT_W_ROOTS,
  IT_COUNT
};

enum MonId : uint16_t {
  // halls
  M_RAT, M_BAT, M_JACKAL, M_GOBLIN, M_KOBOLD, M_OOZE, M_OOZELET, M_ORC, M_SHAMAN, M_CULTIST, M_HOBGOBLIN,
  M_SPIDER, M_SAPPER, M_OGRE, M_WARCHIEF, M_GORLAG, M_WITCH,
  // lair
  M_TOADSTOOL, M_WOLF, M_BEAR, M_ADDER, M_HYDRA, M_MYCONID, M_VINE, M_SPRIGGAN, M_TREANT, M_MYCELIUM,
  // drowned
  M_EEL, M_MERFOLK, M_SIREN, M_CRAB, M_JELLY, M_TURTLE, M_WATERELEM, M_LEVIATHAN,
  // mines
  M_DWARF, M_AUTOMATON, M_COGGOLEM, M_TURRETM, M_GNOME, M_BOMBER, M_COLOSSUS, M_FOREMAN,
  // crypt
  M_ZOMBIE, M_SKELETON, M_WRAITH, M_GHOUL, M_BANSHEE, M_NECROMANCER, M_VAMPIRE, M_HOLLOWKING,
  // forge
  M_IMP, M_SALAMANDER, M_HELLHOUND, M_MAGMAGOLEM, M_EFREET, M_SMITH, M_FIREGIANT, M_PYRRHUS,
  // frozen
  M_ICEBEAST, M_YETI, M_FROSTWRAITH, M_RIMEMAGE, M_GLACIER, M_WINTERWOLF, M_FROSTGIANT, M_RIMEQUEEN,
  // core
  M_DEVIL, M_TITAN, M_DRAGON, M_DEALER, M_PITBOSS, M_ORBGUARD, M_LICH, M_HOUSE,
  // --- expansion
  M_GNOLL, M_TRICKSTER, M_ACOLYTE, M_EGGSAC, M_SPIDERLING,
  M_KILLERBEE, M_DRYAD, M_SPORELING,
  M_SEASERPENT, M_NAGA, M_ANGLER,
  M_CANNON, M_DRONE, M_SENTRY,
  M_MUMMY, M_SHADOW, M_BONEDRAGON,
  M_FIREELEM, M_HELLKNIGHT, M_EMBERSWARM,
  M_POLARBEAR, M_SNOWSPRITE, M_ICEDRAGON,
  M_CROUPIER, M_JACKPOTGOLEM, M_CHAOSSPAWN,
  // slime pits
  M_ACIDJELLY, M_SLIMECREATURE, M_ACIDBLOB, M_DEATHOOZE, M_AZUREJELLY, M_SLIMEBAT, M_GREATSLIME, M_ROYALJELLY,
  // abyss
  M_ABOMINATION, M_WRETCHEDSTAR, M_STARCURSED, M_ABYSSEYE, M_HORROR, M_VOIDSPAWN, M_TENTACLED, M_MAW,
  M_DECOY,
  // v3
  M_TREASURE, M_MIMIC,
  M_COUNT
};

enum SpeciesId : uint8_t {
  SP_IRON, SP_GLASS, SP_LEAD, SP_WISP, SP_GILDED, SP_BONE, SP_EMBER, SP_MOSS,
  SP_RUBBER, SP_CRYSTAL, SP_MAGNET, SP_SLIME, SP_FIEND, SP_DRAKE, SP_DJINN, SP_FELID, SP_CHANGELING, SP_CHAOS,
  SP_COUNT
};
enum BgId : uint8_t {
  BG_FIGHTER, BG_WIZARD, BG_TINKERER, BG_PYRO, BG_ICEWEAVER, BG_STORMCALLER, BG_GAMBLER, BG_NECRO, BG_MONK,
  BG_PINBALLER, BG_DRUID, BG_ALCHEMIST, BG_WANDERER,
  BG_CHAOSKNIGHT, BG_VOIDKNIGHT, BG_BERSERKER, BG_ARTIFICER, BG_SUMMONER, BG_HEXSLINGER, BG_EARTHSHAPER,
  BG_HUNTER, BG_BLOODMAGE, BG_SHAPESHIFTER, BG_CARDSHARP, BG_PILGRIM,
  BG_COUNT
};
enum PatronId : uint8_t {
  PT_VRASK, PT_AURUM, PT_TUMBLER, PT_VERDANA, PT_TOCK, PT_MORGRAVE, PT_ASHKA, PT_MIRRA,
  PT_ARCANA, PT_RUUN, PT_GLUB, PT_TEMPESTRA, PT_AURELIA, PT_ANCESTOR, PT_VOIDMAW, PT_BRAKKA, PT_SIFRA,
  PT_COUNT
};
enum ModId : uint8_t {
  MOD_SHIFTING, MOD_GEARWORKS, MOD_RISINGWATER, MOD_CRUMBLING, MOD_OVERGROWN, MOD_WINDY, MOD_DARKNESS,
  MOD_MAGSTORM, MOD_GRAVITY, MOD_TREASURE, MOD_HAUNTED, MOD_BLESSED, MOD_BOUNCY, MOD_MOLTEN, MOD_ROTPOCKETS,
  MOD_FORTIFIED, MOD_SWARMING,
  MOD_TULIPS, MOD_CASINO, MOD_CONVEYORS, MOD_ANTIGRAV, MOD_STORMFRONT, MOD_TREMORS, MOD_PLAYGROUND,
  MOD_BLOODMOON, MOD_GOLDRUSH, MOD_MIRRORS, MOD_SPRINGS, MOD_WARPED, MOD_GEYSERS, MOD_MINEFIELD, MOD_BOUNTY,
  MOD_COUNT
};

// mutations (demonic facets and other mutations)
enum MutId : uint8_t {
  // tier 0: body
  MUT_HORNS, MUT_SPIKES, MUT_CLAWS, MUT_STINGER, MUT_WINGS, MUT_DEMONTOUCH,
  // tier 1: hide
  MUT_IRONSCALES, MUT_MOLTENSCALES, MUT_ICYSCALES, MUT_SANGUINE, MUT_STURDY, MUT_SLIMY,
  // tier 2: powers
  MUT_DEATHPOWER, MUT_PAINPOWER, MUT_MANALINK, MUT_GUARDIAN, MUT_STENCH, MUT_HELLFIRE, MUT_DAMNATION, MUT_BLACKMARK,
  // tier 3: capstones
  MUT_DEMONWILL, MUT_ROBUST, MUT_WORDCHAOS, MUT_AUGMENT, MUT_CORRUPT,
  // negative
  MUT_FRAIL, MUT_CLUMSY, MUT_LEAKY, MUT_HEAVYBONES, MUT_DEFORMED, MUT_CURSEDBLOOD,
  MUT_COUNT
};
constexpr int DRACO_COUNT = 8;
enum SacrificeId : uint8_t {
  SAC_HEALTH, SAC_MAGIC, SAC_ITEMS, SAC_SIGHT, SAC_LUCK, SAC_GOLD, SAC_ARMOR, SAC_POWER, SAC_TIME, SAC_HEALING,
  SAC_COUNT
};

// ============================================================ entities
struct Peg {
  int id = 0;
  uint8_t kind = PK_PIN;
  uint8_t motion = 0;   // 0 none, 1 orbit, 2 osc-x, 3 osc-y
  bool dead = false;
  bool used = false;    // consumed this shot; reverts/removes at end of shot
  bool temp = false;    // created by an ability (visual hint)
  V2 p, anchor;
  float r = PIN_R;
  int hp = 1;
  int val = 0;          // generic value (bomb timer, chest tier, gold amount...)
  int link = -1;        // gate id / owner monster id
  int ttl = 0;          // turns left (0 = permanent)
  float mA = 0, mSpeed = 0, mPhase = 0;  // motion params
  float flash = 0;      // presentation
  float lastHitT = -10;
  int lastHitBall = -1;
  int row = 0;          // for shifting-row modifier
  V2 vel;               // velocity of moving pegs
  int aux = 0;          // extra per-kind state (target bank reward, tulip open, egg species...)
};

struct Seg {
  int id = 0;
  uint8_t kind = SK_WALL;
  bool dead = false;
  bool open = false;    // gate open
  V2 a, b;              // current endpoints
  V2 c;                 // rotation center / pivot
  float len = 0, ang = 0, angVel = 0, restAng = 0, upAng = 0;
  float th = 4;         // capsule half-thickness
  float rest = 0.7f;
  int link = -1;        // gate/key link, flipper side
  int hp = 0, ttl = 0;
  float flash = 0;
  float kick = 0;       // minimum outgoing speed (kickers)
  float phase = 0;      // pendulum phase
};

struct Zone {
  uint8_t kind = ZK_WATER;
  bool circle = false;
  bool dead = false;
  V2 p;                  // center
  V2 half;               // half extents (rect) ; half.x = radius (circle)
  V2 dir;                // force direction
  float str = 0;
  int link = -1;         // portal partner index
  int ttl = 0;
  float anim = 0;
  uint8_t lit = 0;       // rollover lane lit
  float phase = 0;       // geyser timing
  int dmg = 0;            // sinkhole damage / singularity & rift bonus
};

struct Pocket {
  uint8_t kind = PO_EMPTY;
  uint8_t orig = PO_EMPTY;
  float x0 = 0, x1 = 0;
  int val = 0;           // frozen-pocket timer
  float flash = 0;
};

struct Clearing {
  V2 p;
  float r = 30;
  int mon = -1;
};

struct Ball {
  int id = 0;
  V2 p, v;
  float r = BALL_R;
  int power = 1;
  float age = 0;
  bool alive = true;
  uint32_t flags = 0;
  int pegHits = 0, monHits = 0, wallHits = 0;
  int lastMon = -1;
  float lastMonT = -10;
  V2 stuckRef;
  float stuckT = 0;
  int stuckCount = 0;
  float portalCd = 0;
  int gen = 0;          // split generation
  int catches = 0;
  float gravScale = 1;
  int staticCount = 0;
  int pierceMon = -1;
  float pierceT = -10;
  float lavaAcc = 0;
  // expansion
  uint64_t zoneMask = 0;   // zones the ball was inside last step (entry detection)
  float zoneAcc = 0;       // charge-field / spring accumulator
  float floatT = 0;        // feather peg float time
  int pegsSinceMon = 0;    // pegs hit since the last monster hit (anti bounce-loop)
  int staleHits = 0;       // consecutive monster hits without pegs in between
  uint32_t runeMask = 0;   // rune zones already used
  int flashHits = 0;       // flashpoint: remaining igniting hits
  float stormT = 0;        // storm ball zapping time left
  float sensorCd = 0;      // tulip / chucker cooldown
  float zapT = 0;          // storm ball zap timer
  int8_t runeA = -1, runeB = -1;  // runes collected this shot (runewords)
  uint8_t runeCount = 0;
  uint8_t specialsHit = 0;        // special pegs this ball triggered (combo pegs)
};

// anti-stall bookkeeping for one ball (runtime only, never saved; Floor::watch is indexed like Floor::balls)
struct BallWatch {
  int id = -1, pegs = 0, mons = 0, portals = 0;
  int lastPeg = -1, prevPeg = -1;         // the last two pegs it hit (bouncing between the same ones isn't progress)
  float deepY = 0, prevY = 0, idleT = 0;  // deepest point reached, and time since it last got deeper or hit anything
};

struct Monster {
  int id = 0;
  uint16_t def = 0;
  V2 p;
  float r = 20;
  int hp = 1, maxHp = 1, shield = 0, armor = 0, atkBonus = 0;
  uint8_t intent = IN_NONE;
  int ival = 0, iarg = 0;
  int cd = 1;
  int spos = 0;         // script position
  int phase = 0;
  int burn = 0, poison = 0, hexT = 0, hexPct = 0, frozen = 0, freezeImmune = 0, silenced = 0, chilled = 0;
  int markT = 0, markGold = 0;
  bool undyingUsed = false, reflectUp = false;
  bool dead = false, summoned = false, elite = false, boss = false, fresh = false;
  int clearing = -1;
  uint32_t shotFlags = 0;
  int turnDamage = 0;
  // presentation
  float flash = 0, hpDisp = 0, act = 0;
  V2 moveFrom;
  float moveT = 1;
  float lastHitT = -10;
  int lastHitBall = -1;
  // expansion
  int bleed = 0, bleedT = 0;
  int beamHp = 0;        // damage still needed to interrupt a charging beam
  bool enraged = false;  // next attack deals double damage
  int look = -1;         // render as this def (decoys)
  bool bounty = false;
  bool blinked = false;
  bool split = false;    // already split (TR_SPLITHIT)
  int corruptT = 0, corruptAmt = 0;  // corrupted: takes extra damage, can't heal
  bool charmed = false;  // fights for you while charmT > 0
  int charmT = 0;
  // v3: Diablo-style champions and uniques
  uint8_t champ = 0;     // 0 normal, 1 champion, 2 unique
  uint32_t affix = 0;    // champion affix bits (1 << affix id)
  char uname[28] = {};   // unique monster name
  int escapeT = 0;       // treasure imp: turns until it escapes
  bool firstHitTaken = false;
};

// ============================================================ definitions
struct World;
struct HitCtx {
  int ball = -1, mon = -1;
  float base = 0;        // incoming damage before multipliers
  float mult = 1;
  int flat = 0;
  bool crit = false;
  bool pierce = false;   // ball passes through
  float keepPower = 0;   // fraction of power kept after the hit
  bool first = false;    // first monster hit of this shot
};

// Hook table shared by abilities, relics, patron gifts, mutations and species. Any may be null.
struct Hooks {
  void (*stats)(World&, int lvl) = nullptr;                    // modify w.st
  void (*floorStart)(World&, int lvl) = nullptr;
  void (*floorEnd)(World&, int lvl) = nullptr;
  void (*turnStart)(World&, int lvl) = nullptr;               // player's turn begins (after enemies)
  void (*shotStart)(World&, int lvl) = nullptr;
  void (*shotEnd)(World&, int lvl) = nullptr;
  void (*pegHit)(World&, int ball, int peg, int lvl) = nullptr;
  void (*monHit)(World&, HitCtx&, int lvl) = nullptr;          // before damage is applied
  void (*monDamaged)(World&, int ball, int mon, int dmg, int lvl) = nullptr;  // after ball damage
  void (*kill)(World&, int mon, int lvl) = nullptr;
  void (*wallHit)(World&, int ball, int lvl) = nullptr;
  void (*ballEnd)(World&, int ball, int pocket, int lvl) = nullptr;  // pocket -1 = drained
  void (*tick)(World&, float dt, int lvl) = nullptr;           // each physics tick during flight
  void (*attacked)(World&, int mon, int& dmg, int lvl) = nullptr;  // enemy attack about to land
  void (*enemyPhaseEnd)(World&, int lvl) = nullptr;
  void (*hurt)(World&, int dmg, int lvl) = nullptr;           // after you lose HP
};

struct AbilityDef {
  uint16_t id;
  const char* name;
  uint8_t school, timing, target, rarity, maxLvl;
  int8_t cost[5];        // MP cost per level (or piety cost for divine)
  uint8_t cooldown;      // turns
  int8_t goldCost;       // gold cost base (0 = none)
  const char* desc;      // [a|b|c] values per level
  bool (*cast)(World&, int lvl, V2 pt, V2 pt2, int mon);
  Hooks h;
  int8_t hpCost[3];      // HP cost per level (blood magic)
  bool innate;           // racial / mutation ability: never offered
};

struct RelicDef {
  uint16_t id;
  const char* name;
  uint8_t rarity;
  const char* desc;
  const char* glyph;
  uint32_t color;
  Hooks h;
  uint8_t tier;          // 0 regular, 1 unique (curated legendary), 2 set piece
  int8_t set;            // set index for set pieces (-1 none)
  const char* synergy;   // uniques: what it works well with (shown in tooltips)
};

struct ItemDef {
  uint8_t id;
  const char* name;
  bool potion;
  uint8_t timing;        // T_AIM / T_ANY
  uint8_t target;
  uint8_t rarity;
  int price;
  const char* desc;
  uint32_t color;
  bool (*use)(World&, V2 pt, int mon);
  bool wand;
  int charges;           // wands: starting charges
};

struct Intent {
  uint8_t kind = IN_NONE;
  int16_t val = 0;
  uint8_t delay = 1;     // turns of countdown; bit 0x80 = chains straight into the next intent (same turn)
  int16_t arg = 0;
};
constexpr uint8_t INTENT_CHAIN = 0x80;

struct MonDef {
  uint16_t id;
  const char* name;
  const char* glyph;
  uint32_t color;
  int hp, armor;
  float r;
  int xp, gold;
  uint32_t traits;
  int tval;              // trait value (phasing threshold, regen, thorns, hardened cap ...)
  int splitInto;         // monster id for TR_SPLIT
  Intent s1[5];
  Intent s2[5];
  Intent s3[5];
  const char* desc;
};

struct SpeciesDef {
  uint8_t id;
  const char* name;
  const char* desc;
  uint32_t color;
  int hp, mp, power, armor;
  int hpPerLvl;
  uint8_t aff[3];        // favored schools (SCH_COUNT = none)
  bool exotic;           // outlandish species (shown with a special border)
  int8_t stat[STAT_COUNT];    // starting STR/DEX/INT/VIT/LCK
  float growth[STAT_COUNT];   // level-up growth weights
};

struct BackgroundDef {
  uint8_t id;
  const char* name;
  const char* desc;
  uint16_t ability;      // starting ability (AB_COUNT = none / random, see run.cpp)
  int hp, mp, gold;
  int items[2];          // starting consumables (-1 none, -2 random)
  int patron;            // starting patron (-1 none, -2 random)
  bool exotic;
  int8_t stat[STAT_COUNT];    // stat modifiers
};

struct PatronDef {
  uint8_t id;
  const char* name;
  const char* title;
  uint32_t color;
  const char* likes;
  const char* dislikes;
  const char* desc;
  uint16_t gifts[5];
};

struct BiomeDef {
  uint8_t id;
  const char* name;
  const char* shortName;
  uint32_t bgTop, bgBot, pin, accent, wall;
  int mood;
  uint16_t roster[16];
  uint16_t elites[3];
  uint16_t bosses[2];
  float bumpers, spinners, water, wind, wells, lava, ramps, movers;
  const char* flavor;
};

struct ModDef {
  uint8_t id;
  const char* name;
  const char* desc;
  uint32_t color;
};

struct MutDef {
  uint8_t id;
  const char* name;
  uint8_t tier;          // 0 body, 1 hide, 2 power, 3 capstone, 9 negative
  uint8_t maxLvl;
  const char* desc;      // [a|b|c]
  Hooks h;
};

// ============================================================ run structures
struct OwnedAb {
  uint16_t id = 0;
  uint8_t lvl = 1;
  uint8_t cd = 0;
};

struct InvItem {
  int16_t id = -1;
  int16_t charges = 0;
};

// A randomly generated relic ("randart"). Fully described by its fields (and regenerable from seed).
struct Randart {
  uint32_t seed = 0;
  uint8_t base = 0;
  uint8_t n = 0;
  uint8_t prop[6] = {};
  int8_t val[6] = {};
  uint8_t aux[6] = {};
  uint32_t color = 0xffffff;
  char name[64] = {};
};

struct Player {
  uint8_t species = 0, bg = 0;
  int hp = 40, mp = 5, gold = 0, xp = 0, xl = 1;
  int baseHp = 40, baseMp = 5, basePower = 1, baseArmor = 0;
  int bonusMaxHp = 0;    // permanent bonuses (bone charm, events)
  int bonusPower = 0, bonusMp = 0, bonusArmor = 0;
  std::vector<OwnedAb> abil;
  std::vector<uint16_t> relics;
  std::vector<InvItem> items;  // consumables (size = slots), id -1 empty
  std::vector<Randart> randarts;
  int patron = -1, piety = 0, pietyMax = 0;
  // statuses
  int poison = 0, weak = 0, block = 0;
  int nextShotPower = 0;  // from Power pocket / capacitor
  int deathsDoor = 0;
  bool phoenixUsed = false;
  int rhythm = 0;
  int charmHp = 0;
  // expansion
  uint8_t mut[MUT_COUNT] = {};   // mutation levels
  uint8_t dsSchedMut[16] = {};   // Fiendball: which facet grows at the matching XL
  uint8_t dsSchedXL[16] = {};
  uint8_t dsSchedN = 0;
  bool dsMonstrous = false;
  int lives = 0;          // Nine-Lives Ball extra lives
  int draconic = -1;      // Drakeball color (-1 until XL 5)
  int form = -1;          // Changeling's current form (species id)
  uint32_t sacrifices = 0;
  int guardBlocks = 0;    // attacks fully blocked by a guardian spirit
  int corrode = 0, slowed = 0, sapped = 0;
  bool cursedBall = false;
  bool nextShotDouble = false;
  int pachinkoPegs = 0;   // Pachinko Medal progress
  int medalPower = 0;
  int tumbleCount = 0;
  // v3
  uint8_t stat[STAT_COUNT] = {5, 5, 5, 5, 5};  // base stats (species + background + growth + chosen)
  int statPoints = 0;      // pending "raise a stat" choices
  int shards = 0;          // relic shards (3 = a relic)
  std::vector<Randart> relicAffix;  // magic affixes, parallel to relics (n == 0: plain relic)
  int statGrowthLog = 0;
};

struct Stats {
  int maxHp = 40, maxMp = 5, armor = 0, basePower = 1, mpRegen = 1, hpRegen = 0;
  float gravMul = 1, restBonus = 0, ballR = BALL_R, launch = BASE_LAUNCH, dmgMul = 1, goldMul = 1, xpMul = 1;
  float potionMul = 1, critMul = 2, shopMul = 1, recallWidth = 1, eliteDmgMul = 1, healMul = 1;
  int preview = 0, offers = 3, slots = 4, extraBalls = 0, flatHit = 0;
  int specials[PK_COUNT] = {};
  int thornsDmg = 0, killHeal = 0, killMp = 0, killGold = 0;
  bool ignoreDark = false, keenEye = false, adjustLaunch = false;
  int monsterAtkBonus = 0;
  float reflectPct = 0;
  // expansion
  int allyTurns = 0;
  float allyDmgMul = 1, explosionMul = 1, voidMul = 1.5f, slotMul = 1;
  int zapBonus = 0, chillDmg = 0, burnBonus = 0, tulipBonus = 0, kickerBonus = 0, portalBonus = 0;
  int costReduce = 0, hpCostReduce = 0;
  bool poisonSlow = false, lavaImmune = false, waterImmune = false, windImmune = false, lucky = false;
  bool fullDischarge = false, finesse = false, halveLowHp = false, poisonRes = false, noPotions = false;
  bool hideGuide = false, noRecall = false, hpForMp = false;
  int echoEvery = 0, homing = 0, keenDepth = 1;
  float specialScale = 1, tumblerWatch = 0, lowHpDmg = 0, fullHpDmg = 0, packDmg = 0, cooldownRate = 1;
  float sacHeal = 1;
  bool tumblerKind = false, chaosTwice = false, wallPower = false;
  bool kite = false, warded = false;
  float strikeWidth = 1, spellDmgMul = 1;
  int sparkExtra = 0;
  // v3: core stats and their effects
  int stat[STAT_COUNT] = {};        // effective stats
  int statBonus[STAT_COUNT] = {};   // from items, mutations, shrines, gems
  float critChance = 0, critDmg = 1.5f, dodge = 0, magicFind = 0, luckyPct = 0;
  float burnMul = 1, chillVuln = 0, executeBelow = 0, firstStrike = 0, overkill = 0, bossDmgTaken = 1, dmgTaken = 1;
  int mpShield = 0;                 // mana shield: each MP absorbs this much damage
  int wellBonus = 0, shrineBonus = 0, starBonus = 0, gemBonus = 0, runeBonus = 0;
  bool runeDouble = false, lootUp = false, diceLoaded = false, pierceFirst = false, secondChance = false;
  float impChance = 0, runewordMul = 1;
  int critBleed = 0, spellCost = 0, allyCap = 0, startBlock = 0, killPower = 0, holyPct = 0, discharge = 0;
  uint32_t cheapSchool = 0;         // bit per school: those abilities cost 1 less MP
  float lootMul = 1;
};

struct ShotState {
  int pegHits = 0, specialHits = 0, monHits = 0, kills = 0, damage = 0, wallHits = 0, balls = 0;
  bool fireball = false, chain = false, doubleDown = false, jackpot = false, brand = false, might = false;
  bool berserk = false, kaleido = false, goldTouch = false, boulder = false, anyMonHit = false;
  int chainLvl = 0, fireballLvl = 0, jackpotMul = 1;
  int rebounds = 0, echoLeft = 0, flipsLeft = 0, catchesLeft = 0;
  bool recallRuneUsed = false, prismUsed = false, frostBandUsed = false, freeTurn = false;
  int stormRodCount = 0, sharpCount = 0;
  float levitateT = 0, slowT = 0;
  int spellweaveBonus = 0;
  int mightBonus = 0;
  int ddPenalty = 0;
  bool brandUsed = false;
  // expansion
  bool firstHitDone = false, bankShotUsed = false, golden = false, heroism = false, unstoppable = false;
  bool dimDoorUsed = false, chaosShot = false, beast = false, spellEchoUsed = false;
  int scatter = 0, diceMul10 = 10, powerLeap = 0, idealize = 0, beastLvl = 0, wildCount = 0, ionCount = 0;
  float teleT = 0, gravWarpT = 0, ballScale = 1, sideGravT = 0;
  V2 gravWarpDir, sideGravDir;
  int tumblerActs = 0, springHeal = 0;
  float tumbleClock = 0;
  bool doubled = false, blessed = false, elemental = false, mirrorSplit = false, hydraUsed = false, slimeTideUsed = false;
  float phaseT = 0, stormBallT = 0, shotGrav = 1;
  int flashHits = 0, bleedOnHit = 0, wildSurges = 0;
  // v3
  int starsHit = 0, runewords = 0, prismUsed2 = 0, lastSpecial = -1, cannonShots = 0, crits = 0;
  bool secondChanceUsed = false, pierceUsed = false, constellation = false;
};

struct FloorSpec {
  uint8_t kind = FK_NORMAL;
  uint8_t biome = BI_HALLS;
  int depth = 1;
  uint64_t seed = 1;
  uint8_t mods[3] = {0, 0, 0};
  int nMods = 0;
  uint16_t mons[10] = {};
  int nMons = 0;
  uint8_t format = 0;     // board format (formats.cpp)
  uint8_t champs = 0;     // champion / unique monsters rolled for this floor (bits)
};

struct Floor {
  FloorSpec spec;
  std::vector<Peg> pegs;
  std::vector<Seg> segs;
  std::vector<Zone> zones;
  std::vector<Monster> mons;
  std::vector<Ball> balls;
  std::vector<Ball> newBalls;
  std::vector<BallWatch> watch;   // anti-stall bookkeeping (physics.cpp), not saved
  std::vector<Pocket> pockets;
  std::vector<Clearing> clearings;
  std::vector<Clearing> keepOut;  // board generation: areas pins must avoid
  int nextId = 1;
  int turn = 1;
  float time = 0;
  float shotTime = 0;
  uint8_t phase = PH_AIM;
  ShotState shot;
  // enemy phase
  int enemyIdx = 0;
  float enemyTimer = 0;
  int enemyStage = 0;
  // turn state
  bool pendingFree = false;   // next shot is a free turn (haste/borrowed time)
  bool vulnTurn = false;
  int turnPegHits = 0;
  bool tookDamageThisTurn = false;
  int silenceT = 0;
  // modifiers
  float waterLevel = 0;   // y of water surface (0 = none)
  float lavaLevel = 0;
  float windX = 0;
  float gravNow = 1;
  bool dark = false;
  // devices
  bool hasCatcher = false;
  float catcherX = 800, catcherDir = 1;
  bool hasFlippers = false;
  bool flipKey[2] = {false, false};
  int vaultShots = 0;
  bool isVault = false;
  int hpAtStart = 0;
  int firstAttackBlocked = 0;
  int holsterFree = 0;
  int kills = 0;
  int shotsFired = 0;
  int raisedAllyT = 0, raisedAllyDmg = 0;
  bool favorUsed = false;
  bool cleared = false;
  int revealBonus = 0;
  int relaunchPower = 0;
  int vampAcc = 0;
  uint8_t lastTrig = PK_PIN;
  V2 lastKillPos = V2(800, 400);
  int lastKillDef = -1;
  int turretAcc = 0;
  int focus = -1;         // monster index that receives discharged power
  float launchSpeed = BASE_LAUNCH;
  uint8_t baseSpecials[PK_COUNT] = {};
  bool bouncy = false;
  int dividerSeg[MAX_POCKETS] = {};
  int flipSeg[2] = {-1, -1};
  float flipHeldT[2] = {0, 0};
  float clearT = 0;
  int swarmSpawned = 0;
  int pietyAcc = 0;
  // expansion
  int slotSpins = 0;        // queued slot machine spins
  float slotT = 0;          // current spin time left
  uint8_t slotReel[3] = {0, 1, 2};
  int slotShow = 0;         // result display countdown (frames of game time * 60)
  int slotLast = -1;        // last payout kind
  V2 cursor = V2(800, 450); // UI mouse position (telekinesis, warp gravity)
  int blindTurns = 0;
  int timeStop = 0;
  int streak = 0, streakPower = 0;
  int cardPower = 0;        // Strength card: bonus base power this floor
  int bountyGold = 0;
  bool tumblerFloor = false;
  float moodShown = 0;
  int bankSerial = 0;
  bool ghostSolid = true;
  uint32_t onceFlags = 0;
  int sanctuaryT = 0;        // monster attacks deal half damage
  int blockKeep = 0;         // Block survives this many turn starts
  bool freeCasts = false;    // spells cost no MP until the next turn
  int cardsDrawn = 0, lastCard = -1;
  bool inLifelink = false;
  // v3
  int tempStat[STAT_COUNT] = {};   // floor-long stat changes (gems, shrines, the Tumbler)
  int shrine = -1;                 // active shrine blessing
  int trainingUsed = 0;
  int bossTurns = 0;               // boss floors: turns elapsed (enrage timer)
  bool bossEnraged = false;
  int lootDropped = 0;
  std::vector<int> gridHead, gridNext;
  Rng rng;
};

struct StairOpt {
  uint8_t kind = ST_FLOOR;
  uint8_t biome = BI_HALLS;
  FloorSpec spec;
  int branch = -1;        // for ST_BRANCH: biome of the branch
};

struct ShopEntry {
  uint8_t type = 0;       // 0 ability, 1 relic, 2 item, 3 heal service, 4 upgrade service, 6 randart
  int id = 0;
  int price = 0;
  bool sold = false;
  uint32_t seed = 0;      // relics: magic affix seed (0 = plain)
};

struct Offer {
  uint8_t type = 0;       // 0 ability (new or upgrade), 1 relic, 2 randart (id = seed), 3 sacrifice, 4 stat (id = stat)
  int id = 0;
  uint32_t seed = 0;      // relics: magic affix seed (0 = plain)
};

struct RunStats {
  int kills = 0, damage = 0, shots = 0, turns = 0, floors = 0, goldEarned = 0, biggestHit = 0, bestShot = 0;
  int pegHits = 0, potionsUsed = 0, scrollsUsed = 0, spellsCast = 0;
  int eliteKills = 0, cards = 0, tumbles = 0, jackpots = 0;
  std::string killer;
};

struct Fx {
  uint8_t kind = 0;
  V2 a, b;
  uint32_t col = 0xffffff;
  float v = 0, v2 = 0;
  int i = 0;
  char text[48] = {};
};
enum FxKind : uint8_t {
  FX_TEXT, FX_SOUND, FX_BURST, FX_ZAP, FX_RING, FX_SHAKE, FX_ATTACK, FX_COIN, FX_EXPLODE, FX_PEGHIT, FX_FLASH,
  FX_BANNER, FX_HEALFX, FX_TRAILRESET
};

struct LogLine {
  std::string text;
  uint32_t col = 0xd0d0d0;
  int turn = 0;
};

struct EffRef {
  const Hooks* h = nullptr;
  int lvl = 1;
};

struct World {
  // ---- run state
  uint64_t seed = 1;
  Player pl;
  Stats st;
  std::vector<EffRef> effs;       // derived: active hook tables
  int act = 0, step = 0, depth = 1;
  uint8_t branchA = BI_LAIR, branchB = BI_CRYPT;
  int runes = 0;
  int descent = 0;                // difficulty tier (0 = normal)
  bool won = false, dead = false;
  uint8_t screen = RS_FLOOR;
  Rng rng;                        // run-level decisions
  std::vector<StairOpt> stairs;
  std::vector<ShopEntry> shop;
  std::vector<Offer> offers;      // level-up offers
  int pendingLevels = 0;
  std::vector<Offer> relicOffers; // loot / acquirement / sacrifice choice
  int eventId = -1, eventStage = 0;
  std::string eventResult;
  std::vector<int> altarChoices;
  std::vector<int> rewardItems;   // consumables found this floor (summary)
  int rewardGold = 0;
  bool restUsed = false;
  RunStats rs;
  std::vector<LogLine> log;
  bool shopVisitedLast = false;
  int lastNonCombat = -1;
  int tumblerMood = 50;
  // ---- floor
  Floor fl;
  // ---- output
  std::vector<Fx> fx;
  bool quiet = false;             // bot simulation: no fx/log
  bool autosaveWanted = false;
};

// ============================================================ content tables
extern AbilityDef ABIL[AB_COUNT];
extern RelicDef RELIC[RL_COUNT];
extern ItemDef ITEM[IT_COUNT];
extern MonDef MON[M_COUNT];
extern SpeciesDef SPECIES[SP_COUNT];
extern BackgroundDef BGS[BG_COUNT];
extern PatronDef PATRON[PT_COUNT];
extern BiomeDef BIOME[BI_COUNT];
extern ModDef MODS[MOD_COUNT];
extern MutDef MUTS[MUT_COUNT];
void initContent();
constexpr int PIETY_STAR[5] = {20, 50, 90, 140, 180};
constexpr int PIETY_MAX = 200;
extern const char* SCHOOL_NAME[SCH_COUNT];
extern const uint32_t SCHOOL_COLOR[SCH_COUNT];
extern const char* PEG_NAME[PK_COUNT];
extern const char* PEG_DESC[PK_COUNT];
extern uint32_t PEG_COLOR[PK_COUNT];
extern const char* POCKET_NAME[PO_COUNT];
extern const char* POCKET_SHORTNAME[PO_COUNT];
extern const char* POCKET_DESC[PO_COUNT];
extern uint32_t POCKET_COLOR[PO_COUNT];
extern const char* INTENT_NAME[IN_COUNT];
extern const char* ZONE_NAME[ZK_COUNT];
extern const char* ZONE_DESC[ZK_COUNT];
extern const char* SACRIFICE_NAME[SAC_COUNT];
extern const char* SACRIFICE_DESC[SAC_COUNT];
extern const char* DRACO_NAME[DRACO_COUNT];
extern const char* DRACO_DESC[DRACO_COUNT];
extern const uint32_t DRACO_COLOR[DRACO_COUNT];
bool validateContent(std::string& err);
std::string abilityDesc(int ab, int lvl, bool showUpgrade);
std::string resolveLevels(const char* desc, int lvl, bool showUpgrade);
int abilityCost(const World& w, int ab, int lvl);
int abilityHpCost(const World& w, int ab, int lvl);
bool isInnate(int ab);

// ============================================================ events (content_data.cpp)
struct EventDef {
  const char* title;
  const char* text;
  const char* opt[3];
  int nOpt;
};
extern const EventDef EVENTS[];
extern const int NUM_EVENTS;
bool eventOptionAvailable(const World& w, int ev, int opt, std::string* why);
void eventResolve(World& w, int ev, int opt);

// ============================================================ logic API (floor.cpp / run.cpp / physics.cpp)
// messages & effects
void logMsg(World& w, uint32_t col, const char* f, ...);
void fxText(World& w, V2 p, uint32_t col, const std::string& s, float size = 16);
void fxSound(World& w, int sfx, float vol = 1, float pitch = 1, float x = 800);
void fxBurst(World& w, V2 p, uint32_t col, int n, float speed, float size = 3);
void fxZap(World& w, V2 a, V2 b, uint32_t col);
void fxRing(World& w, V2 p, float r, uint32_t col);
void fxShake(World& w, float amt);
void fxAttack(World& w, V2 from, uint32_t col, int dmg);
void fxBanner(World& w, const std::string& s, uint32_t col);

// player
int abLevel(const World& w, int ab);
bool hasRelic(const World& w, int rl);
void healPlayer(World& w, int amt, bool fromPeg = false);
void damagePlayer(World& w, int amt, int srcMon, bool ignoreArmor, const char* srcName = nullptr);
void selfDamage(World& w, int amt, const char* why);   // non-lethal self-inflicted HP loss
void gainMp(World& w, int amt);
void gainGold(World& w, int amt, V2 at);
void gainXp(World& w, int amt);
void gainPiety(World& w, int amt);
void recalcStats(World& w);
int effPower(const World& w);
int pietyStars(const World& w);

// monsters
int damageMonster(World& w, int mi, int dmg, int src, int ball = -1);
void killMonster(World& w, int mi, int src);
void applyBurn(World& w, int mi, int n);
void applyPoison(World& w, int mi, int n);
void applyChill(World& w, int mi, int n);
void applyBleed(World& w, int mi, int n);
void freezeMonster(World& w, int mi);
int nearestMonster(const World& w, V2 p, int exclude = -1);
int lowestHpMonster(const World& w);
int highestHpMonster(const World& w);
int aliveMonsterCount(const World& w);
int spawnMonster(World& w, int def, int clearing, bool summoned);
int focusTarget(World& w);          // current discharge target (auto-picks if unset)
int defaultFocus(const World& w);
int freeClearing(World& w, V2 near, bool randomPick);
void teleportMonster(World& w, int mi);
void polymorphMonster(World& w, int mi, int newDef);
int randomRosterMonster(World& w, int strength);   // strength: -1 weaker, 0 any, 1 stronger
const MonDef& monLook(const Monster& m);
int numPhases(const MonDef& d);

// pegs / board
int addPeg(World& w, int kind, V2 p, float r = 0);
int convertPins(World& w, int kind, int count, V2 near = V2(-1, -1), float radius = 0);
int countKind(const World& w, int kind);
bool spotFree(const World& w, V2 p, float r, float margin);
int addSeg(World& w, int kind, V2 a, V2 b, float th);
int addZone(World& w, int kind, V2 p, V2 half, bool circle);
int spawnBall(World& w, V2 p, V2 v, int power, uint32_t flags, int gen = 0);
void splitBall(World& w, int bi, float powerFrac, int copies = 1);
void explodeAt(World& w, V2 p, float radius, int dmg, int srcBall);
void pegTriggerEffect(World& w, int bi, int pi, bool echo);
void placeWormhole(World& w, V2 a, V2 b, int ttl);
void placeRift(World& w, V2 a, V2 b, int ttl);
void triggerFireball(World& w, int mi, V2 mpos, int baseDmg);
void triggerChain(World& w, int mi, V2 mpos, int baseDmg);
void growPins(World& w, int n, V2 near, float radius, bool temp);
void addBlock(World& w, int n);
void rotatePockets(World& w, int dir);
void cleanseCurses(World& w, bool pockets);
int abilityGoldCost(const World& w, int ab, int lvl);
void flipperPress(World& w, int side, bool down);
std::vector<int> monstersSorted(const World& w, bool byHpDesc);
bool isEnchant(int kind);
bool isAllyPeg(int kind);
bool isMonsterAlly(const World& w, int mi);
V2 randomFieldSpot(World& w, float r, float margin, float y0 = FIELD_Y0, float y1 = FIELD_Y1);
bool inRock(const World& w, V2 p, float r);        // inside a board format's solid rock
V2 freeSpotNear(const World& w, V2 p, float r);    // nearest open spot for a stuck ball, or (-1, -1)
void clearWedges(World& w);                        // no peg a ball could wedge against a ramp or side wall
int placeAlly(World& w, int kind, V2 near, int dmg, int ttl);
void discharge(World& w, V2 from, int dmg, uint32_t col);
void queueSlotSpin(World& w);
void resolveSlot(World& w);
extern const char* SLOT_NAME[7];
extern const uint32_t SLOT_COLOR[7];
extern const char* CARD_NAME[19];
extern const char* CARD_DESC[19];
int allyPegCount(const World& w);
void hatchEgg(World& w, int pi);
void applyCorrupt(World& w, int mi, int amt, int turns);

// tumbler / cards (tumbler.cpp)
void tumblerAct(World& w, bool invoked);
void tumblerInvoke(World& w, int kindness);   // 0 normal .. 3 very kind
void tumblerFlightAct(World& w);
bool tumblerWatching(const World& w);
void tumblerExcite(World& w, int amt);
void tumblerTurn(World& w);
void drawCard(World& w, bool stacked);
void regenLayout(World& w, bool corrupt);
void mirrorBoard(World& w);
std::string tumblerMoodText(const World& w);

// mutations / species (mutations.cpp)
void gainMutation(World& w, int mut, bool silent);
int randomMutation(World& w, bool allowBad, bool onlyGood);
void rollDemonspawn(World& w);
void speciesLevelUp(World& w);
void speciesFloorStart(World& w);
const Hooks* speciesHooks(int sp);
const Hooks* dracoHooks(int color);
std::string mutationSummary(const World& w, bool future);
void chooseSacrifice(World& w, int sac);
void offerSacrifices(World& w);
bool hasSacrifice(const World& w, int sac);
int sacrificeCount(const World& w);

// randarts (randart.cpp)
Randart makeRandart(uint32_t seed);          // depth lives in the low 5 bits of the seed
uint32_t newRandartSeed(World& w);
const char* randartPropName(int prop);
const char* randartGlyph(const Randart& r);
std::string randartDesc(const Randart& r);
void gainRandart(World& w, uint32_t seed);
extern Hooks RANDART_HOOKS;
bool randartHasProp(const World& w, int prop, int* total);

// floor flow
void floorBegin(World& w, const FloorSpec& spec);
bool canLaunch(const World& w);
void launch(World& w, float angle, float speed);
void relaunch(World& w, float angle);
void redirect(World& w, float angle);
void floorUpdate(World& w, float dt);   // advance simulation (flight / enemy phase)
void endShot(World& w);
void startPlayerTurn(World& w, bool afterEnemies);
V2 launcherPos();
float launchAngleFromMouse(V2 m);
void previewPath(const World& w, float angle, float speed, int bounces, std::vector<V2>& out, V2 origin);

// abilities & items
bool abilityUsable(const World& w, int slot, std::string* why);
bool castAbility(World& w, int slot, V2 pt, V2 pt2, int mon);
bool itemUsable(const World& w, int slot, std::string* why);
bool useItem(World& w, int slot, V2 pt, int mon);
void learnAbility(World& w, int ab);
void gainRelic(World& w, int rl, uint32_t affixSeed = 0);
bool gainItem(World& w, int it);
int itemCount(const World& w);
void generateOffers(World& w);
void chooseOffer(World& w, int idx);   // -1 = skip

// physics
void physicsStep(World& w, float dt);
void animateBoard(World& w, float dt);
void rebuildPegGrid(World& w);
bool flipperSolid(const Seg& s);
bool pegSolid(const World& w, const Peg& p);
bool geyserActive(const World& w, const Zone& z);
// callbacks from physics into game rules (floor.cpp)
void onPegHit(World& w, int bi, int pi, float impact);
bool onMonsterHit(World& w, int bi, int mi);
void onBallPocket(World& w, int bi);
void onWallBounce(World& w, int bi, float impact);
void onSegHit(World& w, int bi, int si, float impact);
void onSensor(World& w, int bi, int pi);
void onZoneEnter(World& w, int bi, int zi);
void endBall(World& w, int bi, int pocket);
void catchBall(World& w, int bi);
// board generation (boardgen.cpp / setpieces.cpp)
void generateBoard(World& w);
void layoutPockets(World& w);
void setupDevices(World& w);
bool hasMod(const World& w, int mod);
void refreshSpecials(World& w);
void applyTurnModifiers(World& w);
FloorSpec makeFloorSpec(World& w, int kind, int biome, int act, int step, int salt);
void addPinPattern(World& w, int pattern);
void placeSetPieces(World& w);
bool placeNamedSetPiece(World& w, int piece, V2 center);
int addTulip(World& w, V2 c, bool chucker);
std::string intentText(const World& w, const Monster& m, bool shortForm);
int intentDamage(const World& w, const Monster& m);
const Intent* monsterScript(const Monster& m, int* len);
bool chooseRelicOffer(World& w, int idx);
void shopTrain(World& w, int shopIdx, int abIdx);

// run flow (run.cpp)
void newRun(World& w, uint64_t seed, int species, int bg, int descent = 0);
constexpr int MAX_DESCENT = 10;
const char* descentText(int dl);
void enterStairs(World& w, int idx);
void genStairs(World& w);
void floorCleared(World& w);
void finishReward(World& w);
void leaveRoom(World& w);
void shopBuy(World& w, int idx);
void restChoose(World& w, int option, int ab);
void altarChoose(World& w, int idx);
int runScore(const World& w);
std::string morgueText(const World& w);
const char* locationName(const World& w);
int actLength(int act);
int xpForLevel(int xl);
int monsterScaledHp(const World& w, int def);

// ============================================================ v3 systems
// stats (stats.cpp)
extern const char* STAT_NAME[STAT_COUNT];
extern const char* STAT_ABBR[STAT_COUNT];
extern const uint32_t STAT_COLOR[STAT_COUNT];
void initStatTables();                          // species / background stat tables (called by initContent)
void rollStartingStats(World& w);               // new run
void applyStatEffects(World& w);                // end of recalcStats
void statLevelUp(World& w);                     // automatic growth / stat choice on level up
void chooseStat(World& w, int stat);
int effStat(const World& w, int stat);
std::string statEffectText(int stat, int value);   // "+12% ball damage" ...
std::string statTooltip(const World& w, int stat);
void addTempStat(World& w, int stat, int amt, const char* why);
bool needsOffers(const World& w);               // ability or stat choices pending
int previewStartHp(int species, int bg);
int previewStartMp(int species, int bg);

// loot, champions, shrines (loot.cpp)
extern const char* SHRINE_NAME[SHRINE_COUNT];
extern const char* SHRINE_DESC[SHRINE_COUNT];
extern const char* AFFIX_NAME[AFFIX_COUNT];
extern const char* AFFIX_DESC[AFFIX_COUNT];
enum AffixId : uint8_t {
  AF_STRONG, AF_FAST, AF_STONESKIN, AF_VAMPIRIC, AF_REGEN, AF_SHIELDED, AF_TELEPORT, AF_THORNS, AF_CURSED,
  AF_MANABURN, AF_SPLITTING, AF_HORDE, AF_AURA, AF_MULTISHOT, AF_BERSERK, AF_FIRE, AF_COLD
};
inline bool hasAffix(const Monster& m, int a) { return (m.affix >> a) & 1u; }
Randart makeAffixes(uint32_t seed, int relicId);   // a magic relic's affixes and full name
uint32_t newAffixSeed(World& w);
uint32_t rollRelicQuality(World& w, bool boss);    // 0 = plain, else an affix seed
int randomRelicFor(World& w, bool boss, bool allowUnique);
int randomUniqueRelic(World& w);
std::string relicName(const World& w, int idx);    // display name of the idx-th owned relic
std::string relicTooltip(const World& w, int idx);
uint32_t relicNameColor(const World& w, int idx);
std::string offerRelicName(int rl, uint32_t seed);
std::string offerRelicDesc(int rl, uint32_t seed);
void rollChampions(World& w);                      // after monsters spawn
void makeChampion(World& w, int mi, bool unique, int forcedAffix = -1);
std::string monsterName(const Monster& m);         // "Bonesnap the Vile" / "champion goblin" / "goblin"
void dropLoot(World& w, V2 pos, int tier);
void collectLoot(World& w, int pi, bool swept);
void sweepLoot(World& w);                          // floor cleared: gather remaining loot
void gainShard(World& w, int n);
void activateShrine(World& w, int kind, V2 at);
void monsterDiedLoot(World& w, const Monster& m, V2 pos);
void champTurn(World& w, int mi);                  // per-turn champion affix effects

// runes (runes.cpp)
extern const char* RUNE_NAME[RUNE_COUNT];
extern const char* RUNEWORD_NAME[RUNEWORD_COUNT];
void runeCircle(World& w, int bi, int zi);
void runePeg(World& w, int bi, int pi);
std::string runeHelpText();

// board formats (formats.cpp)
extern const char* FORMAT_NAME[FORMAT_COUNT];
extern const char* FORMAT_DESC[FORMAT_COUNT];
int pickFormat(World& w, const FloorSpec& s, Rng& R);
bool formatClearings(World& w, int count, bool boss, float bossR);
void buildFormat(World& w);
int formatPinPattern(World& w);
void reformatBoard(World& w, int format);

// new pegs & pockets (floor_ball2.cpp)
bool newPegHit(World& w, int bi, int pi);                 // non-consumable v3 objects
bool newPegTrigger(World& w, int bi, int pi, bool echo);  // consumable v3 specials
bool newPocket(World& w, int bi, int pocket, int mul, V2 at);
void placeGem(World& w, V2 p);
void spawnMimic(World& w, int pi);

// save (save.cpp)
bool saveRun(const World& w, const std::wstring& path);
bool loadRun(World& w, const std::wstring& path);
