// Dropcrawl - v3 content: text for the new pegs / pockets / intents, unique relics (curated legendaries), relic sets,
// and the treasure imp and mimic.
#include "rules.h"

static RelicDef& RD(int id, const char* name, int rarity, const char* glyph, uint32_t col, const char* desc) {
  RelicDef& r = RELIC[id];
  r.id = (uint16_t)id;
  r.name = name;
  r.rarity = (uint8_t)rarity;
  r.glyph = glyph;
  r.color = col;
  r.desc = desc;
  r.h = Hooks();
  r.tier = 0;
  r.set = -1;
  r.synergy = nullptr;
  return r;
}
static RelicDef& UQ(int id, const char* name, const char* glyph, uint32_t col, const char* desc, const char* syn) {
  RelicDef& r = RD(id, name, R_RARE, glyph, col, desc);
  r.tier = 1;
  r.synergy = syn;
  return r;
}
static RelicDef& SETP(int id, int set, const char* name, const char* glyph, const char* desc) {
  RelicDef& r = RD(id, name, R_UNCOMMON, glyph, 0x5ee06a, desc);
  r.tier = 2;
  r.set = (int8_t)set;
  return r;
}

static Intent I(int k, int v = 0, int d = 1, int a = 0) {
  Intent t;
  t.kind = (uint8_t)k;
  t.val = (int16_t)v;
  t.delay = (uint8_t)d;
  t.arg = (int16_t)a;
  return t;
}
static void MD(int id, const char* name, const char* glyph, uint32_t col, int hp, int armor, float r, int xp, int gold,
               uint32_t traits, int tval, int split, std::initializer_list<Intent> s1, std::initializer_list<Intent> s2,
               std::initializer_list<Intent> s3, const char* desc) {
  MonDef& m = MON[id];
  m.id = (uint16_t)id;
  m.name = name;
  m.glyph = glyph;
  m.color = col;
  m.hp = hp;
  m.armor = armor;
  m.r = r;
  m.xp = xp;
  m.gold = gold;
  m.traits = traits;
  m.tval = tval;
  m.splitInto = split;
  int i = 0;
  for (auto& t : s1) if (i < 5) m.s1[i++] = t;
  i = 0;
  for (auto& t : s2) if (i < 5) m.s2[i++] = t;
  i = 0;
  for (auto& t : s3) if (i < 5) m.s3[i++] = t;
  m.desc = desc;
}

// ================================================================ text tables for the new kinds
static void initTables() {
  struct PT { int k; const char* name; const char* desc; uint32_t col; };
  static const PT PEGS[] = {
      {PK_LOOT, "Loot", "Treasure dropped by a monster. Hit it to grab it now; anything left is collected when the floor is cleared. White: an item or gold. Blue: a magic relic. Yellow: a randart. Orange: a unique!", 0xe8e8f0},
      {PK_SHRINE, "Shrine", "Hit it for a blessing that lasts the rest of the floor. Each shrine works once.", 0xfff0c0},
      {PK_WELL, "Healing Well", "Heals 4 HP (+1 per 3 depth) and restores 1 MP when hit. Runs dry after 3 uses.", 0x60d0ff},
      {PK_MIMIC, "Treasure Chest", "Break it open (3 hits) for gold and items.", 0xc08040},
      {PK_SHARD, "Relic Shard", "Collect three shards and they fuse into a relic of your choice.", 0xd0a0ff},
      {PK_PINATA, "Pinata", "Takes three hits, then bursts: +6 power, a shower of gold, and maybe an item.", 0xff80c0},
      {PK_PRISM, "Prism Peg", "Splits the ball into three: one copy carries fire, the other frost.", 0xe0e0ff},
      {PK_DICE, "Dice Peg", "Rolls a die. 1: -3 power. 2: +2. 3: +4. 4: gold. 5: x1.5 power. 6: x2 power!", 0xf4f4f4},
      {PK_STAR, "Star Peg", "+2 power. Hit three Star pegs with one shot for a Constellation: starfall strikes every monster.", 0xfff4a0},
      {PK_MOON, "Moon Peg", "+2 power. The ball turns lunar: it floats for a moment and its next monster hit deals +50%.", 0xc0d0ff},
      {PK_HOURGLASS, "Hourglass Peg", "The monster about to act soonest waits one more turn.", 0xe0c080},
      {PK_BLOOD, "Blood Peg", "Costs you 1 HP, but +7 power.", 0xd02040},
      {PK_CANNON, "Cannon Peg", "+3 power, then fires the ball straight at your focus target.", 0xa8a8b8},
      {PK_ROD, "Lightning Rod", "Lightning strikes your focus target for half the ball's current power. The ball keeps its power.", 0xfff060},
      {PK_COMBO, "Combo Peg", "+2 power for every special peg this ball has triggered this shot.", 0xff9040},
      {PK_SNOWBALL, "Snowball Peg", "The ball grows 25% bigger (it hits more pegs) and gains +3 power.", 0xf0f8ff},
      {PK_ECHO, "Echo Peg", "Repeats the last special peg effect of this shot.", 0xc080ff},
      {PK_BRAND, "Brand Peg", "+2 power, and the ball's next monster hit applies Burn, Poison and Chill.", 0xff60a0},
      {PK_JACKPOT, "Jackpot Peg", "Triples the ball's power!", 0xffd700},
      {PK_GEM, "Gem", "+1 to a stat for the rest of this floor. Ruby: Strength. Emerald: Dexterity. Sapphire: Intelligence. Garnet: Vitality. Topaz: Luck.", 0x60ffd0},
  };
  for (auto& p : PEGS) {
    PEG_NAME[p.k] = p.name;
    PEG_DESC[p.k] = p.desc;
    PEG_COLOR[p.k] = p.col;
  }
  struct PO { int k; const char* name; const char* shortName; const char* desc; uint32_t col; };
  static const PO POCK[] = {
      {PO_LOOT, "Loot", "LOOT", "Grab some loot: an item or gold, and sometimes a magic relic.", 0xe8e8f0},
      {PO_SHRINE, "Shrine", "SHRINE", "A random shrine blessing for the rest of this floor.", 0xfff0c0},
      {PO_RELAUNCH, "Relaunch", "AGAIN", "The ball shoots back up from the top with 75% of its power (once per ball).", 0x80ffd0},
      {PO_SUMMON, "Summon", "IMP", "An imp joins you for 3 turns.", 0xff7040},
      {PO_SMITE, "Smite", "SMITE", "Holy fire strikes the strongest monster for 1.5x the ball's power (double against undead and demons).", 0xfff0a0},
      {PO_SCATTER, "Scatter", "SPLASH", "The ball's power splashes onto every monster (40% each) instead of discharging.", 0x80c0ff},
      {PO_TRAINING, "Training", "+STAT", "Permanently +1 to a random stat. Works once per floor.", 0xff8060},
      {PO_DELAY, "Delay", "WAIT", "Every monster waits one more turn.", 0xc0b090},
      {PO_GAMBLE, "Gamble", "50/50", "A coin flip: discharge triple the ball's power, or nothing at all.", 0xffe060},
      {PO_SHARD, "Shard", "SHARD", "+1 relic shard (three shards fuse into a relic).", 0xd0a0ff},
      {PO_SLOTS, "Slots", "SPIN", "Spin the slot machine.", 0xffd700},
      {PO_PRAYER, "Prayer", "PRAY", "+6 piety (or +XP if you follow no god).", 0xfff8e0},
      {PO_TRAP, "Trap", "TRAP", "A trap springs: take 4 damage (+1 per 3 depth)!", 0x906060},
      {PO_TAX, "Tax", "TAX", "The House takes 8% of your gold.", 0x807050},
  };
  for (auto& p : POCK) {
    POCKET_NAME[p.k] = p.name;
    POCKET_SHORTNAME[p.k] = p.shortName;
    POCKET_DESC[p.k] = p.desc;
    POCKET_COLOR[p.k] = p.col;
  }
  INTENT_NAME[IN_QUAKE] = "Quake";
  INTENT_NAME[IN_LIFEDRAIN] = "Drain life";
  INTENT_NAME[IN_DISPEL] = "Dispel";
  INTENT_NAME[IN_EXECUTE] = "Execute";
  INTENT_NAME[IN_SUNDER] = "Sunder";
  INTENT_NAME[IN_FLEE] = "Flee";
  INTENT_NAME[IN_METEOR] = "Meteor";
}

// ================================================================ uniques
static int school(int s) { return 1 << s; }

static void initUniques() {
  {
    auto& r = UQ(RL_U_STORMCROWN, "Crown of the Tempest", "^", 0xfff080,
                 "Spark pegs arc to 2 more monsters and Chain Lightning jumps 2 more times. Every 25th peg hit in a shot calls "
                 "lightning down on every monster. +2 Intelligence.",
                 "Storm spells, Spark pegs, Chain Lightning");
    r.h.stats = [](World& w, int) {
      w.st.sparkExtra += 2;
      w.st.statBonus[STAT_INT] += 2;
    };
    r.h.pegHit = [](World& w, int, int, int) {
      if (w.fl.shot.pegHits % 25 != 0) return;
      int d = 3 + w.depth / 3;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) {
          fxZap(w, V2(w.fl.mons[i].p.x, 0), w.fl.mons[i].p, 0xfff4a0);
          damageMonster(w, i, d, DS_ZAP);
        }
      fxSound(w, S_ZAP, 0.8f, 0.8f);
    };
  }
  {
    auto& r = UQ(RL_U_INFERNO, "Heart of the Inferno", "*", 0xff6020,
                 "Burn deals +50% damage and only fades by a third each turn. Fire pegs grant +3 more power. +1 Intelligence.",
                 "Flame spells, Fire pegs, Ember balls");
    r.h.stats = [](World& w, int) {
      w.st.burnMul *= 1.5f;
      w.st.statBonus[STAT_INT] += 1;
    };
    r.h.pegHit = [](World& w, int bi, int, int) {
      if (w.fl.lastTrig == PK_FIRE) w.fl.balls[bi].power += 3;
    };
  }
  {
    auto& r = UQ(RL_U_GLACIER, "Glacier's Tear", "o", 0xa0e8ff,
                 "Chilled and frozen monsters take +40% damage. Ice pegs also Chill the nearest monster. +2 Vitality.",
                 "Frost spells, Ice and Frost pegs, Freeze pockets");
    r.h.stats = [](World& w, int) {
      w.st.chillVuln += 0.4f;
      w.st.statBonus[STAT_VIT] += 2;
    };
    r.h.pegHit = [](World& w, int bi, int, int) {
      if (w.fl.lastTrig != PK_ICE) return;
      int t = nearestMonster(w, w.fl.balls[bi].p);
      if (t >= 0) applyChill(w, t, 1);
    };
  }
  {
    auto& r = UQ(RL_U_GAIA, "Gaia's Cradle", "#", 0xc09060,
                 "Stone blocks, pillars and golems grant +4 more power. Earth abilities cost 1 less MP. +2 Vitality, +1 armor.",
                 "Earth spells, Stone blocks, Raise Earth, Stone Golem");
    r.h.stats = [](World& w, int) {
      w.st.cheapSchool |= school(SCH_EARTH);
      w.st.statBonus[STAT_VIT] += 2;
      w.st.armor += 1;
    };
    r.h.pegHit = [](World& w, int bi, int pi, int) {
      int k = w.fl.pegs[pi].kind;
      if (k == PK_STONE || k == PK_PILLAR || k == PK_GOLEM) w.fl.balls[bi].power += 4;
    };
  }
  UQ(RL_U_ARCANUM, "The Arcanum", "?", 0xb090ff, "Arcane abilities cost 1 less MP. Spells deal +20% damage. +3 Intelligence.",
     "Arcane spells, Magic Missile, anything that spends MP")
      .h.stats = [](World& w, int) {
    w.st.cheapSchool |= school(SCH_ARCANE);
    w.st.spellDmgMul *= 1.2f;
    w.st.statBonus[STAT_INT] += 3;
  };
  {
    auto& r = UQ(RL_U_WORLDSEED, "Seed of the World Tree", "&", 0x70e070,
                 "Heal pegs heal 2 more and sprout two pins. Healing received +25%. Life abilities cost 1 less MP.",
                 "Life spells, Heal pegs, Verdana");
    r.h.stats = [](World& w, int) {
      w.st.healMul += 0.25f;
      w.st.cheapSchool |= school(SCH_LIFE);
    };
    r.h.pegHit = [](World& w, int bi, int, int) {
      if (w.fl.lastTrig != PK_HEAL) return;
      healPlayer(w, 2, true);
      growPins(w, 2, w.fl.balls[bi].p, 50, true);
    };
  }
  {
    auto& r = UQ(RL_U_MIDAS, "Midas' Last Coin", "$", 0xffd040,
                 "Gold pegs pay out twice and grant +3 power. Fortune abilities cost 1 less MP. +3 Luck.",
                 "Fortune spells, Gold pegs, Aurum, Golden Ball");
    r.h.stats = [](World& w, int) {
      w.st.cheapSchool |= school(SCH_FORTUNE);
      w.st.statBonus[STAT_LCK] += 3;
    };
    r.h.pegHit = [](World& w, int bi, int, int) {
      if (w.fl.lastTrig != PK_GOLD) return;
      gainGold(w, 2 + w.depth / 3, w.fl.balls[bi].p);
      w.fl.balls[bi].power += 3;
    };
  }
  {
    auto& r = UQ(RL_U_NIGHTVEIL, "Nightveil", "~", 0x9070c0,
                 "Ball hits deal +1 damage per 2 Poison on the monster. Shadow abilities cost 1 less MP. +2 Dexterity.",
                 "Shadow spells, Poison pegs, Venom, Plague");
    r.h.stats = [](World& w, int) {
      w.st.cheapSchool |= school(SCH_SHADOW);
      w.st.statBonus[STAT_DEX] += 2;
    };
    r.h.monHit = [](World& w, HitCtx& c, int) { c.flat += w.fl.mons[c.mon].poison / 2; };
  }
  UQ(RL_U_GEARHEART, "The Gearheart", "%", 0xd0b080,
     "Bumpers, spinners, kickers and pendulums grant +3 more power. Tesla coils strike twice. Clockwork abilities cost 1 less MP.",
     "Clockwork spells, Bumper Kit, Tesla Coil, bumper-heavy boards")
      .h.stats = [](World& w, int) {
    w.st.kickerBonus += 3;
    w.st.cheapSchool |= school(SCH_CLOCKWORK);
  };
  {
    auto& r = UQ(RL_U_CHALICE, "Crimson Grail", "U", 0xe03050,
                 "Blood abilities cost 2 less HP. While below half HP you deal +30% damage and regenerate 2 HP each turn.",
                 "Blood magic, Beast Form, living dangerously");
    r.h.stats = [](World& w, int) {
      w.st.hpCostReduce += 2;
      w.st.lowHpDmg += 0.3f;
    };
    r.h.turnStart = [](World& w, int) {
      if (w.pl.hp * 2 < w.st.maxHp) healPlayer(w, 2);
    };
  }
  UQ(RL_U_JESTER, "The Jester's Grin", ":", 0xff60ff,
     "The Tumbler watches you (12% of turns) and is kinder. Chaos pegs trigger twice. Whenever the Tumbler meddles, you gain 8 gold.",
     "Chaos spells, the Tumbler, Chaos pegs and pockets")
      .h.stats = [](World& w, int) {
    w.st.tumblerWatch += 0.12f;
    w.st.tumblerKind = true;
    w.st.chaosTwice = true;
  };
  UQ(RL_U_SUMMONBELL, "Bell of the Pack", "A", 0xffa060,
     "Your summons last 2 more turns and deal +40% damage. Summoning abilities cost 1 less MP.",
     "Summoning spells, allies, Bondmaster")
      .h.stats = [](World& w, int) {
    w.st.allyTurns += 2;
    w.st.allyDmgMul *= 1.4f;
    w.st.cheapSchool |= school(SCH_SUMMON);
  };
  UQ(RL_U_VOIDHEART, "Voidheart", "0", 0x8040e0, "Void discharges are +75% stronger. Void abilities cost 1 less MP. +2 Intelligence.",
     "Void spells, Void pegs, Singularities, Voidmaw")
      .h.stats = [](World& w, int) {
    w.st.voidMul += 0.75f;
    w.st.cheapSchool |= school(SCH_VOID);
    w.st.statBonus[STAT_INT] += 2;
  };
  {
    auto& r = UQ(RL_U_ENGINE, "Momentum Engine", "@", 0x90b0ff,
                 "Every wall bounce grants +2 power. Force abilities cost 1 less MP. +2 Strength.",
                 "Force spells, Ricochet, Momentum, narrow boards");
    r.h.stats = [](World& w, int) {
      w.st.wallPower = true;
      w.st.cheapSchool |= school(SCH_FORCE);
      w.st.statBonus[STAT_STR] += 2;
    };
    r.h.wallHit = [](World& w, int bi, int) { w.fl.balls[bi].power += 1; };
  }
  UQ(RL_U_CROOKEDDIE, "The Crooked Die", "6", 0xffffff,
     "Dice pegs never roll below 3. Lottery pockets never cost you anything, and Chaos pegs never turn into curses. +2 Luck.",
     "Dice pegs, Lottery pockets, Casino Night, the Tumbler")
      .h.stats = [](World& w, int) {
    w.st.diceLoaded = true;
    w.st.lucky = true;
    w.st.statBonus[STAT_LCK] += 2;
  };
  UQ(RL_U_STARFALL, "Starfall Pendant", "*", 0xfff4a0,
     "Two Star pegs appear each turn and grant +3 more power. A Constellation strikes every monster twice as hard.",
     "Star pegs, big multi-peg shots")
      .h.stats = [](World& w, int) {
    w.st.starBonus += 3;
    w.st.specials[PK_STAR] += 2;
  };
  UQ(RL_U_MOONSTONE, "Moonstone of Ages", "(", 0xc0d0ff, "Critical hits deal x2.25 damage instead of x1.5. +2 Dexterity.",
     "Dexterity, critical hits, Moon pegs")
      .h.stats = [](World& w, int) {
    w.st.critDmg += 0.75f;
    w.st.statBonus[STAT_DEX] += 2;
  };
  UQ(RL_U_ASSASSIN, "Assassin's Mark", "x", 0xff5070, "+12% critical hit chance. Critical hits apply 3 Bleed and 2 Poison.",
     "Dexterity, critical hits, Shadow")
      .h.stats = [](World& w, int) {
    w.st.critChance += 0.12f;
    w.st.critBleed += 3;
  };
  UQ(RL_U_TITANGRIP, "Titan's Grip", "G", 0xff7a50, "+5 Strength. Your balls are 15% larger.", "Strength, ball damage")
      .h.stats = [](World& w, int) {
    w.st.statBonus[STAT_STR] += 5;
    w.st.ballR *= 1.15f;
  };
  UQ(RL_U_SAGELENS, "Sage's Lens", "0", 0x78a8ff, "+5 Intelligence. Your aiming guide shows 2 more bounces.", "Intelligence, spells, aiming")
      .h.stats = [](World& w, int) {
    w.st.statBonus[STAT_INT] += 5;
    w.st.preview += 2;
  };
  UQ(RL_U_IRONBARK, "Ironbark Plate", "[", 0x80a060, "+4 Vitality and +1 armor, but -1 Dexterity.", "Vitality, surviving big hits")
      .h.stats = [](World& w, int) {
    w.st.statBonus[STAT_VIT] += 4;
    w.st.armor += 1;
    w.st.statBonus[STAT_DEX] -= 1;
  };
  UQ(RL_U_FOURLEAF, "Four-Leaf Talisman", "%", 0x50ff70, "+5 Luck. Two Clover pegs appear each turn.", "Luck, loot, pockets")
      .h.stats = [](World& w, int) {
    w.st.statBonus[STAT_LCK] += 5;
    w.st.specials[PK_CLOVER] += 2;
  };
  UQ(RL_U_CENSER, "Shrinekeeper's Censer", "i", 0xfff0c0, "A shrine appears on every floor, and shrine blessings are twice as strong.",
     "Shrines, long boss fights")
      .h.stats = [](World& w, int) { w.st.shrineBonus += 1; };
  UQ(RL_U_CHISEL, "Runemaster's Chisel", "/", 0xb0a0ff,
     "A Rune Road appears on every floor, rune circles grant two runes, and runewords are 50% stronger.",
     "Rune circles, runewords, Rune pegs")
      .h.stats = [](World& w, int) {
    w.st.runeDouble = true;
    w.st.runewordMul *= 1.5f;
  };
  UQ(RL_U_GOBLINSACK, "Goblin King's Sack", "$", 0xe0c060,
     "Treasure imps appear three times as often, monsters drop loot twice as often, and +10% better loot.",
     "Luck, champions, treasure imps")
      .h.stats = [](World& w, int) { w.st.magicFind += 0.1f; };
  UQ(RL_U_WELLSPRING, "Wellspring Amulet", "\"", 0x60d0ff, "A healing well appears on every floor, and wells heal 3 more. +1 HP regeneration.",
     "Healing wells, long fights")
      .h.stats = [](World& w, int) {
    w.st.wellBonus += 3;
    w.st.hpRegen += 1;
  };
}

// ================================================================ sets
static void initSets() {
  SETP(RL_S_JESTERCAP, 0, "Motley Cap", "^", "+2 Luck.").h.stats = [](World& w, int) { w.st.statBonus[STAT_LCK] += 2; };
  SETP(RL_S_JESTERSHOES, 0, "Curly-Toed Slippers", "_", "+2 Dexterity.").h.stats = [](World& w, int) { w.st.statBonus[STAT_DEX] += 2; };
  SETP(RL_S_JESTERSCEPTER, 0, "Jester's Scepter", "!", "+10% critical hit chance.").h.stats = [](World& w, int) { w.st.critChance += 0.1f; };
  SETP(RL_S_DICECUP, 1, "Dice Cup", "u", "+2 Luck.").h.stats = [](World& w, int) { w.st.statBonus[STAT_LCK] += 2; };
  SETP(RL_S_VISOR, 1, "Dealer's Visor", "=", "+15% gold.").h.stats = [](World& w, int) { w.st.goldMul *= 1.15f; };
  SETP(RL_S_CHIPS, 1, "Lucky Chips", "o", "Lottery pockets pay out double.");
  SETP(RL_S_WARHELM, 2, "Warhelm", "n", "+2 Strength and +1 armor.").h.stats = [](World& w, int) {
    w.st.statBonus[STAT_STR] += 2;
    w.st.armor += 1;
  };
  SETP(RL_S_WARPLATE, 2, "Warplate", "[", "+15 max HP.").h.stats = [](World& w, int) { w.st.maxHp += 15; };
  SETP(RL_S_WARBANNER, 2, "War Banner", "P", "+15% damage to elites and bosses.").h.stats = [](World& w, int) { w.st.eliteDmgMul *= 1.15f; };
  SETP(RL_S_ROBE, 3, "Archmage's Robe", "A", "+2 max MP.").h.stats = [](World& w, int) { w.st.maxMp += 2; };
  SETP(RL_S_STAFF, 3, "Archmage's Staff", "/", "+15% spell damage.").h.stats = [](World& w, int) { w.st.spellDmgMul *= 1.15f; };
  SETP(RL_S_CIRCLET, 3, "Archmage's Circlet", "o", "+2 Intelligence.").h.stats = [](World& w, int) { w.st.statBonus[STAT_INT] += 2; };
}

static void setStats(World& w, int) {
  Stats& s = w.st;
  if (relicSetCount(w, 0) >= 2) {
    s.tumblerWatch += 0.1f;
    s.tumblerKind = true;
  }
  if (relicSetCount(w, 0) >= 3) {
    s.chaosTwice = true;
    s.specials[PK_CHAOS] += 2;
  }
  if (relicSetCount(w, 1) >= 2) s.statBonus[STAT_LCK] += 3;
  if (relicSetCount(w, 1) >= 3) {
    s.slotMul *= 2.f;
    s.specials[PK_JACKPOT] += 1;
  }
  if (relicSetCount(w, 2) >= 2) {
    s.statBonus[STAT_STR] += 3;
    s.statBonus[STAT_VIT] += 2;
  }
  if (relicSetCount(w, 2) >= 3) s.killPower += 4;
  if (relicSetCount(w, 3) >= 2) {
    s.statBonus[STAT_INT] += 3;
    s.mpRegen += 1;
  }
  if (relicSetCount(w, 3) >= 3) s.costReduce += 1;
}
static void setFloorStart(World& w, int) {
  Floor& f = w.fl;
  if (f.isVault || relicSetCount(w, 1) < 2) return;
  for (auto& p : f.pockets)
    if (p.kind == PO_LOTTERY) return;
  std::vector<int> c;
  for (int i = 0; i < (int)f.pockets.size(); ++i)
    if (f.pockets[i].kind != PO_STRIKE && f.pockets[i].kind != PO_RECALL) c.push_back(i);
  if (c.empty()) return;
  int i = c[f.rng.range(0, (int)c.size() - 1)];
  f.pockets[i].kind = f.pockets[i].orig = PO_LOTTERY;
  layoutPockets(w);
}
static void setKill(World& w, int, int) {
  if (relicSetCount(w, 2) >= 3) healPlayer(w, 2);
}
Hooks SET_HOOKS = [] {
  Hooks h;
  h.stats = setStats;
  h.floorStart = setFloorStart;
  h.kill = setKill;
  return h;
}();

// ================================================================ monsters
static void initMonsters3() {
  MD(M_TREASURE, "treasure imp", "$", 0xffd040, 24, 0, 18, 12, 25, TR_FLYING, 0, -1, {I(IN_FLEE, 0, 1)}, {}, {},
     "A greedy little imp stuffed with loot. It never attacks, but it blinks around the board and escapes after 4 turns. "
     "Kill it for a pile of treasure!");
  MD(M_MIMIC, "mimic", "m", 0xc08040, 24, 1, 21, 16, 30, 0, 0, -1, {I(IN_ATTACK, 4, 2), I(IN_HEAVY, 7, 2)}, {}, {},
     "A treasure chest with a mouthful of teeth. Kill it for the loot it hoards.");
}


// ================================================================ boss scripts (v3)
// Bosses act every turn, often twice (a chained intent), and their big blows are telegraphed with a longer countdown.
static Intent C(int k, int v = 0, int d = 1, int a = 0) {  // chains into the next intent in the same turn
  Intent t = I(k, v, d, a);
  t.delay = (uint8_t)(std::max(1, d) | INTENT_CHAIN);
  return t;
}
static void script(int id, std::initializer_list<Intent> s1, std::initializer_list<Intent> s2, std::initializer_list<Intent> s3,
                   const char* desc) {
  MonDef& m = MON[id];
  Intent none;
  for (int i = 0; i < 5; ++i) m.s1[i] = m.s2[i] = m.s3[i] = none;
  int i = 0;
  for (auto& t : s1) if (i < 5) m.s1[i++] = t;
  i = 0;
  for (auto& t : s2) if (i < 5) m.s2[i++] = t;
  i = 0;
  for (auto& t : s3) if (i < 5) m.s3[i++] = t;
  if (desc) m.desc = desc;
}
static void initBosses3() {
  MON[M_GORLAG].hp = 135;  // the first Guardian most runs meet: dangerous, but not a wall
  script(M_GORLAG,
         {C(IN_SUMMON, M_GOBLIN, 1, 1), I(IN_ATTACK, 5, 1), C(IN_BLOCK, 10, 2), I(IN_HEAVY, 8, 1), I(IN_ATTACK, 6, 1)},
         {C(IN_SUMMON, M_GOBLIN, 1, 1), I(IN_MULTI, 4, 1, 2), I(IN_ENRAGE, 0, 1), I(IN_HEAVY, 6, 1), I(IN_QUAKE, 5, 1)}, {},
         "Guardian of the Upper Halls. Calls goblins to his side, and when he's hurt he flies into a rage: watch for the enraged smash.");
  script(M_WITCH,
         {C(IN_HEX, 4, 1), I(IN_ATTACK, 5, 1), C(IN_BOMB, 9, 1, 3), I(IN_CURSEBALL, 0, 1), I(IN_ATTACK, 6, 1)},
         {I(IN_METEOR, 12, 1, 2), C(IN_CURSEPOCKET, 0, 1), I(IN_ATTACK, 6, 1), I(IN_LIFEDRAIN, 6, 1), I(IN_BLIND, 1, 1)}, {},
         "Guardian of the Upper Halls. Curses pins and pockets, plants wax bombs, and when desperate calls down a burning star.");
  script(M_MYCELIUM,
         {C(IN_SUMMON, M_TOADSTOOL, 1, 1), I(IN_POISON, 4, 1), C(IN_EAT, 6, 1), I(IN_ATTACK, 8, 1), I(IN_TOTEM, 8, 1)},
         {I(IN_QUAKE, 8, 1), C(IN_SUMMON, M_MYCONID, 1, 1), I(IN_POISON, 6, 1), I(IN_LIFEDRAIN, 8, 1), I(IN_HEAVY, 12, 2)}, {},
         "Guardian of the Lair. A vast fungal mind that devours the board, poisons you and drinks your life.");
  script(M_LEVIATHAN,
         {C(IN_RISE, 40, 1), I(IN_ATTACK, 7, 1), C(IN_SUMMON, M_EEL, 2, 1), I(IN_HEAVY, 10, 1), I(IN_MULTI, 4, 1, 2)},
         {I(IN_BEAM, 14, 2, 26), C(IN_RISE, 40, 1), I(IN_SUMMON, M_EEL, 1, 2), I(IN_EXECUTE, 8, 1), I(IN_QUAKE, 9, 1)}, {},
         "Guardian of the Drowned Halls. Raises the waters, calls eels, and charges a crushing tidal beam: interrupt it!");
  script(M_FOREMAN,
         {C(IN_WALL, 4, 1), I(IN_ATTACK, 8, 1), C(IN_SUMMON, M_TURRETM, 1, 1), I(IN_BOMB, 12, 1, 3), I(IN_SUNDER, 8, 1)},
         {I(IN_METEOR, 18, 1, 2), C(IN_BLOCK, 18, 2), I(IN_HEAVY, 12, 1), C(IN_SUMMON, M_TURRETM, 1, 1), I(IN_QUAKE, 9, 1)}, {},
         "Guardian of the Mines. Builds walls and turrets, sunders your armor, then calls in the artillery.");
  script(M_ROYALJELLY,
         {C(IN_SUMMON, M_ACIDBLOB, 1, 1), I(IN_ACID, 4, 1), I(IN_ATTACK, 9, 1), C(IN_HEAL, 12, 1), I(IN_ATTACK, 7, 1)},
         {I(IN_SUMMON, M_ACIDBLOB, 1, 2), I(IN_LIFEDRAIN, 10, 1), C(IN_ACID, 6, 2), I(IN_HEAVY, 12, 1), I(IN_MULTI, 4, 1, 3)}, {},
         "Guardian of the Slime Pits. Spawns acid blobs, dissolves the board and drinks your life.");
  script(M_HOLLOWKING,
         {C(IN_SUMMON, M_SKELETON, 1, 2), I(IN_ATTACK, 8, 1), C(IN_HEX, 6, 1), I(IN_CURSEBALL, 0, 1), I(IN_HEAVY, 12, 2)},
         {C(IN_WEAKEN, 2, 1), I(IN_LIFEDRAIN, 10, 1), C(IN_SUMMON, M_WRAITH, 1, 1), I(IN_CURSEPOCKET, 0, 1), I(IN_EXECUTE, 11, 2)},
         {I(IN_DISPEL, 9, 1), C(IN_SUMMON, M_SKELETON, 1, 2), I(IN_HEAVY, 13, 1), I(IN_EXECUTE, 12, 1), I(IN_BEAM, 16, 2, 40)},
         "Guardian of the Crypt. Commands the restless dead, curses everything, and tries to finish off the weak.");
  script(M_PYRRHUS,
         {C(IN_RISE, 40, 1), I(IN_ATTACK, 10, 1), C(IN_BOMB, 16, 1, 3), I(IN_SUNDER, 9, 1), I(IN_METEOR, 20, 1, 2)},
         {C(IN_SUMMON, M_IMP, 1, 2), I(IN_HEAVY, 14, 1), C(IN_BUFF, 2, 1), I(IN_MULTI, 6, 1, 2), I(IN_QUAKE, 11, 1)},
         {I(IN_METEOR, 24, 1, 2), C(IN_RISE, 40, 1), I(IN_EXECUTE, 12, 1), C(IN_ENRAGE, 0, 1), I(IN_ATTACK, 10, 1)},
         "Guardian of the Forge. Floods the board with lava, rains meteors, and melts your armor.");
  script(M_RIMEQUEEN,
         {C(IN_WEAKEN, 2, 1), I(IN_ATTACK, 10, 1), C(IN_FREEZEPOCKET, 0, 1), I(IN_SUMMON, M_FROSTWRAITH, 1, 1), I(IN_BEAM, 18, 2, 36)},
         {C(IN_BLOCK, 24, 2), I(IN_HEAVY, 14, 1), C(IN_SLOW, 2, 1), I(IN_MULTI, 6, 1, 3), I(IN_EXECUTE, 12, 1)},
         {I(IN_SUMMON, M_ICEBEAST, 1, 2), I(IN_DISPEL, 11, 1), C(IN_FREEZEPOCKET, 0, 1), I(IN_BEAM, 20, 2, 44), I(IN_QUAKE, 12, 1)},
         "Guardian of the Vaults. Her cold saps your strength, freezes your pockets and charges blizzard beams.");
  script(M_MAW,
         {C(IN_GRAVITY, 0, 1), I(IN_ATTACK, 10, 1), C(IN_DEVOUR, 0, 1), I(IN_LIFEDRAIN, 10, 1), I(IN_BEAM, 18, 2, 40)},
         {I(IN_QUAKE, 12, 1), I(IN_DISPEL, 10, 1), C(IN_GRAVITY, 0, 1), I(IN_EXECUTE, 12, 1), I(IN_SUMMON, M_VOIDSPAWN, 1, 2)},
         {C(IN_MUTATEPEGS, 4, 1), I(IN_HEAVY, 15, 1), I(IN_SUMMON, M_HORROR, 1, 1), I(IN_BEAM, 22, 2, 50), I(IN_EXECUTE, 13, 1)},
         "Guardian of the Abyss. A hungering mouth that bends gravity, swallows magic and tears at your life.");
  script(M_HOUSE,
         {C(IN_SHUFFLE, 0, 1), I(IN_ATTACK, 12, 1), C(IN_SUMMON, M_DEALER, 1, 1), I(IN_CURSEPOCKET, 0, 1), I(IN_HEAVY, 16, 2)},
         {C(IN_WALL, 8, 1), I(IN_BOMB, 20, 1, 3), I(IN_DISPEL, 12, 1), C(IN_BUFF, 3, 1), I(IN_MULTI, 7, 1, 2)},
         {I(IN_EXECUTE, 14, 1), I(IN_METEOR, 26, 1, 2), C(IN_SUMMON, M_PITBOSS, 1, 1), I(IN_LIFEDRAIN, 12, 1), I(IN_BEAM, 24, 2, 60)},
         "The heart of the machine, guarding the Orb of Chance. It rigs the game, dispels your protections and, at the end, "
         "tries to cash you out. The House always wins... unless you beat it.");
}

void initV3Content() {
  initTables();
  initBosses3();
  initUniques();
  initSets();
  initMonsters3();
}
