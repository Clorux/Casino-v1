// Dropcrawl - Diablo-style loot: magic relics with random affixes, uniques and sets, champion and unique monsters,
// loot orbs that drop onto the board, relic shards and shrines.
#include "rules.h"

// ================================================================ magic affixes
static const uint8_t MAGIC_PROPS[] = {
    RP_POWER,     RP_ARMOR,    RP_MAXHP,   RP_MAXMP,     RP_MPREGEN,  RP_HPREGEN,    RP_GOLD,      RP_XP,
    RP_DAMAGE,    RP_ELITE,    RP_HEALMUL, RP_BURN,      RP_POISON,   RP_FLAT,       RP_LIFESTEAL, RP_KILLHEAL,
    RP_KILLGOLD,  RP_KILLBLAST, RP_TURNBLOCK, RP_THORNS,  RP_BLEED,    RP_STR,        RP_DEX,       RP_INT,
    RP_VIT,       RP_LCK,      RP_CRITCHANCE, RP_CRITDMG, RP_DODGE,   RP_SPELLDMG,   RP_MAGICFIND, RP_SPECIAL,
    RP_STARTBLOCK, RP_EXECUTE, RP_FIRSTSTRIKE, RP_HOLY,   RP_DISCHARGE, RP_BURNMUL,  RP_CHILLVULN, RP_SCHOOLCOST,
    RP_KILLPOWER, RP_POTIONMUL};
static const int N_MAGIC = sizeof(MAGIC_PROPS) / sizeof(MAGIC_PROPS[0]);

static const char* prefixOf(int p) {
  switch (p) {
    case RP_POWER: return "Heavy";
    case RP_ARMOR: return "Sturdy";
    case RP_MAXHP: return "Hale";
    case RP_MAXMP: return "Mystic";
    case RP_MPREGEN: return "Humming";
    case RP_HPREGEN: return "Mending";
    case RP_GOLD: return "Gilded";
    case RP_XP: return "Sage's";
    case RP_DAMAGE: return "Cruel";
    case RP_ELITE: return "Hunter's";
    case RP_HEALMUL: return "Blessed";
    case RP_BURN: return "Fiery";
    case RP_POISON: return "Venomous";
    case RP_FLAT: return "Sharp";
    case RP_LIFESTEAL: return "Vampiric";
    case RP_KILLHEAL: return "Ghoulish";
    case RP_KILLGOLD: return "Plundering";
    case RP_KILLBLAST: return "Volatile";
    case RP_TURNBLOCK: return "Guarding";
    case RP_THORNS: return "Spiked";
    case RP_BLEED: return "Serrated";
    case RP_STR: return "Mighty";
    case RP_DEX: return "Nimble";
    case RP_INT: return "Clever";
    case RP_VIT: return "Stout";
    case RP_LCK: return "Lucky";
    case RP_CRITCHANCE: return "Keen";
    case RP_CRITDMG: return "Brutal";
    case RP_DODGE: return "Evasive";
    case RP_SPELLDMG: return "Arcane";
    case RP_MAGICFIND: return "Fortunate";
    case RP_SPECIAL: return "Charmed";
    case RP_STARTBLOCK: return "Bulwark";
    case RP_EXECUTE: return "Merciless";
    case RP_FIRSTSTRIKE: return "Swift";
    case RP_HOLY: return "Holy";
    case RP_DISCHARGE: return "Charged";
    case RP_BURNMUL: return "Smoldering";
    case RP_CHILLVULN: return "Frigid";
    case RP_SCHOOLCOST: return "Scholar's";
    case RP_KILLPOWER: return "Bloodthirsty";
    case RP_POTIONMUL: return "Alchemist's";
  }
  return "Strange";
}
static const char* suffixOf(int p) {
  switch (p) {
    case RP_POWER: return "of Power";
    case RP_ARMOR: return "of Warding";
    case RP_MAXHP: return "of Life";
    case RP_MAXMP: return "of the Magi";
    case RP_MPREGEN: return "of Focus";
    case RP_HPREGEN: return "of Regeneration";
    case RP_GOLD: return "of Greed";
    case RP_XP: return "of Learning";
    case RP_DAMAGE: return "of Slaying";
    case RP_ELITE: return "of the Hunt";
    case RP_HEALMUL: return "of Mending";
    case RP_BURN: return "of Embers";
    case RP_POISON: return "of Venom";
    case RP_FLAT: return "of Wounding";
    case RP_LIFESTEAL: return "of the Leech";
    case RP_KILLHEAL: return "of Feasting";
    case RP_KILLGOLD: return "of Plunder";
    case RP_KILLBLAST: return "of Ruin";
    case RP_TURNBLOCK: return "of the Wall";
    case RP_THORNS: return "of Thorns";
    case RP_BLEED: return "of Bleeding";
    case RP_STR: return "of Strength";
    case RP_DEX: return "of the Fox";
    case RP_INT: return "of the Owl";
    case RP_VIT: return "of the Bear";
    case RP_LCK: return "of Fortune";
    case RP_CRITCHANCE: return "of Precision";
    case RP_CRITDMG: return "of Carnage";
    case RP_DODGE: return "of Evasion";
    case RP_SPELLDMG: return "of Sorcery";
    case RP_MAGICFIND: return "of Treasure";
    case RP_SPECIAL: return "of Plenty";
    case RP_STARTBLOCK: return "of the Rampart";
    case RP_EXECUTE: return "of Execution";
    case RP_FIRSTSTRIKE: return "of the Ambush";
    case RP_HOLY: return "of the Light";
    case RP_DISCHARGE: return "of Thunder";
    case RP_BURNMUL: return "of the Pyre";
    case RP_CHILLVULN: return "of Winter";
    case RP_SCHOOLCOST: return "of Study";
    case RP_KILLPOWER: return "of Frenzy";
    case RP_POTIONMUL: return "of Tonics";
  }
  return "of Wonder";
}

Randart makeAffixes(uint32_t seed, int rl) {
  Randart r;
  r.seed = seed;
  r.n = 0;
  if (!seed || rl < 0 || rl >= RL_COUNT) return r;
  int depth = (int)(seed & 31);
  Rng R((uint64_t)seed * 0x9E3779B97F4A7C15ull + 0x5bd1e995ull + (uint64_t)rl * 7919);
  int n = R.chance(0.35f + 0.012f * depth) ? 2 : 1;
  std::vector<float> wt(N_MAGIC);
  for (int i = 0; i < N_MAGIC; ++i) {
    int p = MAGIC_PROPS[i];
    wt[i] = randPropWeight(p) * ((p >= RP_STR && p <= RP_LCK) ? 1.6f : 1.f);
  }
  for (int k = 0; k < n; ++k) {
    int i = R.weighted(wt);
    if (i < 0) break;
    wt[i] = 0;
    int p = MAGIC_PROPS[i];
    r.prop[r.n] = (uint8_t)p;
    r.val[r.n] = (int8_t)randPropRoll(R, p, depth);
    r.aux[r.n] = (uint8_t)randPropAux(R, p);
    r.n++;
  }
  const char* pre = nullptr;
  const char* suf = nullptr;
  if (r.n >= 2) {
    pre = prefixOf(r.prop[0]);
    suf = suffixOf(r.prop[1]);
  } else if (r.n == 1) {
    if (R.chance(0.5f)) pre = prefixOf(r.prop[0]);
    else suf = suffixOf(r.prop[0]);
  }
  std::string name = std::string(pre ? pre : "") + (pre ? " " : "") + RELIC[rl].name + (suf ? " " : "") + (suf ? suf : "");
  snprintf(r.name, sizeof(r.name), "%s", name.c_str());
  r.color = 0x6aa0ff;
  r.base = 0;
  return r;
}

uint32_t newAffixSeed(World& w) {
  uint32_t x = w.rng.next();
  return (x & ~63u) | (uint32_t)clampv(w.depth, 1, 31);
}

uint32_t rollRelicQuality(World& w, bool boss) {
  float c = 0.22f + 0.015f * w.depth + w.st.magicFind + (boss ? 0.15f : 0.f);
  c = clampv(c, 0.05f, 0.85f);
  return w.rng.chance(c) ? newAffixSeed(w) : 0u;
}

bool isUniqueRelic(int rl) { return rl >= 0 && rl < RL_COUNT && RELIC[rl].tier == 1; }
bool isSetRelic(int rl) { return rl >= 0 && rl < RL_COUNT && RELIC[rl].tier == 2; }

int relicSetCount(const World& w, int set) {
  int n = 0;
  for (auto r : w.pl.relics)
    if (RELIC[r].tier == 2 && RELIC[r].set == set) n++;
  return n;
}

int randomUniqueRelic(World& w) {
  std::vector<int> pool;
  for (int i = 0; i < RL_COUNT; ++i)
    if (RELIC[i].tier == 1 && !hasRelic(w, i)) pool.push_back(i);
  if (pool.empty()) return -1;
  return pool[w.rng.range(0, (int)pool.size() - 1)];
}

int randomRelicFor(World& w, bool boss, bool allowUnique) {
  if (allowUnique) {
    float uc = (boss ? 0.3f : 0.06f) + w.st.magicFind * 0.3f;
    if (w.rng.chance(uc)) {
      int u = randomUniqueRelic(w);
      if (u >= 0) return u;
    }
  }
  std::vector<int> pool;
  std::vector<float> wt;
  for (int i = 0; i < RL_COUNT; ++i) {
    if (hasRelic(w, i) || RELIC[i].tier == 1) continue;
    float x;
    if (RELIC[i].tier == 2) {
      x = 0.7f;
      if (relicSetCount(w, RELIC[i].set) > 0) x = 3.5f;  // sets want to be completed
    } else {
      x = RELIC[i].rarity == R_RARE ? (boss ? 3.f : 1.f) : RELIC[i].rarity == R_UNCOMMON ? 3.f : 4.f;
    }
    pool.push_back(i);
    wt.push_back(x);
  }
  int k = w.rng.weighted(wt);
  return k < 0 ? -1 : pool[k];
}

std::string offerRelicName(int rl, uint32_t seed) {
  if (seed && !isUniqueRelic(rl) && !isSetRelic(rl)) return makeAffixes(seed, rl).name;
  return RELIC[rl].name;
}

const char* RELIC_SET_NAME[SET_COUNT_RELIC] = {"Tumbler's Motley", "Gambler's Regalia", "Warlord's Panoply", "Archmage's Vestments"};
static const char* SET_BONUS2[SET_COUNT_RELIC] = {
    "The Tumbler watches you (10% of turns) and is kinder.", "+3 Luck, and a Lottery pocket appears on every floor.",
    "+3 Strength and +2 Vitality.", "+3 Intelligence and +1 MP regeneration."};
static const char* SET_BONUS3[SET_COUNT_RELIC] = {
    "Chaos pegs trigger twice, two appear each turn, and whenever the Tumbler meddles your balls gain +5 power.",
    "Slot machine payouts are doubled and a Jackpot peg appears each turn.",
    "Kills give your balls +4 power and heal you for 2.",
    "All abilities cost 1 less MP, and every spell you cast gives your next ball +4 power."};

static std::string setInfo(const World* w, int rl) {
  const RelicDef& d = RELIC[rl];
  if (d.tier != 2) return "";
  int have = w ? relicSetCount(*w, d.set) : 0;
  std::string s = fmt("\n\nSet: %s (%d/3)", RELIC_SET_NAME[d.set], have);
  for (int i = RL_FIRST_SET; i < RL_COUNT; ++i)
    if (RELIC[i].set == d.set && RELIC[i].tier == 2) s += fmt("\n  %s %s", (w && hasRelic(*w, i)) ? "[x]" : "[ ]", RELIC[i].name);
  s += fmt("\n(2) %s\n(3) %s", SET_BONUS2[d.set], SET_BONUS3[d.set]);
  return s;
}

std::string offerRelicDesc(int rl, uint32_t seed) {
  const RelicDef& d = RELIC[rl];
  std::string s = d.desc;
  if (seed && d.tier == 0) s += "\n" + randartDesc(makeAffixes(seed, rl));
  if (d.tier == 1 && d.synergy) s += std::string("\nSynergy: ") + d.synergy;
  if (d.tier == 2) s += setInfo(nullptr, rl);
  return s;
}

std::string relicName(const World& w, int idx) {
  if (idx < 0 || idx >= (int)w.pl.relics.size()) return "";
  if (idx < (int)w.pl.relicAffix.size() && w.pl.relicAffix[idx].n > 0) return w.pl.relicAffix[idx].name;
  return RELIC[w.pl.relics[idx]].name;
}

uint32_t relicNameColor(const World& w, int idx) {
  if (idx < 0 || idx >= (int)w.pl.relics.size()) return 0xffffff;
  int rl = w.pl.relics[idx];
  if (RELIC[rl].tier == 1) return 0xffa838;
  if (RELIC[rl].tier == 2) return 0x5ee06a;
  if (idx < (int)w.pl.relicAffix.size() && w.pl.relicAffix[idx].n > 0) return 0x6aa0ff;
  return 0xe8e8f0;
}

std::string relicTooltip(const World& w, int idx) {
  if (idx < 0 || idx >= (int)w.pl.relics.size()) return "";
  int rl = w.pl.relics[idx];
  const RelicDef& d = RELIC[rl];
  std::string s;
  if (d.tier == 1) s = "Unique relic\n";
  else if (d.tier == 2) s = "Set relic\n";
  else if (idx < (int)w.pl.relicAffix.size() && w.pl.relicAffix[idx].n > 0) s = "Magic relic\n";
  s += d.desc;
  if (idx < (int)w.pl.relicAffix.size() && w.pl.relicAffix[idx].n > 0) s += "\n" + randartDesc(w.pl.relicAffix[idx]);
  if (d.tier == 1 && d.synergy) s += std::string("\n\nSynergy: ") + d.synergy;
  s += setInfo(&w, rl);
  return s;
}

// ================================================================ champions & uniques
const char* AFFIX_NAME[AFFIX_COUNT] = {"Extra Strong", "Extra Fast",   "Stone Skin", "Vampiric",  "Regenerating", "Shielded",
                                       "Teleporting",  "Thorny",       "Cursed",     "Mana Burn", "Splitting",    "Horde",
                                       "Healing Aura", "Multishot",    "Berserker",  "Fire Enchanted", "Cold Enchanted"};
const char* AFFIX_DESC[AFFIX_COUNT] = {
    "Deals 40% more damage.",
    "Acts one turn sooner after every action.",
    "+2 armor and 30% more HP.",
    "Heals itself for the damage it deals.",
    "Regenerates 6% of its max HP every turn.",
    "Gains Block equal to 8% of its max HP every turn.",
    "Teleports away whenever a ball hits it.",
    "You take 2 damage (+1 per 5 depth) whenever your ball hits it.",
    "Curses two pins every turn.",
    "Its attacks burn away 2 MP.",
    "Splits in two when a single hit takes a quarter of its health.",
    "Arrived with a pack of minions.",
    "Heals every other monster 3 (+1 per 4 depth) each turn.",
    "Attacks strike twice, at 60% damage each.",
    "Deals double damage while below half HP.",
    "Its attacks burn through armor.",
    "Its attacks chill your next ball (-2 base power for a turn)."};

std::string monsterName(const Monster& m) {
  const MonDef& d = monLook(m);
  if (m.champ == 2 && m.uname[0]) return m.uname;
  if (m.champ == 1) return std::string("champion ") + d.name;
  return d.name;
}

static void uniqueName(Rng& R, char* out, int n) {
  static const char* A[] = {"Bone", "Gore", "Rot",  "Grim", "Blood", "Doom", "Rattle", "Snag", "Grub", "Blight", "Bile",
                            "Dread", "Vile", "Mire", "Ash",  "Frost", "Hex",  "Pit",    "Skull", "Wart", "Gloom", "Tallow"};
  static const char* B[] = {"snap", "fang", "maw", "gut", "wick", "claw", "tooth", "grin", "spit", "hide", "chew", "belly", "howl", "brow", "knuckle"};
  static const char* C[] = {"the Hungry", "the Vile", "the Unclean", "the Cursed", "the Wretched", "the Mad", "the Cruel",
                            "the Grim", "the Greedy", "Pit-Born", "the Hollow", "the Loud", "the Sly", "the Undying", "the Rotten"};
  std::string s = std::string(A[R.range(0, 21)]) + B[R.range(0, 14)] + " " + C[R.range(0, 14)];
  snprintf(out, n, "%s", s.c_str());
}

void makeChampion(World& w, int mi, bool unique, int forcedAffix) {
  Floor& f = w.fl;
  if (mi < 0 || mi >= (int)f.mons.size()) return;
  Monster& m = f.mons[mi];
  if (m.dead || m.boss || m.champ) return;
  const MonDef& d = MON[m.def];
  m.champ = unique ? 2 : 1;
  int n = unique ? f.rng.range(2, 3) : 1;
  std::vector<float> wt(AFFIX_COUNT, 1.f);
  if (d.traits & TR_STATIONARY) wt[AF_TELEPORT] = 0;
  if (d.traits & TR_SPLITHIT) wt[AF_SPLITTING] = 0;
  if (d.traits & TR_LIFESTEAL) wt[AF_VAMPIRIC] = 0;
  if (m.elite) wt[AF_HORDE] = 0.3f;
  if (w.depth < 4) wt[AF_FAST] = wt[AF_MULTISHOT] = 0.4f;
  if (forcedAffix >= 0 && forcedAffix < AFFIX_COUNT) {
    m.affix |= 1u << forcedAffix;
    wt[forcedAffix] = 0;
    n--;
  }
  for (int k = 0; k < n; ++k) {
    int a = f.rng.weighted(wt);
    if (a < 0) break;
    wt[a] = 0;
    m.affix |= 1u << a;
  }
  float hpMul = unique ? 2.0f : 1.4f;
  if (hasAffix(m, AF_STONESKIN)) {
    hpMul *= 1.3f;
    m.armor += 2;
  }
  m.maxHp = std::max(1, (int)std::lround(m.maxHp * hpMul));
  m.hp = m.maxHp;
  m.hpDisp = (float)m.hp;
  if (unique) uniqueName(f.rng, m.uname, sizeof(m.uname));
  if (hasAffix(m, AF_FAST)) m.cd = std::max(1, m.cd - 1);
  V2 pos = m.p;
  if (hasAffix(m, AF_HORDE)) {
    for (int k = 0; k < 2; ++k) {
      int cl = freeClearing(w, pos, false);
      if (cl < 0) break;
      int def = randomRosterMonster(w, -1);
      int ni = spawnMonster(w, def, cl, true);
      if (ni >= 0) {
        f.mons[ni].moveFrom = pos;
        f.mons[ni].moveT = w.quiet ? 1.f : 0.f;
      }
    }
  }
}

static void spawnTreasureImp(World& w) {
  Floor& f = w.fl;
  int cl = freeClearing(w, V2(-1, -1), true);
  if (cl < 0) return;
  int mi = spawnMonster(w, M_TREASURE, cl, false);
  if (mi < 0) return;
  f.mons[mi].escapeT = 4;
  logMsg(w, 0xffd040, "A treasure imp is here! Kill it before it escapes with its loot.");
}

void rollChampions(World& w) {
  Floor& f = w.fl;
  const FloorSpec& sp = f.spec;
  if (sp.kind == FK_BOSS || sp.kind == FK_VAULT) return;
  int depth = sp.depth;
  std::vector<int> cand;
  for (int i = 0; i < (int)f.mons.size(); ++i)
    if (!f.mons[i].dead && !f.mons[i].summoned && !f.mons[i].boss && f.mons[i].def != M_TREASURE) cand.push_back(i);
  if (cand.empty()) return;
  if (sp.kind == FK_ELITE) {
    // the elite may be a champion too
    if (depth >= 3 && f.rng.chance(0.3f)) makeChampion(w, cand[0], false);
  } else if (depth >= 2) {
    float c = 0.2f + 0.012f * depth + 0.05f * w.descent;
    if (f.rng.chance(c)) {
      int mi = cand[f.rng.range(0, (int)cand.size() - 1)];
      bool uni = depth >= 4 && f.rng.chance(0.3f + 0.01f * depth);
      makeChampion(w, mi, uni);
      if (!w.quiet) {
        const Monster& m = f.mons[mi];
        std::string af;
        for (int a = 0; a < AFFIX_COUNT; ++a)
          if (hasAffix(m, a)) af += (af.empty() ? "" : ", ") + std::string(AFFIX_NAME[a]);
        logMsg(w, uni ? 0xffc040 : 0x6aa0ff, "%s %s is here! (%s)", uni ? "The unique monster" : "A", monsterName(m).c_str(), af.c_str());
      }
    }
  }
  if (sp.kind == FK_NORMAL && depth >= 2) {
    float ic = 0.07f;
    if (hasRelic(w, RL_U_GOBLINSACK)) ic *= 3.f;
    if (f.rng.chance(ic)) spawnTreasureImp(w);
  }
}

void champTurn(World& w, int mi) {
  Floor& f = w.fl;
  Monster& m = f.mons[mi];
  if (m.dead || !m.affix || m.charmed) return;
  if (hasAffix(m, AF_REGEN) && m.hp < m.maxHp && m.corruptT <= 0) {
    int h = std::min(m.maxHp - m.hp, std::max(1, m.maxHp * 6 / 100));
    m.hp += h;
    fxText(w, m.p + V2(0, -m.r - 8), 0x70ff90, fmt("+%d", h), 13);
  }
  if (hasAffix(m, AF_SHIELDED)) m.shield += std::max(2, m.maxHp * 8 / 100);
  if (hasAffix(m, AF_CURSED) && !w.st.warded) convertPins(w, PK_CURSE, 2);
  if (hasAffix(m, AF_AURA)) {
    int amt = 3 + w.depth / 4;
    for (int j = 0; j < (int)f.mons.size(); ++j) {
      Monster& o = f.mons[j];
      if (j == mi || o.dead || o.charmed || o.corruptT > 0 || o.hp >= o.maxHp) continue;
      int h = std::min(amt, o.maxHp - o.hp);
      o.hp += h;
      fxText(w, o.p + V2(0, -o.r - 8), 0x70ff90, fmt("+%d", h), 13);
    }
  }
  Monster& mm = f.mons[mi];
  if (hasAffix(mm, AF_BERSERK) && mm.hp * 2 < mm.maxHp && !mm.enraged) {
    mm.enraged = true;
    fxText(w, mm.p + V2(0, -mm.r - 10), 0xff4040, "berserk!", 14);
  }
}

// ================================================================ loot orbs
static const int LOOT_ITEMS[] = {IT_HEALING, IT_HEALING, IT_MANA, IT_MIGHT, IT_RESIST, IT_FEAR, IT_IMMOLATION, IT_ENCHANT,
                                 IT_TELEPORT, IT_VULN, IT_BRAND, IT_LUCK, IT_FLIGHT, IT_UPHEAVAL, IT_BUTTERFLIES, IT_AMBROSIA,
                                 IT_W_FLAME, IT_W_ICE, IT_W_LIGHTNING, IT_W_PARALYSIS, IT_W_ROOTS, IT_BRILLIANCE, IT_CANCEL};
static const int N_LOOT_ITEMS = sizeof(LOOT_ITEMS) / sizeof(LOOT_ITEMS[0]);

static int upgradeTier(World& w, int tier) {
  float up = 0.12f + w.st.magicFind * 0.5f;
  if (w.st.lootUp) up += 0.2f;
  while (tier < 3 && w.fl.rng.chance(up)) {
    tier++;
    up *= 0.35f;
  }
  return tier;
}

void dropLoot(World& w, V2 pos, int tier) {
  Floor& f = w.fl;
  tier = clampv(upgradeTier(w, tier), 0, 3);
  for (int t = 0; t < 60; ++t) {
    V2 p = pos + (t == 0 ? V2(0, 0) : fromAng(f.rng.rangef(0, TAU)) * f.rng.rangef(10, 70 + t * 2));
    if (p.x < PX0 + 20 || p.x > PX1 - 20 || p.y < FIELD_Y0 + 10 || p.y > FIELD_Y1 - 10) continue;
    if (!spotFree(w, p, 10, 4)) continue;
    int pi = addPeg(w, PK_LOOT, p, 10);
    if (pi < 0) break;
    f.pegs[pi].val = tier;
    f.lootDropped++;
    fxBurst(w, p, tier == 3 ? 0xffa838 : tier == 2 ? 0xffe060 : tier == 1 ? 0x6aa0ff : 0xe8e8f0, 20, 160, 3);
    if (tier >= 2) fxSound(w, S_CHEST, 0.6f, 1.6f, p.x);
    return;
  }
  // no room on the board: grab it straight away
  int pi = addPeg(w, PK_LOOT, V2(-100, -100), 1);
  if (pi >= 0) {
    f.pegs[pi].val = tier;
    collectLoot(w, pi, true);
  }
}

void collectLoot(World& w, int pi, bool swept) {
  Floor& f = w.fl;
  if (pi < 0 || pi >= (int)f.pegs.size() || f.pegs[pi].dead || f.pegs[pi].kind != PK_LOOT) return;
  Peg& p = f.pegs[pi];
  p.dead = true;
  int tier = clampv(p.val, 0, 3);
  V2 at = p.p;
  if (at.x < 0) at = V2(800, 400);
  switch (tier) {
    case 0: {
      if (f.rng.chance(0.55f)) {
        int it = LOOT_ITEMS[f.rng.range(0, N_LOOT_ITEMS - 1)];
        if (gainItem(w, it)) {
          logMsg(w, ITEM[it].color, "Loot: %s.", ITEM[it].name);
          fxText(w, at + V2(0, -16), ITEM[it].color, ITEM[it].name, 14);
          w.rewardItems.push_back(it);
          break;
        }
      }
      int g = 15 + 3 * w.depth;
      gainGold(w, g, at);
      if (!swept) fxText(w, at + V2(0, -16), 0xffd040, fmt("+%d gold", g), 14);
      break;
    }
    case 1: {
      int rl = randomRelicFor(w, false, false);
      if (rl >= 0) {
        uint32_t seed = RELIC[rl].tier == 0 ? newAffixSeed(w) : 0u;
        gainRelic(w, rl, seed);
        fxBanner(w, "Loot: " + offerRelicName(rl, seed), 0x6aa0ff);
      } else gainGold(w, 60, at);
      break;
    }
    case 2:
      gainRandart(w, newRandartSeed(w));
      fxBanner(w, "Loot: a randart!", 0xffe060);
      break;
    default: {
      int u = randomUniqueRelic(w);
      if (u >= 0) {
        gainRelic(w, u, 0);
        fxBanner(w, std::string("UNIQUE: ") + RELIC[u].name, 0xffa838);
      } else gainRandart(w, newRandartSeed(w));
      break;
    }
  }
  fxBurst(w, at, tier == 3 ? 0xffa838 : tier == 2 ? 0xffe060 : tier == 1 ? 0x6aa0ff : 0xe8e8f0, 26, 200, 3);
  fxSound(w, S_COIN, 0.7f, 1.2f + 0.1f * tier, at.x);
}

void sweepLoot(World& w) {
  Floor& f = w.fl;
  bool any = false;
  for (int i = 0; i < (int)f.pegs.size(); ++i)
    if (!f.pegs[i].dead && f.pegs[i].kind == PK_LOOT) {
      collectLoot(w, i, true);
      any = true;
    }
  if (any) logMsg(w, 0xd0d8e8, "You gather up the remaining loot.");
}

void lootPegTick(World&) {}

void monsterDiedLoot(World& w, const Monster& m, V2 pos) {
  Floor& f = w.fl;
  if (f.isVault) return;
  float mul = w.st.lootMul * (hasRelic(w, RL_U_GOBLINSACK) ? 2.f : 1.f);
  if (m.def == M_TREASURE) {
    int n = f.rng.range(2, 3);
    for (int k = 0; k < n; ++k) dropLoot(w, pos, k == 0 ? 1 : 0);
    gainGold(w, 40 + 6 * w.depth, pos);
    fxBanner(w, "Treasure imp slain!", 0xffd040);
    return;
  }
  if (m.def == M_MIMIC) {
    dropLoot(w, pos, f.rng.chance(0.35f) ? 2 : 1);
    return;
  }
  if (m.summoned && !m.champ) return;
  if (m.champ == 2) {
    dropLoot(w, pos, 1);
    if (f.rng.chance(0.35f * mul)) dropLoot(w, pos, 0);
  } else if (m.champ == 1) {
    dropLoot(w, pos, f.rng.chance(0.4f) ? 1 : 0);
  } else if (!m.boss && !m.elite && f.rng.chance(0.035f * mul)) {
    dropLoot(w, pos, 0);
  }
}

// ================================================================ shards
void gainShard(World& w, int n) {
  if (n <= 0) return;
  w.pl.shards += n;
  fxText(w, V2(200, 150), 0xd0a0ff, fmt("+%d relic shard%s", n, n > 1 ? "s" : ""), 15);
  logMsg(w, 0xd0a0ff, "You find a relic shard (%d/3).", std::min(3, w.pl.shards));
  if (w.pl.shards >= 3 && w.relicOffers.empty()) {
    w.pl.shards -= 3;
    for (int k = 0; k < 3; ++k) {
      int rl = randomRelicFor(w, k == 0, true);
      if (rl < 0) break;
      bool dup = false;
      for (auto& o : w.relicOffers)
        if (o.type == 1 && o.id == rl) dup = true;
      if (dup) continue;
      Offer o;
      o.type = 1;
      o.id = rl;
      o.seed = (RELIC[rl].tier == 0 && (k == 0 || w.rng.chance(0.4f))) ? newAffixSeed(w) : 0u;
      w.relicOffers.push_back(o);
    }
    fxBanner(w, "The shards fuse into a relic!", 0xd0a0ff);
    fxSound(w, S_CHEST, 1.f, 1.1f);
  }
}

// ================================================================ shrines
const char* SHRINE_NAME[SHRINE_COUNT] = {"Blessed Shrine", "Shrine of Fortune", "Enlightened Shrine", "Frenzied Shrine", "Shrine of Protection",
                                         "Mana Shrine",    "Empowered Shrine",  "Gifted Shrine",      "Bountiful Shrine", "Stone Shrine"};
const char* SHRINE_DESC[SHRINE_COUNT] = {"+30% ball damage for the rest of this floor.",
                                         "+60% gold for the rest of this floor.",
                                         "+50% XP for the rest of this floor.",
                                         "Pins grant +1 extra power for the rest of this floor.",
                                         "+4 Block (+1 per 4 depth) at the start of every turn on this floor.",
                                         "+1 MP regeneration and spells cost 1 less MP on this floor.",
                                         "All cooldowns reset now, and recharge 1 turn faster on this floor.",
                                         "+2 to every stat for the rest of this floor.",
                                         "+2 Crit, Gold and Heal pegs every turn on this floor.",
                                         "+3 armor for the rest of this floor."};

void activateShrine(World& w, int kind, V2 at) {
  Floor& f = w.fl;
  kind = clampv(kind, 0, SHRINE_COUNT - 1);
  f.shrine = kind;
  if (kind == 6)
    for (auto& a : w.pl.abil) a.cd = 0;
  recalcStats(w);
  logMsg(w, 0xfff0c0, "%s: %s", SHRINE_NAME[kind], SHRINE_DESC[kind]);
  fxBanner(w, SHRINE_NAME[kind], 0xfff0c0);
  fxRing(w, at, 160, 0xfff0c0);
  fxBurst(w, at, 0xfff0c0, 40, 260, 4);
  fxSound(w, S_LEVEL, 0.8f, 1.1f, at.x);
  if (w.pl.patron == PT_AURELIA || w.pl.patron == PT_SIFRA) gainPiety(w, 3);
}

// ================================================================ relic offers (rewards, shards, scrolls)
void pushRelicOffersN(World& w, int n, bool boss, bool allowUnique) {
  bool uniqueUsed = false;
  for (int k = 0, guard = 0; k < n && guard < 40; ++guard) {
    int rl = randomRelicFor(w, boss, allowUnique && !uniqueUsed);
    if (rl < 0) break;
    bool dup = false;
    for (auto& o : w.relicOffers)
      if (o.type == 1 && o.id == rl) dup = true;
    if (dup) continue;
    if (RELIC[rl].tier == 1) uniqueUsed = true;
    Offer o;
    o.type = 1;
    o.id = rl;
    o.seed = RELIC[rl].tier == 0 ? rollRelicQuality(w, boss) : 0u;
    w.relicOffers.push_back(o);
    k++;
  }
}
