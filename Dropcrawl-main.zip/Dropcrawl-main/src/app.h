// Dropcrawl - application / UI layer
#pragma once
#include "game.h"
#include "gfx.h"
#include "audio.h"

enum UiScreen { UI_TITLE, UI_NEWRUN, UI_GAME, UI_HALL, UI_HELP, UI_SETTINGS };

// virtual key codes used by the UI (match Win32 VK_*)
constexpr int KEY_ESC = 0x1B, KEY_SPACE = 0x20, KEY_TAB = 0x09, KEY_ENTER = 0x0D, KEY_BACK = 0x08;
constexpr int KEY_LEFT = 0x25, KEY_RIGHT = 0x27, KEY_F11 = 0x7A, KEY_F12 = 0x7B;

// ability hotkeys: 1-9, then 0, - and = for a 10th to 12th ability
constexpr int MAX_ABILITY_KEYS = 12;
inline const char* const ABILITY_KEY_LABEL[MAX_ABILITY_KEYS] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-", "="};
inline constexpr int ABILITY_KEY_VK[MAX_ABILITY_KEYS] = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 0xBD, 0xBB};

struct Input {
  V2 mouse;
  bool lDown = false, rDown = false;
  bool lPressed = false, lReleased = false, rPressed = false;
  float wheel = 0;
  bool keyDown[256] = {};
  bool keyPressed[256] = {};
  std::string chars;
  bool consumed = false;   // a widget used this frame's click
  void endFrame() {
    lPressed = lReleased = rPressed = false;
    wheel = 0;
    for (auto& k : keyPressed) k = false;
    chars.clear();
    consumed = false;
  }
};

struct Particle {
  V2 p, v;
  float life = 1, maxLife = 1, size = 3;
  uint32_t col = 0xffffff;
  uint8_t kind = 0;  // 0 spark, 1 glow dot, 2 coin
};
struct FloatText {
  V2 p;
  std::string s;
  uint32_t col = 0xffffff;
  float life = 1, maxLife = 1, size = 16;
};
struct ZapFx {
  std::vector<V2> pts;
  uint32_t col = 0xffffff;
  float life = 0.3f;
};
struct RingFx {
  V2 p;
  float r = 40, life = 0.5f, maxLife = 0.5f;
  uint32_t col = 0xffffff;
};
struct BannerFx {
  std::string s;
  uint32_t col = 0xffffff;
  float life = 2.f;
};
struct ShotFx {  // monster attack projectile toward the HP bar
  V2 from, to;
  float t = 0;
  uint32_t col = 0xff4040;
};
struct Trail {
  int id = 0;
  std::vector<V2> pts;
  float fade = 1;
  bool seen = false;
};

struct Settings {
  float master = 0.8f, sfx = 0.8f, music = 0.45f;
  bool shake = true, numbers = true, fullscreen = false;
  int speed = 1;  // 1 or 2 (default speed multiplier)
  int maxDescent = 0;  // highest unlocked descent level
  bool tutorialDone = false;  // the first-floor hints have been shown (they only ever appear on one run)
};

struct Tooltip {
  bool active = false;
  std::string title, body;
  uint32_t col = 0xffffff;
};

struct ScoreEntry {
  int score = 0;
  std::string line;
};

struct App {
  Gfx g;
  World w;
  UiScreen ui = UI_TITLE;
  UiScreen settingsReturn = UI_TITLE;
  Input in;
  Settings set;
  bool quit = false;
  bool paused = false;
  bool confirmAbandon = false;
  bool hasSave = false;
  float time = 0;          // real time
  float simAcc = 0;
  bool fastToggle = false;
  // presentation
  std::vector<Particle> parts;
  std::vector<FloatText> texts;
  std::vector<ZapFx> zaps;
  std::vector<RingFx> rings;
  std::vector<BannerFx> banners;
  std::vector<ShotFx> attacks;
  std::vector<Trail> trails;
  float shake = 0;
  V2 shakeOff;
  float hpFlash = 0;
  float deathT = 0;
  bool deathHandled = false;
  // aiming / targeting
  float aimAngle = PI / 2;
  std::vector<V2> preview;
  int targetAb = -1, targetItem = -1, targetStage = 0;
  V2 targetP1;
  int hoverMon = -1;
  int trainShop = -1;      // shop "training" entry being used
  bool restTrain = false;
  bool tutorialRun = false;  // this run shows the first-floor hints
  bool invokeOpen = false;   // the invocations window (G)
  // new run
  int selSpecies = 0, selBg = 0, selDescent = 0;
  std::string seedText;
  bool seedFocus = false;
  // screens
  int helpPage = 0;
  float logScroll = 0;
  Tooltip tip;
  std::vector<ScoreEntry> scores;
  std::wstring baseDir;
  std::string lastMorgue;
  // title demo
  World demo;
  bool demoReady = false;
  float demoAimT = 0;
  Rng demoRng;
  // screenshot request
  std::wstring pendingShot;
};

// ui_common.cpp
bool mouseIn(const App& a, float x, float y, float w, float h);
bool button(App& a, float x, float y, float w, float h, const std::string& label, bool enabled = true, uint32_t accent = 0x8fb3ff,
            float fontSize = 16);
void panelBox(App& a, float x, float y, float w, float h, uint32_t accent, float alpha = 0.92f);
void setTip(App& a, const std::string& title, const std::string& body, uint32_t col = 0xffffff);
void drawTooltip(App& a);
void drawIcon(Gfx& g, int intent, V2 c, float s, uint32_t col, float alpha = 1.f);
void drawPeg(App& a, const Peg& p, float alpha, uint32_t pinCol);
void drawMonsterBody(App& a, const Monster& m, V2 pos, float alpha);
void playFx(App& a, World& w, bool sounds);
void updatePresentation(App& a, float dt);
void drawPresentation(App& a, bool boardClip);
void clearPresentation(App& a);
uint32_t powerColor(int power);
std::string withArticle(const std::string& name);
float textH(App& a, const std::string& s, float size, float width, int font = F_UI);

// ui_board.cpp
void drawBoard(App& a, World& w, bool interactive);
void boardInput(App& a);
void computePreview(App& a);

// ui_panels.cpp
void drawLeftPanel(App& a);
void drawRightPanel(App& a);
std::vector<int> activeList(const World& w);   // castable abilities in hotkey order (never invocations)
std::vector<int> invocationList(const World& w);  // unlocked invocations of your god, in gift order
void drawInvocations(App& a);                  // the invocations window
void tryCast(App& a, int ab, bool fromHotkey);
void tryUseItem(App& a, int slot);

// ui_screens.cpp
void drawTitle(App& a);
void drawNewRun(App& a);
void drawGame(App& a);
void drawHall(App& a);
void drawHelp(App& a);
void drawSettings(App& a);
void startNewRun(App& a, uint64_t seed);
void loadScores(App& a);

// main.cpp
uint64_t tickCount();
void saveSettings(App& a);
void applySettings(App& a);
void writeSave(App& a);
void deleteSave(App& a);
bool tryContinue(App& a);
void recordRunEnd(App& a);
void setFullscreen(App& a, bool on);
