// Dropcrawl - Direct2D / DirectWrite renderer wrapper
#pragma once
#include "common.h"
#include <unordered_map>

struct ID2D1Factory;
struct ID2D1RenderTarget;
struct ID2D1HwndRenderTarget;
struct ID2D1DeviceContext;
struct ID2D1SolidColorBrush;
struct ID2D1RadialGradientBrush;
struct ID2D1LinearGradientBrush;
struct ID2D1StrokeStyle;
struct IDWriteFactory;
struct IDWriteTextFormat;
struct IWICImagingFactory;
struct IWICBitmap;
typedef struct HWND__* HWND;

enum GFont { F_UI = 0, F_UIB, F_MONO, F_MONOB, F_SYM, F_TITLE, F_COUNT };
enum GAlign { AL_L = 0, AL_C = 1, AL_R = 2 };
enum GVAlign { VA_T = 0, VA_M = 1, VA_B = 2 };

struct Xf {  // 2D affine transform (matches D2D1_MATRIX_3X2_F layout)
  float m11 = 1, m12 = 0, m21 = 0, m22 = 1, dx = 0, dy = 0;
  static Xf translate(float x, float y) { Xf t; t.dx = x; t.dy = y; return t; }
  static Xf scale(float s, float cx = 0, float cy = 0) { Xf t; t.m11 = s; t.m22 = s; t.dx = cx - s * cx; t.dy = cy - s * cy; return t; }
  static Xf rotate(float ang, float cx = 0, float cy = 0) {
    Xf t; float c = std::cos(ang), s = std::sin(ang);
    t.m11 = c; t.m12 = s; t.m21 = -s; t.m22 = c;
    t.dx = cx - (c * cx - s * cy); t.dy = cy - (s * cx + c * cy);
    return t;
  }
  Xf operator*(const Xf& b) const {  // this then b
    Xf r;
    r.m11 = m11 * b.m11 + m12 * b.m21; r.m12 = m11 * b.m12 + m12 * b.m22;
    r.m21 = m21 * b.m11 + m22 * b.m21; r.m22 = m21 * b.m12 + m22 * b.m22;
    r.dx = dx * b.m11 + dy * b.m21 + b.dx; r.dy = dx * b.m12 + dy * b.m22 + b.dy;
    return r;
  }
  V2 apply(V2 p) const { return {p.x * m11 + p.y * m21 + dx, p.x * m12 + p.y * m22 + dy}; }
};

struct Gfx {
  // device independent
  ID2D1Factory* factory = nullptr;
  IDWriteFactory* dw = nullptr;
  IWICImagingFactory* wic = nullptr;
  ID2D1StrokeStyle* roundStroke = nullptr;
  IDWriteTextFormat* formats[F_COUNT][64] = {};  // indexed by font, size bucket
  // device dependent
  HWND hwnd = nullptr;
  ID2D1RenderTarget* rt = nullptr;
  ID2D1HwndRenderTarget* hrt = nullptr;
  ID2D1DeviceContext* dc = nullptr;
  IWICBitmap* wicBmp = nullptr;
  ID2D1SolidColorBrush* brush = nullptr;
  std::unordered_map<uint32_t, ID2D1RadialGradientBrush*> glows;
  std::unordered_map<uint64_t, ID2D1LinearGradientBrush*> lins;
  int pixW = 0, pixH = 0;
  // view transform (logical -> pixels)
  float viewScale = 1, viewX = 0, viewY = 0;
  float logicalW = 1600, logicalH = 900;
  std::vector<Xf> xstack;
  Xf cur;
  int clipDepth = 0;
  bool inFrame = false;

  bool initFactories();
  bool initWindow(HWND h);
  bool initOffscreen(int w, int h);
  void resize(int w, int h);
  bool createDeviceResources();
  void releaseDeviceResources();
  void shutdown();

  bool beginFrame();
  void endFrame();
  bool savePng(const std::wstring& path);

  // coordinate helpers
  V2 toLogical(float px, float py) const { return {(px - viewX) / viewScale, (py - viewY) / viewScale}; }
  void pushXf(const Xf& local);
  void popXf();
  void applyXf();
  void pushClip(float x, float y, float w, float h);
  void popClip();
  void additive(bool on);

  // primitives (logical coords; alpha 0..1)
  void clear(uint32_t col);
  void fillRect(float x, float y, float w, float h, uint32_t col, float a = 1);
  void rect(float x, float y, float w, float h, uint32_t col, float a = 1, float width = 1);
  void fillRRect(float x, float y, float w, float h, float r, uint32_t col, float a = 1);
  void rrect(float x, float y, float w, float h, float r, uint32_t col, float a = 1, float width = 1);
  void fillCircle(V2 c, float r, uint32_t col, float a = 1);
  void fillEllipse(V2 c, float rx, float ry, uint32_t col, float a = 1);
  void circle(V2 c, float r, uint32_t col, float a = 1, float width = 1);
  void line(V2 p0, V2 p1, uint32_t col, float a = 1, float width = 1, bool round = true);
  void glow(V2 c, float r, uint32_t col, float a = 1);
  void fillPoly(const V2* pts, int n, uint32_t col, float a = 1);
  void strokePoly(const V2* pts, int n, uint32_t col, float a = 1, float width = 1, bool closed = true);
  void arc(V2 c, float r, float a0, float a1, uint32_t col, float a = 1, float width = 2);
  void vgrad(float x, float y, float w, float h, uint32_t top, uint32_t bot, float a = 1);

  // text
  IDWriteTextFormat* fmtFor(int font, float size);
  void text(const std::string& s, float x, float y, float w, float h, float size, uint32_t col, float a = 1,
            int font = F_UI, int align = AL_L, int valign = VA_T);
  void textSh(const std::string& s, float x, float y, float w, float h, float size, uint32_t col, float a = 1,
              int font = F_UI, int align = AL_L, int valign = VA_T);
  V2 measure(const std::string& s, float size, int font = F_UI, float maxW = 10000);
};

std::wstring widen(const std::string& s);
