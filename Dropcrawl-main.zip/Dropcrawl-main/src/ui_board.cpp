// Dropcrawl - board rendering and board interaction
#include "app.h"

extern bool g_ghostSolid;

static float easeOut(float t) { return 1.f - (1.f - t) * (1.f - t); }

static V2 monPos(const Monster& m) { return lerpv(m.moveFrom, m.p, easeOut(clampv(m.moveT, 0.f, 1.f))); }

static bool guideHidden(const World& w) { return w.fl.blindTurns > 0 || w.st.hideGuide; }

void computePreview(App& a) {
  World& w = a.w;
  Floor& f = w.fl;
  a.preview.clear();
  int bounces = w.st.preview + f.revealBonus;
  bool aimNow = (f.phase == PH_AIM && a.targetAb < 0 && a.targetItem < 0) || f.phase == PH_RELAUNCH;
  if (aimNow && guideHidden(w)) {
    V2 o = launcherPos();
    a.preview.push_back(o + fromAng(a.aimAngle) * 26);
    a.preview.push_back(o + fromAng(a.aimAngle) * 90);
    return;
  }
  if (aimNow) {
    previewPath(w, a.aimAngle, f.launchSpeed, bounces, a.preview, launcherPos());
  } else if (f.phase == PH_REDIRECT) {
    for (auto& b : f.balls)
      if (b.alive) {
        V2 o = b.p - fromAng(a.aimAngle) * 26;
        previewPath(w, a.aimAngle, std::max(650.f, len(b.v)), bounces, a.preview, o);
        break;
      }
  }
}

static void drawZone(App& a, const World& w, const Zone& z) {
  Gfx& g = a.g;
  float t = a.time;
  switch (z.kind) {
    case ZK_WATER: {
      g.fillRect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 0x2a78d0, 0.2f);
      float top = z.p.y - z.half.y;
      V2 prev(z.p.x - z.half.x, top);
      for (float x = z.p.x - z.half.x + 12; x <= z.p.x + z.half.x; x += 12) {
        V2 cur(x, top + std::sin(x * 0.05f + t * 2.f) * 2.5f);
        g.line(prev, cur, 0x8fd0ff, 0.5f, 1.5f);
        prev = cur;
      }
      break;
    }
    case ZK_WIND: {
      g.fillRect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 0xc0e0ff, 0.035f);
      float span = z.half.x * 2;
      for (int row = 0; row < 4; ++row) {
        float yy = z.p.y - z.half.y + (row + 0.5f) * z.half.y * 0.5f;
        for (int k = 0; k < 6; ++k) {
          float ph = std::fmod(t * 120.f * z.dir.x + k * span / 6 + row * 37, span);
          if (ph < 0) ph += span;
          float x = z.p.x - z.half.x + ph;
          V2 c(x, yy);
          g.line(c - V2(z.dir.x * 14, 0), c, 0xd8ecff, 0.18f, 1.5f);
          g.line(c, c + V2(-z.dir.x * 5, -4), 0xd8ecff, 0.18f, 1.5f);
          g.line(c, c + V2(-z.dir.x * 5, 4), 0xd8ecff, 0.18f, 1.5f);
        }
      }
      break;
    }
    case ZK_WELL: {
      bool sink = z.link == -9;
      g.fillCircle(z.p, z.half.x, sink ? 0x4a3010 : 0x1a4a80, 0.15f);
      for (int k = 0; k < 3; ++k) {
        float rr = z.half.x * (0.35f + 0.22f * k);
        float a0 = -t * (2.5f - k * 0.5f) + k;
        g.arc(z.p, rr, a0, a0 + PI * 1.1f, sink ? 0xc8a070 : 0x70c8ff, 0.35f, 2);
      }
      if (z.ttl > 0) g.text(std::to_string(z.ttl), z.p.x - 10, z.p.y - 8, 20, 16, 11, 0xffffff, 0.7f, F_MONOB, AL_C, VA_M);
      break;
    }
    case ZK_REPULSE: g.circle(z.p, z.half.x, 0xff80ff, 0.2f, 1.5f); break;
    case ZK_LAVA: {
      a.g.additive(true);
      g.glow(z.p, std::max(z.half.x, z.half.y) * 1.3f, 0xff5010, 0.25f);
      a.g.additive(false);
      g.fillRRect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 6, 0xd04010, 0.45f);
      for (int k = 0; k < 5; ++k) {
        float bx = z.p.x - z.half.x + std::fmod(k * 53.f + t * 7.f, z.half.x * 2);
        float by = z.p.y + z.half.y - std::fmod(t * 20.f + k * 17.f, z.half.y * 2);
        g.fillCircle(V2(bx, by), 2.5f, 0xffc040, 0.6f);
      }
      break;
    }
    case ZK_BOOST: {
      g.fillCircle(z.p, z.half.x, 0x40ffb0, 0.12f);
      g.circle(z.p, z.half.x, 0x60ffc0, 0.55f, 1.5f);
      V2 tip = z.p + z.dir * (z.half.x * 0.7f);
      g.line(z.p - z.dir * (z.half.x * 0.6f), tip, 0x80ffd0, 0.8f, 3);
      g.line(tip, tip - rot(z.dir, 0.6f) * 8, 0x80ffd0, 0.8f, 3);
      g.line(tip, tip - rot(z.dir, -0.6f) * 8, 0x80ffd0, 0.8f, 3);
      break;
    }
    case ZK_PORTAL:
    case ZK_RIFT: {
      bool rift = z.kind == ZK_RIFT;
      bool entry = z.link >= 0;
      uint32_t col = rift ? 0xb060ff : (entry ? 0x50a8ff : 0xffa040);
      a.g.additive(true);
      g.glow(z.p, z.half.x * 2.f, col, 0.5f);
      a.g.additive(false);
      for (int k = 0; k < 2; ++k) {
        float a0 = t * (entry ? 3.f : -3.f) + k * PI;
        g.arc(z.p, z.half.x, a0, a0 + PI * 0.8f, col, 0.9f, 3);
      }
      g.fillCircle(z.p, z.half.x * 0.5f, 0x05060a, 0.8f);
      if (z.ttl > 0) g.text(std::to_string(z.ttl), z.p.x - 10, z.p.y - 8, 20, 16, 11, 0xffffff, 0.8f, F_MONOB, AL_C, VA_M);
      break;
    }
    case ZK_CONVEYOR: {
      g.fillRRect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 4, 0x3a3020, 0.55f);
      float sp = z.dir.x > 0 ? 1.f : -1.f;
      for (float x = -z.half.x + 6; x < z.half.x - 6; x += 18) {
        float xx = z.p.x + std::fmod(x + z.half.x + sp * t * 60.f + z.half.x * 4, z.half.x * 2) - z.half.x;
        g.line(V2(xx - sp * 4, z.p.y - z.half.y + 4), V2(xx + sp * 3, z.p.y), 0xe0b060, 0.6f, 2);
        g.line(V2(xx + sp * 3, z.p.y), V2(xx - sp * 4, z.p.y + z.half.y - 4), 0xe0b060, 0.6f, 2);
      }
      g.rrect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 4, 0xc0a060, 0.6f, 1.2f);
      break;
    }
    case ZK_ANTIGRAV: {
      g.fillCircle(z.p, z.half.x, 0x80a0ff, 0.1f);
      g.circle(z.p, z.half.x, 0xa0c0ff, 0.4f, 1.5f);
      for (int k = 0; k < 5; ++k) {
        float ph = std::fmod(t * 0.7f + k * 0.2f, 1.f);
        V2 c = z.p + V2((k - 2) * z.half.x * 0.3f, z.half.x * 0.6f - ph * z.half.x * 1.2f);
        g.fillCircle(c, 2.5f, 0xd0e0ff, 0.6f * (1 - std::fabs(ph - 0.5f) * 2));
      }
      break;
    }
    case ZK_HASTE: {
      g.fillRRect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 6, 0x60ffa0, 0.08f);
      for (int k = 0; k < 4; ++k) {
        float xx = z.p.x - z.half.x + std::fmod(t * 200.f + k * z.half.x * 0.5f, z.half.x * 2);
        g.line(V2(xx - 10, z.p.y), V2(xx, z.p.y), 0x80ffc0, 0.5f, 2);
      }
      g.rrect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 6, 0x60ffa0, 0.4f, 1.2f);
      break;
    }
    case ZK_CHARGE: {
      bool fire = z.dmg == 1;
      uint32_t col = fire ? 0xffa040 : 0xfff080;
      if (z.circle) {
        a.g.additive(true);
        g.glow(z.p, z.half.x * 1.2f, col, 0.25f + 0.1f * std::sin(t * 5));
        a.g.additive(false);
        g.circle(z.p, z.half.x, col, 0.5f, 1.5f);
      } else {
        g.fillRRect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 6, col, 0.1f);
        g.rrect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 6, col, 0.5f, 1.2f);
      }
      for (int k = 0; k < 3; ++k) {
        V2 c = z.p + V2(std::sin(t * 3 + k * 2.1f) * z.half.x * 0.6f, std::cos(t * 2.3f + k) * std::min(z.half.x, z.circle ? z.half.x : z.half.y) * 0.6f);
        g.fillCircle(c, 2, 0xffffff, 0.8f);
      }
      if (z.ttl > 0) g.text(std::to_string(z.ttl), z.p.x - 10, z.p.y - 8, 20, 16, 11, 0xffffff, 0.7f, F_MONOB, AL_C, VA_M);
      break;
    }
    case ZK_MIST: {
      for (int k = 0; k < 6; ++k) {
        V2 c = z.p + fromAng(k * 1.05f + t * 0.3f) * z.half.x * 0.45f;
        g.fillCircle(c, z.half.x * 0.55f, 0x70c030, 0.06f);
      }
      g.circle(z.p, z.half.x, 0x90e040, 0.2f, 1);
      if (z.ttl > 0) g.text(std::to_string(z.ttl), z.p.x - 10, z.p.y - 8, 20, 16, 11, 0xd0ffa0, 0.7f, F_MONOB, AL_C, VA_M);
      break;
    }
    case ZK_SPRING: {
      g.fillCircle(z.p, z.half.x, 0x40c0a0, 0.2f);
      g.circle(z.p, z.half.x, 0x70ffd0, 0.5f, 1.5f);
      for (int k = 0; k < 3; ++k) {
        float ph = std::fmod(t * 0.5f + k / 3.f, 1.f);
        g.circle(z.p, z.half.x * ph, 0xb0fff0, 0.4f * (1 - ph), 1.2f);
      }
      break;
    }
    case ZK_BLACKHOLE: {
      a.g.additive(true);
      g.glow(z.p, z.half.x * 1.1f, 0x6030c0, 0.35f);
      a.g.additive(false);
      for (int k = 0; k < 4; ++k) {
        float rr = z.half.x * (0.25f + 0.2f * k);
        float a0 = t * (3.5f - k * 0.6f) + k;
        g.arc(z.p, rr, a0, a0 + PI * 0.9f, 0xb080ff, 0.5f, 2);
      }
      g.fillCircle(z.p, 15, 0x000000, 1.f);
      g.circle(z.p, 15, 0xd0a0ff, 0.8f, 1.5f);
      if (z.ttl > 0) g.text(std::to_string(z.ttl), z.p.x - 10, z.p.y + 16, 20, 16, 11, 0xffffff, 0.8f, F_MONOB, AL_C, VA_T);
      break;
    }
    case ZK_MIRROR: {
      g.fillCircle(z.p, z.half.x, 0xe0f0ff, 0.07f);
      g.circle(z.p, z.half.x, 0xe0f0ff, 0.5f, 1.5f);
      g.line(z.p + V2(0, -z.half.x * 0.7f), z.p + V2(0, z.half.x * 0.7f), 0xffffff, 0.5f, 1.5f);
      g.line(z.p + V2(-8, -6), z.p + V2(-2, 0), 0xffffff, 0.5f, 1.5f);
      g.line(z.p + V2(8, -6), z.p + V2(2, 0), 0xffffff, 0.5f, 1.5f);
      break;
    }
    case ZK_RUNE: {
      g.circle(z.p, z.half.x, 0xb0a0ff, 0.6f, 2);
      g.circle(z.p, z.half.x * 0.75f, 0xb0a0ff, 0.3f, 1);
      for (int k = 0; k < 6; ++k) {
        V2 c = z.p + fromAng(k * TAU / 6 + t * 0.4f) * z.half.x * 0.87f;
        g.text("*", c.x - 6, c.y - 7, 12, 14, 10, 0xd0c0ff, 0.8f, F_MONOB, AL_C, VA_M);
      }
      break;
    }
    case ZK_WEB: {
      for (int k = 0; k < 6; ++k) g.line(z.p - fromAng(k * PI / 6) * z.half.x, z.p + fromAng(k * PI / 6) * z.half.x, 0xe8e8e8, 0.35f, 1);
      for (int r = 1; r <= 3; ++r) g.circle(z.p, z.half.x * r / 3.f, 0xe8e8e8, 0.3f, 1);
      if (z.ttl > 0) g.text(std::to_string(z.ttl), z.p.x - 10, z.p.y - 8, 20, 16, 11, 0xffffff, 0.6f, F_MONOB, AL_C, VA_M);
      break;
    }
    case ZK_GEYSER: {
      bool on = geyserActive(w, z);
      g.fillRRect(z.p.x - z.half.x, z.p.y + z.half.y - 12, z.half.x * 2, 12, 4, 0x405060, 0.9f);
      if (on) {
        a.g.additive(true);
        for (int k = 0; k < 6; ++k) {
          float ph = std::fmod(t * 3.f + k * 0.17f, 1.f);
          V2 c(z.p.x + std::sin(k * 2.3f + t * 5) * z.half.x * 0.5f, z.p.y + z.half.y - ph * z.half.y * 2);
          g.glow(c, 10, 0xa0e0ff, 0.5f * (1 - ph));
        }
        a.g.additive(false);
        g.fillRect(z.p.x - z.half.x * 0.5f, z.p.y - z.half.y, z.half.x, z.half.y * 2, 0xc0f0ff, 0.12f);
      } else {
        g.rrect(z.p.x - z.half.x, z.p.y - z.half.y, z.half.x * 2, z.half.y * 2, 6, 0xa0e0ff, 0.15f, 1);
      }
      break;
    }
    case ZK_ROLLOVER: {
      if (z.lit) {
        a.g.additive(true);
        g.glow(z.p, z.half.x * 1.8f, 0xffe060, 0.5f);
        a.g.additive(false);
        g.fillRRect(z.p.x - z.half.x * 0.55f, z.p.y - z.half.y * 0.6f, z.half.x * 1.1f, z.half.y * 1.2f, 4, 0xffe060, 0.9f);
      } else {
        g.fillRRect(z.p.x - z.half.x * 0.55f, z.p.y - z.half.y * 0.6f, z.half.x * 1.1f, z.half.y * 1.2f, 4, 0x2a2410, 0.9f);
        g.rrect(z.p.x - z.half.x * 0.55f, z.p.y - z.half.y * 0.6f, z.half.x * 1.1f, z.half.y * 1.2f, 4, 0xc0a040, 0.8f, 1.2f);
      }
      V2 c = z.p;
      g.line(c + V2(-4, -3), c + V2(0, 2), z.lit ? 0x3a2a00 : 0xc0a040, 0.9f, 1.6f);
      g.line(c + V2(4, -3), c + V2(0, 2), z.lit ? 0x3a2a00 : 0xc0a040, 0.9f, 1.6f);
      break;
    }
    case ZK_FOG: {
      for (int k = 0; k < 7; ++k) {
        V2 c = z.p + fromAng(k * 0.9f + t * 0.15f) * z.half.x * 0.5f;
        g.fillCircle(c, z.half.x * 0.6f, 0x8080a0, 0.07f);
      }
      break;
    }
  }
}

static void drawSeg(App& a, const Seg& s, uint32_t wallCol) {
  Gfx& g = a.g;
  switch (s.kind) {
    case SK_WALL:
    case SK_RAMP:
      g.line(s.a, s.b, rgbScale(wallCol, 1.3f), 1.f, s.th * 2 + 1);
      g.line(s.a, s.b, rgbLerp(wallCol, 0xffffff, 0.35f + 0.4f * s.flash), 0.9f, 2.f);
      break;
    case SK_SPINNER:
      g.line(s.a, s.b, 0x7a5a28, 1.f, s.th * 2 + 2);
      g.line(s.a, s.b, rgbLerp(0xe0b860, 0xffffff, s.flash), 1.f, s.th * 2 - 3);
      g.fillCircle(s.c, 6, 0x3a2a10, 1.f);
      g.circle(s.c, 6, 0xe0b860, 1.f, 2);
      if (s.ttl > 0) g.text(std::to_string(s.ttl), s.c.x - 10, s.c.y + 7, 20, 14, 10, 0xffe0a0, 0.8f, F_MONOB, AL_C, VA_T);
      break;
    case SK_GATE:
      if (s.open) g.line(s.a, s.b, 0xffe070, 0.18f, 2);
      else {
        g.line(s.a, s.b, 0x8a6a10, 1.f, s.th * 2 + 2);
        g.line(s.a, s.b, 0xffe070, 1.f, 2.5f);
      }
      break;
    case SK_BARRIER: {
      float al = s.hp >= 2 ? 1.f : 0.6f;
      g.line(s.a, s.b, 0x3a5a20, al, s.th * 2 + 2);
      g.line(s.a, s.b, rgbLerp(0x90c060, 0xffffff, s.flash), al, 3);
      break;
    }
    case SK_DIVIDER:
      g.line(s.a, s.b, rgbScale(wallCol, 1.2f), 1.f, s.th * 2);
      g.fillCircle(s.a, s.th + 1, rgbLerp(wallCol, 0xffffff, 0.3f), 1.f);
      break;
    case SK_FLIPPER: {
      bool solid = flipperSolid(s);
      float al = solid ? 1.f : 0.3f;
      g.line(s.a, s.b, 0x8a5a10, al, s.th * 2 + 3);
      g.line(s.a, s.b, 0xffc860, al, s.th * 2 - 3);
      g.fillCircle(s.c, 6, 0xffe0a0, al);
      break;
    }
    case SK_KICKER: {
      a.g.additive(true);
      g.line(s.a, s.b, 0xff9060, 0.25f + 0.6f * s.flash, s.th * 2 + 8);
      a.g.additive(false);
      g.line(s.a, s.b, 0x6a2a18, 1.f, s.th * 2 + 2);
      g.line(s.a, s.b, rgbLerp(0xff9060, 0xffffff, s.flash), 1.f, s.th * 2 - 3);
      break;
    }
    case SK_PENDULUM: {
      g.line(s.a, s.b, 0x5a5a6a, 1.f, 3);
      g.fillCircle(s.b, 11, 0x3a3a48, 1.f);
      g.circle(s.b, 11, rgbLerp(0xc0c0d8, 0xffffff, s.flash), 1.f, 2.5f);
      g.fillCircle(s.a, 4, 0xc0c0d8, 1.f);
      break;
    }
    case SK_PETAL:
      g.line(s.a, s.b, 0x7a2a50, 1.f, s.th * 2 + 1);
      g.line(s.a, s.b, rgbLerp(0xff80c0, 0xffffff, s.flash), 1.f, 2);
      break;
    case SK_ICEWALL: {
      a.g.additive(true);
      g.line(s.a, s.b, 0x90e8ff, 0.25f, s.th * 2 + 8);
      a.g.additive(false);
      g.line(s.a, s.b, 0x507890, 0.9f, s.th * 2 + 2);
      g.line(s.a, s.b, rgbLerp(0xc0f0ff, 0xffffff, s.flash), 0.9f, s.th * 2 - 3);
      V2 mid = (s.a + s.b) * 0.5f;
      g.text(fmt("%d", s.hp), mid.x - 10, mid.y - 18, 20, 14, 10, 0xe0f8ff, 0.9f, F_MONOB, AL_C, VA_M);
      break;
    }
  }
}

static void drawLauncher(App& a, float ang, bool active) {
  Gfx& g = a.g;
  V2 o = launcherPos();
  V2 d = fromAng(ang);
  g.fillCircle(o + V2(2, 3), 24, 0x000000, 0.35f);
  g.line(o, o + d * 36, 0x5a4020, 1.f, 17);
  g.line(o, o + d * 36, active ? 0xe8c070 : 0xa08850, 1.f, 12);
  g.fillCircle(o + d * 36, 7.5f, 0x2a2010, 1.f);
  g.fillCircle(o, 22, 0x3a3a46, 1.f);
  g.circle(o, 22, 0xc8a060, 1.f, 3);
  g.fillCircle(o, 9, 0xc8a060, 1.f);
  g.fillCircle(o + V2(-3, -3), 3.5f, 0xfff0c0, 0.8f);
}

static void drawBall(App& a, const Ball& b) {
  Gfx& g = a.g;
  uint32_t col = powerColor(b.power);
  bool ph = (b.flags & BF_PHANTOM) != 0;
  bool anc = (b.flags & BF_ANCESTOR) != 0;
  uint32_t glowCol = anc ? 0xa0d0ff : ph ? 0x90d8ff : col;
  if (b.flags & BF_GOLDEN) glowCol = 0xffd040;
  if (b.flags & BF_HOLY) glowCol = 0xfff0a0;
  g.additive(true);
  g.glow(b.p, b.r * 2.6f + std::min(40.f, b.power * 0.35f), glowCol, anc ? 0.5f : 0.7f);
  if (b.stormT > 0) g.glow(b.p, b.r * 3.5f, 0xfff080, 0.3f + 0.2f * std::sin(a.time * 30));
  g.additive(false);
  uint32_t body = anc ? 0xb0d8ff : ph ? 0xc0e8ff : (b.flags & BF_GOLDEN) ? 0xffe070 : 0xeef2fa;
  g.fillCircle(b.p, b.r, body, anc ? 0.7f : 1.f);
  g.fillCircle(b.p + V2(b.r * 0.12f, b.r * 0.15f), b.r * 0.78f, ph ? 0x90c8e8 : (b.flags & BF_GOLDEN) ? 0xd0a030 : 0xc8d0e0, 0.6f);
  g.fillCircle(b.p + V2(-b.r * 0.35f, -b.r * 0.38f), b.r * 0.32f, 0xffffff, 0.95f);
  if (b.flags & BF_FIRE) g.circle(b.p, b.r + 2, 0xff7030, 0.9f, 2);
  if (b.flags & BF_FROST) g.circle(b.p, b.r + 3.5f, 0x90e8ff, 0.9f, 1.5f);
  if (b.flags & BF_VENOM) g.circle(b.p, b.r + 5, 0x90e040, 0.9f, 1.5f);
  if (b.flags & BF_LUCKY) g.circle(b.p, b.r + 6.5f, 0x50ff70, 0.8f, 1.2f);
  if (b.flags & BF_BEAST) {
    for (int k = 0; k < 6; ++k) {
      V2 d = fromAng(k * TAU / 6 + a.time * 2);
      g.line(b.p + d * b.r, b.p + d * (b.r + 5), 0xe03848, 0.9f, 2);
    }
  }
  if (b.flags & BF_ELEMENTAL) {
    g.arc(b.p, b.r + 4, a.time * 4, a.time * 4 + 2.f, 0xff7030, 0.9f, 2);
    g.arc(b.p, b.r + 4, a.time * 4 + 2.1f, a.time * 4 + 4.1f, 0x90e8ff, 0.9f, 2);
    g.arc(b.p, b.r + 4, a.time * 4 + 4.2f, a.time * 4 + 6.2f, 0xfff080, 0.9f, 2);
  }
  if (b.flags & BF_HOLY) g.fillEllipse(b.p + V2(0, -b.r - 5), b.r * 0.8f, 2.5f, 0xfff0a0, 0.9f);
  if (b.flags & BF_MOON) {
    g.additive(true);
    g.glow(b.p, b.r * 3.f, 0xc0d0ff, 0.45f);
    g.additive(false);
    g.arc(b.p, b.r + 4, -PI * 0.7f, PI * 0.3f, 0xd0dcff, 0.9f, 2);
  }
  if (b.flags & BF_COMET) {
    g.additive(true);
    g.glow(b.p - norm(b.v) * b.r * 1.5f, b.r * 3.2f, 0xff8030, 0.55f);
    g.additive(false);
  }
  if (b.flags & BF_CRITNEXT) g.circle(b.p, b.r + 8 + std::sin(a.time * 10) * 1.5f, 0xffe040, 0.9f, 1.5f);
  if (b.flags & BF_VOIDED) g.circle(b.p, b.r + 3, 0x8040e0, 0.9f, 2.f);
  if (!ph || anc) g.textSh(std::to_string(b.power), b.p.x - 30, b.p.y - b.r - 22, 60, 18, 14, anc ? 0xb0d8ff : col, 1.f, F_UIB, AL_C, VA_B);
}

static uint32_t intentColor(const Monster& m) {
  switch (m.intent) {
    case IN_ATTACK: case IN_MULTI: return 0xff8080;
    case IN_HEAVY: case IN_BEAM: return 0xff4040;
    case IN_BLOCK: case IN_SHIELDALLY: case IN_BURROW: return 0x9fb8ff;
    case IN_HEAL: return 0x70ff90;
    case IN_HEX: case IN_CURSEPOCKET: case IN_MUTATEPEGS: case IN_CURSEBALL: return 0xc080ff;
    case IN_BOMB: return 0xffa040;
    case IN_POISON: case IN_ACID: return 0x90e040;
    case IN_ENRAGE: return 0xff5050;
    case IN_EGGS: return 0xe0d0a0;
    case IN_FREEZEPOCKET: case IN_SLOW: return 0xa0e0ff;
    case IN_RANDOM: return 0xff60ff;
    case IN_BLIND: case IN_SAP: case IN_WEAKEN: case IN_DRAIN: return 0xb0b0ff;
    case IN_QUAKE: return 0xffa060;
    case IN_LIFEDRAIN: return 0xff6080;
    case IN_DISPEL: return 0xd0a0ff;
    case IN_EXECUTE: return 0xff3030;
    case IN_SUNDER: return 0xffa080;
    case IN_FLEE: return 0xffd040;
    case IN_METEOR: return 0xff8040;
  }
  return 0xb0c8ff;
}

static void drawIntent(App& a, const World& w, const Monster& m, V2 pos) {
  Gfx& g = a.g;
  float y = pos.y - m.r - 20;
  if (m.charmed) {
    std::string s = fmt("charmed %d", m.charmT);
    float bw = g.measure(s, 12, F_UIB).x + 16;
    g.fillRRect(pos.x - bw / 2, y - 10, bw, 20, 10, 0x200820, 0.9f);
    g.rrect(pos.x - bw / 2, y - 10, bw, 20, 10, 0xff90ff, 0.8f, 1.2f);
    g.text(s, pos.x - bw / 2, y - 10, bw, 20, 12, 0xff90ff, 1.f, F_UIB, AL_C, VA_M);
    return;
  }
  std::string sv = intentText(w, m, true);
  uint32_t col = intentColor(m);
  float tw = sv.empty() ? 0 : g.measure(sv, 13, F_UIB).x;
  float bw = 26 + tw + 20;
  float x = pos.x - bw / 2;
  bool soon = m.cd <= 1 && m.frozen == 0;
  float pulse = soon ? 0.6f + 0.4f * std::sin(a.time * 6) : 0.f;
  g.fillRRect(x, y - 10, bw, 20, 10, 0x0b0d12, 0.88f);
  g.rrect(x, y - 10, bw, 20, 10, soon ? 0xff5050 : 0x505868, soon ? 0.6f + 0.4f * pulse : 0.7f, soon ? 1.8f : 1.f);
  if (m.frozen > 0) {
    g.text(m.frozen > 1 ? fmt("frozen %d", m.frozen) : std::string("frozen"), x, y - 10, bw, 20, 12, 0xc0f0ff, 1.f, F_UIB, AL_C, VA_M);
    return;
  }
  drawIcon(g, m.intent, V2(x + 13, y), 10, col);
  if (!sv.empty()) g.text(sv, x + 23, y - 10, tw + 4, 20, 13, col, 1.f, F_UIB, AL_L, VA_M);
  V2 cc(x + bw - 9, y);
  g.fillCircle(cc, 8, soon ? 0x802020 : 0x2a3040, 1.f);
  g.text(std::to_string(std::max(1, m.cd)), cc.x - 8, cc.y - 8, 16, 16, 11, 0xffffff, 1.f, F_MONOB, AL_C, VA_M);
  if (m.intent == IN_BEAM && m.beamHp > 0) {
    float fr = 0.f;
    int n = 0;
    const Intent* s = monsterScript(m, &n);
    if (n > 0 && s[m.spos % n].arg > 0) fr = 1.f - m.beamHp / (float)std::max(1, (int)(s[m.spos % n].arg * (1.f + 0.08f * w.descent)));
    g.fillRRect(x, y + 11, bw, 4, 2, 0x302010, 1.f);
    g.fillRRect(x, y + 11, bw * clampv(fr, 0.f, 1.f), 4, 2, 0xffe080, 1.f);
  }
  if (w.st.keenEye) {
    int n = 0;
    const Intent* s = monsterScript(m, &n);
    if (n > 0) {
      int depth = std::max(1, w.st.keenDepth);
      for (int k = 1; k <= depth && k < n + 1; ++k) {
        const Intent& nx = s[(m.spos + k) % n];
        drawIcon(g, nx.kind, V2(x + bw + 10 + (k - 1) * 16, y), 7, 0x808898, 0.8f - 0.2f * (k - 1));
      }
    }
  }
}

static std::string traitsText(const World& w, const Monster& m) {
  const MonDef& d = MON[m.def];
  std::string b;
  uint32_t tr = d.traits;
  bool decoy = (tr & TR_DECOY) != 0;
  if (decoy) {
    if (w.st.keenEye) return "It's an illusion! A single hit dispels it.\n";
    tr = monLook(m).traits;
  }
  const MonDef& L = monLook(m);
  int tval = decoy ? L.tval : d.tval;
  if (tr & TR_PHASING) b += fmt("Ethereal: balls with < %d power pass through.\n", tval);
  if (tr & TR_FLYING) b += "Flying: moves every turn.\n";
  if (tr & TR_EVASIVE) b += "Evasive: moves when hit.\n";
  if (tr & TR_REGEN) b += fmt("Regenerates %d HP per turn.\n", tval);
  if (tr & TR_SPLIT) b += "Splits when slain.\n";
  if (tr & TR_SPLITHIT) b += m.split ? "Has already split.\n" : "Splits in two when a single hit deals 25%+ of its max HP.\n";
  if (tr & TR_THORNS) b += fmt("Stings you for %d when hit.\n", tval);
  if (tr & TR_UNDYING) b += m.undyingUsed ? "Already risen once.\n" : "Rises again once when slain.\n";
  if (tr & TR_LIFESTEAL) b += "Heals by the damage it deals.\n";
  if (tr & TR_HARDENED) b += fmt("Hardened: max %d damage per hit.\n", tval);
  if (tr & TR_STATIONARY) b += "Stationary.\n";
  if (tr & TR_VOLATILE) b += fmt("Volatile: bursts for %d when slain, igniting nearby pins.\n", tval);
  if (tr & TR_ACIDIC) b += fmt("Acidic: each ball hit dissolves %d nearby pins.\n", std::max(1, tval));
  if (tr & TR_BLINKER) b += m.blinked ? "Has already blinked away.\n" : "Blinks away when it drops below half HP.\n";
  if (tr & TR_AURA) b += fmt("Aura: heals every other monster %d HP per turn.\n", tval);
  if (tr & TR_UNDEAD) b += "Undead.\n";
  if (tr & TR_DEMONIC) b += "Demonic.\n";
  if (tr & TR_SLIMY) b += "Slimy: immune to poison and bleeding.\n";
  return b;
}

static void monsterTooltip(App& a, const World& w, const Monster& m) {
  const MonDef& d = monLook(m);
  bool decoy = (MON[m.def].traits & TR_DECOY) != 0;
  std::string t = monsterName(m);
  if (m.champ == 1) t = std::string("Champion ") + d.name;
  if (m.champ == 2) t += std::string(" (unique ") + d.name + ")";
  if (m.elite && !(d.traits & TR_ELITE)) t = "Elite " + t;
  if (decoy && w.st.keenEye) t += " (illusion)";
  std::string b = fmt("HP %d/%d", std::max(0, m.hp), m.maxHp);
  if (m.armor) b += fmt("   Armor %d", m.armor);
  if (m.shield) b += fmt("   Block %d", m.shield);
  if (m.atkBonus) b += fmt("   Rallied +%d", m.atkBonus);
  b += "\n";
  if (m.charmed) b += fmt("Charmed: fights for you for %d more turn(s).\n", m.charmT);
  else if (m.frozen) b += "Frozen: skips its next action.\n";
  else b += fmt("Next: %s (in %d turn%s)\n", intentText(w, m, false).c_str(), std::max(1, m.cd), m.cd > 1 ? "s" : "");
  if (m.enraged) b += "ENRAGED: its next attack deals double damage.\n";
  if (m.burn) b += fmt("Burning %d (takes %d, then halves)\n", m.burn, m.burn);
  if (m.poison) b += fmt("Poisoned %d (takes %d, then -1)\n", m.poison, m.poison);
  if (m.bleed) b += fmt("Bleeding %d (takes %d, then loses a third)\n", m.bleed, m.bleed);
  if (m.corruptT) b += fmt("Corrupted: +%d damage taken, can't heal (%d turns)\n", m.corruptAmt, m.corruptT);
  if (m.hexT) b += fmt("Hexed: +%d%% damage taken\n", m.hexPct);
  if (m.chilled) b += "Chilled\n";
  if (m.markT) b += "Marked for death\n";
  if (m.bounty) b += "BOUNTY: slay it for bonus gold and a prize!\n";
  if (m.champ) {
    b += m.champ == 2 ? "UNIQUE monster: 3x XP and gold, and it always drops loot.\n" : "CHAMPION: 1.5x XP, double gold, and it may drop loot.\n";
    for (int af = 0; af < AFFIX_COUNT; ++af)
      if (hasAffix(m, af)) b += fmt("  %s: %s\n", AFFIX_NAME[af], AFFIX_DESC[af]);
  }
  if (m.def == M_TREASURE) b += fmt("Escapes in %d turn%s! Drops lots of loot if you catch it.\n", m.escapeT, m.escapeT == 1 ? "" : "s");
  if (m.boss && w.fl.bossEnraged) b += "ENRAGED: the fight went on too long. +50% damage.\n";
  b += traitsText(w, m);
  if (m.summoned && !decoy) b += "Summoned: gives no XP or gold.\n";
  b += d.desc;
  if (w.fl.focus >= 0 && &w.fl.mons[w.fl.focus] == &m) b += "\n[Focus target: leftover ball power discharges here]";
  else b += "\nRight-click to make this your focus target.";
  setTip(a, t, b, m.champ == 2 ? 0xffc040 : m.champ == 1 ? 0x6aa0ff : d.color);
}

// the boss's health bar, phase and enrage timer across the top of the board
static void drawBossBar(App& a, const World& w) {
  const Floor& f = w.fl;
  if (f.spec.kind != FK_BOSS) return;
  const Monster* bm = nullptr;
  for (auto& m : f.mons)
    if (!m.dead && m.boss) bm = &m;
  if (!bm) return;
  Gfx& g = a.g;
  const MonDef& d = MON[bm->def];
  float x = PX0 + 12, y = 10, bw = 300, bh = 14;
  g.fillRRect(x - 6, y - 4, bw + 12, 44, 8, 0x07080c, 0.82f);
  g.rrect(x - 6, y - 4, bw + 12, 44, 8, f.bossEnraged ? 0xff4040 : d.color, 0.8f, 1.5f);
  g.text(d.name, x, y - 2, bw - 150, 16, 12.5f, d.color, 1.f, F_UIB, AL_L, VA_M);
  int np = numPhases(d);
  for (int k = 0; k < np; ++k) {
    V2 c(x + bw - 8 - k * 14.f, y + 6);
    if (np - 1 - k <= bm->phase) g.fillCircle(c, 4, d.color, 1.f);
    else g.circle(c, 4, d.color, 0.7f, 1.2f);
  }
  float fr = clampv(bm->hpDisp / std::max(1, bm->maxHp), 0.f, 1.f), fr2 = clampv(bm->hp / (float)std::max(1, bm->maxHp), 0.f, 1.f);
  g.fillRRect(x, y + 16, bw, bh, 4, 0x200a10, 1.f);
  g.fillRRect(x, y + 16, bw * fr, bh, 4, 0xffd0a0, 0.9f);
  g.fillRRect(x, y + 16, bw * fr2, bh, 4, f.bossEnraged ? 0xff2020 : 0xe03050, 1.f);
  if (np >= 2) {
    float t1 = np == 2 ? 0.5f : 0.66f;
    g.line(V2(x + bw * t1, y + 16), V2(x + bw * t1, y + 16 + bh), 0xffffff, 0.6f, 1.f);
    if (np == 3) g.line(V2(x + bw * 0.33f, y + 16), V2(x + bw * 0.33f, y + 16 + bh), 0xffffff, 0.6f, 1.f);
  }
  g.textSh(fmt("%d / %d", std::max(0, bm->hp), bm->maxHp), x, y + 16, bw, bh, 10.5f, 0xffffff, 1.f, F_UIB, AL_C, VA_M);
  std::string en = f.bossEnraged ? "ENRAGED" : fmt("enrages in %d", std::max(0, 12 - f.bossTurns));
  g.text(en, x + bw - 150, y - 2, 100, 16, 10.5f, f.bossEnraged ? 0xff5050 : 0x98a0b0, 1.f, F_UI, AL_R, VA_M);
  if (mouseIn(a, x - 6, y - 4, bw + 12, 44))
    setTip(a, d.name,
           fmt("Phase %d of %d. Bosses act every turn and often do two things at once; their big blows show a longer "
               "countdown. After 12 turns a boss becomes enraged and deals +50%% damage, so don't dawdle.\n\n%s",
               bm->phase + 1, np, d.desc),
           d.color);
}

static void drawSlotMachine(App& a, const World& w) {
  const Floor& f = w.fl;
  if (f.slotT <= 0 && f.slotShow <= 0 && f.slotSpins <= 0) return;
  Gfx& g = a.g;
  float x = PX1 - 232, y = 14, bw = 220, bh = 50;
  g.fillRRect(x, y, bw, bh, 8, 0x1a1206, 0.92f);
  g.rrect(x, y, bw, bh, 8, 0xffd700, 0.9f, 2);
  for (int i = 0; i < 3; ++i) {
    float rx = x + 10 + i * 68, ry = y + 7;
    g.fillRRect(rx, ry, 64, 36, 4, 0x0a0804, 1.f);
    int sym = f.slotReel[i];
    bool spinning = f.slotT > 0 && f.slotT > 0.25f * (2 - i);
    if (spinning) sym = (int)(a.time * 22 + i * 3) % 7;
    g.text(SLOT_NAME[sym], rx, ry, 64, 36, sym == 0 ? 22.f : 13.f, SLOT_COLOR[sym], spinning ? 0.7f : 1.f, F_UIB, AL_C, VA_M);
  }
  if (f.slotT <= 0 && f.slotShow > 0) {
    std::string res = f.slotLast < 0 ? "no match" : f.slotLast < 10 ? "THREE OF A KIND!" : "a pair";
    g.text(res, x, y + bh, bw, 18, 12, f.slotLast >= 0 ? 0xffd700 : 0x908870, 1.f, F_UIB, AL_C, VA_M);
  }
  if (f.slotSpins > 0) g.text(fmt("+%d spin%s queued", f.slotSpins, f.slotSpins > 1 ? "s" : ""), x, y + bh + (f.slotShow > 0 && f.slotT <= 0 ? 16 : 0), bw, 16, 11, 0xffd700, 0.9f, F_UI, AL_C);
}

static std::string pegTip(const World& w, const Peg& p, std::string& title) {
  title = PEG_NAME[p.kind];
  std::string body = PEG_DESC[p.kind];
  switch (p.kind) {
    case PK_BOMB: body = fmt("Explodes for %d damage to nearby monsters and sets off nearby pegs.", p.val); break;
    case PK_MBOMB: body = fmt("Explodes on YOU for %d damage in %d turn(s)! Hit it with a ball to defuse it.", p.hp, p.val); break;
    case PK_GOLEM: case PK_BONE: body = fmt("+%d power every hit.", p.val); break;
    case PK_PILLAR: body = fmt("+%d power every hit; %d hits left.", p.val, p.hp); break;
    case PK_CHEST: if (p.val == 99) body = "A sealed treasure chest (a relic or a randart)! Hit the key to open the gate, then break it open."; break;
    case PK_EGG: body = fmt("Hatches into %s in %d turn(s)! Hit it with a ball to smash it (+2 power).", withArticle(MON[clampv(p.aux, 0, M_COUNT - 1)].name).c_str(), p.val); break;
    case PK_IMP: body = fmt("Your imp. Firebolts a random monster for %d after each enemy phase. +2 power per hit.", p.val); break;
    case PK_HOUND: body = fmt("Your spectral hound. Bites the nearest monster for %d (and 2 Bleed) after each enemy phase. +4 power per hit.", p.val); break;
    case PK_FAMILIAR: body = fmt("Your familiar. Strikes your focus target for %d after each enemy phase. +2 power per hit.", p.val); break;
    case PK_ANGEL: body = fmt("A divine warrior. Smites the strongest monster for %d after each enemy phase. +5 power per hit.", p.val); break;
    case PK_TESLA: body = fmt("Your tesla coil. Zaps the two nearest monsters for %d after each of your shots. +3 power per hit.", p.val); break;
    case PK_FIREFLY: if (p.temp) body = fmt("+2 power per hit. Stings a random monster for %d after each enemy phase.", p.val); break;
    case PK_COINS: body = fmt("+2 gold and +1 power per hit. %d hit(s) left.", p.hp); break;
    case PK_TARGET: body = p.val ? "Knocked down. Knock down every target in its row for a bonus; they reset each turn."
                                 : "A drop target: knock down every target in its row for a bonus. They stand back up each turn."; break;
    case PK_GHOST: body = w.fl.ghostSolid ? "Solid this turn (it fades next turn). +1 power." : "Faded this turn: balls pass through. It returns next turn."; break;
    case PK_TULIP: body = std::string(PEG_DESC[PK_TULIP]) + (p.aux ? "\nIt is open wide this shot." : ""); break;
    case PK_LOOT: {
      static const char* TN[4] = {"Common loot: an item or a pile of gold.", "Magic loot: a relic with random magic affixes!",
                                  "Rare loot: a randart!", "UNIQUE loot: a legendary relic!"};
      title = p.val >= 3 ? "Unique Loot" : p.val == 2 ? "Rare Loot" : p.val == 1 ? "Magic Loot" : "Loot";
      body = std::string(TN[clampv(p.val, 0, 3)]) + "\nHit it to grab it now (+2 power), or it is collected when the floor is cleared.";
      break;
    }
    case PK_SHRINE:
      title = SHRINE_NAME[clampv(p.aux, 0, SHRINE_COUNT - 1)];
      body = p.hp > 0 ? std::string("Hit it: ") + SHRINE_DESC[clampv(p.aux, 0, SHRINE_COUNT - 1)] : "This shrine's blessing has been used.";
      break;
    case PK_WELL: body = fmt("Heals %d HP and restores 1 MP when hit. %d use%s left.", 4 + w.depth / 3 + w.st.wellBonus, p.hp, p.hp == 1 ? "" : "s"); break;
    case PK_MIMIC:
      if (w.st.keenEye) {
        title = "Mimic!";
        body = "Your keen eyes spot the teeth: this chest is a mimic. Hitting it wakes it up. Kill it for its loot.";
      } else {
        title = PEG_NAME[PK_CHEST];
        body = PEG_DESC[PK_CHEST];
      }
      break;
    case PK_PINATA: body = fmt("%d more hit%s to burst it: +6 power, gold and maybe an item.", p.hp, p.hp == 1 ? "" : "s"); break;
    case PK_GEM: {
      static const char* GN[STAT_COUNT] = {"Ruby", "Emerald", "Sapphire", "Garnet", "Topaz"};
      int st = clampv(p.aux, 0, STAT_COUNT - 1);
      title = GN[st];
      body = fmt("Hit it: +%d %s for the rest of this floor. +2 power.", 1 + w.st.gemBonus, STAT_NAME[st]);
      break;
    }
  }
  if (p.kind == PK_MBOMB && p.r > 12) {
    title = "Meteor Marker";
    body = fmt("A meteor strikes YOU for %d in %d turn(s)! Hit this marker %d more time%s to shatter it.", p.hp, p.val, std::max(1, p.aux),
               p.aux == 1 ? "" : "s");
  }
  if (p.ttl > 0) body += fmt("\nLasts %d more turn(s).", p.ttl);
  return body;
}

static std::string pocketTip(const World& w, const Pocket& p) {
  std::string body = POCKET_DESC[p.kind];
  switch (p.kind) {
    case PO_HEAL: body = fmt("+%d HP.", 4 + w.depth / 3); break;
    case PO_GOLD: body = fmt("+%d gold.", 6 + w.depth); break;
    case PO_CURSED: body = fmt("Take %d damage! (Remove Curse or Dispel can restore it.)", 3 + w.depth / 3); break;
    case PO_XP: body = fmt("+%d XP.", 3 + w.depth); break;
    case PO_SHIELD: body = fmt("+%d Block for the next enemy phase.", 5 + w.depth / 2); break;
    case PO_BOMB: body = fmt("An explosion hits your focus target: %d damage + half the ball's power.", 10 + w.depth); break;
    case PO_FROZEN: body = fmt("Frozen solid by a monster: nothing happens here for %d more turn(s). It was a %s pocket.", p.val, POCKET_NAME[p.orig]); break;
  }
  if (p.kind != PO_VOID) body += "\nEvery ball also discharges half its leftover power into your focus target.";
  return body;
}

void drawBoard(App& a, World& w, bool interactive) {
  Gfx& g = a.g;
  Floor& f = w.fl;
  const BiomeDef& B = BIOME[f.spec.biome];
  g_ghostSolid = f.ghostSolid;
  g.pushXf(Xf::translate(a.shakeOff.x, a.shakeOff.y));
  // background
  g.vgrad(BOARD_X0, 0, BOARD_X1 - BOARD_X0, SCR_H, B.bgTop, B.bgBot);
  for (int i = 0; i < 20; ++i) {
    float y = 30.f + i * 45.f;
    g.line(V2(PX0, y), V2(PX1, y), 0xffffff, 0.018f, 1);
    for (int k = 0; k < 9; ++k) {
      float x = PX0 + k * 102.f + (i % 2) * 51.f;
      g.line(V2(x, y), V2(x, y + 45), 0xffffff, 0.012f, 1);
    }
  }
  g.additive(true);
  g.glow(V2(LAUNCH_X, 380), 520, B.accent, 0.07f);
  g.additive(false);
  // side walls
  g.fillRect(BOARD_X0, 0, PX0 - BOARD_X0, SCR_H, B.wall, 1);
  g.fillRect(PX1, 0, BOARD_X1 - PX1, SCR_H, B.wall, 1);
  g.line(V2(PX0 - 1, 0), V2(PX0 - 1, SCR_H), rgbLerp(B.wall, 0xffffff, 0.35f), 1.f, 2);
  g.line(V2(PX1 + 1, 0), V2(PX1 + 1, SCR_H), rgbLerp(B.wall, 0xffffff, 0.35f), 1.f, 2);
  for (int i = 0; i < 12; ++i) {
    g.fillCircle(V2(BOARD_X0 + 6, 40 + i * 75.f), 2.5f, rgbLerp(B.wall, 0xffffff, 0.3f), 0.8f);
    g.fillCircle(V2(BOARD_X1 - 6, 40 + i * 75.f), 2.5f, rgbLerp(B.wall, 0xffffff, 0.3f), 0.8f);
  }
  // zones (fog is drawn above the pegs)
  for (auto& z : f.zones)
    if (!z.dead && z.kind != ZK_FOG) drawZone(a, w, z);
  // pockets
  for (auto& p : f.pockets) {
    uint32_t col = POCKET_COLOR[p.kind];
    float x0 = p.x0 + 4, x1 = p.x1 - 4;
    g.vgrad(x0, POCKET_TOP, x1 - x0, SCR_H - POCKET_TOP, rgbScale(col, 0.18f), rgbScale(col, 0.45f), 0.9f);
    if (p.flash > 0) {
      g.additive(true);
      g.glow(V2((x0 + x1) / 2, 870), (x1 - x0) * 0.8f, col, p.flash * 0.8f);
      g.additive(false);
    }
    float fs = (x1 - x0) < 80 ? 11.f : 12.5f;
    std::string lab = POCKET_SHORTNAME[p.kind];
    if (p.kind == PO_FROZEN) {
      lab = fmt("ICED %d", p.val);
      g.fillRect(x0, POCKET_TOP + 4, x1 - x0, SCR_H - POCKET_TOP - 4, 0xc0f0ff, 0.18f);
      for (int k = 0; k < 3; ++k) g.line(V2(x0 + 6 + k * 14, POCKET_TOP + 8), V2(x0 + 14 + k * 14, POCKET_TOP + 24), 0xffffff, 0.4f, 1);
    }
    g.text(lab, x0, 852, x1 - x0, 22, fs, rgbLerp(col, 0xffffff, 0.3f), 1.f, F_UIB, AL_C, VA_M);
    if (f.shot.jackpotMul > 1 && p.kind != PO_CURSED && p.kind != PO_EMPTY && p.kind != PO_VOID && p.kind != PO_FROZEN)
      g.text(fmt("x%d", f.shot.jackpotMul), x0, 872, x1 - x0, 18, 11, 0xffd040, 1.f, F_MONOB, AL_C, VA_M);
  }
  // segments
  for (auto& s : f.segs)
    if (!s.dead) drawSeg(a, s, B.wall);
  // catcher
  if (f.hasCatcher) {
    float cx = f.catcherX, cy = 818;
    bool on = f.phase != PH_FLIGHT || f.shot.catchesLeft > 0;
    V2 pts[4] = {V2(cx - 40, cy - 8), V2(cx + 40, cy - 8), V2(cx + 30, cy + 12), V2(cx - 30, cy + 12)};
    g.fillPoly(pts, 4, 0x5a4020, on ? 0.9f : 0.35f);
    g.strokePoly(pts, 4, 0xffc860, on ? 1.f : 0.35f, 2);
  }
  // pegs (with darkness and fog)
  bool dark = f.dark && !w.st.ignoreDark;
  bool anyFog = false;
  for (auto& z : f.zones) anyFog |= !z.dead && z.kind == ZK_FOG;
  for (auto& p : f.pegs) {
    if (p.dead) continue;
    float al = 1.f;
    if (dark) {
      float best = 1e9f;
      for (auto& b : f.balls)
        if (b.alive) best = std::min(best, dist(b.p, p.p));
      for (auto& m : f.mons)
        if (!m.dead) best = std::min(best, dist(m.p, p.p) - m.r);
      best = std::min(best, dist(launcherPos(), p.p) - 60);
      al = clampv(1.f - (best - 70.f) / 70.f, 0.05f, 1.f);
    }
    if (anyFog && !w.st.ignoreDark)
      for (auto& z : f.zones)
        if (!z.dead && z.kind == ZK_FOG && dist2(z.p, p.p) < z.half.x * z.half.x) al = std::min(al, 0.12f);
    drawPeg(a, p, al, B.pin);
  }
  for (auto& z : f.zones)
    if (!z.dead && z.kind == ZK_FOG) drawZone(a, w, z);
  // monsters
  a.hoverMon = -1;
  int focus = f.focus;
  for (int i = 0; i < (int)f.mons.size(); ++i) {
    const Monster& m = f.mons[i];
    if (m.dead) continue;
    V2 pos = monPos(m);
    drawMonsterBody(a, m, pos, 1.f);
    float bw = std::max(44.f, m.r * 2 + 8), bx = pos.x - bw / 2, by = pos.y + m.r + 6;
    g.fillRRect(bx - 1, by - 1, bw + 2, 8, 3, 0x000000, 0.8f);
    float fr = clampv(m.hpDisp / std::max(1, m.maxHp), 0.f, 1.f);
    float fr2 = clampv(m.hp / (float)std::max(1, m.maxHp), 0.f, 1.f);
    g.fillRRect(bx, by, bw * fr, 6, 3, 0xffd0a0, 0.9f);
    g.fillRRect(bx, by, bw * fr2, 6, 3, m.charmed ? 0xd060d0 : (m.boss ? 0xe03050 : 0xd84040), 1.f);
    if (m.shield > 0) g.fillRRect(bx, by, bw * clampv(m.shield / (float)m.maxHp, 0.f, 1.f), 6, 3, 0x80a8ff, 0.85f);
    std::string hs = m.shield > 0 ? fmt("%d +%d", m.hp, m.shield) : std::to_string(m.hp);
    g.textSh(hs, pos.x - 40, by + 6, 80, 14, 11, 0xffffff, 0.95f, F_UIB, AL_C, VA_T);
    if (m.champ || m.def == M_TREASURE) {
      std::string nm = m.def == M_TREASURE ? fmt("treasure imp (%d)", m.escapeT) : monsterName(m);
      uint32_t nc = m.def == M_TREASURE ? 0xffd040 : m.champ == 2 ? 0xffc040 : 0x7ab0ff;
      g.textSh(nm, pos.x - 90, by + 19, 180, 14, 10.5f, nc, 1.f, F_UIB, AL_C, VA_T);
    }
    float sx = pos.x + bw / 2 + 4;
    auto chip = [&](int icon, int val, uint32_t col) {
      drawIcon(g, icon, V2(sx + 5, by + 3), 6, col);
      g.text(std::to_string(val), sx + 11, by - 4, 30, 14, 10.5f, col, 1.f, F_UIB, AL_L, VA_M);
      sx += 26;
    };
    if (m.burn > 0) chip(IN_BOMB, m.burn, 0xff8040);
    if (m.poison > 0) chip(IN_POISON, m.poison, 0x90e040);
    if (m.bleed > 0) chip(IN_ACID, m.bleed, 0xe03848);
    if (i == focus) {
      float r = m.r + 12 + std::sin(a.time * 3) * 1.5f;
      for (int k = 0; k < 4; ++k) {
        float a0 = k * PI / 2 + a.time * 0.8f;
        g.arc(pos, r, a0 - 0.35f, a0 + 0.35f, 0x9fc8ff, 0.9f, 2.5f);
      }
    }
    if (interactive && dist(a.in.mouse, pos) < m.r + 3) a.hoverMon = i;
  }
  // launcher & aim guide
  bool aiming = f.phase == PH_AIM || f.phase == PH_RELAUNCH;
  drawLauncher(a, aiming ? a.aimAngle : PI / 2, aiming);
  if (interactive && !a.preview.empty() && (f.phase == PH_AIM || f.phase == PH_RELAUNCH || f.phase == PH_REDIRECT) &&
      a.targetAb < 0 && a.targetItem < 0) {
    float acc = 0;
    for (size_t i = 1; i < a.preview.size(); ++i) {
      V2 p0 = a.preview[i - 1], p1 = a.preview[i];
      float L = dist(p0, p1);
      int n = std::max(1, (int)(L / 10));
      for (int k = 0; k < n; ++k) {
        acc += L / n;
        if (std::fmod(acc + a.time * 40.f, 16.f) < 8.f) {
          V2 q = lerpv(p0, p1, (k + 0.5f) / n);
          g.fillCircle(q, 2.2f, 0xffffff, 0.55f);
        }
      }
    }
    if (!guideHidden(w)) {
      V2 end = a.preview.back();
      g.circle(end, w.st.ballR, 0xffffff, 0.7f, 1.5f);
    } else {
      g.text(f.blindTurns > 0 ? fmt("BLINDED (%d)", f.blindTurns) : std::string("no aiming guide"), LAUNCH_X - 80, 150, 160, 18, 12,
             0x9090a0, 0.9f, F_UIB, AL_C, VA_M);
    }
  }
  // trails & balls
  for (auto& t : a.trails) t.seen = false;
  for (auto& b : f.balls) {
    if (!b.alive) continue;
    Trail* tr = nullptr;
    for (auto& t : a.trails)
      if (t.id == b.id) tr = &t;
    if (!tr) {
      a.trails.push_back(Trail());
      tr = &a.trails.back();
      tr->id = b.id;
    }
    tr->seen = true;
    tr->fade = 1;
    if (tr->pts.empty() || dist(tr->pts.back(), b.p) > 3) tr->pts.push_back(b.p);
    if (tr->pts.size() > 16) tr->pts.erase(tr->pts.begin());
  }
  g.additive(true);
  for (auto& t : a.trails) {
    if (!t.seen) t.fade -= 0.08f;
    uint32_t col = 0x9fc8ff;
    for (auto& b : f.balls)
      if (b.id == t.id) col = powerColor(b.power);
    for (size_t i = 1; i < t.pts.size(); ++i) {
      float fr = i / (float)t.pts.size();
      if (dist(t.pts[i - 1], t.pts[i]) > 80) continue;
      g.line(t.pts[i - 1], t.pts[i], col, 0.5f * fr * t.fade, 1.f + 7.f * fr);
    }
  }
  g.additive(false);
  a.trails.erase(std::remove_if(a.trails.begin(), a.trails.end(), [](const Trail& t) { return t.fade <= 0; }), a.trails.end());
  for (auto& b : f.balls)
    if (b.alive) drawBall(a, b);
  // intents on top
  for (int i = 0; i < (int)f.mons.size(); ++i) {
    const Monster& m = f.mons[i];
    if (m.dead) continue;
    drawIntent(a, w, m, monPos(m));
  }
  drawSlotMachine(a, w);
  drawBossBar(a, w);
  drawPresentation(a, true);
  g.popXf();

  // targeting / phase prompts
  std::string prompt;
  if (a.targetAb >= 0 || a.targetItem >= 0) {
    bool isItem = a.targetAb < 0;
    int itemId = isItem && a.targetItem < (int)a.w.pl.items.size() ? a.w.pl.items[a.targetItem].id : -1;
    const char* nm = !isItem ? ABIL[a.targetAb].name : (itemId >= 0 ? ITEM[itemId].name : "?");
    int tg = !isItem ? ABIL[a.targetAb].target : (itemId >= 0 ? ITEM[itemId].target : TG_MONSTER);
    if (tg == TG_MONSTER) prompt = fmt("%s: click a monster (right-click to cancel)", nm);
    else if (tg == TG_POINT) prompt = fmt("%s: click a spot on the board (right-click to cancel)", nm);
    else prompt = a.targetStage == 0 ? fmt("%s: click the FIRST point (right-click to cancel)", nm) : fmt("%s: now click the SECOND point", nm);
    if (tg == TG_POINT || tg == TG_TWO_POINTS) {
      g.circle(a.in.mouse, 18, 0xffffff, 0.6f, 1.5f);
      if (a.targetStage == 1) {
        g.line(a.targetP1, a.in.mouse, 0x60c0ff, 0.5f, 2);
        g.circle(a.targetP1, 22, 0x50a8ff, 0.8f, 2);
      }
    }
  } else if (f.phase == PH_REDIRECT) {
    prompt = "Stasis: aim and click to send your balls in a new direction";
  } else if (f.phase == PH_RELAUNCH) {
    prompt = fmt("Second Wind: aim and click to relaunch your ball (%d power)", f.relaunchPower);
  }
  if (prompt.empty() && interactive && a.tutorialRun && w.depth == 1 && w.rs.floors == 0 && f.turn <= 3) {
    if (f.phase == PH_AIM) {
      if (f.turn == 1) prompt = "Aim with the mouse and click to launch. Pins give your ball power; hitting a monster spends it.";
      else if (f.turn == 2) prompt = "Right-click a monster to focus it: leftover ball power discharges into your focus target.";
      else prompt = "Watch the red countdowns above monsters: they act after your next shot. Hover anything for details.";
    } else if (f.phase == PH_FLIGHT && f.turn == 1) {
      prompt = "Hold Space to fast-forward. Catch the ball in a tulip, spin slot machines, knock down targets...";
    }
  }
  if (!prompt.empty()) {
    float tw = std::min(780.f, g.measure(prompt, 15, F_UIB).x + 30);
    float th = std::max(28.f, g.measure(prompt, 15, F_UIB, tw - 24).y + 10);
    float py = 96.f;
    g.fillRRect(LAUNCH_X - tw / 2, py, tw, th, 8, 0x0b0d12, 0.9f);
    g.rrect(LAUNCH_X - tw / 2, py, tw, th, 8, 0xffd060, 0.8f, 1.5f);
    g.text(prompt, LAUNCH_X - tw / 2 + 12, py, tw - 24, th, 15, 0xffe8a0, 1.f, F_UIB, AL_C, VA_M);
  }
  // banners
  if (!a.banners.empty()) {
    const BannerFx& b = a.banners.front();
    float al = clampv(b.life * 2.f, 0.f, 1.f) * clampv((2.2f - b.life) * 6.f, 0.f, 1.f);
    float tw = std::min(820.f, g.measure(b.s, 30, F_TITLE).x + 60);
    g.fillRRect(LAUNCH_X - tw / 2, 300, tw, 56, 12, 0x07080c, 0.78f * al);
    g.rrect(LAUNCH_X - tw / 2, 300, tw, 56, 12, b.col, 0.8f * al, 2);
    g.textSh(b.s, LAUNCH_X - tw / 2, 300, tw, 56, tw >= 820.f ? 24.f : 30.f, b.col, al, F_TITLE, AL_C, VA_M);
  }
  // hover tooltips on board
  if (interactive && a.in.mouse.x > BOARD_X0 && a.in.mouse.x < BOARD_X1 && a.targetAb < 0) {
    if (a.hoverMon >= 0) monsterTooltip(a, w, f.mons[a.hoverMon]);
    else if (f.phase != PH_FLIGHT) {
      for (auto& p : f.pegs) {
        if (p.dead || p.kind == PK_PIN) continue;
        if (dist(a.in.mouse, p.p) < p.r + 4) {
          std::string title;
          std::string body = pegTip(w, p, title);
          setTip(a, title, body, PEG_COLOR[p.kind]);
          break;
        }
      }
      if (!a.tip.active && a.in.mouse.y > POCKET_TOP) {
        for (auto& p : f.pockets)
          if (a.in.mouse.x >= p.x0 && a.in.mouse.x < p.x1) setTip(a, std::string(POCKET_NAME[p.kind]) + " pocket", pocketTip(w, p), POCKET_COLOR[p.kind]);
      }
      if (!a.tip.active && a.in.mouse.y < 90 && a.in.mouse.x > PX1 - 232 && (f.slotShow > 0 || f.slotSpins > 0 || f.slotT > 0))
        setTip(a, "Slot Machine",
               "Catch a ball in a slot chucker to spin. Three of a kind: 7s = jackpot (free turn, gold, healing, +25 power), BARs = "
               "+15 power, BELLs = stun and damage every monster, CHERRIES = heal 30%, COINS = gold, STARS = Crit and Multiball "
               "pegs, SKULLs = a monster appears. Pairs pay a little.",
               0xffd700);
      if (!a.tip.active)
        for (auto& s : f.segs) {
          if (s.dead) continue;
          const char* nm = nullptr;
          const char* ds = nullptr;
          switch (s.kind) {
            case SK_KICKER: nm = "Kicker"; ds = "Slingshot: fires balls away hard. +1 power per kick."; break;
            case SK_PENDULUM: nm = "Pendulum"; ds = "A swinging weight. Hitting it grants +2 power and a big shove."; break;
            case SK_SPINNER: nm = "Spinner"; ds = "A spinning bar that flings balls. +1 power per hit."; break;
            case SK_ICEWALL: nm = "Ice Wall"; ds = "Balls bouncing off it gain +3 power and frost. It shatters after a few hits."; break;
            case SK_BARRIER: nm = "Barrier"; ds = "A monster's wall. Break it with your balls."; break;
            default: break;
          }
          if (!nm) continue;
          V2 cp = closestOnSeg(a.in.mouse, s.a, s.b);
          if (dist(cp, a.in.mouse) < s.th + 6) {
            setTip(a, nm, ds, 0xe0c090);
            break;
          }
        }
      if (!a.tip.active)
        for (auto& z : f.zones) {
          if (z.dead) continue;
          bool inside = z.circle ? dist(a.in.mouse, z.p) < z.half.x
                                 : (std::fabs(a.in.mouse.x - z.p.x) < z.half.x && std::fabs(a.in.mouse.y - z.p.y) < z.half.y);
          if (!inside) continue;
          std::string nm = ZONE_NAME[z.kind], ds = ZONE_DESC[z.kind];
          if (z.kind == ZK_PORTAL) nm = z.link >= 0 ? "Portal entrance" : "Portal exit";
          if (z.kind == ZK_WELL && z.link == -9) {
            nm = "Sinkhole";
            ds = fmt("Drags balls toward it, and monsters in its pull take %d damage each enemy phase.", z.dmg);
          }
          if (z.kind == ZK_BLACKHOLE && z.dmg > 0) ds = fmt("Pulls balls in. A swallowed ball discharges %d%% of its power into your target.", z.dmg);
          if (z.kind == ZK_CHARGE && z.dmg == 1) {
            nm = "Sunspot";
            ds += " Balls passing through also ignite.";
          }
          if (z.kind == ZK_RIFT && z.dmg > 0) ds += fmt(" (+%d power)", z.dmg);
          if (z.ttl > 0) ds += fmt("\nLasts %d more turn(s).", z.ttl);
          setTip(a, nm, ds, 0x9fd0ff);
          break;
        }
    }
  }
}

// ------------------------------------------------------------------ input on the board
void boardInput(App& a) {
  World& w = a.w;
  Floor& f = w.fl;
  f.cursor = a.in.mouse;
  bool inBoard = a.in.mouse.x > BOARD_X0 && a.in.mouse.x < BOARD_X1;
  bool modal = !w.offers.empty() || !w.relicOffers.empty() || a.paused;
  if (modal) return;
  // targeting mode
  if (a.targetAb >= 0 || a.targetItem >= 0) {
    if (a.in.rPressed || a.in.keyPressed[KEY_ESC]) {
      a.targetAb = a.targetItem = -1;
      a.targetStage = 0;
      audio::play(S_CLICK, 0.4f, 0.7f);
      return;
    }
    if (f.phase != PH_AIM && (a.targetAb < 0 || ABIL[a.targetAb].timing != T_FLIGHT)) {
      a.targetAb = a.targetItem = -1;
      return;
    }
    if (a.in.lPressed && !a.in.consumed && inBoard) {
      a.in.consumed = true;
      bool isItem = a.targetAb < 0;
      int itemId = isItem && a.targetItem < (int)w.pl.items.size() ? w.pl.items[a.targetItem].id : -1;
      int tg = !isItem ? ABIL[a.targetAb].target : (itemId >= 0 ? ITEM[itemId].target : TG_MONSTER);
      bool done = false;
      if (tg == TG_MONSTER) {
        if (a.hoverMon >= 0) {
          done = !isItem ? castAbility(w, a.targetAb, a.in.mouse, a.in.mouse, a.hoverMon) : useItem(w, a.targetItem, a.in.mouse, a.hoverMon);
          if (!done) {
            audio::play(S_DENY, 0.6f);
            fxText(w, a.in.mouse, 0xff8080, "No effect on that target", 14);
          }
          a.targetAb = a.targetItem = -1;
        }
      } else if (tg == TG_POINT) {
        done = !isItem ? castAbility(w, a.targetAb, a.in.mouse, a.in.mouse, -1) : useItem(w, a.targetItem, a.in.mouse, -1);
        if (!done) {
          audio::play(S_DENY, 0.6f);
          fxText(w, a.in.mouse, 0xff8080, "Can't do that there", 14);
        }
        a.targetAb = a.targetItem = -1;
      } else {
        if (a.targetStage == 0) {
          a.targetP1 = a.in.mouse;
          a.targetStage = 1;
          audio::play(S_CLICK, 0.5f, 1.2f);
        } else {
          done = castAbility(w, a.targetAb, a.targetP1, a.in.mouse, -1);
          if (!done) {
            audio::play(S_DENY, 0.6f);
            fxText(w, a.in.mouse, 0xff8080, "Too close together", 14);
          }
          a.targetAb = -1;
          a.targetStage = 0;
        }
      }
    }
    return;
  }
  // aiming
  if (f.phase == PH_AIM || f.phase == PH_RELAUNCH) {
    if (inBoard) a.aimAngle = launchAngleFromMouse(a.in.mouse);
    if (w.st.adjustLaunch && a.in.wheel != 0 && inBoard) {
      f.launchSpeed = clampv(f.launchSpeed + a.in.wheel * 40.f, 360.f, 980.f);
    }
    if (a.in.rPressed && a.hoverMon >= 0 && f.phase == PH_AIM) {
      if (!f.mons[a.hoverMon].charmed) {
        f.focus = a.hoverMon;
        audio::play(S_CLICK, 0.6f, 1.3f);
      }
    } else if (a.in.lPressed && !a.in.consumed && inBoard && a.in.mouse.y < POCKET_TOP) {
      a.in.consumed = true;
      if (f.phase == PH_AIM) {
        if (canLaunch(w)) launch(w, a.aimAngle, f.launchSpeed);
      } else relaunch(w, a.aimAngle);
    }
  } else if (f.phase == PH_REDIRECT) {
    V2 o(0, 0);
    for (auto& b : f.balls)
      if (b.alive) {
        o = b.p;
        break;
      }
    V2 d = a.in.mouse - o;
    a.aimAngle = std::atan2(d.y, d.x);
    if (a.in.lPressed && !a.in.consumed && inBoard) {
      a.in.consumed = true;
      redirect(w, a.aimAngle);
    }
  } else if (f.phase == PH_FLIGHT || f.phase == PH_ENEMY) {
    if (a.in.rPressed && a.hoverMon >= 0 && !f.mons[a.hoverMon].charmed) {
      f.focus = a.hoverMon;
      audio::play(S_CLICK, 0.6f, 1.3f);
    }
  }
}
