// Dropcrawl - ball events: pegs, sensors (tulips / slot chucker), zones, monster hits, pockets, slot machine
#include "rules.h"

const char* SLOT_NAME[7] = {"7", "BAR", "BELL", "CHERRY", "COIN", "STAR", "SKULL"};
const uint32_t SLOT_COLOR[7] = {0xff4050, 0xe0e0e0, 0xffd040, 0xff4080, 0xffc840, 0x80c0ff, 0xb0a0c0};

void allBallsPower(World& w, int amt) {
  Floor& f = w.fl;
  bool any = false;
  if (f.phase == PH_FLIGHT)
    for (auto& b : f.balls)
      if (b.alive && !(b.flags & BF_PHANTOM)) {
        b.power += amt;
        any = true;
      }
  if (!any) w.pl.nextShotPower += amt;
}

static void grantFreeTurn(World& w) {
  Floor& f = w.fl;
  if (f.phase == PH_FLIGHT) f.shot.freeTurn = true;
  else f.pendingFree = true;
}

// ================================================================ special peg effects
static void voidSwallow(World& w, int bi, float mul) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  if (!b.alive) return;
  fxBurst(w, b.p, 0x8040e0, 26, 240, 4);
  fxRing(w, b.p, 50, 0x8040e0);
  fxSound(w, S_PORTAL, 0.8f, 0.5f, b.p.x);
  if (!(b.flags & BF_PHANTOM) && b.power > 0) {
    int dmg = std::max(1, (int)std::lround(b.power * mul));
    fxText(w, b.p + V2(0, -18), 0xb080ff, fmt("Void! x%.1f", mul), 15);
    discharge(w, b.p, dmg, 0xa070ff);
  }
  if (w.pl.patron == PT_VOIDMAW) gainPiety(w, 3);
  f.balls[bi].power = 0;
  endBall(w, bi, -1);
}

void onBlackHole(World& w, int bi, int zi) {
  const Zone& z = w.fl.zones[zi];
  float mul = z.dmg > 0 ? z.dmg / 100.f : w.st.voidMul;
  voidSwallow(w, bi, mul);
}

void pegTriggerEffect(World& w, int bi, int pi, bool echo) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Peg& p = f.pegs[pi];
  int k = p.kind;
  V2 pp = p.p;
  f.lastTrig = (uint8_t)k;
  bool special = true;
  switch (k) {
    case PK_CRIT: {
      int np = (int)std::ceil(std::max(1, b.power) * w.st.critMul);
      fxText(w, pp + V2(0, -12), 0xff5060, fmt("x%g", w.st.critMul), 15);
      b.power = np;
      fxSound(w, S_CRIT, 0.35f, 1.6f, pp.x);
      break;
    }
    case PK_GOLD: gainGold(w, 2 + w.depth / 3, pp); fxSound(w, S_COIN, 0.6f, 1.f, pp.x); break;
    case PK_HEAL: {
      bool moss = w.pl.species == SP_MOSS || (w.pl.species == SP_CHANGELING && w.pl.form == SP_MOSS);
      healPlayer(w, 2 + (moss ? 1 : 0), true);
      fxSound(w, S_HEAL, 0.4f, 1.3f, pp.x);
      break;
    }
    case PK_MANA: gainMp(w, 1); fxSound(w, S_MANA, 0.5f, 1.f, pp.x); break;
    case PK_MULTI: splitBall(w, bi, 1.f); fxSound(w, S_CAST, 0.5f, 1.5f, pp.x); break;
    case PK_FIRE: b.power += 2; b.flags |= BF_FIRE; fxSound(w, S_FIRE, 0.4f, 1.3f, pp.x); break;
    case PK_ICE: b.power += 3; b.flags |= BF_FROST; fxSound(w, S_FREEZE, 0.4f, 1.3f, pp.x); break;
    case PK_POISON: b.power += 2; b.flags |= BF_VENOM; fxSound(w, S_POISON, 0.5f, 1.f, pp.x); break;
    case PK_SPARK: {
      int dmg = std::max(1, b.power / 2);
      int mi = nearestMonster(w, pp);
      int hits = 1 + w.st.sparkExtra;
      int last = -1;
      V2 from = pp;
      for (int h = 0; h < hits; ++h) {
        int t = h == 0 ? mi : nearestMonster(w, from, last);
        if (t < 0) break;
        fxZap(w, from, f.mons[t].p, 0xfff080);
        from = f.mons[t].p;
        last = t;
        damageMonster(w, t, h == 0 ? dmg : std::max(1, dmg / 2), DS_ZAP);
      }
      fxSound(w, S_ZAP, 0.5f, 1.2f, pp.x);
      break;
    }
    case PK_CRYSTAL: b.power += 4; fxSound(w, S_PEG_SPECIAL, 0.5f, 1.3f, pp.x); break;
    case PK_XP: gainXp(w, 3 + w.depth / 2); fxText(w, pp, 0xffffff, "+XP", 13); break;
    case PK_REFRESH:
      gainMp(w, 2);
      for (auto& a : w.pl.abil)
        if (a.cd > 0) a.cd--;
      fxSound(w, S_MANA, 0.6f, 1.4f, pp.x);
      break;
    case PK_LIFE: b.power += 2; healPlayer(w, 1, true); break;
    case PK_CURSE:
      if (abLevel(w, AB_CURSEEATER)) {
        int lv = abLevel(w, AB_CURSEEATER);
        b.power += lv <= 1 ? 4 : lv == 2 ? 6 : 8;
        fxText(w, pp, 0xc080ff, "devoured", 12);
      } else if (w.st.warded) {
        fxText(w, pp, 0xe0e0ff, "warded", 12);
      } else {
        b.power = b.power / 2;
        fxText(w, pp, 0xb060ff, "cursed!", 13);
        fxSound(w, S_DENY, 0.5f, 0.8f, pp.x);
      }
      break;
    case PK_TELEPORT: {
      b.power += 2;
      V2 np = randomFieldSpot(w, b.r + 4, 4, FIELD_Y0, FIELD_Y0 + 420);
      if (np.x >= 0) {
        fxBurst(w, b.p, 0x80a0ff, 14, 180);
        b.p = np;
        b.stuckRef = np;
        fxBurst(w, np, 0x80a0ff, 14, 180);
        fxSound(w, S_PORTAL, 0.6f, 1.4f, np.x);
      }
      break;
    }
    case PK_JELLY:
      b.power += 4;
      b.v *= 0.15f;
      fxText(w, pp, 0x60f0a0, "squish", 12);
      fxSound(w, S_POISON, 0.5f, 0.6f, pp.x);
      if (w.pl.patron == PT_GLUB) gainPiety(w, 1);
      break;
    case PK_MIRROR:
      b.power += 2;
      b.v.y = -std::max(420.f, std::fabs(b.v.y));
      fxSound(w, S_SHATTER, 0.4f, 1.8f, pp.x);
      break;
    case PK_VAMPIRE: {
      int mi = nearestMonster(w, pp);
      if (mi >= 0) {
        fxZap(w, f.mons[mi].p, pp, 0xc02040);
        int d = damageMonster(w, mi, 3 + w.depth / 4, DS_SPELL);
        if (d > 0) healPlayer(w, d);
      }
      fxSound(w, S_CAST, 0.5f, 0.6f, pp.x);
      break;
    }
    case PK_CHAOS: {
      static const int POOL[] = {PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_MULTI, PK_FIRE, PK_ICE, PK_POISON, PK_SPARK,
                                 PK_CRYSTAL, PK_XP, PK_REFRESH, PK_LIFE, PK_TELEPORT, PK_MIRROR, PK_VAMPIRE, PK_FREEZE,
                                 PK_CLOVER, PK_ANVIL, PK_FEATHER, PK_SHIELD, PK_SEED, PK_RUNE, PK_STAR, PK_MOON, PK_DICE,
                                 PK_BRAND, PK_SNOWBALL, PK_HOURGLASS, PK_COMBO, PK_JACKPOT, PK_CURSE};
      const int N = sizeof(POOL) / sizeof(POOL[0]);
      int times = w.st.chaosTwice ? 2 : 1;
      for (int t = 0; t < times; ++t) {
        int rk = POOL[f.rng.range(0, N - 1)];
        if (rk == PK_CURSE && (w.st.lucky || f.rng.chance(0.6f))) rk = POOL[f.rng.range(0, N - 2)];
        f.pegs[pi].kind = (uint8_t)rk;
        fxText(w, pp + V2(0, -14 - 12 * t), PEG_COLOR[rk], PEG_NAME[rk], 12);
        pegTriggerEffect(w, bi, pi, true);
        f.pegs[pi].kind = PK_CHAOS;
      }
      f.lastTrig = PK_CHAOS;
      fxSound(w, S_CAST, 0.5f, 1.8f, pp.x);
      break;
    }
    case PK_FREEZE: {
      b.power += 2;
      int mi = nearestMonster(w, pp);
      if (mi >= 0) {
        fxZap(w, pp, f.mons[mi].p, 0xa0f0ff);
        applyChill(w, mi, 1);
      }
      fxSound(w, S_FREEZE, 0.4f, 1.5f, pp.x);
      break;
    }
    case PK_CLOVER:
      b.power += 1;
      b.flags |= BF_LUCKY;
      fxText(w, pp, 0x50ff70, "lucky!", 12);
      fxSound(w, S_COIN, 0.5f, 1.8f, pp.x);
      break;
    case PK_ANVIL:
      b.power += 5;
      b.gravScale = std::min(1.6f, b.gravScale * 1.15f);
      fxSound(w, S_BLOCK, 0.5f, 0.7f, pp.x);
      break;
    case PK_FEATHER:
      b.power += 1;
      b.floatT = std::max(b.floatT, 0.9f);
      fxSound(w, S_WHOOSH, 0.4f, 1.6f, pp.x);
      break;
    case PK_VOID:
      if (!echo) b.flags |= BF_VOIDED;
      break;
    case PK_SHIELD: addBlock(w, 3 + w.depth / 5); fxSound(w, S_BLOCK, 0.4f, 1.4f, pp.x); break;
    case PK_SEED:
      b.power += 1;
      growPins(w, 3, pp, 60, true);
      fxSound(w, S_HEAL, 0.4f, 1.6f, pp.x);
      break;
    case PK_RUNE: runePeg(w, bi, pi); break;
    default: special = newPegTrigger(w, bi, pi, echo); break;
  }
  if (special && !echo) {
    f.shot.specialHits++;
    if (f.balls[bi].specialsHit < 250) f.balls[bi].specialsHit++;
    if (k != PK_ECHO && k != PK_CHAOS) f.shot.lastSpecial = k;
  }
}

static void checkTargetBank(World& w, int pi) {
  Floor& f = w.fl;
  int bank = f.pegs[pi].link;
  int total = 0, down = 0;
  for (auto& p : f.pegs)
    if (!p.dead && p.kind == PK_TARGET && p.link == bank) {
      total++;
      if (p.val) down++;
    }
  if (total == 0 || down < total) return;
  // bank complete: reward, then the targets pop back up
  int reward = f.pegs[pi].aux;
  V2 at = f.pegs[pi].p;
  switch (reward % 4) {
    case 0: allBallsPower(w, 12); gainMp(w, 1); fxText(w, at + V2(0, -20), 0xff6040, "+12 power, +1 MP", 16); break;
    case 1: gainGold(w, 12 + w.depth, at); break;
    case 2: healPlayer(w, 5 + w.depth / 3); break;
    default: discharge(w, at, 10 + w.depth, 0xff6040); break;
  }
  fxBanner(w, "Target bank cleared!", 0xff8060);
  fxSound(w, S_CHEST, 0.8f, 1.3f, at.x);
  for (auto& p : f.pegs)
    if (!p.dead && p.kind == PK_TARGET && p.link == bank) {
      p.val = 0;
      p.flash = 1.f;
    }
}

void onPegHit(World& w, int bi, int pi, float impact) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Peg& p = f.pegs[pi];
  if (p.dead) return;
  b.pegHits++;
  b.pegsSinceMon++;
  f.shot.pegHits++;
  f.turnPegHits++;
  w.rs.pegHits++;
  p.flash = 1.f;
  f.lastTrig = PK_PIN;
  int k = p.kind;
  float pan = p.p.x;
  V2 pp = p.p;
  if (p.used || k == PK_PIN || k == PK_GHOST) {
    b.power += 1;
    if (f.shrine == 3) b.power += 1 + w.st.shrineBonus;
    int idx = std::min(b.pegHits - 1, 20);
    static const int SC[] = {0, 2, 4, 7, 9, 12, 14, 16, 19, 21, 24, 26, 28, 31, 33, 36, 38, 40, 43, 45, 48};
    fxSound(w, S_PEG, 0.28f, audio::semis((float)SC[idx] * 0.5f), pan);
    if (b.flashHits > 0 && !p.used) {
      b.flashHits--;
      b.power += 2;
      fxBurst(w, pp, 0xff7030, 8, 120, 2.5f);
      int mi = nearestMonster(w, pp);
      if (mi >= 0) applyBurn(w, mi, 1);
    }
  } else if (isEnchant(k)) {
    bool consumed = true;
    int pf = abLevel(w, AB_PERMAFROST);
    if (pf && f.rng.chance(pf == 1 ? 0.2f : pf == 2 ? 0.35f : 0.5f)) consumed = false;
    int ld = abLevel(w, AB_LOADEDDICE);
    if (ld && k == PK_CRIT && f.rng.chance(ld == 1 ? 0.25f : ld == 2 ? 0.35f : 0.5f)) consumed = false;
    if (k == PK_VOID) consumed = true;
    pegTriggerEffect(w, bi, pi, false);
    if (w.st.luckyPct > 0 && k != PK_CURSE && k != PK_VOID && k != PK_TELEPORT && k != PK_CANNON && f.balls[bi].alive &&
        f.rng.chance(w.st.luckyPct)) {
      fxText(w, pp + V2(0, 24), 0x50ff70, "lucky!", 12);
      pegTriggerEffect(w, bi, pi, true);
    }
    if (f.shot.echoLeft > 0 && k != PK_CURSE && k != PK_VOID && k != PK_TELEPORT) {
      f.shot.echoLeft--;
      fxText(w, pp + V2(0, 12), 0xc080ff, "echo!", 12);
      pegTriggerEffect(w, bi, pi, true);
    }
    if (consumed) f.pegs[pi].used = true;
    else fxText(w, pp + V2(0, 12), 0xa0e8ff, "kept", 11);
    fxSound(w, S_PEG_SPECIAL, 0.3f, 0.9f + 0.05f * std::min(f.balls[bi].pegHits, 12), pan);
    fxBurst(w, pp, PEG_COLOR[k], 8, 120, 2.5f);
  } else {
    switch (k) {
      case PK_BOMB: {
        p.dead = true;
        f.shot.specialHits++;
        explodeAt(w, pp, 120, p.val, bi);
        break;
      }
      case PK_GLASS:
        b.power += 3;
        p.dead = true;
        fxBurst(w, pp, 0xd0f0ff, 12, 160, 2);
        fxSound(w, S_SHATTER, 0.4f, 1.3f, pan);
        break;
      case PK_STONE:
      case PK_PILLAR:
        b.power += (k == PK_STONE ? 1 : std::max(1, p.val));
        if (--p.hp <= 0) {
          p.dead = true;
          fxBurst(w, pp, PEG_COLOR[k], 14, 160, 3);
          fxSound(w, S_BLOCK, 0.5f, 0.6f, pan);
        } else fxSound(w, S_WALL, 0.6f, 1.f, pan);
        break;
      case PK_BUMPER:
      case PK_MUSHROOM: {
        int add = k == PK_BUMPER ? 2 : 1;
        int oc = abLevel(w, AB_OVERCLOCK);
        if (oc) add += oc <= 1 ? 2 : oc == 2 ? 3 : 4;
        if (hasRelic(w, RL_RUBBER)) add += 3;
        if (hasRelic(w, RL_U_GEARHEART)) add += 3;
        b.power += add;
        fxSound(w, S_BUMP, 0.5f, k == PK_BUMPER ? 1.f : 1.4f, pan);
        fxRing(w, pp, p.r + 10, PEG_COLOR[k]);
        break;
      }
      case PK_CHEST:
        b.power += 1;
        if (--p.hp <= 0) {
          p.dead = true;
          int tier = p.val;
          gainGold(w, 10 + 2 * w.depth, pp);
          if (tier == 99) {
            if (f.rng.chance(0.45f)) {
              uint32_t seed = newRandartSeed(w);
              gainRandart(w, seed);
              fxBanner(w, "A randart!", 0xffd040);
            } else {
              int rl = randomRelicFor(w, true, true);
              if (rl >= 0) {
                uint32_t sd = RELIC[rl].tier == 0 ? rollRelicQuality(w, true) : 0u;
                gainRelic(w, rl, sd);
                fxBanner(w, std::string("Relic: ") + offerRelicName(rl, sd), RELIC[rl].tier == 1 ? 0xffa838 : sd ? 0x6aa0ff : RELIC[rl].color);
              }
            }
          }
          int roll = f.rng.range(0, 99);
          if (roll < 45) {
            static const int L[] = {IT_HEALING, IT_MANA, IT_MIGHT, IT_RESIST, IT_FEAR, IT_IMMOLATION, IT_ENCHANT, IT_BRAND,
                                    IT_VULN, IT_TELEPORT, IT_AMBROSIA, IT_REVEAL, IT_LUCK, IT_W_FLAME, IT_W_ICE, IT_W_BUMPERS,
                                    IT_CANCEL, IT_UPHEAVAL, IT_BUTTERFLIES, IT_W_ROOTS};
            int it = L[f.rng.range(0, 19)];
            if (gainItem(w, it)) {
              logMsg(w, 0xffd080, "The chest contains a %s!", ITEM[it].name);
              fxText(w, pp + V2(0, -18), ITEM[it].color, ITEM[it].name, 14);
              w.rewardItems.push_back(it);
            }
          }
          fxSound(w, S_CHEST, 0.8f, 1.f, pan);
          fxBurst(w, pp, 0xffd040, 24, 220, 3);
        } else fxSound(w, S_WALL, 0.7f, 0.8f, pan);
        break;
      case PK_KEY:
        b.power += 1;
        p.dead = true;
        for (auto& s : f.segs)
          if (!s.dead && s.kind == SK_GATE && s.link == p.link) s.open = true;
        fxText(w, pp, 0xffe070, "Unlocked!", 15);
        fxSound(w, S_CHEST, 0.8f, 1.4f, pan);
        break;
      case PK_TOTEM:
        b.power += 1;
        if (--p.hp <= 0) {
          p.dead = true;
          fxBurst(w, pp, PEG_COLOR[k], 14, 160, 3);
          fxSound(w, S_SHATTER, 0.5f, 0.7f, pan);
        } else fxSound(w, S_WALL, 0.6f, 0.9f, pan);
        break;
      case PK_BONE: b.power += std::max(1, p.val); fxSound(w, S_BUMP, 0.4f, 0.7f, pan); break;
      case PK_THORN: b.power += 3; fxSound(w, S_PEG, 0.3f, 0.8f, pan); break;
      case PK_GOLEM: b.power += std::max(1, p.val); fxSound(w, S_BUMP, 0.6f, 0.5f, pan); fxRing(w, pp, p.r + 12, PEG_COLOR[k]); break;
      case PK_TREE: b.power += 8; healPlayer(w, 1, true); fxSound(w, S_BUMP, 0.5f, 0.6f, pan); break;
      case PK_SKELETON: b.power += 4; fxSound(w, S_BUMP, 0.5f, 0.8f, pan); break;
      case PK_MBOMB:
        b.power += 3;
        if (p.aux > 1) {
          p.aux--;
          p.flash = 1.f;
          fxText(w, pp + V2(0, -18), 0xffc080, fmt("cracked! (%d more)", p.aux), 14);
          fxBurst(w, pp, 0xff8040, 12, 160, 3);
          fxSound(w, S_SHATTER, 0.6f, 0.8f, pan);
        } else {
          p.dead = true;
          fxText(w, pp, 0xa0ffa0, p.r > 12 ? "meteor shattered!" : "defused!", 15);
          fxSound(w, S_CHEST, 0.6f, 1.6f, pan);
        }
        break;
      case PK_MAGNET: b.power += 1; fxSound(w, S_BUMP, 0.4f, 1.6f, pan); break;
      case PK_COINS:
        b.power += 1;
        gainGold(w, 2, pp);
        fxSound(w, S_COIN, 0.5f, 1.2f, pan);
        if (--p.hp <= 0) {
          p.dead = true;
          fxBurst(w, pp, 0xffc840, 16, 180, 3);
        }
        break;
      case PK_SPRING:
        b.power += 1;
        b.v = V2(b.v.x * 0.5f, -std::max(950.f, len(b.v)));
        fxRing(w, pp, p.r + 10, PEG_COLOR[k]);
        fxSound(w, S_BUMP, 0.6f, 1.6f, pan);
        break;
      case PK_EGG:
        b.power += 2;
        p.dead = true;
        fxText(w, pp, 0xe0d0a0, "splat!", 13);
        fxBurst(w, pp, 0xe0d0a0, 14, 150, 3);
        fxSound(w, S_POISON, 0.5f, 1.2f, pan);
        break;
      case PK_IMP: case PK_FAMILIAR: case PK_FIREFLY: b.power += 2; fxSound(w, S_BUMP, 0.4f, 1.5f, pan); break;
      case PK_HOUND: b.power += 4; fxSound(w, S_BUMP, 0.5f, 1.1f, pan); break;
      case PK_TESLA: b.power += 3; fxSound(w, S_ZAP, 0.3f, 1.8f, pan); break;
      case PK_ANGEL: b.power += 5; fxSound(w, S_BUMP, 0.5f, 1.3f, pan); break;
      case PK_BELL:
        b.power += 1;
        if (p.val < 2) {
          p.val++;
          int d = 2 + w.depth / 3;
          fxRing(w, pp, 220, 0xffe0a0);
          fxSound(w, S_LEVEL, 0.5f, 1.8f, pan);
          for (int i = 0; i < (int)f.mons.size(); ++i)
            if (isHostile(w, i)) damageMonster(w, i, d, DS_SPELL);
        } else fxSound(w, S_WALL, 0.4f, 1.8f, pan);
        break;
      case PK_TARGET:
        if (p.val == 0) {
          p.val = 1;
          b.power += 2;
          fxBurst(w, pp, PEG_COLOR[k], 10, 140, 2.5f);
          fxSound(w, S_BLOCK, 0.5f, 1.4f, pan);
          checkTargetBank(w, pi);
        }
        break;
      default:
        if (!newPegHit(w, bi, pi)) f.balls[bi].power += 1;
        break;
    }
  }
  Ball& bb = f.balls[bi];
  if (f.shot.goldTouch) {
    bb.power += 1;
    gainGold(w, 1, pp);
  }
  if ((bb.flags & BF_GOLDEN) && f.shot.pegHits <= 40) gainGold(w, 1, pp);
  if (w.pl.patron == PT_VERDANA && f.turnPegHits % 25 == 0) gainPiety(w, 1);
  FOR_EFF(pegHit, bi, pi);
  (void)impact;
  if (f.shot.mirrorSplit && !(f.balls[bi].flags & BF_PHANTOM)) {
    f.shot.mirrorSplit = false;
    splitBall(w, bi, 1.f);
  }
  if (f.balls[bi].alive && (f.balls[bi].flags & BF_VOIDED)) voidSwallow(w, bi, w.st.voidMul);
}

// ================================================================ sensors (tulips / slot chucker)
static void setPetals(World& w, int pi, bool open) {
  for (auto& s : w.fl.segs) {
    if (s.dead || s.kind != SK_PETAL || s.link != pi) continue;
    s.ang = open ? s.upAng : s.restAng;
    s.a = s.c;
    s.b = s.c + fromAng(s.ang) * s.len;
  }
}

void onSensor(World& w, int bi, int pi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Peg& p = f.pegs[pi];
  if (p.dead || b.sensorCd > 0) return;
  b.sensorCd = 0.45f;
  V2 c = p.p;
  p.flash = 1.f;
  if (p.kind == PK_TULIP) {
    int bonus = 6 + w.st.tulipBonus + (p.aux ? 2 : 0);
    b.power += bonus;
    gainGold(w, 2 + w.depth / 4, c);
    fxText(w, c + V2(0, -24), PEG_COLOR[PK_TULIP], fmt("Tulip! +%d", bonus), 15);
    fxSound(w, S_POCKET, 0.7f, 1.45f, c.x);
    fxBurst(w, c, PEG_COLOR[PK_TULIP], 16, 160, 3);
    if (!p.aux) {
      p.aux = 1;
      setPetals(w, pi, true);
    }
  } else if (p.kind == PK_CHUCKER) {
    b.power += 2 + w.st.tulipBonus / 2;
    queueSlotSpin(w);
    fxText(w, c + V2(0, -24), PEG_COLOR[PK_CHUCKER], "SPIN!", 16);
    fxSound(w, S_COIN, 0.8f, 0.9f, c.x);
    fxBurst(w, c, PEG_COLOR[PK_CHUCKER], 18, 180, 3);
  } else {
    return;
  }
  f.shot.specialHits++;
  // spit the ball out underneath
  Ball& bb = f.balls[bi];
  bb.p = c + V2(0, p.r + bb.r + 3);
  bb.v = V2(f.rng.rangef(-70, 70), 200);
  bb.stuckRef = bb.p;
  bb.pegsSinceMon++;
}

// ================================================================ zones
void onZoneEnter(World& w, int bi, int zi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Zone& z = f.zones[zi];
  switch (z.kind) {
    case ZK_MIRROR:
      b.v.x = -b.v.x;
      if (std::fabs(b.v.x) < 140) b.v.x = (b.v.x < 0 ? -1.f : 1.f) * 140;
      b.power += 1;
      fxBurst(w, b.p, 0xe0f0ff, 8, 120);
      fxSound(w, S_SHATTER, 0.3f, 2.f, b.p.x);
      break;
    case ZK_RUNE: runeCircle(w, bi, zi); break;
    case ZK_SPRING:
      if (f.shot.springHeal < 5 && !(b.flags & BF_PHANTOM)) {
        f.shot.springHeal++;
        healPlayer(w, 1, true);
      }
      break;
    case ZK_ROLLOVER:
      if (!z.lit) {
        z.lit = 1;
        b.power += 1;
        fxSound(w, S_PEG_SPECIAL, 0.4f, 1.7f, b.p.x);
        bool all = true;
        for (auto& o : f.zones)
          if (!o.dead && o.kind == ZK_ROLLOVER && o.link == z.link && !o.lit) all = false;
        if (all) {
          b.power += 10;
          gainMp(w, 1);
          fxBanner(w, "Lanes lit! +10 power", 0xffe060);
          fxSound(w, S_LEVEL, 0.6f, 1.5f, b.p.x);
          for (auto& o : f.zones)
            if (!o.dead && o.kind == ZK_ROLLOVER && o.link == z.link) o.lit = 0;
        }
      }
      break;
    case ZK_MIST:
      if (!(b.flags & BF_VENOM)) {
        b.flags |= BF_VENOM;
        fxText(w, b.p, 0x90e040, "venom", 11);
      }
      break;
    case ZK_WATER:
      if (hasRelic(w, RL_DIVINGBELL)) {
        b.power += 2;
        fxText(w, b.p, 0x60c8ff, "+2", 11);
      }
      break;
    case ZK_CHARGE:
      if (z.dmg == 1 && !(b.flags & BF_FIRE)) {
        b.flags |= BF_FIRE;
        fxText(w, b.p, 0xffa040, "ignited", 11);
      }
      break;
    case ZK_LAVA:
      if (hasRelic(w, RL_LAVALAMP)) b.flags |= BF_FIRE;
      break;
    default: break;
  }
}

// ================================================================ monster hits
// Armed "next hit" effects. They fire on the first qualifying ball hit, or on the final discharge.
void triggerFireball(World& w, int mi, V2 mpos, int baseDmg) {
  Floor& f = w.fl;
  f.shot.fireball = false;
  float frac = f.shot.fireballLvl <= 1 ? 0.7f : f.shot.fireballLvl == 2 ? 0.9f : 1.1f;
  fxBurst(w, mpos, 0xff7020, 40, 300, 4);
  fxRing(w, mpos, 190, 0xff7020);
  fxSound(w, S_BOOM, 0.9f, 1.1f, mpos.x);
  int sd = std::max(1, (int)(baseDmg * frac));
  for (int i = 0; i < (int)f.mons.size(); ++i) {
    if (i == mi || !isHostile(w, i)) continue;
    if (dist(f.mons[i].p, mpos) - f.mons[i].r < 190) damageMonster(w, i, sd, DS_EXPLOSION);
  }
}

void triggerChain(World& w, int mi, V2 mpos, int baseDmg) {
  Floor& f = w.fl;
  f.shot.chain = false;
  int n = (f.shot.chainLvl <= 1 ? 2 : f.shot.chainLvl == 2 ? 3 : 4) + (hasRelic(w, RL_U_STORMCROWN) ? 2 : 0);
  std::vector<int> others;
  for (int i = 0; i < (int)f.mons.size(); ++i)
    if (i != mi && isHostile(w, i)) others.push_back(i);
  std::sort(others.begin(), others.end(), [&](int a, int b2) { return dist2(f.mons[a].p, mpos) < dist2(f.mons[b2].p, mpos); });
  V2 from = mpos;
  int cd = std::max(1, baseDmg * 6 / 10);
  for (int k = 0; k < n && k < (int)others.size(); ++k) {
    int t = others[k];
    if (f.mons[t].dead) continue;
    fxZap(w, from, f.mons[t].p, 0xfff080);
    from = f.mons[t].p;
    damageMonster(w, t, cd, DS_ZAP);
  }
  fxSound(w, S_ZAP, 0.9f, 1.f, mpos.x);
}

bool onMonsterHit(World& w, int bi, int mi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  Monster& m = f.mons[mi];
  if (m.dead) return true;
  if (m.charmed) return false;  // your charmed thrall: the ball just bounces off
  const MonDef& d = MON[m.def];
  // anti bounce-loop: consecutive monster hits with no peg in between lose force
  bool stale = b.monHits > 0 && b.pegsSinceMon == 0;
  b.staleHits = stale ? b.staleHits + 1 : 0;
  b.pegsSinceMon = 0;
  HitCtx c;
  c.ball = bi;
  c.mon = mi;
  c.base = (float)std::max(0, b.power);
  c.mult = w.st.dmgMul;
  c.flat = w.st.flatHit;
  bool real = !(b.flags & BF_PHANTOM);
  if (!f.shot.firstHitDone && real) {
    c.first = true;
    f.shot.firstHitDone = true;
  }
  if (f.shot.doubleDown) c.mult *= 2.f;
  if (f.shot.berserk) c.mult *= 2.f;
  if (f.shot.might) c.mult *= 1.5f;
  if (f.shot.doubled) c.mult *= 2.f;
  if (f.shot.heroism) c.mult *= 1.4f;
  if (f.shot.diceMul10 != 10) c.mult *= f.shot.diceMul10 / 10.f;
  if (f.vulnTurn) c.mult *= 1.5f;
  if (m.hexT > 0) c.mult *= 1.f + m.hexPct / 100.f;
  if (m.elite || m.boss) c.mult *= w.st.eliteDmgMul;
  if (b.flags & BF_ECHO) c.mult *= 0.5f;
  if (w.st.finesse && c.first) c.mult *= 2.f;
  if (w.st.lowHpDmg > 0 && w.pl.hp * 2 < w.st.maxHp) c.mult *= 1.f + w.st.lowHpDmg;
  if (w.st.fullHpDmg > 0 && w.pl.hp >= w.st.maxHp) c.mult *= 1.f + w.st.fullHpDmg;
  // critical hits (Dexterity) and moonlight
  if ((b.flags & BF_CRITNEXT) || (w.st.critChance > 0 && f.rng.chance(w.st.critChance))) {
    c.crit = true;
    c.mult *= w.st.critDmg;
    b.flags &= ~BF_CRITNEXT;
    f.shot.crits++;
  }
  if (b.flags & BF_MOON) {
    c.mult *= 1.5f;
    b.flags &= ~BF_MOON;
  }
  if (w.st.packDmg > 0) c.mult *= 1.f + w.st.packDmg * std::min(3, allyPegCount(w));
  if (f.streakPower > 0) c.mult *= 1.f + f.streakPower / 100.f;
  if (b.flags & BF_BEAST) c.mult *= 1.f + (f.shot.beastLvl <= 1 ? 0.3f : f.shot.beastLvl == 2 ? 0.45f : 0.6f);
  if (b.flags & BF_HOLY) {
    c.flat += 5;
    if (isUndeadOrDemon(m)) c.mult *= 1.5f;
  }
  if (b.flags & BF_GOLDEN) {
    int gl = std::max(1, abLevel(w, AB_GOLDENBALL));
    int div = gl <= 1 ? 10 : gl == 2 ? 8 : 6, cap = gl <= 1 ? 8 : gl == 2 ? 12 : 16;
    c.flat += std::min(cap, w.pl.gold / div);
  }
  if (b.flags & BF_BANKED) {
    int bl = std::max(1, abLevel(w, AB_BANKSHOT));
    c.mult *= 1.f + (bl <= 1 ? 0.25f : bl == 2 ? 0.4f : 0.55f);
    b.flags &= ~BF_BANKED;
  }
  if (f.shot.unstoppable && real) {
    c.pierce = true;
    c.keepPower = std::max(c.keepPower, 0.7f);
  }
  FOR_EFF(monHit, c);
  int dmg = (int)std::lround(c.base * c.mult) + c.flat;
  Ball& b1 = f.balls[bi];
  if (b1.staleHits >= 3) {
    dmg = 0;
    fxText(w, f.mons[mi].p + V2(0, -f.mons[mi].r - 10), 0xa0a0b0, "glances off", 13);
  } else if (b1.staleHits > 0) {
    dmg = std::max(1, dmg >> b1.staleHits);
    fxText(w, f.mons[mi].p + V2(0, -f.mons[mi].r - 22), 0xa0a0b0, "glancing", 11);
  }
  if (f.mons[mi].reflectUp && dmg > 0) {
    f.mons[mi].reflectUp = false;
    dmg = 0;
    fxText(w, f.mons[mi].p + V2(0, -f.mons[mi].r - 10), 0xffffff, "reflected!", 14);
  }
  V2 mpos = f.mons[mi].p;
  float mr = f.mons[mi].r;
  int dealt = dmg > 0 ? damageMonster(w, mi, dmg, DS_BALL, bi) : 0;
  Ball& bb = f.balls[bi];
  f.shot.monHits++;
  f.shot.damage += dealt;
  f.shot.anyMonHit = true;
  w.rs.biggestHit = std::max(w.rs.biggestHit, dealt);
  noteDamageDealt(w, dealt);
  if (dealt > 0) {
    uint32_t col = c.crit ? 0xffe040 : 0xffffff;
    float sz = clampv(16.f + dealt * 0.25f, 16.f, 44.f);
    fxText(w, mpos + V2(f.rng.rangef(-8, 8), -mr - 10), col, fmt(c.crit ? "%d!" : "%d", dealt), sz);
    if (c.crit) fxText(w, mpos + V2(0, -mr - 34), 0xffe040, "CRIT", 12);
  }
  fxSound(w, (c.crit || dealt >= 40) ? S_CRIT : S_HIT, clampv(0.5f + dealt * 0.01f, 0.5f, 1.f), 1.f, mpos.x);
  fxShake(w, clampv(dealt * 0.12f, 1.f, 14.f));
  fxBurst(w, bb.p, d.color, clampv(6 + dealt / 3, 6, 40), 220, 3);
  // ancestor ball
  if (bb.flags & BF_ANCESTOR) {
    if (w.pl.patron == PT_ANCESTOR && dealt > 0) {
      f.pietyAcc += dealt;
      if (f.pietyAcc >= 10) {
        gainPiety(w, f.pietyAcc / 10);
        f.pietyAcc %= 10;
      }
    }
    if (abLevel(w, AB_P_ANCBLESS) && dealt > 0) healPlayer(w, 1);
    if (abLevel(w, AB_P_ANCBOND))
      for (auto& o : f.balls)
        if (o.alive && !(o.flags & BF_PHANTOM)) o.power += 3;
  }
  // on-hit statuses
  if (!f.mons[mi].dead && dealt > 0) {
    if (bb.flags & BF_FIRE) { applyBurn(w, mi, 4); bb.flags &= ~BF_FIRE; }
    if (bb.flags & BF_FROST) { applyChill(w, mi, 1); bb.flags &= ~BF_FROST; }
    if (bb.flags & BF_VENOM) { applyPoison(w, mi, 5); bb.flags &= ~BF_VENOM; }
    if (f.shot.brand) { applyBurn(w, mi, 3); applyPoison(w, mi, 3); applyChill(w, mi, 1); }
    if (w.pl.species == SP_EMBER || (w.pl.species == SP_CHANGELING && w.pl.form == SP_EMBER)) applyBurn(w, mi, 2);
    if (bb.flags & BF_BEAST) applyBleed(w, mi, 2);
    if (f.shot.bleedOnHit > 0 && real) applyBleed(w, mi, f.shot.bleedOnHit);
    if (bb.flags & BF_ELEMENTAL) {
      applyBurn(w, mi, 3);
      applyChill(w, mi, 1);
      int o = nearestMonster(w, mpos, mi);
      if (o >= 0) {
        fxZap(w, mpos, f.mons[o].p, 0xfff080);
        damageMonster(w, o, std::max(1, dealt / 2), DS_ZAP);
      }
    }
    if ((bb.flags & BF_ANCESTOR) && f.shot.idealize) applyChill(w, mi, 1);
    if (hasMod(w, MOD_BLOODMOON)) applyBleed(w, mi, 1);
    if (c.crit && w.st.critBleed > 0) applyBleed(w, mi, w.st.critBleed);
    if (c.crit && hasRelic(w, RL_U_ASSASSIN)) applyPoison(w, mi, 2);
  } else {
    bb.flags &= ~(BF_FIRE | BF_FROST | BF_VENOM);
  }
  int baseDmg = std::max(dealt, (int)std::lround(c.base * c.mult));
  if (c.base >= 10 && dealt > 0) {
    if (f.shot.fireball) triggerFireball(w, mi, mpos, baseDmg);
    if (f.shot.chain) triggerChain(w, mi, mpos, baseDmg);
  }
  if (f.shot.powerLeap && dealt > 0 && real) {
    f.shot.powerLeap = 0;
    fxRing(w, mpos, 130, 0xe0c090);
    fxShake(w, 10);
    fxSound(w, S_BOOM, 0.9f, 0.8f, mpos.x);
    hitMonstersInRadius(w, mpos, 130, dealt, DS_EXPLOSION, mi);
  }
  if (f.shot.kaleido && f.balls[bi].monHits == 0) splitBall(w, bi, 1.f, 2);
  bool slimey = w.pl.species == SP_SLIME || (w.pl.species == SP_CHANGELING && w.pl.form == SP_SLIME);
  if (slimey && real && !(f.balls[bi].flags & BF_SLIMESPLIT) && f.balls[bi].gen == 0) {
    f.balls[bi].flags |= BF_SLIMESPLIT;
    Ball& sb = f.balls[bi];
    spawnBall(w, sb.p, rot(sb.v, 0.5f) * 1.02f, std::max(1, sb.power / 2), BF_PHANTOM, sb.gen + 1);
    fxText(w, f.balls[bi].p, 0x80e080, "mitosis!", 12);
  }
  if (abLevel(w, AB_P_SLIMETIDE) && !f.shot.slimeTideUsed && real) {
    f.shot.slimeTideUsed = true;
    splitBall(w, bi, 0.7f, 1);
  }
  if (hasRelic(w, RL_HYDRASCALE) && !f.shot.hydraUsed && real) {
    f.shot.hydraUsed = true;
    splitBall(w, bi, 0.6f, 1);
  }
  if ((d.traits & TR_THORNS) && !w.dead) {
    damagePlayer(w, d.tval, -1, true, "a jellyfish sting");
    fxText(w, f.balls[bi].p, 0xd0b0ff, "sting!", 12);
  }
  if (!f.mons[mi].dead && hasAffix(f.mons[mi], AF_THORNS) && !w.dead) {
    damagePlayer(w, 2 + w.depth / 5, -1, true, "a thorny champion");
    fxText(w, f.balls[bi].p, 0x90c060, "thorns!", 12);
  }
  if (d.traits & TR_ACIDIC) {
    int n = 0;
    for (auto& p : f.pegs) {
      if (n >= std::max(1, d.tval)) break;
      if (p.dead || p.kind != PK_PIN || p.motion || dist2(p.p, mpos) > 110 * 110) continue;
      p.dead = true;
      fxBurst(w, p.p, 0xa0ff40, 6, 90);
      n++;
    }
    if (n) fxText(w, mpos + V2(0, mr + 10), 0xa0ff40, "acid!", 12);
  }
  FOR_EFF(monDamaged, bi, mi, dealt);
  Ball& b2 = f.balls[bi];
  b2.monHits++;
  int keep = (int)std::floor(b2.power * c.keepPower);
  b2.power = std::max(effPower(w), keep);
  if (b2.flags & BF_BOULDER) b2.power = std::max(b2.power, effPower(w));
  if (hasRelic(w, RL_FEATHERCAP)) b2.floatT = std::max(b2.floatT, 0.4f);
  if (!f.mons[mi].dead && ((d.traits & TR_EVASIVE) || hasAffix(f.mons[mi], AF_TELEPORT))) f.mons[mi].shotFlags |= 2;
  return c.pierce || f.mons[mi].dead;
}

void onWallBounce(World& w, int bi, float impact) {
  Floor& f = w.fl;
  f.balls[bi].wallHits++;
  f.shot.wallHits++;
  if (w.st.wallPower) f.balls[bi].power += 1;
  if (f.balls[bi].flags & BF_GEARED) f.balls[bi].power += 1;
  if (impact > 150) fxSound(w, S_WALL, 0.25f, 1.f, f.balls[bi].p.x);
  FOR_EFF(wallHit, bi);
}

void onSegHit(World& w, int bi, int si, float impact) {
  Floor& f = w.fl;
  Seg& s = f.segs[si];
  Ball& b = f.balls[bi];
  s.flash = 1.f;
  switch (s.kind) {
    case SK_WALL:
    case SK_RAMP: onWallBounce(w, bi, impact); break;
    case SK_SPINNER: {
      int add = 1 + w.st.kickerBonus;
      int oc = abLevel(w, AB_OVERCLOCK);
      if (oc) add += oc <= 1 ? 2 : oc == 2 ? 3 : 4;
      b.power += add;
      fxSound(w, S_FLIP, 0.4f, 1.2f, b.p.x);
      break;
    }
    case SK_BARRIER:
      b.power += 1;
      if (--s.hp <= 0) {
        s.dead = true;
        fxBurst(w, s.c, 0x80c060, 12, 150, 3);
        fxSound(w, S_SHATTER, 0.5f, 0.8f, s.c.x);
      } else fxSound(w, S_WALL, 0.6f, 0.8f, b.p.x);
      break;
    case SK_FLIPPER: fxSound(w, S_FLIP, 0.5f, 1.f, b.p.x); break;
    case SK_DIVIDER: if (impact > 120) fxSound(w, S_WALL, 0.2f, 1.4f, b.p.x); break;
    case SK_GATE: fxSound(w, S_WALL, 0.4f, 0.7f, b.p.x); break;
    case SK_KICKER:
      if (impact > 60) {
        b.power += 1 + w.st.kickerBonus;
        fxRing(w, b.p, 24, 0xff9060);
        fxSound(w, S_BUMP, 0.6f, 1.3f, b.p.x);
      }
      break;
    case SK_PENDULUM:
      b.power += 2 + w.st.kickerBonus;
      fxSound(w, S_BUMP, 0.5f, 0.7f, b.p.x);
      break;
    case SK_PETAL: if (impact > 90) fxSound(w, S_PEG, 0.2f, 1.9f, b.p.x); break;
    case SK_ICEWALL:
      b.power += 3;
      b.flags |= BF_FROST;
      fxBurst(w, b.p, 0xc0f0ff, 8, 120, 2.5f);
      if (--s.hp <= 0) {
        s.dead = true;
        fxBurst(w, s.c, 0xc0f0ff, 20, 180, 3);
        fxSound(w, S_SHATTER, 0.6f, 1.2f, s.c.x);
      } else fxSound(w, S_FREEZE, 0.4f, 1.4f, b.p.x);
      break;
  }
}

int defaultFocus(const World& w) {
  int best = -1;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
    const Monster& m = w.fl.mons[i];
    if (m.dead || isMonsterAlly(w, i)) continue;
    if (best < 0) { best = i; continue; }
    const Monster& b = w.fl.mons[best];
    int dm = intentDamage(w, m), db = intentDamage(w, b);
    // soonest threat first, then biggest hit, then lowest HP
    if (m.cd != b.cd ? m.cd < b.cd : (dm != db ? dm > db : m.hp < b.hp)) best = i;
  }
  return best;
}

int focusTarget(World& w) {
  Floor& f = w.fl;
  if (f.focus < 0 || f.focus >= (int)f.mons.size() || !isHostile(w, f.focus)) f.focus = defaultFocus(w);
  return f.focus;
}

void endBall(World& w, int bi, int pocket) {
  Floor& f = w.fl;
  if (!f.balls[bi].alive) return;
  Ball& b = f.balls[bi];
  // leftover power discharges into the focus target (half, or all of it from a Strike pocket)
  if (!(b.flags & BF_PHANTOM) && b.power > 0 && !f.isVault) {
    int t = focusTarget(w);
    if (t >= 0) {
      bool full = (b.flags & BF_STRIKE) || w.st.fullDischarge;
      int dmg = full ? b.power : std::max(1, b.power / 2);
      if (w.st.discharge > 0) dmg = dmg * (100 + w.st.discharge) / 100;
      V2 from(b.p.x, std::min(b.p.y, 870.f));
      V2 tp = f.mons[t].p;
      discharge(w, from, dmg, full ? 0xff5060 : 0x9fc8ff);
      bool lastBall = true;
      for (int k = 0; k < (int)f.balls.size(); ++k)
        if (k != bi && f.balls[k].alive && !(f.balls[k].flags & BF_PHANTOM)) lastBall = false;
      if (lastBall && f.newBalls.empty()) {
        if (f.shot.fireball) triggerFireball(w, t, tp, dmg);
        if (f.shot.chain) triggerChain(w, t, tp, dmg);
      }
    }
  }
  FOR_EFF(ballEnd, bi, pocket);
  f.balls[bi].alive = false;
}

void catchBall(World& w, int bi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  f.shot.catchesLeft--;
  int lv = abLevel(w, AB_CATCHER);
  int bonus = lv <= 1 ? 2 : lv == 2 ? 4 : 6;
  b.power += bonus;
  b.catches++;
  b.flags |= BF_CAUGHT;
  fxText(w, b.p + V2(0, -16), 0xffc860, fmt("Caught! +%d", bonus), 15);
  fxSound(w, S_POCKET, 0.7f, 1.3f, b.p.x);
  b.p = launcherPos() + V2(f.rng.rangef(-30, 30), 24);
  b.v = V2(f.rng.rangef(-160, 160), 140);
  b.stuckRef = b.p;
  b.staleHits = 0;
}

// ================================================================ pockets
static void lottery(World& w, int mul, V2 at) {
  Floor& f = w.fl;
  if (hasRelic(w, RL_S_CHIPS)) mul *= 2;
  int roll = f.rng.range(0, 99);
  if (roll >= 70 && w.st.lucky) roll = f.rng.range(0, 99);
  if (hasRelic(w, RL_U_CROOKEDDIE)) roll = std::min(roll, 69);
  if (roll < 70) {
    int prize = f.rng.range(0, 4);
    switch (prize) {
      case 0: gainGold(w, (25 + 2 * w.depth) * mul, at); fxText(w, at + V2(0, -30), 0xffd040, "Lottery: gold!", 15); break;
      case 1: healPlayer(w, (8 + w.depth / 2) * mul); fxText(w, at + V2(0, -30), 0x60ff80, "Lottery: healing!", 15); break;
      case 2: gainMp(w, 2 * mul); fxText(w, at + V2(0, -30), 0x70a8ff, "Lottery: magic!", 15); break;
      case 3: w.pl.nextShotPower += 8 * mul; fxText(w, at + V2(0, -30), 0xff9040, "Lottery: +8 next shot!", 15); break;
      default: {
        static const int P[] = {IT_HEALING, IT_MANA, IT_MIGHT, IT_RESIST, IT_LUCK, IT_AMBROSIA};
        int it = P[f.rng.range(0, 5)];
        if (gainItem(w, it)) fxText(w, at + V2(0, -30), ITEM[it].color, std::string("Lottery: ") + ITEM[it].name, 15);
        else gainGold(w, 20, at);
        break;
      }
    }
    fxSound(w, S_COIN, 0.8f, 1.3f, at.x);
  } else {
    int pen = f.rng.range(0, 2);
    switch (pen) {
      case 0: {
        int g = std::min(w.pl.gold, 10 + w.depth);
        w.pl.gold -= g;
        fxText(w, at + V2(0, -30), 0xa0a0a0, fmt("Lottery: -%d gold", g), 15);
        break;
      }
      case 1: selfDamage(w, 3 + w.depth / 3, nullptr); fxText(w, at + V2(0, -30), 0xff6060, "Lottery: ouch!", 15); break;
      default: {
        int t = pickRandomHostile(w);
        if (t >= 0) {
          f.mons[t].shield += 6 + w.depth;
          fxText(w, f.mons[t].p + V2(0, -f.mons[t].r - 10), 0xb0c0ff, "Lottery: +Block", 14);
        }
        break;
      }
    }
    fxSound(w, S_DENY, 0.6f, 1.f, at.x);
  }
}

void onBallPocket(World& w, int bi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  if (b.flags & BF_PHANTOM) {
    endBall(w, bi, -1);
    return;
  }
  int pi = -1;
  for (int i = 0; i < (int)f.pockets.size(); ++i)
    if (b.p.x >= f.pockets[i].x0 && b.p.x < f.pockets[i].x1) pi = i;
  if (pi < 0) pi = b.p.x < LAUNCH_X ? 0 : (int)f.pockets.size() - 1;
  Pocket& P = f.pockets[pi];
  int dd = abLevel(w, AB_DIMDOOR);
  if (dd && !f.shot.dimDoorUsed && P.kind != PO_STRIKE && P.kind != PO_RECALL && P.kind != PO_JACKPOT && P.kind != PO_DOUBLE) {
    V2 np = randomFieldSpot(w, b.r + 4, 4, FIELD_Y0, FIELD_Y0 + 320);
    if (np.x >= 0) {
      f.shot.dimDoorUsed = true;
      fxBurst(w, b.p, 0x8060e0, 16, 200);
      b.p = np;
      b.v = V2(f.rng.rangef(-120, 120), 60);
      b.stuckRef = np;
      b.power += dd <= 1 ? 3 : dd == 2 ? 5 : 7;
      fxText(w, np + V2(0, -18), 0x8060e0, "Dimension Door!", 14);
      fxSound(w, S_PORTAL, 0.7f, 0.9f, np.x);
      return;
    }
  }
  if (hasRelic(w, RL_RECALLRUNE) && !f.shot.recallRuneUsed &&
      (P.kind == PO_EMPTY || P.kind == PO_CURSED || P.kind == PO_VOID || P.kind == PO_FROZEN)) {
    f.shot.recallRuneUsed = true;
    fxText(w, b.p + V2(0, -20), 0x40ffb0, "Rune of Return!", 15);
    fxSound(w, S_PORTAL, 0.7f, 1.2f, b.p.x);
    b.p = launcherPos() + V2(f.rng.rangef(-30, 30), 24);
    b.v = V2(f.rng.rangef(-150, 150), 150);
    b.stuckRef = b.p;
    return;
  }
  if (w.st.secondChance && !f.shot.secondChanceUsed &&
      (P.kind == PO_EMPTY || P.kind == PO_CURSED || P.kind == PO_VOID || P.kind == PO_FROZEN || P.kind == PO_TRAP || P.kind == PO_TAX)) {
    f.shot.secondChanceUsed = true;
    fxText(w, b.p + V2(0, -20), 0x80ffd0, "Second chance!", 15);
    fxSound(w, S_PORTAL, 0.7f, 1.3f, b.p.x);
    b.p = launcherPos() + V2(f.rng.rangef(-30, 30), 24);
    b.v = V2(f.rng.rangef(-150, 150), 150);
    b.stuckRef = b.p;
    return;
  }
  if (P.kind == PO_RELAUNCH && !(b.flags & BF_RELAUNCHED)) {
    b.flags |= BF_RELAUNCHED;
    if (!(b.flags & BF_LUCKY)) b.power = std::max(1, b.power * 3 / 4);
    P.flash = 1.f;
    fxText(w, V2((P.x0 + P.x1) * 0.5f, 820), POCKET_COLOR[PO_RELAUNCH], "Relaunch!", 15);
    fxSound(w, S_LAUNCH, 0.7f, 1.3f, b.p.x);
    b.p = launcherPos() + V2(f.rng.rangef(-40, 40), 24);
    b.v = V2(f.rng.rangef(-180, 180), 160);
    b.stuckRef = b.p;
    b.staleHits = 0;
    return;
  }
  int mul = std::max(1, f.shot.jackpotMul);
  if (b.flags & BF_LUCKY) {
    mul *= 2;
    fxText(w, b.p + V2(0, -34), 0x50ff70, "Lucky! x2", 14);
  }
  P.flash = 1.f;
  V2 at((P.x0 + P.x1) * 0.5f, 860);
  switch (P.kind) {
    case PO_RECALL:
      if (!f.shot.freeTurn) {
        f.shot.freeTurn = true;
        fxBanner(w, "FREE TURN!", POCKET_COLOR[PO_RECALL]);
        tumblerExcite(w, 6);
      }
      break;
    case PO_MANA: gainMp(w, 2 * mul); break;
    case PO_HEAL: healPlayer(w, (4 + w.depth / 3) * mul); break;
    case PO_GOLD: gainGold(w, (6 + w.depth) * mul, at); break;
    case PO_POWER:
      w.pl.nextShotPower += 5 * mul;
      fxText(w, at + V2(0, -20), POCKET_COLOR[PO_POWER], fmt("+%d next shot", 5 * mul), 14);
      break;
    case PO_STRIKE:
      b.flags |= BF_STRIKE;
      if (mul > 1) b.power *= mul;
      break;
    case PO_CURSED:
      if (w.st.warded) fxText(w, at + V2(0, -20), 0xe0e0ff, "warded", 14);
      else damagePlayer(w, 3 + w.depth / 3, -1, true, "a cursed pocket");
      break;
    case PO_JACKPOT: gainGold(w, (20 + 2 * w.depth) * mul, at); fxBanner(w, "JACKPOT!", POCKET_COLOR[PO_JACKPOT]); break;
    case PO_DOUBLE:
      w.pl.nextShotDouble = true;
      if (mul > 1) w.pl.nextShotPower += 5 * (mul - 1);
      fxText(w, at + V2(0, -20), POCKET_COLOR[PO_DOUBLE], "Next shot x2 damage!", 14);
      break;
    case PO_REFRESH:
      for (int k = 0; k < mul; ++k)
        for (auto& a : w.pl.abil)
          if (a.cd > 0) a.cd--;
      gainMp(w, mul);
      break;
    case PO_XP: gainXp(w, (3 + w.depth) * mul); fxText(w, at + V2(0, -20), 0xffffff, "+XP", 14); break;
    case PO_SHIELD: addBlock(w, (5 + w.depth / 2) * mul); break;
    case PO_MULTI:
      if (b.gen < 2) {
        int n = 1 + mul;
        for (int k = 0; k < n; ++k) {
          float x = PX0 + 80 + (PX1 - PX0 - 160) * (k + 0.5f) / n + f.rng.rangef(-30, 30);
          spawnBall(w, V2(x, 30), V2(f.rng.rangef(-80, 80), 80), effPower(w), 0, b.gen + 1);
        }
        fxText(w, at + V2(0, -20), POCKET_COLOR[PO_MULTI], "Multiball!", 15);
      }
      break;
    case PO_BOMB: {
      int t = focusTarget(w);
      if (t >= 0) explodeAt(w, f.mons[t].p, 120, (10 + w.depth + b.power / 2) * mul, -1);
      break;
    }
    case PO_FREEZE:
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) applyChill(w, i, 1);
      fxSound(w, S_FREEZE, 0.8f, 0.9f, at.x);
      break;
    case PO_BURN:
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) applyBurn(w, i, 4 * mul);
      fxSound(w, S_FIRE, 0.7f, 1.f, at.x);
      break;
    case PO_POISON:
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) applyPoison(w, i, 4 * mul);
      fxSound(w, S_POISON, 0.7f, 1.f, at.x);
      break;
    case PO_LOTTERY: lottery(w, mul, at); break;
    case PO_CHAOS:
      for (int k = 0; k < std::min(2, mul); ++k) tumblerAct(w, false);
      break;
    case PO_BANK: {
      int g = clampv(w.pl.gold * 5 / 100, 5, 30) * mul;
      gainGold(w, g, at);
      break;
    }
    case PO_VOID:
      f.balls[bi].power = 0;
      fxText(w, at + V2(0, -20), 0x8060e0, "lost to the void", 14);
      break;
    case PO_FROZEN: fxText(w, at + V2(0, -20), 0xa0d0f0, "frozen solid", 14); break;
    default: newPocket(w, bi, pi, mul, at); break;
  }
  fxSound(w, P.kind == PO_CURSED ? S_DENY : S_POCKET, 0.6f, P.kind == PO_RECALL ? 1.25f : 1.f, at.x);
  fxBurst(w, at, POCKET_COLOR[P.kind], 16, 180, 3);
  endBall(w, bi, pi);
}

// ================================================================ slot machine
static int rollReel(Rng& r) {
  static const float W[7] = {5, 12, 15, 18, 22, 14, 14};
  std::vector<float> wt(W, W + 7);
  return std::max(0, r.weighted(wt));
}

void queueSlotSpin(World& w) {
  w.fl.slotSpins = std::min(w.fl.slotSpins + 1, 9);
}

static void startSpin(World& w) {
  Floor& f = w.fl;
  f.slotSpins--;
  f.slotT = 1.0f;
  for (int i = 0; i < 3; ++i) f.slotReel[i] = (uint8_t)rollReel(f.rng);
  if (w.st.lucky && f.slotReel[0] != f.slotReel[1] && f.slotReel[1] != f.slotReel[2] && f.slotReel[0] != f.slotReel[2])
    f.slotReel[2] = (uint8_t)rollReel(f.rng);
  fxSound(w, S_TICK, 0.6f, 1.6f);
}

void resolveSlot(World& w) {
  Floor& f = w.fl;
  f.slotT = 0;
  f.slotShow = 300;
  int a = f.slotReel[0], b = f.slotReel[1], c = f.slotReel[2];
  float m = w.st.slotMul;
  auto M = [&](int x) { return std::max(1, (int)std::lround(x * m)); };
  V2 at(LAUNCH_X, 140);
  if (a == b && b == c) {
    f.slotLast = a;
    switch (a) {
      case 0:
        grantFreeTurn(w);
        gainGold(w, M(60 + 3 * w.depth), at);
        healPlayer(w, M(w.st.maxHp / 5));
        allBallsPower(w, M(25));
        fxBanner(w, "JACKPOT! 7 7 7", 0xff4050);
        fxShake(w, 14);
        tumblerExcite(w, 25);
        w.rs.jackpots++;
        break;
      case 1: allBallsPower(w, M(15)); fxBanner(w, "BAR BAR BAR: +15 power!", 0xe0e0e0); break;
      case 2:
        for (int i = 0; i < (int)f.mons.size(); ++i)
          if (isHostile(w, i)) {
            damageMonster(w, i, 5 + w.depth / 2, DS_SPELL);
            if (!f.mons[i].dead && !f.mons[i].boss) f.mons[i].cd += 1;
          }
        fxBanner(w, "BELLS! The monsters are stunned!", 0xffd040);
        break;
      case 3: healPlayer(w, M(w.st.maxHp * 3 / 10)); fxBanner(w, "CHERRIES: healed!", 0xff4080); break;
      case 4: gainGold(w, M(40 + 3 * w.depth), at); fxBanner(w, "COINS: payday!", 0xffc840); break;
      case 5:
        convertPins(w, PK_CRIT, 6);
        convertPins(w, PK_MULTI, 2);
        fxBanner(w, "STARS: the board sparkles!", 0x80c0ff);
        break;
      default: {
        int def = randomRosterMonster(w, -1);
        int cl = freeClearing(w, V2(-1, -1), true);
        if (cl >= 0) spawnMonster(w, def, cl, true);
        selfDamage(w, 5, nullptr);
        fxBanner(w, "SKULLS: the house wins!", 0xb0a0c0);
        break;
      }
    }
    fxSound(w, a == 6 ? S_DENY : S_WIN, 0.8f, a == 0 ? 1.2f : 1.f);
  } else if (a == b || b == c || a == c) {
    int s = (a == b || a == c) ? a : b;
    f.slotLast = 10 + s;
    switch (s) {
      case 0: allBallsPower(w, M(10)); break;
      case 1: allBallsPower(w, M(6)); break;
      case 2: gainMp(w, 1); break;
      case 3: healPlayer(w, M(5)); break;
      case 4: gainGold(w, M(8 + w.depth / 2), at); break;
      case 5: convertPins(w, PK_CRIT, 2); break;
      default: break;
    }
    fxSound(w, S_COIN, 0.6f, 1.4f);
  } else {
    f.slotLast = -1;
    fxSound(w, S_TICK, 0.5f, 0.8f);
  }
}

void flushSlots(World& w) {
  Floor& f = w.fl;
  int guard = 0;
  while ((f.slotT > 0 || f.slotSpins > 0) && guard++ < 20) {
    if (f.slotT <= 0) startSpin(w);
    resolveSlot(w);
  }
}

void closeTulips(World& w) {
  Floor& f = w.fl;
  for (int i = 0; i < (int)f.pegs.size(); ++i)
    if (!f.pegs[i].dead && f.pegs[i].kind == PK_TULIP && f.pegs[i].aux) {
      f.pegs[i].aux = 0;
      setPetals(w, i, false);
    }
}

void processSlots(World& w, float dt) {
  Floor& f = w.fl;
  if (f.slotShow > 0) f.slotShow--;
  if (f.slotT > 0) {
    f.slotT -= dt;
    if (f.slotT <= 0) resolveSlot(w);
  } else if (f.slotSpins > 0) {
    startSpin(w);
  }
}
