// Dropcrawl - rune circles and rune pegs. A ball crossing a rune circle rolls a rune; runes of a school you study are
// much more likely and grow with your abilities in that school. Two runes on one ball can spell a runeword.
#include "rules.h"

enum RuneId {
  RN_POWER, RN_FIRE, RN_FROST, RN_VENOM, RN_LUCK, RN_MAGIC, RN_MIGHT, RN_GOLD, RN_STORMS, RN_BLOOD, RN_IRON, RN_SPLIT,
  RN_ECHOES, RN_WISDOM, RN_THORNS, RN_HOLY, RN_VOID, RN_PRECISION, RN_GROWTH, RN_FEATHERS, RN_CHAOS,
  // school synergy runes
  RN_PYRO, RN_WINTER, RN_TEMPEST, RN_MOUNTAIN, RN_ARCANIST, RN_LIFE, RN_FORTUNE, RN_SHADOWS, RN_GEARS, RN_BLOODMOON,
  RN_MAYHEM, RN_PACK, RN_ABYSS, RN_FORCE,
  RN_COUNT
};
static_assert(RN_COUNT == RUNE_COUNT, "rune count");
static const int FIRST_SYNERGY = RN_PYRO;

const char* RUNE_NAME[RUNE_COUNT] = {
    "Rune of Power",   "Rune of Fire",      "Rune of Frost",     "Rune of Venom",    "Rune of Luck",     "Rune of Magic",
    "Rune of Might",   "Rune of Gold",      "Rune of Storms",    "Rune of Blood",    "Rune of Iron",     "Rune of Splitting",
    "Rune of Echoes",  "Rune of Wisdom",    "Rune of Thorns",    "Rune of Light",    "Rune of the Void", "Rune of Precision",
    "Rune of Growth",  "Rune of Feathers",  "Rune of Chaos",
    "Rune of the Pyromancer", "Rune of Winter", "Rune of the Tempest", "Rune of the Mountain", "Rune of the Arcanist",
    "Rune of Life",    "Rune of Fortune",   "Rune of Shadows",   "Rune of Gears",    "Rune of the Blood Moon",
    "Rune of Mayhem",  "Rune of the Pack",  "Rune of the Abyss", "Rune of Force"};
static const int RUNE_SCHOOL[RUNE_COUNT - FIRST_SYNERGY] = {SCH_FLAME, SCH_FROST,   SCH_STORM, SCH_EARTH, SCH_ARCANE,
                                                            SCH_LIFE,  SCH_FORTUNE, SCH_SHADOW, SCH_CLOCKWORK, SCH_BLOOD,
                                                            SCH_CHAOS, SCH_SUMMON,  SCH_VOID,  SCH_FORCE};

struct Runeword {
  int a, b;
  const char* name;
  const char* desc;
};
static const Runeword WORDS[RUNEWORD_COUNT] = {
    {RN_FIRE, RN_STORMS, "Plasma", "The ball's next monster hit explodes."},
    {RN_FROST, RN_IRON, "Glacier", "+10 Block."},
    {RN_VENOM, RN_THORNS, "Pestilence", "Every monster gains 4 Poison and 3 Bleed."},
    {RN_LUCK, RN_GOLD, "Fortune's Favor", "+25 gold, and the ball's pocket pays triple."},
    {RN_POWER, RN_MIGHT, "Titan", "The ball's power doubles."},
    {RN_MAGIC, RN_ECHOES, "Resonance", "Every cooldown resets and you gain 2 MP."},
    {RN_HOLY, RN_IRON, "Aegis", "The next monster attack against you is blocked."},
    {RN_VOID, RN_CHAOS, "Oblivion", "The ball's power doubles, then the void swallows it."},
    {RN_SPLIT, RN_PRECISION, "Barrage", "Three more balls burst out, each a guaranteed critical hit."},
    {RN_BLOOD, RN_GROWTH, "Vitality", "Heal 20% of your max HP."},
    {RN_WISDOM, RN_MAGIC, "Enlightenment", "+10 XP (+1 per depth) and +2 MP."},
    {RN_FIRE, RN_GROWTH, "Wildfire", "Six pins burst into Fire pegs."},
};
const char* RUNEWORD_NAME[RUNEWORD_COUNT] = {"Plasma", "Glacier", "Pestilence", "Fortune's Favor", "Titan", "Resonance",
                                             "Aegis", "Oblivion", "Barrage", "Vitality", "Enlightenment", "Wildfire"};

std::string runeHelpText() {
  std::string s = "Runewords (two runes on one ball, in any order):\n";
  for (auto& r : WORDS) s += fmt("%s: %s + %s. %s\n", r.name, RUNE_NAME[r.a] + 8, RUNE_NAME[r.b] + 8, r.desc);
  return s;
}

static int schoolLevels(const World& w, int sch) {
  int n = 0;
  for (auto& a : w.pl.abil)
    if (ABIL[a.id].school == sch) n += a.lvl;
  return std::min(n, 6);
}

static int pickRune(World& w, bool minor) {
  std::vector<float> wt(RUNE_COUNT, 1.f);
  wt[RN_CHAOS] = 0.6f;
  wt[RN_SPLIT] = 0.8f;
  for (int r = FIRST_SYNERGY; r < RUNE_COUNT; ++r) {
    int lv = schoolLevels(w, RUNE_SCHOOL[r - FIRST_SYNERGY]);
    wt[r] = minor ? 0.f : (lv > 0 ? 1.5f + 0.6f * lv : 0.f);
  }
  if (minor) wt[RN_CHAOS] = wt[RN_SPLIT] = 0.f;
  return std::max(0, w.fl.rng.weighted(wt));
}

static void applyRune(World& w, int bi, int r, V2 at, bool minor, int depthGuard = 0);

static void checkRuneword(World& w, int bi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  if (b.runeA < 0 || b.runeB < 0) return;
  int x = b.runeA, y = b.runeB;
  for (int i = 0; i < RUNEWORD_COUNT; ++i) {
    const Runeword& rw = WORDS[i];
    if (!((rw.a == x && rw.b == y) || (rw.a == y && rw.b == x))) continue;
    float mul = w.st.runewordMul;
    f.shot.runewords++;
    fxBanner(w, std::string("Runeword: ") + rw.name + "!", 0xd0b0ff);
    logMsg(w, 0xd0b0ff, "Runeword %s! %s", rw.name, rw.desc);
    fxSound(w, S_LEVEL, 0.8f, 1.5f, b.p.x);
    fxRing(w, b.p, 70, 0xd0b0ff);
    switch (i) {
      case 0:
        f.shot.fireball = true;
        f.shot.fireballLvl = 3;
        break;
      case 1: addBlock(w, (int)(10 * mul)); break;
      case 2:
        for (int m = 0; m < (int)f.mons.size(); ++m)
          if (isHostile(w, m)) {
            applyPoison(w, m, (int)(4 * mul));
            applyBleed(w, m, (int)(3 * mul));
          }
        break;
      case 3:
        gainGold(w, (int)(25 * mul), b.p);
        f.shot.jackpotMul = std::max(f.shot.jackpotMul, 3);
        break;
      case 4: f.balls[bi].power = (int)(f.balls[bi].power * (2.f + (mul - 1.f))); break;
      case 5:
        for (auto& a : w.pl.abil) a.cd = 0;
        gainMp(w, 2);
        break;
      case 6: w.pl.guardBlocks = std::max(w.pl.guardBlocks, 1); break;
      case 7:
        f.balls[bi].power *= 2;
        f.balls[bi].flags |= BF_VOIDED;
        break;
      case 8:
        if (f.balls[bi].gen < 2) {
          int pw = std::max(1, f.balls[bi].power / 2);
          for (int k = 0; k < 3; ++k)
            spawnBall(w, f.balls[bi].p, rot(f.balls[bi].v, -0.6f + 0.6f * k), pw, BF_PHANTOM | BF_CRITNEXT, f.balls[bi].gen + 1);
        }
        break;
      case 9: healPlayer(w, (int)(w.st.maxHp * 0.2f * mul)); break;
      case 10:
        gainXp(w, (int)((10 + w.depth) * mul));
        gainMp(w, 2);
        break;
      default: convertPins(w, PK_FIRE, (int)(6 * mul), f.balls[bi].p, 260); break;
    }
    break;
  }
  f.balls[bi].runeA = f.balls[bi].runeB = -1;
}

static void noteRune(World& w, int bi, int r) {
  Ball& b = w.fl.balls[bi];
  if (r >= FIRST_SYNERGY) return;  // synergy runes are strong enough on their own
  if (b.runeA < 0) b.runeA = (int8_t)r;
  else if (b.runeB < 0) b.runeB = (int8_t)r;
  else {
    b.runeA = b.runeB;
    b.runeB = (int8_t)r;
  }
  checkRuneword(w, bi);
}

static void applyRune(World& w, int bi, int r, V2 at, bool minor, int depthGuard) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  int bonus = w.st.runeBonus;
  float m = minor ? 0.5f : 1.f;
  auto pw = [&](int n) { b.power += std::max(1, (int)(n * m)) + bonus; };
  switch (r) {
    case RN_POWER: pw(5); break;
    case RN_FIRE: b.flags |= BF_FIRE; pw(2); break;
    case RN_FROST: b.flags |= BF_FROST; pw(2); break;
    case RN_VENOM: b.flags |= BF_VENOM; pw(2); break;
    case RN_LUCK: b.flags |= BF_LUCKY; break;
    case RN_MAGIC: gainMp(w, 1); pw(1); break;
    case RN_MIGHT: b.power = (int)std::ceil(b.power * (minor ? 1.25f : 1.5f)); break;
    case RN_GOLD: b.flags |= BF_GOLDEN; break;
    case RN_STORMS: b.stormT = std::max(b.stormT, minor ? 0.8f : 1.6f); break;
    case RN_BLOOD:
      pw(8);
      selfDamage(w, minor ? 1 : 2, nullptr);
      break;
    case RN_IRON: addBlock(w, (int)((4 + w.depth / 4) * m) + 1); break;
    case RN_SPLIT: splitBall(w, bi, 0.6f); break;
    case RN_ECHOES: f.shot.echoLeft += minor ? 1 : 2; break;
    case RN_WISDOM: gainXp(w, (int)((4 + w.depth / 2) * m) + 1); break;
    case RN_THORNS: f.shot.bleedOnHit += minor ? 1 : 2; break;
    case RN_HOLY: b.flags |= BF_HOLY; break;
    case RN_VOID: b.flags |= BF_VOIDED; break;
    case RN_PRECISION: b.flags |= BF_CRITNEXT; break;
    case RN_GROWTH: growPins(w, minor ? 2 : 4, at, 70, true); break;
    case RN_FEATHERS:
      b.floatT = std::max(b.floatT, minor ? 0.8f : 1.5f);
      pw(2);
      break;
    case RN_CHAOS:
      if (depthGuard < 1)
        for (int k = 0; k < 2; ++k) {
          int rr = f.rng.range(0, RN_CHAOS - 1);
          fxText(w, at + V2(0, -30 - 12 * k), 0xff80ff, RUNE_NAME[rr], 12);
          applyRune(w, bi, rr, at, minor, depthGuard + 1);
        }
      break;
    default: {
      int lv = std::max(1, schoolLevels(w, RUNE_SCHOOL[r - FIRST_SYNERGY]));
      switch (r) {
        case RN_PYRO: b.flags |= BF_FIRE; pw(2 * lv); break;
        case RN_WINTER: {
          b.flags |= BF_FROST;
          pw(2 * lv);
          int t = nearestMonster(w, at);
          if (t >= 0) applyChill(w, t, 1);
          break;
        }
        case RN_TEMPEST:
          for (int k = 0; k < 3; ++k) {
            int t = pickRandomHostile(w);
            if (t < 0) break;
            fxZap(w, at, f.mons[t].p, 0xfff080);
            damageMonster(w, t, 2 * lv + w.depth / 2, DS_ZAP);
          }
          break;
        case RN_MOUNTAIN:
          addBlock(w, 2 + 2 * lv);
          pw(2 * lv);
          break;
        case RN_ARCANIST:
          gainMp(w, 1 + lv / 2);
          pw(lv);
          break;
        case RN_LIFE: healPlayer(w, 1 + lv); break;
        case RN_FORTUNE:
          gainGold(w, 3 + 3 * lv, at);
          b.flags |= BF_LUCKY;
          break;
        case RN_SHADOWS:
          b.flags |= BF_VENOM;
          f.shot.bleedOnHit += std::max(1, lv / 2);
          break;
        case RN_GEARS:
          b.flags |= BF_GEARED;
          pw(lv);
          break;
        case RN_BLOODMOON:
          pw(3 * lv);
          selfDamage(w, 1, nullptr);
          break;
        case RN_MAYHEM: tumblerInvoke(w, 2); break;
        case RN_PACK: {
          float mul = allyDamageMul(w);
          for (auto& p : f.pegs) {
            if (p.dead || !(isAllyPeg(p.kind) || p.kind == PK_FIREFLY)) continue;
            int t = nearestMonster(w, p.p);
            if (t < 0) break;
            fxZap(w, p.p, f.mons[t].p, PEG_COLOR[p.kind]);
            damageMonster(w, t, std::max(1, (int)((std::max(2, p.val) + lv) * mul)), DS_ALLY);
          }
          break;
        }
        case RN_ABYSS:
          pw(3 * lv);
          b.flags |= BF_VOIDED;
          break;
        default:  // RN_FORCE
          pw(3 * lv);
          b.gravScale = std::min(1.6f, b.gravScale * 1.1f);
          break;
      }
      break;
    }
  }
}

void runeCircle(World& w, int bi, int zi) {
  Floor& f = w.fl;
  Ball& b = f.balls[bi];
  const Zone& z = f.zones[zi];
  uint32_t bit = 1u << (zi & 31);
  if (b.runeMask & bit) return;
  b.runeMask |= bit;
  V2 at = z.p;
  int n = w.st.runeDouble ? 2 : 1;
  int last = -1;
  for (int k = 0; k < n; ++k) {
    int r = pickRune(w, false);
    if (r == last) r = pickRune(w, false);
    last = r;
    fxText(w, at + V2(0, -18 - 14 * k), r >= FIRST_SYNERGY ? 0xffd0ff : 0xb0a0ff, RUNE_NAME[r], 14);
    applyRune(w, bi, r, at, false);
    if (!f.balls[bi].alive) return;
    noteRune(w, bi, r);
  }
  fxRing(w, at, z.half.x, 0xb0a0ff);
  fxSound(w, S_MANA, 0.5f, 1.2f, at.x);
  b.runeCount++;
}

void runePeg(World& w, int bi, int pi) {
  Floor& f = w.fl;
  V2 pp = f.pegs[pi].p;
  f.balls[bi].power += 2;
  if (w.pl.patron >= 0) gainPiety(w, 2);
  else gainXp(w, 2);
  int r = pickRune(w, true);
  fxText(w, pp + V2(0, -14), 0xb0a0ff, RUNE_NAME[r] + 8, 11);
  applyRune(w, bi, r, pp, true);
  if (f.balls[bi].alive) noteRune(w, bi, r);
  fxSound(w, S_MANA, 0.5f, 0.8f, pp.x);
}

void tumblerRune(World& w, int bi) {
  int r = w.fl.rng.range(0, RN_CHAOS - 1);
  fxText(w, w.fl.balls[bi].p + V2(0, -20), 0xff80ff, RUNE_NAME[r], 14);
  applyRune(w, bi, r, w.fl.balls[bi].p, false);
  if (w.fl.balls[bi].alive) noteRune(w, bi, r);
}
