// Dropcrawl - headless bot used for balance testing (and the title-screen demo)
#include "game.h"
#include "sim.h"

static float shotValue(const World& before, const World& after) {
  float v = 0;
  int monHpBefore = 0, monHpAfter = 0;
  for (auto& m : before.fl.mons)
    if (!m.dead) monHpBefore += m.hp + m.shield;
  for (auto& m : after.fl.mons)
    if (!m.dead) monHpAfter += m.hp + m.shield;
  v += (float)(monHpBefore - monHpAfter);
  v += 25.f * (after.fl.kills - before.fl.kills);
  if (after.fl.phase == PH_CLEARED) v += 400.f;
  v += 3.f * (after.pl.hp - before.pl.hp);
  v += 2.f * (after.pl.mp - before.pl.mp);
  v += 0.3f * (after.pl.gold - before.pl.gold);
  v += 0.5f * (after.pl.nextShotPower - before.pl.nextShotPower);
  if (after.fl.phase == PH_AIM) v += 20.f;  // free turn
  if (after.dead) v -= 1000.f;
  return v;
}

static void simulateShot(World& w, float angle, float speed) {
  launch(w, angle, speed);
  int guard = 0;
  while (w.fl.phase == PH_FLIGHT && guard++ < 120 * 60) floorUpdate(w, TICK);
}

float botPickAngle(const World& w, int candidates, int samples, float noise, uint64_t salt) {
  float bestA = PI * 0.5f, bestV = -1e9f;
  Rng r(salt);
  for (int c = 0; c < candidates; ++c) {
    float a = 0.2f + (PI - 0.4f) * (c + 0.5f) / candidates;
    float tot = 0;
    for (int s = 0; s < samples; ++s) {
      World t = w;
      t.quiet = true;
      t.fx.clear();
      t.fl.rng.s ^= mix64(salt + c * 131 + s);
      simulateShot(t, a + r.rangef(-noise, noise), w.fl.launchSpeed);
      tot += shotValue(w, t);
    }
    tot /= samples;
    if (tot > bestV) {
      bestV = tot;
      bestA = a;
    }
  }
  return bestA;
}

static int botTarget(const World& w) {
  int best = -1;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
    const Monster& m = w.fl.mons[i];
    if (m.dead) continue;
    if (best < 0) { best = i; continue; }
    const Monster& b = w.fl.mons[best];
    int td = intentDamage(w, m), bd = intentDamage(w, b);
    float sm = (td + 2) / (float)(m.cd) - m.hp * 0.02f;
    float sb = (bd + 2) / (float)(b.cd) - b.hp * 0.02f;
    if (sm > sb) best = i;
  }
  return best;
}

static void botUseAbilities(World& w, Rng& r) {
  // healing first
  for (int s = 0; s < (int)w.pl.items.size(); ++s) {
    int it = w.pl.items[s].id;
    if (it < 0) continue;
    bool use = false;
    switch (it) {
      case IT_HEALING: case IT_AMBROSIA: use = w.pl.hp < w.st.maxHp * 0.4f; break;
      case IT_MANA: case IT_BRILLIANCE: use = w.pl.mp <= 1 && w.st.maxMp >= 4; break;
      case IT_ACQUIRE: case IT_EXPERIENCE: case IT_MUTATION: case IT_WONDER: use = true; break;
      case IT_RESIST: use = w.pl.hp < w.st.maxHp * 0.35f; break;
      case IT_REMOVECURSE: case IT_CANCEL: use = countKind(w, PK_CURSE) > 3 || w.pl.poison > 4; break;
      case IT_TORMENT: use = w.fl.spec.kind != FK_NORMAL && w.pl.hp > w.st.maxHp / 2; break;
      default:
        if (ITEM[it].wand) use = r.chance(w.fl.spec.kind != FK_NORMAL ? 0.6f : 0.25f);
        else use = (w.fl.spec.kind != FK_NORMAL || w.pl.hp < w.st.maxHp * 0.5f) && r.chance(0.5f);
        break;
    }
    if (use) {
      int mon = botTarget(w);
      V2 pt = mon >= 0 ? w.fl.mons[mon].p + V2(0, -w.fl.mons[mon].r - 50) : V2(800, 450);
      useItem(w, s, pt, mon);
      if (!w.relicOffers.empty()) chooseRelicOffer(w, 0);
    }
  }
  std::vector<int> abs;
  for (auto& a : w.pl.abil) abs.push_back(a.id);
  if (w.pl.patron >= 0)
    for (int k = 0; k < 5; ++k) abs.push_back(PATRON[w.pl.patron].gifts[k]);
  for (int ab : abs) {
    if (!abilityUsable(w, ab, nullptr)) continue;
    const AbilityDef& d = ABIL[ab];
    if (d.timing != T_AIM) continue;
    if (ab == AB_HEALWOUNDS && w.pl.hp > w.st.maxHp * 0.6f) continue;
    if (ab == AB_P_REWIND && w.pl.hp > w.st.maxHp * 0.4f) continue;
    if (ab == AB_ROTOR) continue;
    if (abilityHpCost(w, ab, abLevel(w, ab)) > 0 && w.pl.hp < w.st.maxHp * 0.5f) continue;
    if (ab == AB_RENEWAL && w.pl.poison == 0 && w.pl.hp > w.st.maxHp * 0.7f) continue;
    if (!r.chance(0.8f)) continue;
    int mon = botTarget(w);
    V2 pt(800, 450), pt2(800, 200);
    if (mon >= 0) {
      pt = w.fl.mons[mon].p + V2(r.rangef(-60, 60), -w.fl.mons[mon].r - 60);
      pt2 = V2(w.fl.mons[mon].p.x, 150);
    }
    if (d.target == TG_TWO_POINTS) {
      pt = V2(r.rangef(PX0 + 100, PX1 - 100), 760);
      pt2 = V2(pt.x, 160);
    }
    castAbility(w, ab, pt, pt2, mon);
  }
}

static void botFlight(World& w, Rng& r) {
  // occasionally use in-flight abilities once the ball is low on the board
  std::vector<int> fl;
  for (auto& a : w.pl.abil) fl.push_back(a.id);
  if (w.pl.patron >= 0)
    for (int k = 0; k < 5; ++k) fl.push_back(PATRON[w.pl.patron].gifts[k]);
  for (int id : fl) {
    const AbilityDef& d = ABIL[id];
    if (d.timing != T_FLIGHT) continue;
    if (!abilityUsable(w, id, nullptr)) continue;
    bool lowBall = false;
    for (auto& b : w.fl.balls)
      if (b.alive && b.p.y > 650 && b.power > 8) lowBall = true;
    if (!lowBall || !r.chance(0.02f)) continue;
    int mon = botTarget(w);
    V2 pt = mon >= 0 ? w.fl.mons[mon].p : V2(800, 400);
    castAbility(w, id, pt, pt, mon);
  }
  if (w.fl.hasFlippers && w.fl.shot.flipsLeft > 0)
    for (auto& b : w.fl.balls)
      if (b.alive && b.p.y > 770 && b.p.y < 820 && b.v.y > 0) flipperPress(w, b.p.x < LAUNCH_X ? 0 : 1, true);
}

static int botLevelPick(const World& w, Rng& r) {
  if (w.offers.empty()) return -1;
  if (w.offers[0].type == 4) {
    // stat choice: favour damage and toughness, magic if the build casts a lot
    int casters = 0;
    for (auto& a : w.pl.abil)
      if (ABIL[a.id].timing != T_PASSIVE && ABIL[a.id].cost[0] > 0) casters++;
    float wt[STAT_COUNT] = {3.f, 2.f, 1.f + 0.6f * casters, 2.2f, 1.f};
    if (w.st.hpForMp) wt[STAT_VIT] += 1.5f;
    std::vector<float> v(wt, wt + STAT_COUNT);
    int s = r.weighted(v);
    for (int i = 0; i < (int)w.offers.size(); ++i)
      if (w.offers[i].id == s) return i;
    return 0;
  }
  int best = 0;
  float bv = -1;
  for (int i = 0; i < (int)w.offers.size(); ++i) {
    const AbilityDef& d = ABIL[w.offers[i].id];
    float v = r.f();
    if (abLevel(w, d.id)) v += 0.4f;
    if (d.timing == T_PASSIVE) v += 0.2f;
    if (v > bv) { bv = v; best = i; }
  }
  return best;
}

void botScreenStep(World& w, Rng& r, BotStats* bs) {
  switch (w.screen) {
    case RS_FLOOR: {
      Floor& f = w.fl;
      if (!w.offers.empty()) { chooseOffer(w, botLevelPick(w, r)); return; }
      if (!w.relicOffers.empty()) { chooseRelicOffer(w, 0); return; }
      switch (f.phase) {
        case PH_AIM: {
          botUseAbilities(w, r);
          if (!w.relicOffers.empty()) { chooseRelicOffer(w, 0); return; }
          if (w.fl.phase != PH_AIM || !canLaunch(w)) return;
          float a = bs && bs->smart ? botPickAngle(w, bs->candidates, bs->samples, 0.012f, r.next())
                                    : r.rangef(0.3f, PI - 0.3f);
          launch(w, a, w.fl.launchSpeed);
          break;
        }
        case PH_FLIGHT:
          botFlight(w, r);
          floorUpdate(w, TICK);
          break;
        case PH_ENEMY: floorUpdate(w, TICK); break;
        case PH_REDIRECT: redirect(w, r.rangef(0.4f, PI - 0.4f)); break;
        case PH_RELAUNCH: relaunch(w, r.rangef(0.4f, PI - 0.4f)); break;
        case PH_TARGET: f.phase = PH_AIM; break;
        case PH_CLEARED:
          if (bs) {
            int a = clampv(w.act, 0, 3), k = clampv((int)w.fl.spec.kind, 0, 3);
            bs->turns[a][k] += w.fl.turn;
            bs->hpLost[a][k] += (w.fl.hpAtStart - w.pl.hp) / (double)std::max(1, w.st.maxHp);
            bs->count[a][k] += 1;
            bs->dmgPerShot[a][k] += w.rs.damage;  // cumulative; converted below
          }
          floorCleared(w);
          break;
        default: break;
      }
      break;
    }
    case RS_REWARD:
      if (!w.relicOffers.empty()) chooseRelicOffer(w, r.range(0, (int)w.relicOffers.size() - 1));
      if (!w.offers.empty()) { chooseOffer(w, botLevelPick(w, r)); return; }
      finishReward(w);
      break;
    case RS_STAIRS: {
      if (!w.offers.empty()) { chooseOffer(w, botLevelPick(w, r)); return; }
      int pick = 0;
      float bv = -1e9f;
      float hpf = w.pl.hp / (float)w.st.maxHp;
      for (int i = 0; i < (int)w.stairs.size(); ++i) {
        const StairOpt& o = w.stairs[i];
        float v = r.f() * 0.5f;
        switch (o.kind) {
          case ST_FLOOR: v += 2; break;
          case ST_ELITE: v += hpf > 0.7f ? 2.5f : 0.5f; break;
          case ST_REST: v += hpf < 0.55f ? 4 : 0.8f; break;
          case ST_SHOP: v += w.pl.gold >= 110 ? 3 : 0.5f; break;
          case ST_TREASURE: v += 2.8f; break;
          case ST_ALTAR: v += 3.5f; break;
          case ST_EVENT: v += 1.5f; break;
          default: v += 3; break;
        }
        if (v > bv) { bv = v; pick = i; }
      }
      enterStairs(w, pick);
      break;
    }
    case RS_SHOP: {
      for (int i = 0; i < (int)w.shop.size(); ++i) {
        const ShopEntry& e = w.shop[i];
        if (e.sold || e.price > w.pl.gold) continue;
        if (e.type == 3 && w.pl.hp < w.st.maxHp * 0.6f) shopBuy(w, i);
        else if (e.type == 2 && (e.id == IT_HEALING || r.chance(0.3f))) shopBuy(w, i);
        else if (e.type == 0 || e.type == 1 || e.type == 6) shopBuy(w, i);
      }
      leaveRoom(w);
      break;
    }
    case RS_REST: {
      if (!w.relicOffers.empty()) { chooseRelicOffer(w, r.range(0, (int)w.relicOffers.size() - 1)); leaveRoom(w); break; }
      if (w.pl.patron == PT_RUUN && w.pl.hp >= w.st.maxHp * 0.75f && r.chance(0.6f)) { restChoose(w, 3, -1); break; }
      if (w.pl.hp < w.st.maxHp * 0.75f) restChoose(w, 0, -1);
      else {
        int idx = -1;
        for (int i = 0; i < (int)w.pl.abil.size(); ++i)
          if (w.pl.abil[i].lvl < ABIL[w.pl.abil[i].id].maxLvl) idx = i;
        if (idx >= 0) restChoose(w, 1, idx);
        else restChoose(w, 0, -1);
      }
      leaveRoom(w);
      break;
    }
    case RS_ALTAR:
      if (w.pl.patron < 0) altarChoose(w, r.range(0, (int)w.altarChoices.size() - 1));
      if (!w.relicOffers.empty()) chooseRelicOffer(w, r.range(0, (int)w.relicOffers.size() - 1));
      leaveRoom(w);
      break;
    case RS_EVENT: {
      if (w.eventResult.empty()) {
        std::vector<int> ok;
        for (int o = 0; o < EVENTS[w.eventId].nOpt; ++o)
          if (eventOptionAvailable(w, w.eventId, o, nullptr)) ok.push_back(o);
        int o = ok.empty() ? EVENTS[w.eventId].nOpt - 1 : ok[r.range(0, (int)ok.size() - 1)];
        eventResolve(w, w.eventId, o);
        if (w.eventResult.empty()) w.eventResult = " ";
      } else {
        if (!w.offers.empty()) { chooseOffer(w, botLevelPick(w, r)); return; }
        if (!w.relicOffers.empty()) chooseRelicOffer(w, r.range(0, (int)w.relicOffers.size() - 1));
        leaveRoom(w);
      }
      break;
    }
    default: break;
  }
}

SimResult simRun(uint64_t seed, int species, int bg, BotStats& bs) {
  World w;
  newRun(w, seed, species, bg);
  w.quiet = true;
  w.log.clear();
  Rng r(seed ^ 0x5151);
  SimResult res;
  long long guard = 0;
  int lastDepth = 0;
  while (!w.dead && !w.won && guard++ < 40000000LL) {
    botScreenStep(w, r, &bs);
    w.fx.clear();
    if (w.depth != lastDepth) {
      lastDepth = w.depth;
      if (bs.trace) printf("  depth %2d act %d step %d %-8s xl %2d hp %3d/%3d gold %4d abil %d relics %d\n", w.depth, w.act,
                           w.step, w.screen == RS_FLOOR ? "floor" : "room", w.pl.xl, w.pl.hp, w.st.maxHp, w.pl.gold,
                           (int)w.pl.abil.size(), (int)w.pl.relics.size());
    }
  }
  res.won = w.won;
  res.depth = w.depth;
  res.act = w.act;
  res.xl = w.pl.xl;
  res.killer = w.rs.killer;
  res.turns = w.rs.turns;
  res.location = locationName(w);
  res.hitGuard = guard >= 40000000LL;
  return res;
}
