// Dropcrawl - data tables: relics, items, monsters, species, backgrounds, patrons, biomes, modifiers, events
#include "rules.h"

RelicDef RELIC[RL_COUNT];
ItemDef ITEM[IT_COUNT];
MonDef MON[M_COUNT];
SpeciesDef SPECIES[SP_COUNT];
BackgroundDef BGS[BG_COUNT];
PatronDef PATRON[PT_COUNT];
BiomeDef BIOME[BI_COUNT];
ModDef MODS[MOD_COUNT];

void initAbilities();

const char* SCHOOL_NAME[SCH_COUNT] = {"Force", "Flame",  "Frost",     "Storm",     "Earth", "Arcane", "Life",  "Fortune",
                                      "Shadow", "Clockwork", "Blood", "Chaos", "Summoning", "Void", "Divine"};
const uint32_t SCHOOL_COLOR[SCH_COUNT] = {0x9fc0ff, 0xff8040, 0x90e8ff, 0xfff070, 0xd0a870, 0xc080ff, 0x70e880, 0xffd040,
                                          0xa070d0, 0xe0b070, 0xe03848, 0xff60ff, 0x80d0c0, 0x8060e0, 0xfff0c0};

const char* PEG_NAME[PK_COUNT] = {
    "Pin",          "Crit Peg",     "Gold Peg",    "Heal Peg",      "Mana Peg",   "Bomb",          "Multiball Peg",
    "Fire Peg",     "Ice Peg",      "Poison Peg",  "Spark Peg",     "Crystal Peg", "Glass Peg",    "Stone Block",
    "Bumper",       "Treasure Chest", "Key",       "Curse Peg",     "Totem",      "Bone Pile",     "Wisdom Peg",
    "Refresh Peg",  "Life Peg",     "Monster Bomb", "Bramble",      "Mushroom",   "Stone Golem",   "Stone Pillar",
    "World Tree",   "Skeleton Ally",
    "Tulip",        "Slot Chucker", "Drop Target", "Magnet",        "Warp Peg",   "Jelly Peg",     "Mirror Peg",
    "Vampire Peg",  "Chaos Peg",    "Frost Peg",   "Clover Peg",    "Anvil Peg",  "Feather Peg",   "Void Peg",
    "Shield Peg",   "Seed Peg",     "Coin Stack",  "Spring Peg",    "Monster Egg", "Imp Ally",     "Spectral Hound",
    "Tesla Coil",   "Familiar",     "Firefly",     "Divine Warrior", "Bell Peg",  "Rune Peg",      "Ghost Pin"};
const char* PEG_DESC[PK_COUNT] = {
    "+1 power.",
    "Multiplies the ball's power (x2).",
    "Grants gold.",
    "Heals 2 HP.",
    "Restores 1 MP.",
    "Explodes, damaging nearby monsters and setting off nearby pegs.",
    "Splits the ball in two.",
    "+2 power. The ball's next monster hit applies 4 Burn.",
    "+3 power. The ball's next monster hit Chills (countdown +1).",
    "+2 power. The ball's next monster hit applies 5 Poison.",
    "Zaps the nearest monster for half the ball's power.",
    "+4 power.",
    "+3 power. Shatters when hit.",
    "+1 power. Breaks after 3 hits.",
    "Kicks the ball hard. +2 power.",
    "Break it open (3 hits) for gold and items.",
    "Opens the matching gate.",
    "Halves the ball's power!",
    "Shields its master every enemy phase. Breaks after 3 hits.",
    "Grants bonus power every hit.",
    "Grants 3 XP (+1 per 2 depth).",
    "+2 MP and all ability cooldowns -1.",
    "+2 power and heals 1 HP.",
    "Explodes on YOU when its timer runs out! Hit it with a ball to defuse it.",
    "+3 power every hit.",
    "Bouncy. +1 power every hit.",
    "Grants bonus power every hit.",
    "Grants bonus power; crumbles after several hits.",
    "+8 power and heals 1 HP every hit.",
    "+4 power every hit. Strikes a monster after each enemy phase.",
    "Catch a ball in it: +6 power and gold, and it opens wider for the rest of the shot.",
    "Catch a ball in it to spin the slot machine. Three of a kind pays out big!",
    "Knock down every target in a bank for a bonus. Targets stand back up each turn.",
    "Pulls nearby balls toward it. +1 power per hit.",
    "Warps the ball to a random spot on the board. +2 power.",
    "Sticky! The ball nearly stops, but gains +4 power.",
    "Reflects the ball back upward. +2 power.",
    "Drains the nearest monster (3, +1 per 4 depth) and heals you that much.",
    "Triggers the effect of a random special peg.",
    "+2 power and Chills the nearest monster (countdown +1).",
    "The ball's next pocket effect is doubled.",
    "+5 power, but the ball becomes heavier.",
    "The ball floats gently for a moment. +1 power.",
    "Swallows the ball! It discharges 1.5x its power into your focus target.",
    "Grants 3 Block (+1 per 5 depth).",
    "+1 power. Three new pins sprout around it.",
    "+2 gold and +1 power per hit. Breaks after 5 hits.",
    "Launches the ball high into the air. +1 power.",
    "Hatches into a monster when its timer runs out! Hit it with a ball to smash it.",
    "+2 power per hit. Firebolts a random monster after each enemy phase.",
    "+4 power per hit. Bites the nearest monster after each enemy phase.",
    "+3 power per hit. Zaps the two nearest monsters after each of your shots.",
    "+2 power per hit. Strikes your focus target after each enemy phase.",
    "+2 power per hit.",
    "+5 power per hit. Smites the strongest monster after each enemy phase.",
    "Rings out: every monster takes 2 damage (+1 per 3 depth).",
    "+2 power and grants piety (or XP if you follow no god).",
    "Only solid on every other turn. +1 power."};
uint32_t PEG_COLOR[PK_COUNT] = {
    0xc8d0dc, 0xff4050, 0xffd040, 0x50e070, 0x4a90ff, 0xff8020, 0xc060ff, 0xff7030, 0x90e8ff, 0x90e040, 0xfff080,
    0x60ffe0, 0xd0f0ff, 0x9a9088, 0xff70b0, 0xc08040, 0xffe070, 0x9a3cff, 0xb07040, 0xe8e0c8, 0xffffff, 0x40e0ff,
    0x90ff90, 0xff3030, 0x7aa848, 0xe070ff, 0xb0a080, 0xa89880, 0x60d060, 0xe8e8d8,
    0xff80c0, 0xffd700, 0xff6040, 0xc0c0d0, 0x80a0ff, 0x60f0a0, 0xe0f0ff, 0xc02040, 0xff60ff, 0xa0f0ff, 0x50ff70,
    0x8890a0, 0xf0f0ff, 0x8040e0, 0x80b0ff, 0xa0d060, 0xffc840, 0x70ffd0, 0xe0d0a0, 0xff6040, 0xa0c0ff, 0xffe060,
    0xd0a0ff, 0xffff80, 0xfff4c0, 0xffe0a0, 0xb0a0ff, 0xc0c8e0};

const char* POCKET_NAME[PO_COUNT] = {"Empty",  "Free Turn", "Mana",   "Heal",      "Gold",   "Charge", "Strike", "Cursed",
                                     "Jackpot", "Double",   "Refresh", "Wisdom",   "Shield", "Multiball", "Bomb", "Freeze",
                                     "Burn",   "Plague",    "Lottery", "Chaos",    "Bank",   "Void",   "Frozen"};
const char* POCKET_SHORTNAME[PO_COUNT] = {"--",    "FREE",  "MANA",   "HEAL",  "GOLD",  "CHARGE", "STRIKE", "CURSE",
                                          "$$$",   "x2",    "REFRESH", "XP",   "SHIELD", "MULTI", "BOMB",   "FREEZE",
                                          "BURN",  "PLAGUE", "LOTTO", "CHAOS", "BANK",  "VOID",   "ICED"};
const char* POCKET_DESC[PO_COUNT] = {
    "Nothing happens.",
    "Monsters skip their turn after this shot.",
    "+2 MP.",
    "+4 HP (+1 per 3 depth).",
    "+6 gold (+1 per depth).",
    "Your next shot starts with +5 power.",
    "The ball discharges ALL its remaining power into your target (instead of half).",
    "Take 3 damage (+1 per 3 depth)!",
    "A pile of gold!",
    "Your next shot deals double damage.",
    "All ability cooldowns -1 and +1 MP.",
    "+3 XP (+1 per depth).",
    "+5 Block (+1 per 2 depth) for the next enemy phase.",
    "Two extra balls drop from the top of the board.",
    "An explosion hits your focus target (10, +1 per depth, + half the ball's power).",
    "Every monster is Chilled (countdown +1).",
    "Every monster gains 4 Burn.",
    "Every monster gains 4 Poison.",
    "A random prize... or a random penalty.",
    "The Tumbler meddles!",
    "Earn 5% interest on your gold (5 to 30).",
    "The ball is lost to the void: no pocket effect and no discharge.",
    "Frozen solid by a monster: nothing happens until it thaws."};
uint32_t POCKET_COLOR[PO_COUNT] = {0x4a5262, 0x40ffb0, 0x4a90ff, 0x50e070, 0xffd040, 0xff9040, 0xff4a5a, 0x9a3cff,
                                         0xffe070, 0xff60a0, 0x40e0ff, 0xf0f0f0, 0x80b0ff, 0xc060ff, 0xff8020, 0xa0f0ff,
                                         0xff7030, 0x90e040, 0xffe060, 0xff60ff, 0xffd040, 0x6030c0, 0x90c8e0};
const char* INTENT_NAME[IN_COUNT] = {
    "Idle",       "Attack",     "Heavy attack", "Flurry",      "Block",        "Heal allies", "Rally",
    "Summon",     "Hex",        "Plant bomb",   "Barrier",     "Teleport",     "Drain",       "Poison",
    "Weaken",     "Grow",       "Devour",       "Raise totem", "Curse pocket", "Steal",       "Charging",
    "Shuffle",    "Flood",      "Lay eggs",     "Spin webs",   "Blind",        "Drain ball",  "Shield ally",
    "Enrage",     "Burrow",     "Charge beam",  "Acid",        "Warp pegs",    "Swap",        "Mirror image",
    "Freeze pocket", "Devour magic", "Gravity well", "Chaos",  "Slow",         "Sap",         "Call"};
const char* ZONE_NAME[ZK_COUNT] = {"Water",       "Wind",       "Whirlpool",   "Repulsor",    "Lava",         "Boost Pad",
                                   "Portal",      "Conveyor",   "Anti-gravity", "Haste Field", "Charge Field", "Poison Mist",
                                   "Healing Spring", "Singularity", "Mirror Field", "Rune Circle", "Web",       "Geyser",
                                   "Rollover Lane", "Fog",      "Rift"};
const char* ZONE_DESC[ZK_COUNT] = {
    "Slows balls and makes them float.",
    "Pushes balls sideways.",
    "Drags balls into a spiral.",
    "Pushes balls away.",
    "Drains 1 power every 0.1 s a ball spends inside.",
    "Flings balls in the arrow's direction.",
    "Balls entering the blue portal exit at the orange one.",
    "Carries balls sideways.",
    "Gravity is reversed inside: balls float upward.",
    "Balls inside speed up.",
    "Balls gain +1 power every 0.15 s inside.",
    "Balls passing through become venomous; monsters inside are poisoned each turn.",
    "Balls passing through heal you (up to 5 HP per shot).",
    "Pulls balls in. A swallowed ball discharges 1.5x its power into your target.",
    "Reverses a ball's sideways motion when it enters.",
    "Grants a random blessing to each ball that crosses it.",
    "Sticky threads slow balls to a crawl.",
    "Erupts every few seconds, blasting balls upward.",
    "Light every lane in a set for a bonus: +10 power and +1 MP.",
    "Hides the pegs inside it.",
    "A two-way tear: balls entering either end emerge from the other with bonus power."};
const char* SACRIFICE_NAME[SAC_COUNT] = {"Sacrifice Health", "Sacrifice Magic", "Sacrifice Pockets", "Sacrifice Sight",
                                         "Sacrifice Luck",   "Sacrifice Greed", "Sacrifice Skin",    "Sacrifice Strength",
                                         "Sacrifice Time",   "Sacrifice Mending"};
const char* SACRIFICE_DESC[SAC_COUNT] = {"-15% max HP, forever.",
                                         "-3 max MP, forever.",
                                         "-1 item slot, forever.",
                                         "Your aiming guide is hidden, forever.",
                                         "Free Turn pockets no longer appear.",
                                         "You find 40% less gold.",
                                         "-2 armor, forever.",
                                         "-2 base power, forever.",
                                         "Monsters act 1 turn sooner at the start of every floor.",
                                         "All healing you receive is halved."};
const char* DRACO_NAME[DRACO_COUNT] = {"Red", "White", "Green", "Yellow", "Black", "Purple", "Pale", "Grey"};
const char* DRACO_DESC[DRACO_COUNT] = {
    "Ball hits apply 1 Burn. Breath: Fire.",
    "+1 armor. Breath: Frost (chills everything it hits).",
    "Immune to poison. Breath: Venom.",
    "+2 damage on every ball hit. Breath: Acid (strips armor).",
    "+2 Spark pegs each turn. Breath: Storm (chains between monsters).",
    "+2 max MP and +1 MP regeneration. Breath: Magic (a focused blast).",
    "+1 armor. Breath: Steam (hits everything nearby and shields you).",
    "+15 max HP and +1 armor. No breath - instead, a crushing Tail Slam."};
const uint32_t DRACO_COLOR[DRACO_COUNT] = {0xff5030, 0xe0f4ff, 0x60d050, 0xffe040, 0x8a8aa8, 0xb060ff, 0xc8d0d8, 0x9a9a9a};

// ================================================================ relics
static RelicDef& RD(int id, const char* name, int rarity, const char* glyph, uint32_t col, const char* desc) {
  RelicDef& r = RELIC[id];
  r.id = (uint16_t)id;
  r.name = name;
  r.rarity = (uint8_t)rarity;
  r.glyph = glyph;
  r.color = col;
  r.desc = desc;
  r.h = Hooks();
  return r;
}

static void initRelics() {
  RD(RL_IRONRING, "Iron Ring", R_COMMON, "o", 0xb8b8c0, "+1 base power.").h.stats = [](World& w, int) { w.st.basePower += 1; };
  RD(RL_PROTECTION, "Ring of Protection", R_COMMON, "o", 0x90b0ff, "+1 armor.").h.stats = [](World& w, int) { w.st.armor += 1; };
  RD(RL_VIGOR, "Amulet of Vigor", R_COMMON, "\"", 0xff7080, "+12 max HP.").h.stats = [](World& w, int) { w.st.maxHp += 12; };
  RD(RL_MANACRYSTAL, "Mana Crystal", R_COMMON, "*", 0x6090ff, "+2 max MP.").h.stats = [](World& w, int) { w.st.maxMp += 2; };
  RD(RL_LUCKYCOIN, "Lucky Coin", R_UNCOMMON, "$", 0x40ffb0, "Free Turn pockets are 40% wider.").h.stats = [](World& w, int) { w.st.recallWidth *= 1.4f; };
  RD(RL_LENS, "Scrying Lens", R_COMMON, "0", 0xc0a0ff, "Your aiming guide shows 1 more bounce.").h.stats = [](World& w, int) { w.st.preview += 1; };
  RD(RL_WHETSTONE, "Whetstone", R_UNCOMMON, "/", 0xff5060, "Crit pegs triple your power instead of doubling it.").h.stats =
      [](World& w, int) { w.st.critMul = std::max(w.st.critMul, 3.f); };
  RD(RL_SPIKED, "Spiked Shell", R_UNCOMMON, "@", 0xd0b090, "Your balls are 25% larger.").h.stats = [](World& w, int) { w.st.ballR *= 1.25f; };
  RD(RL_FEATHER, "Owl Feather", R_COMMON, "~", 0xe0e0f0, "Gravity -10%.").h.stats = [](World& w, int) { w.st.gravMul *= 0.9f; };
  RD(RL_ANVIL, "Tiny Anvil", R_COMMON, "#", 0x9090a0, "+3 base power, but gravity +12%.").h.stats = [](World& w, int) {
    w.st.basePower += 3;
    w.st.gravMul *= 1.12f;
  };
  RD(RL_HOURGLASS, "Hourglass", R_RARE, "8", 0xe0c080, "Monsters begin each floor with their countdown +1.").h.floorStart =
      [](World& w, int) {
        for (auto& m : w.fl.mons)
          if (!m.dead) m.cd += 1;
      };
  RD(RL_TOME, "Tome of Echoes", R_UNCOMMON, "+", 0xc080ff, "The first special peg you hit each shot triggers twice.").h.shotStart =
      [](World& w, int) { w.fl.shot.echoLeft += 1; };
  RD(RL_PURSE, "Coin Purse", R_COMMON, "$", 0xffd040, "+25% gold.").h.stats = [](World& w, int) { w.st.goldMul *= 1.25f; };
  RD(RL_SALVE, "Healing Salve", R_COMMON, "!", 0x70ff90, "Heal 6 HP after each floor.").h.floorEnd = [](World& w, int) { healPlayer(w, 6); };
  RD(RL_BLOODSTONE, "Bloodstone", R_COMMON, "*", 0xd02040, "Heal 1 HP per kill.").h.stats = [](World& w, int) { w.st.killHeal += 1; };
  RD(RL_VENOMGLAND, "Venom Gland", R_COMMON, "%", 0x90e040, "Every ball hit applies 1 Poison.").h.monDamaged =
      [](World& w, int, int mi, int, int) { applyPoison(w, mi, 1); };
  RD(RL_EMBERCORE, "Ember Core", R_COMMON, "*", 0xff7030, "Every ball hit applies 1 Burn.").h.monDamaged =
      [](World& w, int, int mi, int, int) { applyBurn(w, mi, 1); };
  RD(RL_STORMROD, "Storm Rod", R_UNCOMMON, "/", 0xfff080, "Every 20th peg hit in a shot zaps every monster for 3.").h.pegHit =
      [](World& w, int bi, int, int) {
        if (++w.fl.shot.stormRodCount % 20 != 0) return;
        V2 from = w.fl.balls[bi].p;
        for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
          if (w.fl.mons[i].dead || isMonsterAlly(w, i)) continue;
          fxZap(w, from, w.fl.mons[i].p, 0xfff080);
          damageMonster(w, i, 3, DS_ZAP);
        }
        fxSound(w, S_ZAP, 0.7f);
      };
  RD(RL_FROSTBAND, "Frost Band", R_RARE, "o", 0x90e8ff, "Your first monster hit each shot Chills it (countdown +1).").h.monDamaged =
      [](World& w, int, int mi, int, int) {
        if (w.fl.shot.frostBandUsed) return;
        w.fl.shot.frostBandUsed = true;
        applyChill(w, mi, 1);
      };
  RD(RL_GLASSCANNON, "Glass Cannon", R_RARE, "!", 0xd0f0ff, "+30% damage, but -10 max HP.").h.stats = [](World& w, int) {
    w.st.dmgMul *= 1.3f;
    w.st.maxHp -= 10;
  };
  RD(RL_BAG, "Bottomless Bag", R_COMMON, "(", 0xc09060, "+1 consumable slot.").h.stats = [](World& w, int) { w.st.slots += 1; };
  RD(RL_SEAL, "Merchant's Seal", R_COMMON, "=", 0xffd040, "Shop prices -20%.").h.stats = [](World& w, int) { w.st.shopMul *= 0.8f; };
  RD(RL_RUBBER, "Rubber Coating", R_COMMON, "o", 0xff70b0, "Bumpers and mushrooms grant +3 more power.");
  RD(RL_KEENEYE, "Keen Eye", R_UNCOMMON, "0", 0xffffff, "See what each monster will do after its current intent.").h.stats =
      [](World& w, int) { w.st.keenEye = true; };
  RD(RL_RECALLRUNE, "Rune of Return", R_UNCOMMON, "&", 0x40ffb0,
     "Once per shot, a ball falling into an Empty or Cursed pocket is sent back to the top instead.");
  RD(RL_MIDASCOIN, "Midas Coin", R_COMMON, "$", 0xffe070, "+1 Gold peg each turn.").h.stats = [](World& w, int) { w.st.specials[PK_GOLD] += 1; };
  RD(RL_BONECHARM, "Bone Charm", R_UNCOMMON, "\"", 0xe8e0c8, "Each kill permanently grants +1 max HP (up to +20).").h.kill =
      [](World& w, int mi, int) {
        if (w.pl.charmHp < 20 && !w.fl.mons[mi].summoned) {
          w.pl.charmHp++;
          w.pl.bonusMaxHp++;
          w.pl.hp++;
          recalcStats(w);
        }
      };
  RD(RL_DEMONHORN, "Demon Horn", R_UNCOMMON, "^", 0xff5040, "+25% damage to elites and bosses.").h.stats =
      [](World& w, int) { w.st.eliteDmgMul *= 1.25f; };
  RD(RL_HOLSTER, "Wand Holster", R_UNCOMMON, "(", 0xc080ff, "The first MP ability you cast each floor is free.").h.floorStart =
      [](World& w, int) { w.fl.holsterFree = 1; };
  RD(RL_SOULGEM, "Soul Gem", R_UNCOMMON, "*", 0xa070ff, "+1 MP per kill.").h.stats = [](World& w, int) { w.st.killMp += 1; };
  RD(RL_THORNCOLLAR, "Thorned Collar", R_COMMON, "o", 0x7aa848, "Monsters that attack you take 3 damage.").h.stats =
      [](World& w, int) { w.st.thornsDmg += 3; };
  RD(RL_DICE, "Weighted Dice", R_UNCOMMON, ":", 0xff80ff, "Level-ups offer 1 more choice.").h.stats = [](World& w, int) { w.st.offers += 1; };
  RD(RL_COMPASS, "Compass", R_COMMON, "+", 0xa0c0ff, "The stairs always offer 3 choices.");
  RD(RL_SCHOLAR, "Scholar's Monocle", R_COMMON, "0", 0xfff0c0, "+20% XP.").h.stats = [](World& w, int) { w.st.xpMul *= 1.2f; };
  RD(RL_AEGIS, "Aegis", R_UNCOMMON, "[", 0xc0d0ff, "The first attack against you each floor deals no damage.").h.floorStart =
      [](World& w, int) { w.fl.firstAttackBlocked = 1; };
  RD(RL_PRISM, "Prism", R_RARE, "^", 0xff80c0, "The first Crit peg you hit each shot also splits the ball.").h.pegHit =
      [](World& w, int bi, int, int) {
        if (w.fl.lastTrig == PK_CRIT && !w.fl.shot.prismUsed) {
          w.fl.shot.prismUsed = true;
          splitBall(w, bi, 1.f);
        }
      };
  RD(RL_LODESTONE, "Lodestone", R_UNCOMMON, "*", 0x8080a0, "Balls are gently drawn toward nearby special pegs.").h.tick =
      [](World& w, float dt, int) {
        for (auto& b : w.fl.balls) {
          if (!b.alive) continue;
          float best = 130 * 130;
          int bp = -1;
          for (int i = 0; i < (int)w.fl.pegs.size(); ++i) {
            const Peg& p = w.fl.pegs[i];
            if (p.dead || p.used || !isEnchant(p.kind) || p.kind == PK_CURSE) continue;
            float d2 = dist2(p.p, b.p);
            if (d2 < best) { best = d2; bp = i; }
          }
          if (bp >= 0) b.v += norm(w.fl.pegs[bp].p - b.p) * 260.f * dt;
        }
      };
  RD(RL_CLOCKHEART, "Clockwork Heart", R_UNCOMMON, "8", 0xe0b070, "+1 MP regeneration per turn.").h.stats =
      [](World& w, int) { w.st.mpRegen += 1; };
  RD(RL_PHILOSOPHER, "Philosopher's Stone", R_UNCOMMON, "*", 0xff4060, "Potions are 50% stronger.").h.stats =
      [](World& w, int) { w.st.potionMul *= 1.5f; };
  RD(RL_IDOL, "Cursed Idol", R_RARE, "&", 0x9a3cff, "+4 base power, but monsters deal +1 damage.").h.stats = [](World& w, int) {
    w.st.basePower += 4;
    w.st.monsterAtkBonus += 1;
  };
  RD(RL_KEYSTONE, "Keystone", R_RARE, "|", 0xffd040, "+2 base power for each Rune you hold.").h.stats =
      [](World& w, int) { w.st.basePower += 2 * w.runes; };
  RD(RL_SHARPENER, "Sharpening Kit", R_COMMON, "/", 0xc0c0c0, "Every 5th peg hit in a shot grants +3 extra power.").h.pegHit =
      [](World& w, int bi, int, int) {
        if (++w.fl.shot.sharpCount % 5 == 0) w.fl.balls[bi].power += 3;
      };
  RD(RL_TROLLBLOOD, "Troll Blood", R_UNCOMMON, "!", 0x60a040, "Regenerate 1 HP each turn.").h.stats = [](World& w, int) { w.st.hpRegen += 1; };
  RD(RL_POCKETWATCH, "Pocket Watch", R_RARE, "8", 0xfff0c0, "Your first shot on each floor is a free turn.").h.floorStart =
      [](World& w, int) { w.fl.pendingFree = true; };
  RD(RL_KNUCKLES, "Brass Knuckles", R_COMMON, "%", 0xd0a040, "+2 damage on every ball hit.").h.stats = [](World& w, int) { w.st.flatHit += 2; };
  RD(RL_LANTERN, "Lantern", R_COMMON, "!", 0xffe080, "Darkness has no effect on you. Your aiming guide shows 1 more bounce.").h.stats =
      [](World& w, int) {
        w.st.ignoreDark = true;
        w.st.preview += 1;
      };
}

// ================================================================ items
static ItemDef& ID_(int id, const char* name, bool potion, int timing, int target, int rarity, int price, uint32_t col,
                    const char* desc) {
  ItemDef& d = ITEM[id];
  d.id = (uint8_t)id;
  d.name = name;
  d.potion = potion;
  d.timing = (uint8_t)timing;
  d.target = (uint8_t)target;
  d.rarity = (uint8_t)rarity;
  d.price = price;
  d.color = col;
  d.desc = desc;
  d.use = nullptr;
  d.wand = false;
  d.charges = 0;
  return d;
}

static const int ENCHANT_KINDS[] = {PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_MULTI, PK_FIRE, PK_ICE, PK_POISON, PK_SPARK, PK_CRYSTAL};

static void initItems() {
  ID_(IT_HEALING, "Potion of Healing", true, T_AIM, TG_NONE, R_COMMON, 30, 0xff5060, "Heal 20 HP + 20% of your max HP.").use =
      [](World& w, V2, int) {
        if (w.pl.hp >= w.st.maxHp) return false;
        float mul = w.st.potionMul * (w.pl.species == SP_BONE ? 0.5f : 1.f);
        healPlayer(w, (int)((20 + w.st.maxHp * 0.2f) * mul));
        fxSound(w, S_HEAL, 0.9f);
        return true;
      };
  ID_(IT_MANA, "Potion of Magic", true, T_AIM, TG_NONE, R_COMMON, 25, 0x5080ff, "Restore all MP.").use = [](World& w, V2, int) {
    if (w.pl.mp >= w.st.maxMp) return false;
    gainMp(w, w.st.maxMp);
    fxSound(w, S_MANA, 0.9f);
    return true;
  };
  ID_(IT_MIGHT, "Potion of Might", true, T_AIM, TG_NONE, R_COMMON, 30, 0xff8040,
      "This shot: your ball starts with +8 power and deals 50% more damage.").use = [](World& w, V2, int) {
    if (w.fl.shot.might) return false;
    w.fl.shot.might = true;
    w.fl.shot.mightBonus += (int)(8 * w.st.potionMul);
    fxSound(w, S_GROWL, 0.8f, 1.4f);
    return true;
  };
  ID_(IT_HASTE, "Potion of Haste", true, T_AIM, TG_NONE, R_UNCOMMON, 40, 0x60ffa0, "Your next shot is a free turn: monsters do not act after it.").use =
      [](World& w, V2, int) {
        if (w.fl.pendingFree) return false;
        w.fl.pendingFree = true;
        fxSound(w, S_WHOOSH, 0.9f, 1.4f);
        if (w.pl.patron == PT_TOCK) {
          gainPiety(w, -15);
          logMsg(w, 0xc0b090, "Old Tock frowns upon your haste.");
        }
        return true;
      };
  ID_(IT_RESIST, "Potion of Resistance", true, T_AIM, TG_NONE, R_COMMON, 30, 0xc0a060, "Gain 15 Block (+1 per depth) for the next enemy phase.").use =
      [](World& w, V2, int) {
        addBlock(w, (int)((15 + w.depth) * w.st.potionMul));
        fxSound(w, S_BLOCK, 0.9f);
        return true;
      };
  ID_(IT_EXPERIENCE, "Potion of Experience", true, T_AIM, TG_NONE, R_RARE, 90, 0xffe060, "Gain a level.").use = [](World& w, V2, int) {
    gainXp(w, std::max(1, xpForLevel(w.pl.xl) - w.pl.xp));
    return true;
  };
  ID_(IT_BERSERK, "Potion of Berserk Rage", true, T_AIM, TG_NONE, R_COMMON, 30, 0xd03030,
      "This shot deals double damage. Drinking it costs 4 HP.").use = [](World& w, V2, int) {
    if (w.fl.shot.berserk || w.pl.hp <= 4) return false;
    w.fl.shot.berserk = true;
    w.pl.hp -= 4;
    fxText(w, V2(190, 110), 0xff4040, "-4", 18);
    fxSound(w, S_GROWL, 1.f, 1.1f);
    return true;
  };
  ID_(IT_AMBROSIA, "Potion of Ambrosia", true, T_AIM, TG_NONE, R_UNCOMMON, 30, 0xf0c0ff, "Heal 10 HP, restore 3 MP and cure poison and weakness.").use =
      [](World& w, V2, int) {
        healPlayer(w, (int)(10 * w.st.potionMul));
        gainMp(w, 3);
        w.pl.poison = 0;
        w.pl.weak = 0;
        fxSound(w, S_HEAL, 0.9f, 1.2f);
        return true;
      };
  ID_(IT_TELEPORT, "Scroll of Teleportation", false, T_AIM, TG_NONE, R_COMMON, 25, 0xc0a0ff, "Every monster is whisked to a new spot on the board.").use =
      [](World& w, V2, int) {
        for (int i = 0; i < (int)w.fl.mons.size(); ++i)
          if (!w.fl.mons[i].dead && !(MON[w.fl.mons[i].def].traits & TR_STATIONARY)) teleportMonster(w, i);
        fxSound(w, S_PORTAL, 1.f);
        return true;
      };
  ID_(IT_FEAR, "Scroll of Fear", false, T_AIM, TG_NONE, R_UNCOMMON, 40, 0xe0e0e0, "Every monster's countdown increases by 2.").use =
      [](World& w, V2, int) {
        for (int i = 0; i < (int)w.fl.mons.size(); ++i)
          if (!w.fl.mons[i].dead && !isMonsterAlly(w, i) && !w.fl.mons[i].boss) w.fl.mons[i].cd += 2;
          else if (!w.fl.mons[i].dead && w.fl.mons[i].boss) w.fl.mons[i].cd += 1;
        fxSound(w, S_GROWL, 0.8f, 0.6f);
        return true;
      };
  ID_(IT_IMMOLATION, "Scroll of Immolation", false, T_AIM, TG_NONE, R_COMMON, 35, 0xff7030,
      "Every monster takes 8 damage (+1 per depth) and gains 6 Burn.").use = [](World& w, V2, int) {
    for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
      if (w.fl.mons[i].dead || isMonsterAlly(w, i)) continue;
      fxBurst(w, w.fl.mons[i].p, 0xff7030, 20, 220);
      applyBurn(w, i, 6);
      damageMonster(w, i, 8 + w.depth, DS_SPELL);
    }
    fxSound(w, S_FIRE, 1.f, 0.8f);
    return true;
  };
  ID_(IT_ENCHANT, "Scroll of Enchantment", false, T_AIM, TG_NONE, R_COMMON, 30, 0x60ffe0, "Ten random pins become special pegs.").use =
      [](World& w, V2, int) {
        int n = 0;
        for (int k = 0; k < 10; ++k) n += convertPins(w, ENCHANT_KINDS[w.fl.rng.range(0, 9)], 1);
        fxSound(w, S_CAST, 0.9f, 1.2f);
        return n > 0;
      };
  ID_(IT_ACQUIRE, "Scroll of Acquirement", false, T_AIM, TG_NONE, R_RARE, 120, 0xffd040, "Choose one of three relics.").use =
      [](World& w, V2, int) {
        w.relicOffers.clear();
        pushRelicOffersN(w, 3, true, true);
        fxSound(w, S_CHEST, 1.f);
        return !w.relicOffers.empty();
      };
  ID_(IT_REMOVECURSE, "Scroll of Remove Curse", false, T_AIM, TG_NONE, R_COMMON, 20, 0xf0f0ff,
      "Cleanse Curse pegs and cursed pockets, and cure poison and weakness.").use = [](World& w, V2, int) {
    cleanseCurses(w, true);
    w.pl.poison = 0;
    w.pl.weak = 0;
    fxSound(w, S_CAST, 0.9f, 1.5f);
    return true;
  };
  ID_(IT_VULN, "Scroll of Vulnerability", false, T_AIM, TG_NONE, R_COMMON, 30, 0xff80a0, "Monsters take 50% more damage this turn.").use =
      [](World& w, V2, int) {
        if (w.fl.vulnTurn) return false;
        w.fl.vulnTurn = true;
        fxSound(w, S_CAST, 0.9f, 0.7f);
        return true;
      };
  ID_(IT_SILENCE, "Scroll of Silence", false, T_AIM, TG_NONE, R_UNCOMMON, 30, 0xa0a0b0, "For 2 turns monsters can only attack; all other actions fizzle.").use =
      [](World& w, V2, int) {
        w.fl.silenceT = std::max(w.fl.silenceT, 2);
        fxSound(w, S_CAST, 0.9f, 0.4f);
        return true;
      };
  ID_(IT_BRAND, "Scroll of Branding", false, T_AIM, TG_NONE, R_COMMON, 30, 0xffa060, "This shot, every ball hit applies 3 Burn, 3 Poison and Chill.").use =
      [](World& w, V2, int) {
        if (w.fl.shot.brand) return false;
        w.fl.shot.brand = true;
        fxSound(w, S_FIRE, 0.8f, 1.3f);
        return true;
      };
  ID_(IT_SUMMON, "Scroll of Summoning", false, T_AIM, TG_NONE, R_UNCOMMON, 35, 0xb0a080,
      "A stone golem joins you for this floor. Each ball hit on it grants +6 power.").use = [](World& w, V2, int) {
    for (int tries = 0; tries < 300; ++tries) {
      V2 p(w.fl.rng.rangef(PX0 + 60, PX1 - 60), w.fl.rng.rangef(FIELD_Y0 + 40, FIELD_Y1 - 100));
      if (spotFree(w, p, 18, 8)) {
        int pi = addPeg(w, PK_GOLEM, p, 18);
        if (pi >= 0) w.fl.pegs[pi].val = 6;
        fxSound(w, S_SPAWN, 0.9f);
        return true;
      }
    }
    return false;
  };
  ID_(IT_REVEAL, "Scroll of Revelation", false, T_AIM, TG_NONE, R_COMMON, 25, 0xc0e0ff, "For the rest of this floor, your aiming guide shows 2 more bounces.").use =
      [](World& w, V2, int) {
        w.fl.revealBonus += 2;
        fxSound(w, S_CAST, 0.8f, 1.6f);
        return true;
      };
}

// ================================================================ monsters
static Intent I(int k, int v = 0, int d = 1, int a = 0) {
  Intent t;
  t.kind = (uint8_t)k;
  t.val = (int16_t)v;
  t.delay = (uint8_t)d;
  t.arg = (int16_t)a;
  return t;
}
static void MD(int id, const char* name, const char* glyph, uint32_t col, int hp, int armor, float r, int xp, int gold,
               uint32_t traits, int tval, int split, std::initializer_list<Intent> s1, std::initializer_list<Intent> s2,
               std::initializer_list<Intent> s3, const char* desc) {
  MonDef& m = MON[id];
  m.id = (uint16_t)id;
  m.name = name;
  m.glyph = glyph;
  m.color = col;
  m.hp = hp;
  m.armor = armor;
  m.r = r;
  m.xp = xp;
  m.gold = gold;
  m.traits = traits;
  m.tval = tval;
  m.splitInto = split;
  int i = 0;
  for (auto& t : s1) if (i < 5) m.s1[i++] = t;
  i = 0;
  for (auto& t : s2) if (i < 5) m.s2[i++] = t;
  i = 0;
  for (auto& t : s3) if (i < 5) m.s3[i++] = t;
  m.desc = desc;
}

static void initMonsters() {
  // ---------------- Upper Halls
  MD(M_RAT, "rat", "r", 0xa08c74, 7, 0, 17, 2, 1, 0, 0, -1, {I(IN_ATTACK, 2, 2)}, {}, {}, "A mangy dungeon rat.");
  MD(M_BAT, "giant bat", "b", 0x9a78c8, 6, 0, 16, 2, 1, TR_FLYING, 0, -1, {I(IN_ATTACK, 1, 1)}, {}, {},
     "Erratic. Flits to a new spot every turn.");
  MD(M_JACKAL, "jackal", "j", 0xc8a060, 8, 0, 17, 2, 1, TR_SWARM, 0, -1, {I(IN_ATTACK, 2, 2)}, {}, {}, "Hunts in packs.");
  MD(M_KOBOLD, "kobold", "k", 0xc08050, 10, 0, 18, 3, 2, 0, 0, -1, {I(IN_ATTACK, 1, 1), I(IN_ATTACK, 2, 1)}, {}, {},
     "Small, sneaky and relentless.");
  MD(M_GOBLIN, "goblin", "g", 0x80c060, 13, 0, 19, 3, 3, 0, 0, -1, {I(IN_ATTACK, 3, 2)}, {}, {}, "A greedy little brute.");
  MD(M_OOZE, "ooze", "J", 0x50c0b0, 16, 0, 22, 3, 2, TR_SPLIT, 0, M_OOZELET, {I(IN_ATTACK, 2, 2)}, {}, {},
     "Splits into two oozelets when slain.");
  MD(M_OOZELET, "oozelet", "J", 0x80e8d8, 6, 0, 15, 1, 0, 0, 0, -1, {I(IN_ATTACK, 1, 2)}, {}, {}, "A small blob of ooze.");
  MD(M_ORC, "orc", "o", 0xd05a48, 20, 0, 21, 5, 4, 0, 0, -1, {I(IN_ATTACK, 4, 2)}, {}, {}, "A burly orc warrior.");
  MD(M_SHAMAN, "orc shaman", "o", 0x60a8f0, 14, 0, 20, 5, 4, 0, 0, -1, {I(IN_HEAL, 5, 2), I(IN_ATTACK, 3, 2)}, {}, {},
     "Heals its allies. Kill it first.");
  MD(M_CULTIST, "cultist", "p", 0xb060d0, 14, 0, 20, 5, 4, 0, 0, -1, {I(IN_HEX, 3, 2), I(IN_ATTACK, 3, 2)}, {}, {},
     "Twists pins into Curse pegs that halve your ball's power.");
  MD(M_HOBGOBLIN, "hobgoblin", "g", 0xe08a40, 24, 1, 23, 6, 5, 0, 0, -1, {I(IN_ATTACK, 5, 3)}, {}, {}, "Tougher than a goblin, and meaner.");
  MD(M_SPIDER, "giant spider", "s", 0x8a6a6a, 18, 0, 21, 6, 4, 0, 0, -1, {I(IN_POISON, 3, 2), I(IN_ATTACK, 2, 2)}, {}, {},
     "Its bite poisons you: poison deals its stacks as damage each turn, then halves.");
  MD(M_SAPPER, "kobold sapper", "k", 0xf0c850, 12, 0, 19, 5, 5, 0, 0, -1, {I(IN_BOMB, 8, 3, 3), I(IN_ATTACK, 1, 1)}, {}, {},
     "Plants bombs. Hit a bomb with a ball to defuse it.");
  MD(M_OGRE, "ogre", "O", 0xd0a878, 70, 1, 32, 16, 18, TR_ELITE, 0, -1,
     {I(IN_ATTACK, 5, 2), I(IN_CHARGE, 0, 1), I(IN_HEAVY, 12, 1)}, {}, {}, "Winds up for crushing blows that ignore armor.");
  MD(M_WARCHIEF, "goblin warchief", "G", 0xa0e070, 60, 1, 30, 16, 18, TR_ELITE, 0, -1,
     {I(IN_SUMMON, M_GOBLIN, 2, 1), I(IN_BUFF, 1, 2), I(IN_ATTACK, 5, 2)}, {}, {}, "Calls goblins to battle and rallies them.");
  MD(M_GORLAG, "Gorlag, Goblin King", "G", 0xffd040, 160, 1, 46, 40, 60, TR_BOSS, 0, -1,
     {I(IN_SUMMON, M_GOBLIN, 2, 1), I(IN_ATTACK, 6, 2), I(IN_BLOCK, 12, 1)},
     {I(IN_ATTACK, 8, 2), I(IN_SUMMON, M_HOBGOBLIN, 2, 1), I(IN_BUFF, 1, 2)}, {},
     "Guardian of the Upper Halls. Surrounds himself with goblins, and grows desperate when hurt.");
  MD(M_WITCH, "The Tallow Witch", "W", 0xf0e8b0, 142, 0, 44, 40, 60, TR_BOSS, 0, -1,
     {I(IN_HEX, 5, 2), I(IN_ATTACK, 5, 1), I(IN_BOMB, 10, 2, 3)},
     {I(IN_CURSEPOCKET, 0, 1), I(IN_ATTACK, 7, 1), I(IN_HEAL, 15, 2), I(IN_HEX, 6, 1)}, {},
     "Guardian of the Upper Halls. Curses pins and pockets and plants wax bombs.");
  // ---------------- Fungal Lair
  MD(M_TOADSTOOL, "toadstool", "f", 0xd08cff, 24, 0, 20, 5, 2, TR_STATIONARY, 0, -1, {I(IN_POISON, 2, 2)}, {}, {},
     "Rooted in place. Releases poison spores.");
  MD(M_WOLF, "wolf", "h", 0xb0b0b8, 22, 0, 20, 6, 3, TR_SWARM, 0, -1, {I(IN_ATTACK, 4, 2)}, {}, {}, "Hunts in packs.");
  MD(M_ADDER, "adder", "S", 0x70b848, 18, 0, 18, 6, 3, 0, 0, -1, {I(IN_POISON, 4, 2), I(IN_ATTACK, 3, 1)}, {}, {}, "A venomous snake.");
  MD(M_SPRIGGAN, "spriggan", "i", 0x90ff90, 16, 0, 17, 7, 5, TR_EVASIVE, 0, -1, {I(IN_ATTACK, 3, 1)}, {}, {},
     "Darts to a new spot whenever a ball hits it.");
  MD(M_MYCONID, "myconid", "f", 0xf0b0f0, 28, 0, 22, 8, 4, 0, 0, -1, {I(IN_HEAL, 6, 2), I(IN_TOTEM, 6, 3)}, {}, {},
     "Heals allies and raises spore totems that shield it.");
  MD(M_VINE, "vine stalker", "v", 0x40b040, 30, 0, 22, 8, 4, 0, 0, -1, {I(IN_WALL, 4, 2), I(IN_ATTACK, 5, 2)}, {}, {},
     "Grows thorny barriers around itself.");
  MD(M_BEAR, "black bear", "q", 0x806050, 48, 1, 28, 11, 6, 0, 0, -1, {I(IN_ATTACK, 8, 3)}, {}, {}, "Slow, but hits like a landslide.");
  MD(M_HYDRA, "hydra", "D", 0x48c868, 56, 0, 30, 14, 8, TR_REGEN, 5, -1, {I(IN_MULTI, 3, 2, 2)}, {}, {},
     "Regenerates 5 HP every turn. Bites twice.");
  MD(M_TREANT, "treant", "T", 0x70b050, 140, 2, 34, 26, 25, TR_ELITE, 0, -1,
     {I(IN_HEAL, 12, 2), I(IN_WALL, 6, 1), I(IN_HEAVY, 12, 2)}, {}, {}, "An ancient walking tree.");
  MD(M_MYCELIUM, "The Mother Mycelium", "M", 0xe080ff, 420, 0, 52, 70, 90, TR_BOSS | TR_STATIONARY, 0, -1,
     {I(IN_SUMMON, M_TOADSTOOL, 1, 2), I(IN_POISON, 4, 1), I(IN_ATTACK, 8, 2)},
     {I(IN_EAT, 6, 2), I(IN_ATTACK, 10, 1), I(IN_SUMMON, M_MYCONID, 1, 2)}, {},
     "Guardian of the Lair. A vast fungal mind that devours the board to heal itself.");
  // ---------------- Drowned Halls
  MD(M_EEL, "electric eel", "e", 0x50b0f0, 22, 0, 19, 7, 4, TR_EVASIVE, 0, -1, {I(IN_ATTACK, 3, 2)}, {}, {},
     "Slips away to a new spot whenever it is hit.");
  MD(M_MERFOLK, "merfolk", "m", 0x4890d0, 30, 0, 22, 7, 4, 0, 0, -1, {I(IN_ATTACK, 3, 1)}, {}, {}, "A trident-wielding warrior.");
  MD(M_SIREN, "siren", "m", 0x90d0ff, 22, 0, 21, 7, 4, 0, 0, -1, {I(IN_DRAIN, 2, 2), I(IN_ATTACK, 3, 2)}, {}, {},
     "Its song drains your MP.");
  MD(M_JELLY, "jellyfish", "J", 0xd0b0ff, 20, 0, 21, 6, 3, TR_THORNS, 1, -1, {I(IN_ATTACK, 3, 2)}, {}, {},
     "Stings you for 1 damage whenever a ball hits it.");
  MD(M_CRAB, "giant crab", "c", 0xf07050, 26, 3, 23, 8, 5, 0, 0, -1, {I(IN_BLOCK, 8, 1), I(IN_ATTACK, 5, 2)}, {}, {},
     "Heavily armored, and hides behind its claws.");
  MD(M_TURTLE, "snapping turtle", "t", 0x6a9048, 36, 4, 26, 9, 6, 0, 0, -1, {I(IN_ATTACK, 6, 3)}, {}, {},
     "Its shell shrugs off weak hits.");
  MD(M_WATERELEM, "water elemental", "E", 0x70d0ff, 130, 0, 32, 26, 25, TR_ELITE | TR_PHASING, 6, -1,
     {I(IN_ATTACK, 7, 2), I(IN_BLOCK, 15, 2)}, {}, {}, "Balls with less than 6 power pass right through it.");
  MD(M_LEVIATHAN, "The Leviathan", "L", 0x40a0d0, 440, 2, 56, 75, 95, TR_BOSS, 0, -1,
     {I(IN_RISE, 40, 2), I(IN_SUMMON, M_EEL, 1, 2), I(IN_HEAVY, 14, 2)},
     {I(IN_ATTACK, 8, 1), I(IN_DRAIN, 3, 2), I(IN_SUMMON, M_EEL, 2, 2)}, {},
     "Guardian of the Drowned Halls. Raises the waters and calls eels from the deep.");
  // ---------------- Clockwork Mines
  MD(M_DWARF, "dwarf miner", "d", 0xe0b070, 30, 2, 22, 8, 6, 0, 0, -1, {I(IN_ATTACK, 5, 2)}, {}, {}, "Tough and well armored.");
  MD(M_AUTOMATON, "automaton", "a", 0xb8c0d0, 34, 3, 23, 9, 5, 0, 0, -1, {I(IN_ATTACK, 6, 2)}, {}, {}, "A clanking clockwork soldier.");
  MD(M_TURRETM, "arrow turret", "t", 0x9a9aa8, 22, 2, 20, 7, 4, TR_STATIONARY, 0, -1, {I(IN_ATTACK, 3, 2)}, {}, {},
     "Bolted down. Fires every other turn.");
  MD(M_GNOME, "gnome tinkerer", "n", 0x90f0b0, 22, 0, 20, 8, 7, 0, 0, -1, {I(IN_WALL, 3, 2), I(IN_HEAL, 6, 2)}, {}, {},
     "Builds barriers and repairs its allies.");
  MD(M_BOMBER, "powder monkey", "k", 0xffb050, 20, 0, 19, 8, 6, 0, 0, -1, {I(IN_BOMB, 12, 2, 3), I(IN_ATTACK, 2, 1)}, {}, {},
     "Plants powder kegs. Hit them with a ball to defuse them.");
  MD(M_COGGOLEM, "cog golem", "8", 0xd0a048, 40, 0, 25, 9, 5, 0, 0, -1, {I(IN_BLOCK, 10, 1), I(IN_ATTACK, 6, 2)}, {}, {},
     "Alternates between shielding and striking.");
  MD(M_COLOSSUS, "iron colossus", "X", 0x90a0b0, 170, 5, 36, 30, 30, TR_ELITE, 0, -1,
     {I(IN_BLOCK, 20, 1), I(IN_HEAVY, 16, 2), I(IN_ATTACK, 6, 1)}, {}, {}, "A walking fortress. Armor 5.");
  MD(M_FOREMAN, "The Foreman", "F", 0xffc860, 360, 2, 54, 80, 100, TR_BOSS, 0, -1,
     {I(IN_WALL, 4, 1), I(IN_SUMMON, M_TURRETM, 1, 2), I(IN_ATTACK, 9, 2)},
     {I(IN_BOMB, 15, 1, 3), I(IN_HEAVY, 14, 2), I(IN_BLOCK, 20, 1)}, {},
     "Guardian of the Mines. Builds walls and turrets, then brings out the explosives.");
  // ---------------- Crypt
  MD(M_ZOMBIE, "zombie", "z", 0x88a888, 50, 0, 25, 11, 5, 0, 0, -1, {I(IN_ATTACK, 8, 3)}, {}, {}, "Slow and tough.");
  MD(M_SKELETON, "skeleton", "Z", 0xe8e8d8, 28, 1, 22, 10, 5, TR_UNDYING, 0, -1, {I(IN_ATTACK, 6, 2)}, {}, {},
     "Rises once more after being destroyed.");
  MD(M_GHOUL, "ghoul", "z", 0xb07070, 38, 0, 24, 11, 6, TR_LIFESTEAL, 0, -1, {I(IN_ATTACK, 6, 2)}, {}, {},
     "Heals by the damage it deals.");
  MD(M_WRAITH, "wraith", "W", 0x8888ff, 32, 0, 23, 12, 6, TR_PHASING, 8, -1, {I(IN_DRAIN, 2, 2), I(IN_ATTACK, 5, 2)}, {}, {},
     "Balls with less than 8 power pass right through it.");
  MD(M_BANSHEE, "banshee", "W", 0xe8d0ff, 26, 0, 21, 11, 6, TR_FLYING, 0, -1, {I(IN_WEAKEN, 2, 2), I(IN_ATTACK, 4, 1)}, {}, {},
     "Its wail Weakens you (halving your base power).");
  MD(M_NECROMANCER, "necromancer", "p", 0xa050d0, 34, 0, 23, 13, 8, 0, 0, -1,
     {I(IN_SUMMON, M_SKELETON, 1, 3), I(IN_HEX, 4, 2), I(IN_ATTACK, 5, 2)}, {}, {}, "Raises skeletons and curses pins.");
  MD(M_VAMPIRE, "vampire lord", "V", 0xe03050, 190, 1, 34, 34, 35, TR_ELITE | TR_LIFESTEAL, 0, -1,
     {I(IN_ATTACK, 8, 1), I(IN_BLOCK, 15, 2), I(IN_SUMMON, M_BAT, 2, 2)}, {}, {}, "Drinks your blood to heal.");
  MD(M_HOLLOWKING, "The Hollow King", "K", 0xc8c8ff, 640, 1, 56, 100, 120, TR_BOSS, 0, -1,
     {I(IN_SUMMON, M_SKELETON, 2, 2), I(IN_HEX, 8, 2), I(IN_HEAVY, 16, 2)},
     {I(IN_WEAKEN, 2, 2), I(IN_ATTACK, 10, 1), I(IN_CURSEPOCKET, 0, 2)}, {},
     "Guardian of the Crypt. Commands the restless dead.");
  // ---------------- Ember Forge
  MD(M_IMP, "fire imp", "i", 0xff7040, 22, 0, 18, 9, 6, TR_FLYING, 0, -1, {I(IN_ATTACK, 4, 1)}, {}, {}, "Flits about. Attacks every turn.");
  MD(M_HELLHOUND, "hellhound", "h", 0xd04030, 32, 0, 22, 10, 5, TR_SWARM, 0, -1, {I(IN_ATTACK, 5, 2)}, {}, {}, "Hunts in packs.");
  MD(M_SALAMANDER, "salamander", "S", 0xff9050, 40, 0, 24, 11, 6, 0, 0, -1, {I(IN_ATTACK, 7, 2)}, {}, {}, "A lizard wreathed in flame.");
  MD(M_SMITH, "cinder smith", "d", 0xf0b050, 36, 1, 23, 12, 9, 0, 0, -1, {I(IN_BUFF, 2, 2), I(IN_BLOCK, 10, 2)}, {}, {},
     "Forges weapons for its allies, making them hit harder.");
  MD(M_EFREET, "efreet", "E", 0xff8030, 52, 0, 27, 14, 8, 0, 0, -1, {I(IN_ATTACK, 6, 2), I(IN_BOMB, 14, 3, 3)}, {}, {},
     "Hurls fireballs and plants fire-bombs.");
  MD(M_MAGMAGOLEM, "magma golem", "8", 0xff5010, 64, 4, 28, 14, 7, TR_REGEN, 6, -1, {I(IN_ATTACK, 8, 3)}, {}, {},
     "Armored and regenerating. Burn and poison help.");
  MD(M_FIREGIANT, "fire giant", "C", 0xff6030, 220, 3, 38, 36, 40, TR_ELITE, 0, -1, {I(IN_HEAVY, 18, 2), I(IN_ATTACK, 8, 1)}, {}, {},
     "Massive and relentless.");
  MD(M_PYRRHUS, "Pyrrhus the Forge-Heart", "P", 0xff4020, 700, 3, 56, 105, 125, TR_BOSS, 0, -1,
     {I(IN_RISE, 40, 2), I(IN_BOMB, 16, 2, 3), I(IN_ATTACK, 10, 1)},
     {I(IN_HEAVY, 20, 2), I(IN_SUMMON, M_IMP, 2, 2), I(IN_BUFF, 3, 2)}, {},
     "Guardian of the Forge. Floods the board with lava and fire.");
  // ---------------- Frozen Vaults
  MD(M_WINTERWOLF, "winter wolf", "h", 0xd8ecff, 32, 0, 22, 11, 5, TR_SWARM, 0, -1, {I(IN_ATTACK, 6, 2)}, {}, {}, "Hunts in packs.");
  MD(M_ICEBEAST, "ice beast", "Y", 0xa8e0ff, 48, 0, 26, 11, 6, 0, 0, -1, {I(IN_ATTACK, 7, 2)}, {}, {}, "A shaggy horror of the cold.");
  MD(M_YETI, "yeti", "Y", 0xeef6ff, 56, 0, 27, 12, 6, 0, 0, -1, {I(IN_ATTACK, 5, 1)}, {}, {}, "Attacks every turn.");
  MD(M_FROSTWRAITH, "frost wraith", "W", 0x90d8ff, 36, 0, 23, 12, 6, TR_PHASING, 10, -1, {I(IN_ATTACK, 6, 2)}, {}, {},
     "Balls with less than 10 power pass right through it.");
  MD(M_RIMEMAGE, "rime mage", "p", 0x98c8ff, 32, 0, 22, 12, 8, 0, 0, -1, {I(IN_BLOCK, 10, 2), I(IN_WEAKEN, 2, 3), I(IN_ATTACK, 4, 2)}, {}, {},
     "Wards itself and Weakens you.");
  MD(M_GLACIER, "living glacier", "I", 0xc8ecff, 80, 6, 30, 15, 8, TR_HARDENED, 25, -1, {I(IN_ATTACK, 9, 3)}, {}, {},
     "Hardened: no single hit deals more than 25 damage.");
  MD(M_FROSTGIANT, "frost giant", "C", 0x98d0ff, 240, 4, 38, 38, 42, TR_ELITE, 0, -1,
     {I(IN_HEAVY, 20, 3), I(IN_BLOCK, 20, 1), I(IN_ATTACK, 9, 1)}, {}, {}, "A towering giant clad in ice.");
  MD(M_RIMEQUEEN, "The Rime Queen", "Q", 0xd0f4ff, 720, 1, 54, 110, 130, TR_BOSS, 0, -1,
     {I(IN_WEAKEN, 2, 2), I(IN_SUMMON, M_FROSTWRAITH, 1, 2), I(IN_HEAVY, 18, 2)},
     {I(IN_BLOCK, 30, 1), I(IN_ATTACK, 12, 1), I(IN_SUMMON, M_ICEBEAST, 2, 3)}, {},
     "Guardian of the Vaults. Her cold saps your strength.");
  // ---------------- The Core
  MD(M_DEVIL, "red devil", "4", 0xff4848, 70, 0, 25, 18, 10, 0, 0, -1, {I(IN_ATTACK, 9, 2)}, {}, {}, "A lesser demon.");
  MD(M_DEALER, "dealer", "$", 0xe8c868, 48, 0, 24, 16, 16, 0, 0, -1, {I(IN_CURSEPOCKET, 0, 2), I(IN_HEX, 5, 2), I(IN_ATTACK, 6, 2)}, {}, {},
     "Rigs the game: curses pockets and pins.");
  MD(M_PITBOSS, "pit boss", "&", 0xffa8a8, 96, 1, 28, 22, 16, 0, 0, -1, {I(IN_BUFF, 3, 2), I(IN_BLOCK, 20, 2), I(IN_ATTACK, 9, 2)}, {}, {},
     "Keeps the other monsters in line.");
  MD(M_ORBGUARD, "orb guardian", "X", 0xd8a8ff, 120, 4, 30, 25, 12, TR_PHASING, 12, -1, {I(IN_ATTACK, 12, 2)}, {}, {},
     "Balls with less than 12 power pass right through it.");
  MD(M_TITAN, "titan", "C", 0xffe48a, 140, 3, 34, 30, 14, 0, 0, -1, {I(IN_HEAVY, 22, 3), I(IN_BLOCK, 20, 2)}, {}, {}, "A giant of legend.");
  MD(M_DRAGON, "golden dragon", "D", 0xffd048, 170, 3, 36, 35, 20, 0, 0, -1,
     {I(IN_ATTACK, 10, 2), I(IN_POISON, 5, 2), I(IN_HEAVY, 20, 3)}, {}, {}, "Breathes poison and fire.");
  MD(M_LICH, "ancient lich", "L", 0xb070ff, 280, 1, 36, 45, 50, TR_ELITE, 0, -1,
     {I(IN_SUMMON, M_WRAITH, 1, 2), I(IN_DRAIN, 3, 2), I(IN_HEAVY, 22, 2)}, {}, {}, "A master of death magic.");
  MD(M_HOUSE, "The House", "$", 0xffd700, 1500, 2, 64, 0, 0, TR_BOSS | TR_STATIONARY, 0, -1,
     {I(IN_SHUFFLE, 0, 1), I(IN_SUMMON, M_DEALER, 1, 2), I(IN_ATTACK, 12, 2)},
     {I(IN_WALL, 8, 1), I(IN_CURSEPOCKET, 0, 2), I(IN_HEAVY, 20, 2)},
     {I(IN_ATTACK, 10, 1), I(IN_BOMB, 20, 1, 3), I(IN_BUFF, 3, 2)},
     "The heart of the machine, guarding the Orb of Chance. The House always wins... unless you beat it.");
}

// ================================================================ species / backgrounds / patrons
static void initPeople() {
  auto SP = [](int id, const char* name, uint32_t col, int hp, int mp, int pow, int arm, int hpl, int a0, int a1, int a2,
               const char* desc) {
    SpeciesDef& s = SPECIES[id];
    s.id = (uint8_t)id;
    s.name = name;
    s.color = col;
    s.hp = hp;
    s.mp = mp;
    s.power = pow;
    s.armor = arm;
    s.hpPerLvl = hpl;
    s.aff[0] = (uint8_t)a0;
    s.aff[1] = (uint8_t)a1;
    s.aff[2] = (uint8_t)a2;
    s.desc = desc;
    s.exotic = false;
  };
  SP(SP_IRON, "Iron Ball", 0xb8c4d0, 42, 5, 1, 1, 4, SCH_FORCE, SCH_CLOCKWORK, SCH_COUNT,
     "Sturdy and dependable. Starts with 1 armor and sees 4 choices at every level-up.");
  SP(SP_GLASS, "Glass Ball", 0xd8f4ff, 34, 6, 1, 0, 3, SCH_ARCANE, SCH_STORM, SCH_FORTUNE,
     "Brittle but lively: bounces 12% higher and deals 20% more damage. Low HP.");
  SP(SP_LEAD, "Lead Ball", 0x8a8f9a, 54, 3, 3, 0, 5, SCH_EARTH, SCH_FORCE, SCH_COUNT,
     "Heavy and brutal: +2 base power and lots of HP, but falls fast and has little MP.");
  SP(SP_WISP, "Wisp", 0xa8f0ff, 37, 8, 1, 0, 3, SCH_ARCANE, SCH_FROST, SCH_STORM,
     "A drifting spark of magic. Floats down slowly and regains an extra MP each turn. Fragile.");
  SP(SP_GILDED, "Gilded Ball", 0xffd84a, 40, 5, 1, 0, 4, SCH_FORTUNE, SCH_CLOCKWORK, SCH_COUNT,
     "Born of greed: +50% gold, starts with 60 gold, and shops are 10% cheaper.");
  SP(SP_BONE, "Bone Ball", 0xe8e0c8, 38, 5, 1, 0, 4, SCH_SHADOW, SCH_FROST, SCH_COUNT,
     "Restless dead: heals 3 HP per kill and is immune to poison, but healing potions work at half strength.");
  SP(SP_EMBER, "Ember", 0xff7a3a, 44, 5, 1, 0, 4, SCH_FLAME, SCH_STORM, SCH_COUNT,
     "A living coal: every ball hit applies 2 Burn and lava cannot hurt it. Frost spells cost +1 MP.");
  SP(SP_MOSS, "Mossball", 0x7ad070, 40, 5, 1, 0, 4, SCH_LIFE, SCH_EARTH, SCH_SHADOW,
     "Soft and green: regenerates 1 HP each turn, and heal pegs heal 1 more.");

  auto BG = [](int id, const char* name, int ab, int hp, int mp, int gold, int it0, int it1, const char* desc) {
    BackgroundDef& b = BGS[id];
    b.id = (uint8_t)id;
    b.name = name;
    b.ability = (uint16_t)ab;
    b.hp = hp;
    b.mp = mp;
    b.gold = gold;
    b.items[0] = it0;
    b.items[1] = it1;
    b.desc = desc;
    b.patron = -1;
    b.exotic = false;
  };
  BG(BG_FIGHTER, "Fighter", AB_MOMENTUM, 8, 0, 0, IT_HEALING, -1, "Trained to hit hard and keep hitting. Starts with Momentum.");
  BG(BG_WIZARD, "Wizard", AB_MISSILE, 0, 2, 0, IT_MANA, -1, "A student of the arcane. Starts with Magic Missile.");
  BG(BG_TINKERER, "Tinkerer", AB_BUMPERKIT, 0, 1, 20, IT_ENCHANT, -1, "Builds bumpers out of spare parts. Starts with Bumper Kit.");
  BG(BG_PYRO, "Pyromancer", AB_KINDLE, 0, 1, 0, IT_IMMOLATION, -1, "Sets everything alight. Starts with Kindle.");
  BG(BG_ICEWEAVER, "Ice Weaver", AB_ICELANCE, 0, 2, 0, IT_FEAR, -1, "Cold, precise and patient. Starts with Ice Lance.");
  BG(BG_STORMCALLER, "Stormcaller", AB_STATIC, 0, 1, 0, IT_MANA, -1, "Lightning follows the ball. Starts with Static.");
  BG(BG_GAMBLER, "Gambler", AB_DOUBLEDOWN, 0, 0, 50, IT_HASTE, -1, "Everything on red. Starts with Double Down and extra gold.");
  BG(BG_NECRO, "Necromancer", AB_BONEHARVEST, 0, 1, 0, IT_HEALING, -1, "The fallen serve you. Starts with Bone Harvest.");
  BG(BG_MONK, "Monk", AB_NUDGE, 4, 1, 0, IT_AMBROSIA, -1, "Guides the ball with a gentle touch. Starts with Nudge.");
  BG(BG_PINBALLER, "Pinballer", AB_PINBALL, 4, 0, 0, IT_HEALING, -1, "Brought their own flippers. Starts with Pinball Wizard.");
  BG(BG_DRUID, "Druid", AB_OVERGROWTH, 4, 1, 0, IT_HEALING, -1, "The board grows at their feet. Starts with Overgrowth.");
  BG(BG_ALCHEMIST, "Alchemist", AB_VENOM, 0, 0, 0, IT_HEALING, IT_MIGHT, "Venoms and potions. Starts with Venom and two potions.");
  BG(BG_WANDERER, "Wanderer", AB_COUNT, 0, 0, 30, -2, -2, "Nobody knows where they came from. A random ability and random items.");

  auto PT = [](int id, const char* name, const char* title, uint32_t col, const char* likes, const char* dislikes,
               const char* desc, int g0, int g1, int g2, int g3, int g4) {
    PatronDef& p = PATRON[id];
    p.id = (uint8_t)id;
    p.name = name;
    p.title = title;
    p.color = col;
    p.likes = likes;
    p.dislikes = dislikes;
    p.desc = desc;
    p.gifts[0] = (uint16_t)g0;
    p.gifts[1] = (uint16_t)g1;
    p.gifts[2] = (uint16_t)g2;
    p.gifts[3] = (uint16_t)g3;
    p.gifts[4] = (uint16_t)g4;
  };
  PT(PT_VRASK, "Vrask", "the Unbroken", 0xff6040, "Slaying monsters.", "Casting spells that cost MP.",
     "A god of battle who despises sorcery. Grants brute strength and a thick hide.", AB_P_BERSERK, AB_P_IRONHIDE, AB_P_TROPHY,
     AB_P_WRATH, AB_P_UNBREAKABLE);
  PT(PT_AURUM, "Aurum", "the Gilded", 0xffd040, "Collecting gold.", "Nothing. Gold is gold.",
     "A god of wealth whose miracles are bought, not prayed for. Invocations cost gold instead of piety.", AB_P_TOLL,
     AB_P_GILDED, AB_P_GOLDTOUCH, AB_P_BUYOUT, AB_P_GOLDSTORM);
  PT(PT_TUMBLER, "The Tumbler", "Lord of Chance", 0xff80ff, "Wild combos and living dangerously.", "Nothing.",
     "A capricious god of chaos who meddles in your fights. Usually it helps. Usually.", AB_P_LUCKY, AB_P_GIFTS, AB_P_DICE,
     AB_P_FAVOR, AB_P_CHAOSSTORM);
  PT(PT_VERDANA, "Verdana", "the Green Mother", 0x70e070, "Healing, and hitting lots of pegs.", "Casting Flame spells.",
     "A goddess of growth whose followers make the board bloom.", AB_P_SPROUT, AB_P_GREEN, AB_P_BRAMBLE, AB_P_WORLDTREE, AB_P_EVERGREEN);
  PT(PT_TOCK, "Old Tock", "Keeper of Hours", 0xc8b890, "Enemy phases in which you take no damage.", "Haste in any form.",
     "A slow, patient god who rewards those who take their time.", AB_P_STALL, AB_P_PATIENCE, AB_P_BORROWED, AB_P_REWIND, AB_P_TIMESTOP);
  PT(PT_MORGRAVE, "Morgrave", "the Pale Warden", 0xc0c0ff, "Kills, especially of poisoned or burning monsters.", "Nothing.",
     "Keeper of the dead. The fallen rise again at the Warden's word.", AB_P_SKELETON, AB_P_HARVEST, AB_P_SOULREND,
     AB_P_DEATHSDOOR, AB_P_ARMY);
  PT(PT_ASHKA, "Ashka", "the Kindled", 0xff8030, "Burning monsters to death.", "Casting Frost spells.",
     "A goddess of fire and ruin who delights in destruction.", AB_P_FIRESTORM, AB_P_KINDLING, AB_P_IMMOLATE, AB_P_APOCALYPSE, AB_P_RAINFIRE);
  PT(PT_MIRRA, "Mirra", "of the Glass", 0xa0e0ff, "Splitting balls and using portals.", "Nothing.",
     "A goddess of reflections and multiplicity.", AB_P_MIRRORBALL, AB_P_REFLECTION, AB_P_SHATTERGLASS, AB_P_KALEIDO, AB_P_MIRRORHALL);
}

// ================================================================ biomes / modifiers
static void initWorld() {
  auto BI = [](int id, const char* name, const char* sn, uint32_t top, uint32_t bot, uint32_t pin, uint32_t acc, uint32_t wall,
               int mood, std::initializer_list<int> roster, std::initializer_list<int> elites, std::initializer_list<int> bosses,
               float bumpers, float spinners, float water, float wind, float wells, float lava, float ramps, float movers,
               const char* flavor) {
    BiomeDef& b = BIOME[id];
    b.id = (uint8_t)id;
    b.name = name;
    b.shortName = sn;
    b.bgTop = top;
    b.bgBot = bot;
    b.pin = pin;
    b.accent = acc;
    b.wall = wall;
    b.mood = mood;
    for (int i = 0; i < 16; ++i) b.roster[i] = M_COUNT;
    int i = 0;
    for (int m : roster) if (i < 16) b.roster[i++] = (uint16_t)m;
    for (int k = 0; k < 3; ++k) b.elites[k] = M_COUNT;
    i = 0;
    for (int m : elites) if (i < 3) b.elites[i++] = (uint16_t)m;
    b.bosses[0] = b.bosses[1] = M_COUNT;
    i = 0;
    for (int m : bosses) if (i < 2) b.bosses[i++] = (uint16_t)m;
    b.bumpers = bumpers;
    b.spinners = spinners;
    b.water = water;
    b.wind = wind;
    b.wells = wells;
    b.lava = lava;
    b.ramps = ramps;
    b.movers = movers;
    b.flavor = flavor;
  };
  BI(BI_HALLS, "The Upper Halls", "D", 0x1b2233, 0x0a0d14, 0xc6cfdb, 0x8fb3ff, 0x4b5569, 1,
     {M_RAT, M_JACKAL, M_KOBOLD, M_GOBLIN, M_BAT, M_OOZE, M_ORC, M_SHAMAN, M_CULTIST, M_SPIDER, M_HOBGOBLIN, M_SAPPER},
     {M_OGRE, M_WARCHIEF, M_HOBGOBLIN}, {M_GORLAG, M_WITCH}, 1.0f, 0.3f, 0, 0, 0, 0, 0.6f, 0.2f,
     "Dusty stone halls where the Descent begins.");
  BI(BI_LAIR, "The Fungal Lair", "Lair", 0x15271a, 0x070f09, 0xb8d6a8, 0x8cff8c, 0x3e5a3e, 2,
     {M_WOLF, M_TOADSTOOL, M_ADDER, M_SPRIGGAN, M_VINE, M_MYCONID, M_BEAR, M_HYDRA}, {M_TREANT, M_HYDRA, M_BEAR},
     {M_MYCELIUM}, 1.6f, 0.2f, 0.2f, 0, 0, 0, 0.3f, 0.3f, "A damp cavern of glowing fungus and hungry beasts.");
  BI(BI_DROWNED, "The Drowned Halls", "Deep", 0x0e2238, 0x040a14, 0xa8d0f0, 0x60c8ff, 0x2c4a6a, 3,
     {M_MERFOLK, M_EEL, M_JELLY, M_SIREN, M_CRAB, M_TURTLE}, {M_WATERELEM, M_TURTLE, M_CRAB}, {M_LEVIATHAN}, 0.6f, 0.2f,
     1.0f, 0.5f, 0.8f, 0, 0.3f, 0.2f, "Flooded galleries. Water slows the ball; whirlpools pull it in.");
  BI(BI_MINES, "The Clockwork Mines", "Mines", 0x2a2014, 0x0e0a05, 0xe0c090, 0xffc060, 0x5a4630, 4,
     {M_DWARF, M_TURRETM, M_AUTOMATON, M_GNOME, M_BOMBER, M_COGGOLEM}, {M_COLOSSUS, M_COGGOLEM, M_AUTOMATON}, {M_FOREMAN},
     0.6f, 1.3f, 0, 0.2f, 0, 0, 0.6f, 1.0f, "Grinding gears and spinning machinery.");
  BI(BI_CRYPT, "The Crypt", "Crypt", 0x1d1528, 0x07050b, 0xc8c0d8, 0xb080ff, 0x3c3050, 5,
     {M_ZOMBIE, M_SKELETON, M_GHOUL, M_BANSHEE, M_WRAITH, M_NECROMANCER}, {M_VAMPIRE, M_NECROMANCER, M_ZOMBIE},
     {M_HOLLOWKING}, 0.4f, 0.3f, 0, 0, 0.3f, 0, 0.5f, 0.3f, "Cold tombs where the dead do not rest.");
  BI(BI_FORGE, "The Ember Forge", "Forge", 0x2e1410, 0x0e0504, 0xf0b8a0, 0xff7040, 0x5a2c20, 6,
     {M_IMP, M_HELLHOUND, M_SALAMANDER, M_SMITH, M_EFREET, M_MAGMAGOLEM}, {M_FIREGIANT, M_EFREET, M_MAGMAGOLEM},
     {M_PYRRHUS}, 0.6f, 0.5f, 0, 0, 0, 1.0f, 0.4f, 0.3f, "Rivers of lava and roaring furnaces.");
  BI(BI_FROZEN, "The Frozen Vaults", "Vaults", 0x152634, 0x050b12, 0xd8f0ff, 0xa0e8ff, 0x3a5868, 7,
     {M_WINTERWOLF, M_ICEBEAST, M_YETI, M_FROSTWRAITH, M_RIMEMAGE, M_GLACIER}, {M_FROSTGIANT, M_GLACIER, M_YETI},
     {M_RIMEQUEEN}, 0.5f, 0.3f, 0, 0.6f, 0, 0, 0.9f, 0.3f, "Glittering halls of ice, swept by freezing winds.");
  BI(BI_CORE, "The Core", "Core", 0x221b08, 0x0a0803, 0xf0e0a0, 0xffd040, 0x5a4a20, 8,
     {M_DEVIL, M_DEALER, M_PITBOSS, M_ORBGUARD, M_TITAN, M_DRAGON}, {M_LICH, M_DRAGON, M_TITAN}, {M_HOUSE}, 0.8f, 0.6f,
     0.2f, 0.2f, 0.3f, 0.2f, 0.5f, 0.5f, "The golden heart of the machine, where the Orb of Chance is kept.");

  auto MO = [](int id, const char* name, uint32_t col, const char* desc) {
    MODS[id].id = (uint8_t)id;
    MODS[id].name = name;
    MODS[id].color = col;
    MODS[id].desc = desc;
  };
  MO(MOD_SHIFTING, "Shifting Rows", 0xa0c0ff, "Each turn, rows of pins slide sideways.");
  MO(MOD_GEARWORKS, "Gearworks", 0xffc060, "Rings of pins rotate continuously.");
  MO(MOD_RISINGWATER, "Rising Water", 0x60c8ff, "Water rises from below each turn, slowing balls.");
  MO(MOD_CRUMBLING, "Crumbling", 0xa08060, "Four pins crumble away each turn.");
  MO(MOD_OVERGROWN, "Overgrown", 0x70e070, "Four new pins sprout each turn.");
  MO(MOD_WINDY, "Gusting Winds", 0xc0e0ff, "A crosswind blows, changing direction each turn.");
  MO(MOD_DARKNESS, "Darkness", 0x8060a0, "Only pegs near your balls and monsters can be seen.");
  MO(MOD_MAGSTORM, "Magnetic Storm", 0xfff080, "Three Spark pegs appear each turn.");
  MO(MOD_GRAVITY, "Unstable Gravity", 0xc080ff, "Gravity changes strength every turn.");
  MO(MOD_TREASURE, "Treasure Trove", 0xffd040, "Four extra Gold pegs each turn.");
  MO(MOD_HAUNTED, "Haunted", 0x9a60d0, "Two Curse pegs appear each turn.");
  MO(MOD_BLESSED, "Blessed", 0x80ff90, "Two extra Heal pegs each turn.");
  MO(MOD_BOUNCY, "Springy", 0xff90c0, "Everything is 15% bouncier.");
  MO(MOD_MOLTEN, "Molten Floor", 0xff6020, "Lava pools drain the power of balls that pass through them.");
  MO(MOD_ROTPOCKETS, "Carousel", 0xffa0ff, "The pockets rotate one slot each turn.");
  MO(MOD_FORTIFIED, "Fortified", 0xb0b0c0, "Monsters begin with Block equal to 25% of their HP.");
  MO(MOD_SWARMING, "Swarming", 0xff7070, "A new monster arrives every 3 turns.");
}

// ================================================================ events
const EventDef EVENTS[] = {
    {"The Wishing Well", "A mossy well glitters with coins. A crooked sign reads: \"Toss a coin, make a wish.\"",
     {"Toss in 15 gold (heal 25% HP and restore 2 MP)", "Climb down for the coins (+30 gold, take 6 damage)", "Walk on"}, 3},
    {"The Wandering Merchant", "A hunched figure with an enormous backpack waves you over. \"Potions! Fresh potions!\"",
     {"Buy a mystery potion (20 gold)", "Sell some blood (take 8 damage, +45 gold)", "Decline politely"}, 3},
    {"The Idol of Chance", "A grinning stone idol holds out two closed fists. \"Pick one,\" it rumbles.",
     {"Left fist (50%: a random relic / 50%: take 12 damage)", "Right fist (50%: +60 gold / 50%: nothing)", "Leave the idol be"}, 3},
    {"The Healing Spring", "Crystal-clear water bubbles up through the stones.",
     {"Drink deeply (heal 35% HP)", "Fill a flask (gain a Potion of Healing)", "Move on"}, 3},
    {"The Training Grounds", "Battered dummies and a rack of practice balls line the walls.",
     {"Train (upgrade a random ability you own)", "Spar with the dummies (take 10 damage, gain half a level of XP)", "Move on"}, 3},
    {"The Collapsed Library", "Scrolls lie scattered among fallen shelves.",
     {"Search the stacks (gain 2 random scrolls)", "Study the old tomes (take 6 damage, gain a level-up choice)", "Move on"}, 3},
    {"The Altar of Sacrifice", "A blood-stained altar hums with a hungry power.",
     {"Sacrifice 8 max HP (+2 base power)", "Sacrifice 40 gold (+1 armor)", "Leave"}, 3},
    {"The Trapped Chest", "A gilded chest sits alone in a narrow room. The floor is suspiciously clean.",
     {"Open it carefully (gain a random relic, take 10 damage)", "Pry it open from a distance (+25 gold)", "Leave it"}, 3},
    {"The Goblin Gambler", "A goblin in a tiny top hat shuffles three cups. \"Double or nothing, friend?\"",
     {"Bet 30 gold (50%: win 60)", "Bet 60 gold (50%: win 120)", "No thanks"}, 3},
    {"The Mana Fountain", "A fountain of liquid starlight shimmers in the dark.",
     {"Drink (+2 max MP)", "Bathe (restore all MP and heal 15 HP)", "Move on"}, 3},
    {"The Lost Adventurer", "A wounded adventurer slumps against the wall, begging for help.",
     {"Give them a potion (gain a random relic)", "Give them 25 gold (+1 max MP, +5 max HP)", "Rob them (+40 gold, -5 max HP)"}, 3},
    {"The Mimic's Den", "Something in the corner looks like a treasure chest. It is breathing.",
     {"Poke it (take 12 damage; it flees and drops a relic)", "Leave quietly"}, 2},
    {"The Artificer's Workshop", "A cluttered workshop hums with half-finished trinkets. A tinkerer looks up: \"Commissions welcome!\"",
     {"Commission a trinket (70 gold: choose 1 of 3 randarts)", "Buy a wand (40 gold)", "Leave"}, 3},
    {"The Pool of Chaos", "A pool of swirling rainbow liquid bubbles and giggles to itself.",
     {"Drink (gain a random mutation, usually good)", "Toss in a coin (10 gold: a random potion or scroll)", "Leave"}, 3},
    {"The Demon's Bargain", "A grinning demon lounges on a throne of bones. \"I can make you... more.\"",
     {"Accept its mark (a random good mutation, and a random bad one)", "Learn its curse (lose 8 max HP: learn or improve Hurl Damnation)", "Refuse"}, 3},
    {"The Mirror Pond", "Your reflection in the still water winks at you.",
     {"Gaze deeper (improve a random ability, but gain a bad mutation)", "Shatter the reflection (+30 gold, take 5 damage)", "Leave"}, 3},
};
const int NUM_EVENTS = sizeof(EVENTS) / sizeof(EVENTS[0]);

static int randomPotion(Rng& r) {
  static const int P[] = {IT_HEALING, IT_HEALING, IT_MANA, IT_MIGHT, IT_RESIST, IT_BERSERK, IT_AMBROSIA, IT_HASTE, IT_LUCK,
                          IT_FLIGHT, IT_CANCEL};
  return P[r.range(0, 10)];
}
static int randomScroll(Rng& r) {
  static const int S[] = {IT_TELEPORT, IT_FEAR, IT_IMMOLATION, IT_ENCHANT, IT_REMOVECURSE, IT_VULN, IT_SILENCE, IT_BRAND,
                          IT_SUMMON, IT_REVEAL, IT_UPHEAVAL, IT_BUTTERFLIES, IT_POISONSCROLL};
  return S[r.range(0, 12)];
}
static int randomWand(Rng& r) {
  static const int W[] = {IT_W_FLAME, IT_W_ICE, IT_W_LIGHTNING, IT_W_DIGGING, IT_W_POLYMORPH, IT_W_CHARMING, IT_W_ACID,
                          IT_W_BUMPERS, IT_W_PARALYSIS, IT_W_ROOTS};
  return W[r.range(0, 9)];
}
static int badMutation(World& w) {
  std::vector<int> c;
  for (int m = 0; m < MUT_COUNT; ++m)
    if (MUTS[m].tier == 9 && w.pl.mut[m] < MUTS[m].maxLvl) c.push_back(m);
  if (c.empty()) return -1;
  return c[w.rng.range(0, (int)c.size() - 1)];
}
static int randomRelic(World& w) { return randomRelicFor(w, false, false); }
static bool hasPotion(const World& w) {
  for (auto& it : w.pl.items)
    if (it.id >= 0 && ITEM[it.id].potion) return true;
  return false;
}

bool eventOptionAvailable(const World& w, int ev, int opt, std::string* why) {
  auto need = [&](bool ok, const char* msg) {
    if (!ok && why) *why = msg;
    return ok;
  };
  switch (ev) {
    case 0: if (opt == 0) return need(w.pl.gold >= 15, "Not enough gold."); break;
    case 1: if (opt == 0) return need(w.pl.gold >= 20, "Not enough gold."); if (opt == 1) return need(w.pl.hp > 8, "Too weak."); break;
    case 2: if (opt == 0) return need(w.pl.hp > 12, "Too risky right now."); break;
    case 4: if (opt == 1) return need(w.pl.hp > 10, "Too weak."); break;
    case 5: if (opt == 1) return need(w.pl.hp > 6, "Too weak."); break;
    case 6: if (opt == 0) return need(w.st.maxHp > 20, "You cannot spare it."); if (opt == 1) return need(w.pl.gold >= 40, "Not enough gold."); break;
    case 7: if (opt == 0) return need(w.pl.hp > 10, "Too weak."); break;
    case 8: if (opt == 0) return need(w.pl.gold >= 30, "Not enough gold."); if (opt == 1) return need(w.pl.gold >= 60, "Not enough gold."); break;
    case 10: if (opt == 0) return need(hasPotion(w), "You have no potion."); if (opt == 1) return need(w.pl.gold >= 25, "Not enough gold."); break;
    case 11: if (opt == 0) return need(w.pl.hp > 12, "Too weak."); break;
    case 12: if (opt == 0) return need(w.pl.gold >= 70, "Not enough gold."); if (opt == 1) return need(w.pl.gold >= 40, "Not enough gold."); break;
    case 13: if (opt == 1) return need(w.pl.gold >= 10, "Not enough gold."); break;
    case 14: if (opt == 1) return need(w.st.maxHp > 20, "You cannot spare it."); break;
    case 15: if (opt == 1) return need(w.pl.hp > 5, "Too weak."); break;
  }
  return true;
}

void eventResolve(World& w, int ev, int opt) {
  std::string& R = w.eventResult;
  R.clear();
  auto hurt = [&](int d) {
    w.pl.hp = std::max(1, w.pl.hp - d);
  };
  switch (ev) {
    case 0:
      if (opt == 0) { w.pl.gold -= 15; healPlayer(w, w.st.maxHp / 4); gainMp(w, 2); R = "The coin sinks with a soft plink. You feel refreshed."; }
      else if (opt == 1) { hurt(6); gainGold(w, 30, V2(800, 450)); R = "You scrape your knees but come back up with a fistful of coins."; }
      else R = "You leave the well to its wishes.";
      break;
    case 1:
      if (opt == 0) {
        w.pl.gold -= 20;
        int it = randomPotion(w.rng);
        if (gainItem(w, it)) R = std::string("The merchant hands you a ") + ITEM[it].name + ".";
        else R = "Your pack is full; the merchant shrugs and keeps your gold.";
      } else if (opt == 1) { hurt(8); w.pl.gold += 45; R = "The merchant carefully bottles your blood. \"A fine vintage.\""; }
      else R = "The merchant shuffles off into the dark.";
      break;
    case 2:
      if (opt == 0) {
        if (w.rng.chance(0.5f)) {
          int rl = randomRelic(w);
          if (rl >= 0) { gainRelic(w, rl); R = std::string("The fist opens: a ") + RELIC[rl].name + "!"; }
          else R = "The fist opens. It is empty.";
        } else { hurt(12); R = "The fist opens and slaps you. Hard."; }
      } else if (opt == 1) {
        if (w.rng.chance(0.5f)) { gainGold(w, 60, V2(800, 450)); R = "Gold pours from the stone hand!"; }
        else R = "The fist opens. It is empty. The idol snickers.";
      } else R = "The idol's grin follows you as you leave.";
      break;
    case 3:
      if (opt == 0) { healPlayer(w, (int)(w.st.maxHp * 0.35f)); R = "The water is cold and wonderful."; }
      else if (opt == 1) { if (gainItem(w, IT_HEALING)) R = "You fill a flask with the healing water."; else R = "You have no room for another flask."; }
      else R = "You move on.";
      break;
    case 4:
      if (opt == 0) {
        std::vector<int> up;
        for (int i = 0; i < (int)w.pl.abil.size(); ++i)
          if (w.pl.abil[i].lvl < ABIL[w.pl.abil[i].id].maxLvl) up.push_back(i);
        if (up.empty()) R = "You have nothing left to learn here.";
        else {
          int i = up[w.rng.range(0, (int)up.size() - 1)];
          w.pl.abil[i].lvl++;
          recalcStats(w);
          R = std::string("Your ") + ABIL[w.pl.abil[i].id].name + " improves to level " + std::to_string(w.pl.abil[i].lvl) + ".";
        }
      } else if (opt == 1) { hurt(10); gainXp(w, std::max(1, xpForLevel(w.pl.xl) / 2)); R = "The dummies hit back, but you learn a thing or two."; }
      else R = "You move on.";
      break;
    case 5:
      if (opt == 0) {
        int a = randomScroll(w.rng), b = randomScroll(w.rng);
        bool ok1 = gainItem(w, a), ok2 = gainItem(w, b);
        R = "You find ";
        if (ok1) R += ITEM[a].name;
        if (ok1 && ok2) R += " and ";
        if (ok2) R += ITEM[b].name;
        if (!ok1 && !ok2) R = "You find some scrolls, but have no room to carry them.";
        else R += ".";
      } else if (opt == 1) { hurt(6); w.pendingLevels++; generateOffers(w); R = "A shelf collapses on you, but the knowledge was worth it."; }
      else R = "You move on.";
      break;
    case 6:
      if (opt == 0) { w.pl.bonusMaxHp -= 8; w.pl.bonusPower += 2; recalcStats(w); w.pl.hp = std::min(w.pl.hp, w.st.maxHp); R = "The altar drinks deeply. You feel stronger."; }
      else if (opt == 1) { w.pl.gold -= 40; w.pl.bonusArmor += 1; recalcStats(w); R = "The gold melts into the altar. Your skin hardens."; }
      else R = "You leave the altar hungry.";
      break;
    case 7:
      if (opt == 0) {
        hurt(10);
        int rl = randomRelic(w);
        if (rl >= 0) { gainRelic(w, rl); R = std::string("A dart grazes you, but inside you find a ") + RELIC[rl].name + "."; }
        else R = "A dart grazes you. The chest is empty.";
      } else if (opt == 1) { gainGold(w, 25, V2(800, 450)); R = "The trap fires harmlessly. You pocket the coins."; }
      else R = "You leave the chest alone.";
      break;
    case 8:
      if (opt == 0 || opt == 1) {
        int bet = opt == 0 ? 30 : 60;
        w.pl.gold -= bet;
        if (w.rng.chance(0.5f)) { w.pl.gold += bet * 2; R = "You find the pea! The goblin grumbles and pays up."; }
        else R = "The pea was never under any cup. The goblin tips his hat.";
      } else R = "The goblin shrugs and shuffles on.";
      break;
    case 9:
      if (opt == 0) { w.pl.bonusMp += 2; recalcStats(w); w.pl.mp += 2; R = "Starlight fills you. (+2 max MP)"; }
      else if (opt == 1) { gainMp(w, w.st.maxMp); healPlayer(w, 15); R = "You emerge refreshed and sparkling."; }
      else R = "You move on.";
      break;
    case 10:
      if (opt == 0) {
        for (auto& it : w.pl.items)
          if (it.id >= 0 && ITEM[it.id].potion) { it = InvItem(); break; }
        int rl = randomRelic(w);
        if (rl >= 0) { gainRelic(w, rl); R = std::string("In gratitude, they press a ") + RELIC[rl].name + " into your hands."; }
        else R = "They thank you warmly.";
      } else if (opt == 1) { w.pl.gold -= 25; w.pl.bonusMp += 1; w.pl.bonusMaxHp += 5; recalcStats(w); w.pl.hp += 5; R = "They bless you before limping away."; }
      else { w.pl.gold += 40; w.pl.bonusMaxHp -= 5; recalcStats(w); w.pl.hp = std::min(w.pl.hp, w.st.maxHp); R = "You take their purse. Something inside you withers."; }
      break;
    case 11:
      if (opt == 0) {
        hurt(12);
        int rl = randomRelic(w);
        if (rl >= 0) { gainRelic(w, rl); R = std::string("The mimic bites you and flees, dropping a ") + RELIC[rl].name + "!"; }
        else R = "The mimic bites you and flees.";
      } else R = "You back away slowly.";
      break;
    case 12:
      if (opt == 0) {
        w.pl.gold -= 70;
        w.relicOffers.clear();
        for (int k = 0; k < 3; ++k) {
          Offer o;
          o.type = 2;
          o.id = (int)newRandartSeed(w);
          w.relicOffers.push_back(o);
        }
        R = "The tinkerer lays out three glittering trinkets. \"Take your pick.\"";
      } else if (opt == 1) {
        int it = randomWand(w.rng);
        if (gainItem(w, it)) { w.pl.gold -= 40; R = std::string("You buy a ") + ITEM[it].name + "."; }
        else R = "Your pack is full.";
      } else R = "You leave the workshop.";
      break;
    case 13:
      if (opt == 0) {
        int m = randomMutation(w, w.rng.chance(0.3f), false);
        if (m >= 0) { gainMutation(w, m, false); R = std::string("The liquid fizzes through you. You gain ") + MUTS[m].name + "!"; }
        else R = "The liquid tastes of nothing at all.";
      } else if (opt == 1) {
        w.pl.gold -= 10;
        int it = w.rng.chance(0.5f) ? randomPotion(w.rng) : randomScroll(w.rng);
        if (gainItem(w, it)) R = std::string("The pool spits out a ") + ITEM[it].name + ".";
        else R = "The pool burps. Your pack is full.";
      } else R = "The pool giggles as you leave.";
      break;
    case 14:
      if (opt == 0) {
        int g = randomMutation(w, false, true);
        if (g >= 0) gainMutation(w, g, false);
        int b = badMutation(w);
        if (b >= 0) gainMutation(w, b, false);
        R = "The demon's mark burns into you. You feel stronger... and stranger.";
      } else if (opt == 1) {
        w.pl.bonusMaxHp -= 8;
        recalcStats(w);
        w.pl.hp = std::min(w.pl.hp, w.st.maxHp);
        learnAbility(w, AB_DAMNATION);
        R = "The demon whispers a word of damnation. It burns your tongue.";
      } else R = "The demon shrugs. \"Your loss.\"";
      break;
    case 15:
      if (opt == 0) {
        std::vector<int> up;
        for (int i = 0; i < (int)w.pl.abil.size(); ++i)
          if (w.pl.abil[i].lvl < ABIL[w.pl.abil[i].id].maxLvl) up.push_back(i);
        if (!up.empty()) learnAbility(w, w.pl.abil[up[w.rng.range(0, (int)up.size() - 1)]].id);
        int b = badMutation(w);
        if (b >= 0) gainMutation(w, b, false);
        R = up.empty() ? "Your reflection shrugs; you have nothing left to learn. Something about you twists." : "You learn something from yourself. Something about you twists.";
      } else if (opt == 1) { hurt(5); gainGold(w, 30, V2(800, 450)); R = "Shards of silver glass scatter - and some of them are coins."; }
      else R = "Your reflection waves goodbye.";
      break;
  }
}

// ================================================================ descriptions & validation
std::string resolveLevels(const char* desc, int lvl, bool showUpgrade) {
  std::string out;
  const char* p = desc;
  while (*p) {
    if (*p == '[') {
      const char* e = strchr(p, ']');
      if (!e) { out += p; break; }
      std::vector<std::string> parts;
      std::string cur;
      for (const char* q = p + 1; q < e; ++q) {
        if (*q == '|') { parts.push_back(cur); cur.clear(); }
        else cur += *q;
      }
      parts.push_back(cur);
      int idx = clampv(lvl - 1, 0, (int)parts.size() - 1);
      if (showUpgrade && idx > 0 && parts[idx] != parts[idx - 1]) out += parts[idx - 1] + " > " + parts[idx];
      else out += parts[idx];
      p = e + 1;
    } else {
      out += *p++;
    }
  }
  return out;
}

std::string abilityDesc(int ab, int lvl, bool showUpgrade) { return resolveLevels(ABIL[ab].desc, lvl, showUpgrade); }

bool isInnate(int ab) { return ab >= AB_FIRST_INNATE && ab < AB_FIRST_DIVINE; }

static int rawMpCost(const World& w, int ab, int lvl) {
  const AbilityDef& d = ABIL[ab];
  int c = d.cost[clampv(lvl - 1, 0, 4)];
  if (d.school == SCH_DIVINE) return c;
  if (w.pl.species == SP_EMBER && d.school == SCH_FROST && c > 0) c += 1;
  if (c > 0 && w.st.costReduce > 0) c = std::max(1, c - w.st.costReduce);
  if (c > 1 && ((w.st.cheapSchool >> d.school) & 1u)) c -= 1;
  return c;
}

int abilityCost(const World& w, int ab, int lvl) {
  if (w.st.hpForMp && ABIL[ab].school != SCH_DIVINE) return 0;  // djinn pay with HP instead
  return rawMpCost(w, ab, lvl);
}

int abilityHpCost(const World& w, int ab, int lvl) {
  const AbilityDef& d = ABIL[ab];
  int h = d.hpCost[clampv(lvl - 1, 0, 2)];
  if (h > 0) h = std::max(1, h - w.st.hpCostReduce);
  if (w.st.hpForMp && d.school != SCH_DIVINE) h += rawMpCost(w, ab, lvl);
  return h;
}

void initAbilities2();
void initDivine();
void initRelics2();
void initItems2();
void initMonsters2();
void initPeople2();
void initWorld2();
void initMutations();

void initContent() {
  initAbilities();
  initAbilities2();
  initDivine();
  initRelics();
  initRelics2();
  initItems();
  initItems2();
  initMonsters();
  initMonsters2();
  initPeople();
  initPeople2();
  initWorld();
  initWorld2();
  initMutations();
  initV3Content();
  static bool statsDone = false;
  if (!statsDone) {
    statsDone = true;
    initStatTables();
  }
}

bool validateContent(std::string& err) {
  for (int i = 0; i < AB_COUNT; ++i)
    if (!ABIL[i].name || ABIL[i].id != i) { err = fmt("ability %d missing", i); return false; }
  for (int i = 0; i < RL_COUNT; ++i)
    if (!RELIC[i].name || RELIC[i].id != i) { err = fmt("relic %d missing", i); return false; }
  for (int i = 0; i < IT_COUNT; ++i)
    if (!ITEM[i].name || ITEM[i].id != i || !ITEM[i].use) { err = fmt("item %d missing", i); return false; }
  for (int i = 0; i < M_COUNT; ++i)
    if (!MON[i].name || MON[i].id != i || MON[i].s1[0].kind == IN_NONE) { err = fmt("monster %d missing", i); return false; }
  for (int i = 0; i < SP_COUNT; ++i)
    if (!SPECIES[i].name) { err = fmt("species %d missing", i); return false; }
  for (int i = 0; i < BG_COUNT; ++i)
    if (!BGS[i].name) { err = fmt("bg %d missing", i); return false; }
  for (int i = 0; i < PT_COUNT; ++i)
    if (!PATRON[i].name) { err = fmt("patron %d missing", i); return false; }
  for (int i = 0; i < BI_COUNT; ++i)
    if (!BIOME[i].name) { err = fmt("biome %d missing", i); return false; }
  for (int i = 0; i < MOD_COUNT; ++i)
    if (!MODS[i].name) { err = fmt("mod %d missing", i); return false; }
  for (int i = 0; i < AB_COUNT; ++i) {
    const AbilityDef& a = ABIL[i];
    if (a.timing != T_PASSIVE && !a.cast) { err = fmt("active ability %s has no cast", a.name); return false; }
  }
  for (int i = 0; i < MUT_COUNT; ++i)
    if (!MUTS[i].name || MUTS[i].id != i) { err = fmt("mutation %d missing", i); return false; }
  for (int i = 0; i < PK_COUNT; ++i)
    if (!PEG_NAME[i] || !PEG_DESC[i]) { err = fmt("peg text %d missing", i); return false; }
  for (int i = 0; i < PO_COUNT; ++i)
    if (!POCKET_NAME[i] || !POCKET_DESC[i] || !POCKET_SHORTNAME[i]) { err = fmt("pocket text %d missing", i); return false; }
  for (int i = 0; i < IN_COUNT; ++i)
    if (!INTENT_NAME[i]) { err = fmt("intent name %d missing", i); return false; }
  for (int i = 0; i < ZK_COUNT; ++i)
    if (!ZONE_NAME[i] || !ZONE_DESC[i]) { err = fmt("zone text %d missing", i); return false; }
  for (int i = 0; i < PT_COUNT; ++i)
    for (int k = 0; k < 5; ++k)
      if (PATRON[i].gifts[k] < AB_FIRST_DIVINE || PATRON[i].gifts[k] >= AB_COUNT) { err = fmt("patron %d gift %d bad", i, k); return false; }
  return true;
}
