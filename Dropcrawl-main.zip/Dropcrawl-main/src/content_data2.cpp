// Dropcrawl - expansion data: relics, items (potions, scrolls, wands), monsters, species, backgrounds, gods, branches, modifiers
#include "rules.h"

// ================================================================ relics
static RelicDef& RD(int id, const char* name, int rarity, const char* glyph, uint32_t col, const char* desc) {
  RelicDef& r = RELIC[id];
  r.id = (uint16_t)id;
  r.name = name;
  r.rarity = (uint8_t)rarity;
  r.glyph = glyph;
  r.color = col;
  r.desc = desc;
  r.h = Hooks();
  return r;
}

void initRelics2() {
  RD(RL_TULIPSEED, "Tulip Seed", R_UNCOMMON, "*", 0xff80c0, "A row of tulips grows on every floor, and tulips grant +3 power.").h.stats =
      [](World& w, int) { w.st.tulipBonus += 3; };
  {
    auto& r = RD(RL_SLOTTOKEN, "Slot Token", R_UNCOMMON, "$", 0xffd700,
                 "A slot machine appears on every floor, you get a free spin when you arrive, and slot payouts are 50% bigger.");
    r.h.stats = [](World& w, int) { w.st.slotMul *= 1.5f; };
    r.h.floorStart = [](World& w, int) {
      if (!w.fl.isVault) queueSlotSpin(w);
    };
  }
  RD(RL_SLINGCAP, "Slingshot Cap", R_COMMON, "^", 0xff9060,
     "Slingshot kickers appear on every floor. Spinners, kickers and pendulums grant +2 power.").h.stats = [](World& w, int) { w.st.kickerBonus += 2; };
  RD(RL_TROPHY, "Trophy Rack", R_UNCOMMON, "&", 0xd0a060, "+3% damage for every elite or boss you have slain (max +30%).").h.stats =
      [](World& w, int) { w.st.dmgMul *= 1.f + std::min(0.3f, 0.03f * w.rs.eliteKills); };
  RD(RL_ROSE, "Thorned Rose", R_COMMON, "*", 0xff4070, "Whenever you heal 2 or more HP, gain Block equal to half the amount.");
  RD(RL_STORMJAR, "Storm in a Jar", R_UNCOMMON, "!", 0xfff080,
     "At the start of each turn, lightning strikes the monster with the most HP for 4 (+1 per 3 depth).").h.turnStart = [](World& w, int) {
    int t = highestHpMonster(w);
    if (t < 0) return;
    fxZap(w, V2(w.fl.mons[t].p.x, 0), w.fl.mons[t].p, 0xfff4a0);
    damageMonster(w, t, 4 + w.depth / 3, DS_ZAP);
  };
  RD(RL_LAVALAMP, "Lava Lamp", R_COMMON, "!", 0xff6020, "Lava no longer drains your balls; instead it ignites them (their next hit Burns).").h.stats =
      [](World& w, int) { w.st.lavaImmune = true; };
  RD(RL_DIVINGBELL, "Diving Bell", R_COMMON, "0", 0x60c8ff, "Water no longer slows your balls, and entering water grants +2 power.").h.stats =
      [](World& w, int) { w.st.waterImmune = true; };
  RD(RL_CHAIN, "Chain Link", R_UNCOMMON, "8", 0xc0c0d0, "Your discharges arc to a second monster for half damage.");
  RD(RL_ECHOSHELL, "Echo Shell", R_RARE, "@", 0xa0e0ff, "Every 4th shot, a full-power echo of your ball follows it.").h.stats = [](World& w, int) {
    w.st.echoEvery = w.st.echoEvery > 0 ? std::min(w.st.echoEvery, 4) : 4;
  };
  RD(RL_FANG, "Serpent Fang", R_COMMON, "/", 0x90e040, "Poison you apply is 50% stronger.");
  RD(RL_HYDRASCALE, "Hydra Scale", R_RARE, "%", 0x48c868, "Once per shot, your ball splits in two (60% power) on its first monster hit.");
  RD(RL_BRIMSTONE, "Brimstone", R_COMMON, "*", 0xff7030, "Burn you apply is 50% stronger.");
  RD(RL_FROZENTEAR, "Frozen Tear", R_UNCOMMON, "'", 0xa0f0ff, "Chilled and frozen monsters take +3 damage from every source.").h.stats =
      [](World& w, int) { w.st.chillDmg += 3; };
  RD(RL_THUNDEREGG, "Thunder Egg", R_COMMON, "0", 0xfff080, "+2 Spark pegs each turn, and zaps deal +2 damage.").h.stats = [](World& w, int) {
    w.st.specials[PK_SPARK] += 2;
    w.st.zapBonus += 2;
  };
  RD(RL_RATSKULL, "Rat Skull", R_COMMON, "&", 0xa08c74, "Monsters summoned by your enemies have 30% less HP.");
  {
    auto& r = RD(RL_SALAMANDER, "Salamander Tail", R_COMMON, "~", 0xff9050, "+1 HP regeneration. Killing a burning monster heals 3 HP.");
    r.h.stats = [](World& w, int) { w.st.hpRegen += 1; };
    r.h.kill = [](World& w, int mi, int) {
      if (w.fl.mons[mi].burn > 0) healPlayer(w, 3);
    };
  }
  RD(RL_ORACLE, "Oracle's Eye", R_UNCOMMON, "0", 0xe0c0ff, "See each monster's next two actions, and your aiming guide shows 1 more bounce.").h.stats =
      [](World& w, int) {
        w.st.keenEye = true;
        w.st.keenDepth = std::max(w.st.keenDepth, 2);
        w.st.preview += 1;
      };
  RD(RL_RABBITFOOT, "Rabbit's Foot", R_UNCOMMON, "\"", 0xf0e0d0,
     "Chance effects (Lottery pockets, slot machines, Chaos pegs) are luckier, and a Clover peg appears each turn.").h.stats = [](World& w, int) {
    w.st.lucky = true;
    w.st.specials[PK_CLOVER] += 1;
  };
  RD(RL_PHILCOIN, "Alchemist's Coin", R_UNCOMMON, "$", 0xffe070, "Every other Gold peg you hit also restores 1 MP.").h.pegHit =
      [](World& w, int, int, int) {
        if (w.fl.lastTrig == PK_GOLD && w.fl.shot.specialHits % 2 == 0) gainMp(w, 1);
      };
  RD(RL_MAGERING, "Ring of Wizardry", R_UNCOMMON, "o", 0xc080ff, "Your spells cost 1 less MP (minimum 1).").h.stats = [](World& w, int) {
    w.st.costReduce += 1;
  };
  RD(RL_CHALICE, "Blood Chalice", R_COMMON, "!", 0xd02040, "Blood magic costs 1 less HP, and casting any spell heals 1 HP.").h.stats =
      [](World& w, int) { w.st.hpCostReduce += 1; };
  RD(RL_HORN, "Horn of Summoning", R_UNCOMMON, "(", 0xc0a060, "Your summons last +1 turn and deal +25% damage.").h.stats = [](World& w, int) {
    w.st.allyTurns += 1;
    w.st.allyDmgMul *= 1.25f;
  };
  RD(RL_CHAOSDICE, "Chaos Dice", R_UNCOMMON, ":", 0xff60ff,
     "The Tumbler watches you (8% chance to meddle each turn) and its meddling is kind. Chaos pegs trigger twice.").h.stats = [](World& w, int) {
    w.st.tumblerWatch += 0.08f;
    w.st.tumblerKind = true;
    w.st.chaosTwice = true;
  };
  RD(RL_VOIDPEARL, "Void Pearl", R_UNCOMMON, "o", 0x8040e0, "+1 Void peg each turn, and swallowed balls discharge +50% more.").h.stats =
      [](World& w, int) {
        w.st.specials[PK_VOID] += 1;
        w.st.voidMul += 0.5f;
      };
  RD(RL_CLOCKKEY, "Clockwork Key", R_COMMON, "-", 0xe0b070, "Ability cooldowns are 1 turn shorter (minimum 1).");
  RD(RL_MOUNTAIN, "Mountain Heart", R_UNCOMMON, "*", 0xa89880, "+20 max HP, but your balls bounce 5% less.").h.stats = [](World& w, int) {
    w.st.maxHp += 20;
    w.st.restBonus -= 0.05f;
  };
  RD(RL_MONOCLE, "Jeweler's Monocle", R_UNCOMMON, "0", 0xffffff, "Randarts you find have one extra property.");
  RD(RL_BEARING, "Ball Bearing", R_COMMON, "o", 0xd0d8e0, "Your balls bounce 5% livelier, and your aiming guide shows 1 more bounce.").h.stats =
      [](World& w, int) {
        w.st.restBonus += 0.05f;
        w.st.preview += 1;
      };
  {
    auto& r = RD(RL_THORNCROWN, "Crown of Thorns", R_RARE, "^", 0x90c060, "+3 base power, but you lose 1 HP at the start of each turn (never lethal).");
    r.h.stats = [](World& w, int) { w.st.basePower += 3; };
    r.h.turnStart = [](World& w, int) { selfDamage(w, 1, nullptr); };
  }
  RD(RL_JESTERBELL, "Jester's Bell", R_UNCOMMON, "&", 0xff80ff,
     "The Tumbler watches you (12% chance to meddle each turn), and Chaos pockets appear more often.").h.stats = [](World& w, int) {
    w.st.tumblerWatch += 0.12f;
  };
  RD(RL_ANCHOR, "Anchor", R_COMMON, "T", 0x8090a0, "Wind, conveyors and water no longer push or slow your balls. +1 armor.").h.stats =
      [](World& w, int) {
        w.st.windImmune = true;
        w.st.waterImmune = true;
        w.st.armor += 1;
      };
  RD(RL_KITE, "Kite", R_UNCOMMON, "^", 0xa0e0ff, "While a ball has 20+ power, it falls 15% slower.").h.stats = [](World& w, int) { w.st.kite = true; };
  RD(RL_SLIPPER, "Glass Slipper", R_UNCOMMON, "\"", 0xd0f0ff, "Strike pockets are 30% wider.").h.stats = [](World& w, int) {
    w.st.strikeWidth *= 1.3f;
  };
  RD(RL_MAIDEN, "Iron Maiden", R_UNCOMMON, "#", 0x9090a0, "Monsters that attack you take 3 damage and gain 2 Bleed.").h.stats = [](World& w, int) {
    w.st.thornsDmg += 3;
  };
  RD(RL_PACKTOTEM, "Pack Totem", R_UNCOMMON, "|", 0xc09060, "+15% damage for each ally on the board (up to 3 allies).").h.stats = [](World& w, int) {
    w.st.packDmg += 0.15f;
  };
  RD(RL_MERCHANT, "Merchant's Ledger", R_COMMON, "=", 0xffd040, "Shops always stock a randart, and prices are 10% lower.").h.stats =
      [](World& w, int) { w.st.shopMul *= 0.9f; };
  RD(RL_AGES, "Sands of Ages", R_RARE, "8", 0xe0c080, "Every 7th turn on a floor is a free turn.");
  RD(RL_CANDLE, "Everburning Candle", R_COMMON, "!", 0xffe0a0, "Darkness and fog don't hinder you, and a Fire peg appears each turn.").h.stats =
      [](World& w, int) {
        w.st.ignoreDark = true;
        w.st.specials[PK_FIRE] += 1;
      };
  RD(RL_WARDING, "Amulet of Warding", R_UNCOMMON, "\"", 0xe0e0ff,
     "Curses can't touch you: Curse pegs don't halve your power, and monster hexes, pocket curses, blinding and ball drains fail.").h.stats =
      [](World& w, int) { w.st.warded = true; };
  RD(RL_DEPTHMAP, "Depth Map", R_COMMON, "?", 0xa0c0ff, "The stairs offer one more choice, and you gain +10% XP.").h.stats = [](World& w, int) {
    w.st.xpMul *= 1.1f;
  };
  RD(RL_MEDAL, "Pachinko Medal", R_UNCOMMON, "o", 0xffc840, "Every 150 peg hits permanently grant +1 base power (up to +5).").h.pegHit =
      [](World& w, int, int, int) {
        Player& p = w.pl;
        if (p.medalPower >= 5) return;
        if (++p.pachinkoPegs >= 150) {
          p.pachinkoPegs = 0;
          p.medalPower++;
          p.bonusPower++;
          recalcStats(w);
          fxBanner(w, "Pachinko Medal: +1 base power!", 0xffc840);
        }
      };
  RD(RL_FEATHERCAP, "Feathered Cap", R_COMMON, "^", 0xf0f0ff, "Your ball floats briefly after each monster hit.");
  RD(RL_GRIMOIRE, "Forbidden Grimoire", R_RARE, "+", 0x8040a0, "Your spells deal +35% damage, but each spell costs 1 HP.").h.stats =
      [](World& w, int) { w.st.spellDmgMul *= 1.35f; };
}

// ================================================================ items
static ItemDef& ID_(int id, const char* name, bool potion, int timing, int target, int rarity, int price, uint32_t col,
                    const char* desc) {
  ItemDef& d = ITEM[id];
  d.id = (uint8_t)id;
  d.name = name;
  d.potion = potion;
  d.timing = (uint8_t)timing;
  d.target = (uint8_t)target;
  d.rarity = (uint8_t)rarity;
  d.price = price;
  d.color = col;
  d.desc = desc;
  d.use = nullptr;
  d.wand = false;
  d.charges = 0;
  return d;
}

static ItemDef& WAND(int id, const char* name, int target, int rarity, int price, uint32_t col, int charges, const char* desc) {
  ItemDef& d = ID_(id, name, false, T_AIM, target, rarity, price, col, desc);
  d.wand = true;
  d.charges = charges;
  return d;
}

void initItems2() {
  // ---------------- potions
  ID_(IT_CANCEL, "Potion of Cancellation", true, T_AIM, TG_NONE, R_UNCOMMON, 35, 0xe0e0ff,
      "Cure all your ailments, and strip every monster's Block, rage and bonus damage.").use = [](World& w, V2, int) {
    Player& p = w.pl;
    p.poison = p.weak = p.corrode = p.slowed = p.sapped = 0;
    p.cursedBall = false;
    for (auto& m : w.fl.mons)
      if (!m.dead) {
        m.shield = 0;
        m.enraged = false;
        m.atkBonus = std::min(m.atkBonus, 0);
      }
    fxRing(w, V2(800, 450), 420, 0xe0e0ff);
    fxSound(w, S_CAST, 0.9f, 1.3f);
    return true;
  };
  ID_(IT_LUCK, "Potion of Luck", true, T_AIM, TG_NONE, R_UNCOMMON, 35, 0x50ff70,
      "This shot, pocket effects are tripled, and 5 pins become Clover and Crit pegs.").use = [](World& w, V2, int) {
    if (w.fl.shot.jackpotMul >= 3) return false;
    w.fl.shot.jackpotMul = 3;
    convertPins(w, PK_CLOVER, 2);
    convertPins(w, PK_CRIT, 3);
    fxSound(w, S_COIN, 1.f, 1.5f);
    return true;
  };
  ID_(IT_FLIGHT, "Potion of Flight", true, T_AIM, TG_NONE, R_COMMON, 25, 0xc0e0ff, "This shot, gravity is halved and your ball starts with +4 power.").use =
      [](World& w, V2, int) {
        if (w.fl.shot.shotGrav < 1.f) return false;
        w.fl.shot.shotGrav = 0.5f;
        w.fl.shot.mightBonus += 4;
        fxSound(w, S_WHOOSH, 0.9f, 1.4f);
        return true;
      };
  ID_(IT_BRILLIANCE, "Potion of Brilliance", true, T_AIM, TG_NONE, R_UNCOMMON, 40, 0x80a0ff,
      "Restore all MP, and your spells cost no MP for the rest of this turn.").use = [](World& w, V2, int) {
    if (w.fl.freeCasts) return false;
    gainMp(w, w.st.maxMp);
    w.fl.freeCasts = true;
    fxSound(w, S_MANA, 1.f, 1.2f);
    return true;
  };
  ID_(IT_MUTATION, "Potion of Mutation", true, T_AIM, TG_NONE, R_RARE, 60, 0xe080ff,
      "Cures one bad mutation, then grants two random mutations (usually good).").use = [](World& w, V2, int) {
    for (int m = 0; m < MUT_COUNT; ++m)
      if (MUTS[m].tier == 9 && w.pl.mut[m] > 0) {
        w.pl.mut[m]--;
        logMsg(w, 0xe080ff, "Your %s fades.", MUTS[m].name);
        break;
      }
    for (int k = 0; k < 2; ++k) {
      int m = randomMutation(w, w.rng.chance(0.25f), false);
      if (m >= 0) gainMutation(w, m, false);
    }
    recalcStats(w);
    return true;
  };
  // ---------------- scrolls
  ID_(IT_UPHEAVAL, "Scroll of Upheaval", false, T_AIM, TG_NONE, R_COMMON, 25, 0xc8a070,
      "The board is torn apart and rebuilt, and every monster takes 6 (+1 per depth) damage.").use = [](World& w, V2, int) {
    regenLayout(w, false);
    for (int i = 0; i < (int)w.fl.mons.size(); ++i)
      if (isHostile(w, i)) damageMonster(w, i, 6 + w.depth, DS_SPELL);
    return true;
  };
  ID_(IT_TORMENT, "Scroll of Torment", false, T_AIM, TG_NONE, R_UNCOMMON, 40, 0x9a3cff,
      "Every monster loses 25% of its HP (12% for bosses), and you lose 10% of yours.").use = [](World& w, V2, int) {
    for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
      if (!isHostile(w, i)) continue;
      Monster& m = w.fl.mons[i];
      damageMonster(w, i, std::max(1, (int)(m.hp * (m.boss ? 0.12f : 0.25f))), DS_SPELL);
    }
    selfDamage(w, std::max(1, w.pl.hp / 10), nullptr);
    fxSound(w, S_CAST, 1.f, 0.4f);
    fxShake(w, 10);
    return true;
  };
  ID_(IT_BUTTERFLIES, "Scroll of Butterflies", false, T_AIM, TG_NONE, R_COMMON, 25, 0xffb0e0,
      "A cloud of butterflies: 6 drifting fireflies (+2 power per hit) appear for this floor, and you heal 5.").use = [](World& w, V2, int) {
    for (int k = 0; k < 6; ++k) {
      V2 c = randomFieldSpot(w, 26, 4, FIELD_Y0 + 40, FIELD_Y1 - 60);
      if (c.x < 0) continue;
      int pi = addPeg(w, PK_FIREFLY, c, 7);
      if (pi < 0) break;
      Peg& p = w.fl.pegs[pi];
      p.motion = 4;
      p.anchor = c;
      p.mA = w.fl.rng.rangef(18, 30);
      p.mSpeed = w.fl.rng.rangef(0.5f, 0.9f);
      p.mPhase = w.fl.rng.rangef(0, TAU);
      p.val = 1;
    }
    healPlayer(w, 5);
    fxSound(w, S_HEAL, 0.8f, 1.8f);
    return true;
  };
  ID_(IT_POISONSCROLL, "Scroll of Poison", false, T_AIM, TG_NONE, R_COMMON, 30, 0x90e040,
      "Every monster gains 8 (+1 per 2 depth) Poison, and two clouds of poison mist spread across the board.").use = [](World& w, V2, int) {
    for (int i = 0; i < (int)w.fl.mons.size(); ++i)
      if (isHostile(w, i)) applyPoison(w, i, 8 + w.depth / 2);
    for (int k = 0; k < 2; ++k) {
      int zi = addZone(w, ZK_MIST, V2(w.fl.rng.rangef(PX0 + 100, PX1 - 100), w.fl.rng.rangef(300, 700)), V2(60, 0), true);
      if (zi >= 0) w.fl.zones[zi].ttl = 4;
    }
    fxSound(w, S_POISON, 1.f, 0.7f);
    return true;
  };
  ID_(IT_WONDER, "Scroll of Wonder", false, T_AIM, TG_NONE, R_RARE, 70, 0xffe0ff,
      "Something wonderful happens: choose one of three randarts, choose a relic, or the Tumbler meddles twice (kindly).").use =
      [](World& w, V2, int) {
        int r = w.rng.range(0, 99);
        w.relicOffers.clear();
        if (r < 40) {
          for (int k = 0; k < 3; ++k) {
            Offer o;
            o.type = 2;
            o.id = (int)newRandartSeed(w);
            w.relicOffers.push_back(o);
          }
        } else if (r < 65) {
          pushRelicOffersN(w, 3, false, true);
        } else {
          tumblerInvoke(w, 2);
          tumblerInvoke(w, 2);
        }
        fxSound(w, S_CHEST, 1.f, 1.4f);
        return true;
      };
  // ---------------- wands
  WAND(IT_W_FLAME, "Wand of Flame", TG_MONSTER, R_COMMON, 40, 0xff7030, 4, "Zap a bolt of fire: 8 (+1 per depth) damage and 4 Burn.").use =
      [](World& w, V2, int mon) {
        if (mon < 0) return false;
        fxZap(w, launcherPos(), w.fl.mons[mon].p, 0xff7030);
        fxSound(w, S_FIRE, 0.8f, 1.2f);
        applyBurn(w, mon, 4);
        damageMonster(w, mon, 8 + w.depth, DS_SPELL);
        return true;
      };
  WAND(IT_W_ICE, "Wand of Frost", TG_MONSTER, R_UNCOMMON, 45, 0xa0e8ff, 3, "Freeze a monster solid (it skips its next action) and deal 5 damage.").use =
      [](World& w, V2, int mon) {
        if (mon < 0) return false;
        Monster& m = w.fl.mons[mon];
        fxZap(w, launcherPos(), m.p, 0xa0e8ff);
        m.freezeImmune = 0;
        freezeMonster(w, mon);
        damageMonster(w, mon, 5, DS_SPELL);
        return true;
      };
  WAND(IT_W_LIGHTNING, "Wand of Lightning", TG_MONSTER, R_UNCOMMON, 45, 0xfff080, 3, "6 (+1 per depth) damage, chaining to 2 more monsters.").use =
      [](World& w, V2, int mon) {
        if (mon < 0) return false;
        int d = 6 + w.depth;
        V2 at = w.fl.mons[mon].p;
        fxZap(w, launcherPos(), at, 0xfff080);
        damageMonster(w, mon, d, DS_ZAP);
        int last = mon;
        for (int k = 0; k < 2; ++k) {
          int o = nearestMonster(w, at, last);
          if (o < 0) break;
          fxZap(w, at, w.fl.mons[o].p, 0xfff080);
          at = w.fl.mons[o].p;
          damageMonster(w, o, d, DS_ZAP);
          last = o;
        }
        fxSound(w, S_ZAP, 1.f, 0.9f);
        return true;
      };
  WAND(IT_W_DIGGING, "Wand of Digging", TG_POINT, R_COMMON, 30, 0xc8a070, 4, "Blast away every pin within 70 px of a spot.").use =
      [](World& w, V2 pt, int) {
        int n = 0;
        for (auto& p : w.fl.pegs)
          if (!p.dead && (p.kind == PK_PIN || p.kind == PK_STONE || p.kind == PK_CURSE) && dist2(p.p, pt) < 70 * 70) {
            p.dead = true;
            fxBurst(w, p.p, 0xc8a070, 5, 90);
            n++;
          }
        fxRing(w, pt, 70, 0xc8a070);
        fxSound(w, S_BOOM, 0.6f, 1.3f, pt.x);
        return n > 0;
      };
  WAND(IT_W_POLYMORPH, "Wand of Polymorph", TG_MONSTER, R_RARE, 60, 0xff60ff, 2, "Polymorph a non-boss monster into a random monster of this floor.").use =
      [](World& w, V2, int mon) {
        if (mon < 0 || w.fl.mons[mon].boss) return false;
        fxZap(w, launcherPos(), w.fl.mons[mon].p, 0xff60ff);
        polymorphMonster(w, mon, randomRosterMonster(w, 0));
        return true;
      };
  WAND(IT_W_CHARMING, "Wand of Charming", TG_MONSTER, R_RARE, 65, 0xff90ff, 2,
       "Charm a non-boss monster below 60% HP: for 3 turns it fights for you.").use = [](World& w, V2, int mon) {
    if (mon < 0) return false;
    Monster& m = w.fl.mons[mon];
    if (m.boss || m.hp * 10 > m.maxHp * 6) return false;
    m.charmed = true;
    m.charmT = 3;
    if (w.fl.focus == mon) w.fl.focus = -1;
    fxZap(w, launcherPos(), m.p, 0xff90ff);
    fxText(w, m.p + V2(0, -m.r - 12), 0xff90ff, "charmed!", 16);
    fxSound(w, S_CAST, 0.9f, 1.8f, m.p.x);
    return true;
  };
  WAND(IT_W_ACID, "Wand of Acid", TG_MONSTER, R_COMMON, 35, 0xa0ff40, 3, "6 damage; the monster loses its Block and 2 armor.").use =
      [](World& w, V2, int mon) {
        if (mon < 0) return false;
        Monster& m = w.fl.mons[mon];
        m.shield = 0;
        m.armor = std::max(0, m.armor - 2);
        fxZap(w, launcherPos(), m.p, 0xa0ff40);
        fxSound(w, S_POISON, 0.8f, 1.2f);
        damageMonster(w, mon, 6, DS_SPELL);
        return true;
      };
  WAND(IT_W_BUMPERS, "Wand of Bumpers", TG_POINT, R_COMMON, 30, 0xff70b0, 3, "Three bumpers pop up around a spot for 3 turns.").use =
      [](World& w, V2 pt, int) {
        int made = 0;
        for (int t = 0; t < 60 && made < 3; ++t) {
          V2 p = pt + fromAng(w.fl.rng.rangef(0, TAU)) * w.fl.rng.rangef(20, 70);
          if (!spotFree(w, p, 14, 4)) continue;
          int pi = addPeg(w, PK_BUMPER, p, 14);
          if (pi < 0) break;
          w.fl.pegs[pi].ttl = 3;
          w.fl.pegs[pi].temp = true;
          made++;
        }
        fxSound(w, S_BUMP, 0.9f, 1.f, pt.x);
        return made > 0;
      };
  WAND(IT_W_PARALYSIS, "Wand of Paralysis", TG_MONSTER, R_UNCOMMON, 50, 0xd0d0a0, 2,
       "A non-boss monster skips its next 2 actions (a boss, its next 1).").use = [](World& w, V2, int mon) {
    if (mon < 0) return false;
    Monster& m = w.fl.mons[mon];
    m.frozen = std::max(m.frozen, m.boss ? 1 : 2);
    m.freezeImmune = 0;
    fxZap(w, launcherPos(), m.p, 0xd0d0a0);
    fxText(w, m.p + V2(0, -m.r - 12), 0xd0d0a0, "paralysed!", 15);
    fxSound(w, S_FREEZE, 0.8f, 0.6f);
    return true;
  };
  WAND(IT_W_ROOTS, "Wand of Roots", TG_POINT, R_COMMON, 30, 0x60b040, 3, "A thicket grows around a spot: 10 pins and 3 Brambles (+3 power each).").use =
      [](World& w, V2 pt, int) {
        growPins(w, 10, pt, 90, true);
        int made = 0;
        for (int t = 0; t < 60 && made < 3; ++t) {
          V2 p = pt + fromAng(w.fl.rng.rangef(0, TAU)) * w.fl.rng.rangef(10, 80);
          if (!spotFree(w, p, 7, 6)) continue;
          if (addPeg(w, PK_THORN, p, 7) >= 0) made++;
        }
        fxSound(w, S_HEAL, 0.8f, 0.7f, pt.x);
        return true;
      };
}

// ================================================================ monsters
static Intent I(int k, int v = 0, int d = 1, int a = 0) {
  Intent t;
  t.kind = (uint8_t)k;
  t.val = (int16_t)v;
  t.delay = (uint8_t)d;
  t.arg = (int16_t)a;
  return t;
}
static void MD(int id, const char* name, const char* glyph, uint32_t col, int hp, int armor, float r, int xp, int gold,
               uint32_t traits, int tval, int split, std::initializer_list<Intent> s1, std::initializer_list<Intent> s2,
               std::initializer_list<Intent> s3, const char* desc) {
  MonDef& m = MON[id];
  m.id = (uint16_t)id;
  m.name = name;
  m.glyph = glyph;
  m.color = col;
  m.hp = hp;
  m.armor = armor;
  m.r = r;
  m.xp = xp;
  m.gold = gold;
  m.traits = traits;
  m.tval = tval;
  m.splitInto = split;
  int i = 0;
  for (auto& t : s1) if (i < 5) m.s1[i++] = t;
  i = 0;
  for (auto& t : s2) if (i < 5) m.s2[i++] = t;
  i = 0;
  for (auto& t : s3) if (i < 5) m.s3[i++] = t;
  m.desc = desc;
}

void initMonsters2() {
  // ---------------- tag the originals
  for (int m : {M_ZOMBIE, M_SKELETON, M_WRAITH, M_GHOUL, M_BANSHEE, M_VAMPIRE, M_HOLLOWKING, M_LICH, M_FROSTWRAITH}) MON[m].traits |= TR_UNDEAD;
  for (int m : {M_DEVIL, M_IMP, M_HELLHOUND, M_PITBOSS, M_EFREET}) MON[m].traits |= TR_DEMONIC;
  for (int m : {M_OOZE, M_OOZELET}) MON[m].traits |= TR_SLIMY;
  // ---------------- halls
  MD(M_GNOLL, "gnoll", "g", 0xc0a060, 18, 0, 20, 5, 3, 0, 0, -1, {I(IN_ATTACK, 3, 2), I(IN_ATTACK, 3, 1)}, {}, {},
     "A hyena-headed brute that strikes in quick bursts.");
  MD(M_TRICKSTER, "goblin trickster", "g", 0xa0ff80, 14, 0, 19, 6, 6, TR_EVASIVE, 0, -1, {I(IN_SWAP, 0, 1), I(IN_DECOY, 1, 2), I(IN_ATTACK, 3, 1)}, {}, {},
     "Swaps places with its friends and conjures mirror images of itself.");
  MD(M_ACOLYTE, "cult acolyte", "p", 0xd080ff, 16, 0, 20, 6, 5, 0, 0, -1, {I(IN_BLIND, 1, 2), I(IN_CURSEBALL, 0, 2), I(IN_ATTACK, 3, 2)}, {}, {},
     "Blinds you (no aiming guide) and drains the power from your next ball.");
  MD(M_EGGSAC, "spider egg sac", "0", 0xe0d0a0, 20, 0, 18, 5, 3, TR_STATIONARY, 0, -1, {I(IN_EGGS, 2, 2, M_SPIDERLING), I(IN_BLOCK, 4, 1)}, {}, {},
     "Lays spider eggs around itself. Smash them with a ball before they hatch!");
  MD(M_SPIDERLING, "spiderling", "s", 0xb09080, 5, 0, 13, 1, 0, 0, 0, -1, {I(IN_ATTACK, 1, 1)}, {}, {}, "A tiny, hungry spider.");
  // ---------------- lair
  MD(M_KILLERBEE, "killer bee", "a", 0xffd040, 14, 0, 16, 6, 3, TR_FLYING | TR_SWARM, 0, -1, {I(IN_POISON, 2, 1), I(IN_ATTACK, 3, 2)}, {}, {},
     "Swarms, flits and stings.");
  MD(M_DRYAD, "dryad", "D", 0x70e070, 28, 0, 21, 9, 6, TR_REGEN, 3, -1, {I(IN_WEB, 2, 2), I(IN_HEAL, 6, 2), I(IN_ATTACK, 4, 2)}, {}, {},
     "Weaves sticky vines across the board and tends her allies.");
  MD(M_SPORELING, "sporeling", "f", 0xf0a0d0, 12, 0, 16, 5, 2, TR_VOLATILE, 8, -1, {I(IN_ATTACK, 3, 2)}, {}, {},
     "Bursts when slain, igniting nearby pins and hurting nearby monsters.");
  // ---------------- drowned
  MD(M_SEASERPENT, "sea serpent", "S", 0x40a0c0, 60, 1, 28, 14, 8, TR_SPLITHIT, 0, -1, {I(IN_BURROW, 6, 2), I(IN_HEAVY, 10, 2)}, {}, {},
     "Burrows to new spots. Hit it too hard and it splits in two!");
  MD(M_NAGA, "naga warrior", "N", 0x80c080, 40, 1, 24, 12, 8, 0, 0, -1, {I(IN_POISON, 3, 1), I(IN_SLOW, 2, 2), I(IN_ATTACK, 6, 2)}, {}, {},
     "Poisons you and slows your magic.");
  MD(M_ANGLER, "anglerfish", "A", 0x6080d0, 34, 0, 23, 11, 7, 0, 0, -1, {I(IN_GRAVITY, 0, 2), I(IN_ATTACK, 7, 2)}, {}, {},
     "Its glowing lure opens gravity wells that drag your ball off course.");
  // ---------------- mines
  MD(M_CANNON, "steam cannon", "=", 0xa0a0b0, 36, 3, 22, 12, 8, TR_STATIONARY, 0, -1, {I(IN_BEAM, 14, 2, 20), I(IN_BLOCK, 8, 1)}, {}, {},
     "Charges a devastating blast. Deal enough damage while it charges to interrupt it.");
  MD(M_DRONE, "clockwork drone", "d", 0xd0c080, 18, 1, 17, 8, 5, TR_FLYING, 0, -1, {I(IN_MUTATEPEGS, 2, 2), I(IN_ATTACK, 3, 1)}, {}, {},
     "Rewires your special pegs into curses.");
  MD(M_SENTRY, "gear sentry", "S", 0xc0b090, 44, 2, 24, 11, 6, 0, 0, -1, {I(IN_SHIELDALLY, 10, 1), I(IN_ATTACK, 5, 2)}, {}, {},
     "Shields its weakest ally.");
  // ---------------- crypt
  MD(M_MUMMY, "mummy", "M", 0xd8c8a0, 48, 1, 25, 13, 8, TR_UNDEAD, 0, -1, {I(IN_CURSEBALL, 0, 2), I(IN_SAP, 2, 2), I(IN_ATTACK, 7, 2)}, {}, {},
     "Its ancient curse drains your balls and saps your power.");
  MD(M_SHADOW, "shadow", "W", 0x606088, 30, 0, 22, 12, 6, TR_PHASING | TR_BLINKER | TR_UNDEAD, 9, -1, {I(IN_BLIND, 2, 2), I(IN_ATTACK, 6, 2)}, {}, {},
     "Only balls with 9+ power can touch it. Blinks away when hurt.");
  MD(M_BONEDRAGON, "bone dragon", "D", 0xe8e8d8, 230, 2, 36, 36, 38, TR_ELITE | TR_UNDEAD, 0, -1,
     {I(IN_BEAM, 18, 2, 40), I(IN_ATTACK, 8, 1), I(IN_SUMMON, M_SKELETON, 1, 1)}, {}, {},
     "Charges a blast of necrotic breath - hit it hard to interrupt it.");
  // ---------------- forge
  MD(M_FIREELEM, "fire elemental", "E", 0xff8040, 40, 0, 24, 12, 7, TR_VOLATILE, 10, -1, {I(IN_ENRAGE, 0, 1), I(IN_ATTACK, 7, 1)}, {}, {},
     "Builds to a fury, then bursts in flame when slain.");
  MD(M_HELLKNIGHT, "hell knight", "K", 0xd03030, 70, 3, 27, 16, 12, TR_DEMONIC, 0, -1, {I(IN_BLOCK, 12, 1), I(IN_ENRAGE, 0, 1), I(IN_HEAVY, 9, 2)}, {}, {},
     "Armored and furious.");
  MD(M_EMBERSWARM, "ember swarm", "*", 0xffa040, 16, 0, 16, 7, 3, TR_FLYING | TR_SWARM | TR_VOLATILE, 4, -1, {I(IN_ATTACK, 4, 1)}, {}, {},
     "A cloud of living embers.");
  // ---------------- frozen
  MD(M_POLARBEAR, "polar bear", "q", 0xf0f8ff, 64, 1, 28, 14, 7, 0, 0, -1, {I(IN_ENRAGE, 0, 1), I(IN_HEAVY, 9, 2)}, {}, {},
     "Works itself into a rage before mauling you.");
  MD(M_SNOWSPRITE, "snow sprite", "i", 0xe0f8ff, 20, 0, 17, 10, 6, TR_FLYING, 0, -1, {I(IN_FREEZEPOCKET, 0, 2), I(IN_SLOW, 2, 2), I(IN_ATTACK, 3, 1)}, {}, {},
     "Freezes your best pockets solid.");
  MD(M_ICEDRAGON, "ice dragon", "D", 0xa0e8ff, 250, 3, 36, 38, 40, TR_ELITE, 0, -1,
     {I(IN_BEAM, 18, 2, 45), I(IN_FREEZEPOCKET, 0, 1), I(IN_ATTACK, 9, 1)}, {}, {}, "Charges a freezing breath and ices over your pockets.");
  // ---------------- core
  MD(M_CROUPIER, "croupier", "$", 0xe0c070, 60, 0, 25, 20, 20, 0, 0, -1, {I(IN_FREEZEPOCKET, 0, 1), I(IN_STEAL, 15, 2), I(IN_ATTACK, 8, 2)}, {}, {},
     "Freezes your pockets and pockets your gold.");
  MD(M_JACKPOTGOLEM, "jackpot golem", "8", 0xffd700, 110, 3, 30, 24, 40, TR_SPLITHIT, 0, -1, {I(IN_BLOCK, 20, 1), I(IN_HEAVY, 16, 2)}, {}, {},
     "Made of solid gold. Splits in two when hit hard.");
  MD(M_CHAOSSPAWN, "chaos spawn", "?", 0xff60ff, 80, 0, 27, 22, 14, TR_BLINKER, 0, -1, {I(IN_RANDOM, 8, 1), I(IN_RANDOM, 8, 1), I(IN_MUTATEPEGS, 3, 1)}, {}, {},
     "Nobody knows what it will do next. Least of all itself.");
  // ---------------- slime pits
  MD(M_ACIDJELLY, "acid jelly", "J", 0xa0ff40, 26, 0, 23, 9, 5, TR_SLIMY | TR_ACIDIC, 3, -1, {I(IN_ACID, 4, 2), I(IN_ATTACK, 5, 2)}, {}, {},
     "Dissolves pins around it when struck, and spits corroding acid.");
  MD(M_SLIMECREATURE, "slime creature", "J", 0x60e080, 32, 0, 25, 11, 6, TR_SLIMY | TR_SPLITHIT, 0, -1, {I(IN_ATTACK, 5, 2), I(IN_GROW, 6, 2)}, {}, {},
     "Splits in two when hit hard, and grows when left alone.");
  MD(M_ACIDBLOB, "acid blob", "j", 0xc0ff60, 12, 0, 17, 5, 2, TR_SLIMY | TR_ACIDIC | TR_SWARM, 2, -1, {I(IN_ATTACK, 3, 2)}, {}, {},
     "Small, sticky and corrosive.");
  MD(M_DEATHOOZE, "death ooze", "J", 0x8a4a8a, 50, 1, 27, 14, 10, TR_SLIMY | TR_LIFESTEAL, 0, -1, {I(IN_HEAVY, 9, 2), I(IN_DEVOUR, 0, 1)}, {}, {},
     "Drinks your life and devours the magic of nearby pegs.");
  MD(M_AZUREJELLY, "azure jelly", "J", 0x60a0ff, 38, 0, 25, 12, 8, TR_SLIMY, 0, -1, {I(IN_FREEZEPOCKET, 0, 1), I(IN_SLOW, 2, 2), I(IN_ATTACK, 6, 2)}, {}, {},
     "Its chill freezes your pockets and slows your magic.");
  MD(M_SLIMEBAT, "slime bat", "b", 0x80e0a0, 16, 0, 16, 7, 4, TR_FLYING | TR_SLIMY, 0, -1, {I(IN_ATTACK, 2, 1)}, {}, {}, "A gooey bat that flits about.");
  MD(M_GREATSLIME, "great slime", "J", 0x40c060, 150, 1, 36, 30, 32, TR_ELITE | TR_SLIMY | TR_SPLITHIT, 0, -1,
     {I(IN_DEVOUR, 0, 1), I(IN_HEAVY, 12, 2), I(IN_SUMMON, M_ACIDBLOB, 2, 1)}, {}, {}, "A heaving mountain of slime that splits under heavy blows.");
  MD(M_ROYALJELLY, "The Royal Jelly", "J", 0xffe060, 340, 1, 56, 80, 100, TR_BOSS | TR_SLIMY | TR_STATIONARY, 0, -1,
     {I(IN_SUMMON, M_ACIDBLOB, 1, 2), I(IN_ACID, 4, 1), I(IN_HEAVY, 12, 2)},
     {I(IN_DEVOUR, 0, 1), I(IN_SUMMON, M_ACIDBLOB, 1, 2), I(IN_FREEZEPOCKET, 0, 1), I(IN_ATTACK, 9, 1)}, {},
     "Guardian of the Slime Pits. Spawns jellies, dissolves the board and devours its magic.");
  // ---------------- abyss
  MD(M_ABOMINATION, "small abomination", "X", 0xa06080, 48, 1, 25, 12, 7, TR_REGEN, 4, -1, {I(IN_ATTACK, 7, 2), I(IN_GROW, 4, 2)}, {}, {},
     "A mass of mismatched limbs that regenerates.");
  MD(M_WRETCHEDSTAR, "wretched star", "*", 0xffb0ff, 34, 0, 22, 14, 8, TR_AURA | TR_FLYING, 3, -1, {I(IN_MUTATEPEGS, 3, 1), I(IN_BLIND, 1, 2)}, {}, {},
     "Its twisted light heals the other monsters every turn and warps pegs into curses.");
  MD(M_STARCURSED, "starcursed mass", "X", 0x8060c0, 50, 0, 27, 15, 9, TR_SPLITHIT, 0, -1, {I(IN_CALL, 0, 2), I(IN_ATTACK, 6, 2)}, {}, {},
     "Chants to call more horrors, and splits under heavy blows.");
  MD(M_ABYSSEYE, "abyssal eye", "e", 0xc080ff, 30, 0, 22, 13, 8, TR_STATIONARY, 0, -1, {I(IN_BLIND, 2, 1), I(IN_DRAIN, 3, 2), I(IN_SAP, 2, 2)}, {}, {},
     "Stares into you. Blinds, drains and saps.");
  MD(M_HORROR, "unseen horror", "H", 0x7070a0, 50, 0, 26, 15, 9, TR_PHASING, 12, -1, {I(IN_ENRAGE, 0, 1), I(IN_HEAVY, 10, 2)}, {}, {},
     "Only balls with 12+ power can touch it.");
  MD(M_VOIDSPAWN, "void spawn", "v", 0x6030c0, 28, 0, 21, 12, 7, TR_BLINKER | TR_FLYING, 0, -1, {I(IN_GRAVITY, 0, 2), I(IN_ATTACK, 6, 1)}, {}, {},
     "Opens gravity wells and flits between them.");
  MD(M_TENTACLED, "tentacled monstrosity", "X", 0x604090, 230, 2, 38, 40, 44, TR_ELITE, 0, -1,
     {I(IN_SWAP, 0, 1), I(IN_GRAVITY, 0, 1), I(IN_HEAVY, 14, 2), I(IN_MULTI, 5, 1, 3)}, {}, {},
     "Warps gravity around your ball and lashes you with many tentacles.");
  MD(M_MAW, "The Maw Below", "O", 0x8040e0, 700, 2, 60, 110, 130, TR_BOSS | TR_STATIONARY, 0, -1,
     {I(IN_GRAVITY, 0, 1), I(IN_DEVOUR, 0, 1), I(IN_HEAVY, 16, 2), I(IN_CALL, 0, 1)},
     {I(IN_BEAM, 22, 2, 60), I(IN_MUTATEPEGS, 4, 1), I(IN_SUMMON, M_VOIDSPAWN, 2, 1), I(IN_HEAVY, 18, 2)}, {},
     "Guardian of the Abyss. A hungering mouth that swallows the board itself.");
  MD(M_DECOY, "mirror image", "?", 0xffffff, 1, 0, 18, 0, 0, TR_DECOY, 0, -1, {I(IN_ATTACK, 0, 9)}, {}, {},
     "An illusion. A single hit dispels it.");
}

// ================================================================ species / backgrounds / patrons
void initPeople2() {
  auto SP = [](int id, const char* name, uint32_t col, int hp, int mp, int pow, int arm, int hpl, int a0, int a1, int a2, bool exotic,
               const char* desc) {
    SpeciesDef& s = SPECIES[id];
    s.id = (uint8_t)id;
    s.name = name;
    s.color = col;
    s.hp = hp;
    s.mp = mp;
    s.power = pow;
    s.armor = arm;
    s.hpPerLvl = hpl;
    s.aff[0] = (uint8_t)a0;
    s.aff[1] = (uint8_t)a1;
    s.aff[2] = (uint8_t)a2;
    s.desc = desc;
    s.exotic = exotic;
  };
  SP(SP_RUBBER, "Rubber Ball", 0xff70b0, 40, 5, 1, 0, 4, SCH_FORCE, SCH_CLOCKWORK, SCH_FORTUNE, false,
     "Boing! Bounces 10% higher, and every wall bounce grants +1 power.");
  SP(SP_CRYSTAL, "Crystal Ball", 0xd8c8ff, 38, 7, 1, 0, 3, SCH_ARCANE, SCH_FROST, SCH_VOID, false,
     "Sees the future: its aiming guide shows 2 more bounces and it knows each monster's next two actions. Fragile.");
  SP(SP_MAGNET, "Magnet Ball", 0xd05050, 40, 5, 1, 0, 4, SCH_STORM, SCH_EARTH, SCH_CLOCKWORK, false,
     "Balls with 5+ power curve toward the nearest monster. A magnet peg appears on every floor, and magnets pull it harder.");
  SP(SP_SLIME, "Slime Ball", 0x70e080, 42, 4, 1, 0, 4, SCH_LIFE, SCH_SHADOW, SCH_CHAOS, false,
     "Squishy and resilient: immune to poison, and its ball buds off a slime (a phantom copy with half its power) on its "
     "first monster hit each shot.");
  SP(SP_FIEND, "Fiendball", 0xff4a3a, 38, 5, 1, 0, 4, SCH_FLAME, SCH_SHADOW, SCH_BLOOD, true,
     "Demonspawn. Grows a unique set of demonic facets as it levels - a body part, a hide, two powers and a capstone (or, "
     "rarely, a monstrous set of three body parts). No two Fiendballs are alike.");
  SP(SP_DRAKE, "Drakeball", 0xc8a060, 42, 4, 1, 0, 4, SCH_FLAME, SCH_FROST, SCH_STORM, true,
     "A draconian. At XL 5 its scales take one of eight random colors, granting a trait and a breath weapon that grows at XL "
     "11 and 17.");
  SP(SP_DJINN, "Djinn Ball", 0x60c0ff, 50, 0, 1, 0, 5, SCH_ARCANE, SCH_FLAME, SCH_CHAOS, true,
     "A being of living flame with no MP at all: its spells cost HP instead (1 HP per MP). Regenerates 2 HP each turn.");
  SP(SP_FELID, "Nine-Lives Ball", 0xffc080, 34, 6, 1, 0, 3, SCH_SHADOW, SCH_FORTUNE, SCH_ARCANE, true,
     "Has extra lives: comes back from death with half HP (one spare life, another at XL 7 and XL 14). Can't drink potions, "
     "but learns 15% faster.");
  SP(SP_CHANGELING, "Changeling", 0xb0ffd0, 38, 5, 1, 0, 4, SCH_CHAOS, SCH_ARCANE, SCH_LIFE, true,
     "Takes a new form on every floor, gaining the traits of a random other kind of ball.");
  SP(SP_CHAOS, "Chaos Orb", 0xff60ff, 36, 6, 1, 0, 4, SCH_CHAOS, SCH_FORTUNE, SCH_VOID, true,
     "Beloved of the Tumbler, which meddles on 15% of turns even if you worship another god. +1 choice at level-ups, and it "
     "mutates every 4 levels.");

  auto BG = [](int id, const char* name, int ab, int hp, int mp, int gold, int it0, int it1, int patron, bool exotic, const char* desc) {
    BackgroundDef& b = BGS[id];
    b.id = (uint8_t)id;
    b.name = name;
    b.ability = (uint16_t)ab;
    b.hp = hp;
    b.mp = mp;
    b.gold = gold;
    b.items[0] = it0;
    b.items[1] = it1;
    b.desc = desc;
    b.patron = patron;
    b.exotic = exotic;
  };
  BG(BG_CHAOSKNIGHT, "Chaos Knight", AB_CHAOSBOLT, 4, 1, 0, IT_LUCK, -1, PT_TUMBLER, false,
     "A champion of the Tumbler: starts worshipping it (first gift unlocked), with Chaos Bolt.");
  BG(BG_VOIDKNIGHT, "Void Knight", AB_RIFT, 4, 1, 0, IT_W_DIGGING, -1, PT_VOIDMAW, false,
     "A servant of Voidmaw, the Hungering Dark (first gift unlocked). Starts with Rift and a Wand of Digging.");
  BG(BG_BERSERKER, "Berserker", AB_BEASTFORM, 12, -1, 0, IT_BERSERK, -1, PT_VRASK, false,
     "Devoted to Vrask (first gift unlocked). +12 HP, Beast Form and a potion of berserk rage.");
  BG(BG_ARTIFICER, "Artificer", AB_TESLACOIL, 0, 1, 20, -3, -3, -1, false, "A tinkerer of wands. Starts with a Tesla Coil and three random wands.");
  BG(BG_SUMMONER, "Summoner", AB_SUMMONIMP, 0, 2, 0, IT_MANA, -1, -1, false, "Never fights alone. Starts with Summon Imp.");
  BG(BG_HEXSLINGER, "Hexslinger", AB_HEX, 0, 1, 10, IT_VULN, IT_W_ACID, -1, false, "Curses first, questions later. Starts with Hex and a Wand of Acid.");
  BG(BG_EARTHSHAPER, "Earth Shaper", AB_RAISEEARTH, 6, 0, 0, IT_UPHEAVAL, -1, -1, false, "Reshapes the board itself. Starts with Raise Earth.");
  BG(BG_HUNTER, "Hunter", AB_MARKSMAN, 4, 0, 10, IT_W_FLAME, -1, -1, false, "Makes the first shot count. Starts with Marksman and a Wand of Flame.");
  BG(BG_BLOODMAGE, "Blood Mage", AB_BLOODRITE, 10, 0, 0, IT_HEALING, -1, -1, false, "Pays for power in blood. +10 HP and Blood Rite.");
  BG(BG_SHAPESHIFTER, "Shapeshifter", AB_BEASTFORM, 6, 1, 0, IT_AMBROSIA, -1, -1, true,
     "Starts with Beast Form and one random (good) mutation. Every Shapeshifter is a little different.");
  BG(BG_CARDSHARP, "Card Sharp", AB_DICEBALL, 0, 1, 40, IT_LUCK, -1, PT_ARCANA, false,
     "A gambler blessed by Arcana, the Fatebinder (first gift: Draw a Card). Starts with Dice Ball and extra gold.");
  BG(BG_PILGRIM, "Pilgrim", AB_HEALWOUNDS, 4, 1, 0, IT_HEALING, -1, -2, true,
     "A wandering devotee of a random god (first gift unlocked). Starts with Heal Wounds.");
  BGS[BG_WANDERER].desc =
      "Nobody knows where they came from. Random abilities (one of them practised), random stats, random items and maybe a "
      "wand or a relic - no two Wanderers are alike.";
  BGS[BG_WANDERER].exotic = true;

  auto PT = [](int id, const char* name, const char* title, uint32_t col, const char* likes, const char* dislikes,
               const char* desc, int g0, int g1, int g2, int g3, int g4) {
    PatronDef& p = PATRON[id];
    p.id = (uint8_t)id;
    p.name = name;
    p.title = title;
    p.color = col;
    p.likes = likes;
    p.dislikes = dislikes;
    p.desc = desc;
    p.gifts[0] = (uint16_t)g0;
    p.gifts[1] = (uint16_t)g1;
    p.gifts[2] = (uint16_t)g2;
    p.gifts[3] = (uint16_t)g3;
    p.gifts[4] = (uint16_t)g4;
  };
  PT(PT_ARCANA, "Arcana", "the Fatebinder", 0xe0c0ff, "Slaying monsters, especially elites and bosses.", "Nothing.",
     "A goddess of fate who deals from the Deck of Fates. Her followers draw cards of wild power.", AB_P_DRAW, AB_P_STACKED,
     AB_P_TRIPLEDRAW, AB_P_FATEDRAW, AB_P_WHEEL);
  PT(PT_RUUN, "Ruun", "the Unburdened", 0xe0c090, "Your sacrifices. Piety also grows slowly with time.", "Nothing.",
     "A god of renunciation. Give up parts of yourself for raw power: choose sacrifices when you join and at rest sites.",
     AB_P_RUUNPOWER, AB_P_RECKONING, AB_P_POWERLEAP, AB_P_UNBURDENED, AB_P_RUUNEND);
  PT(PT_GLUB, "Glub", "the Oozing One", 0x60f0a0, "Hitting Jelly pegs, and slaying slimes.", "Casting Flame spells.",
     "A slime god who reshapes its followers and floods the board with jelly.", AB_P_JELLYPEGS, AB_P_OOZE, AB_P_MUTATE,
     AB_P_ACIDRAIN, AB_P_SLIMETIDE);
  PT(PT_TEMPESTRA, "Tempestra", "Eye of the Storm", 0xfff4a0, "Slaying monsters, and shots that hit lots of pegs.", "Nothing.",
     "A goddess of storms and upheaval who reshapes the board and strikes your foes with lightning.", AB_P_STORMAURA,
     AB_P_UPHEAVAL, AB_P_EYESTORM, AB_P_ELEMENTAL, AB_P_DISASTER);
  PT(PT_AURELIA, "Aurelia", "the Shining", 0xfff0a0, "Slaying monsters, especially undead and demons.", "Blood, Shadow and Chaos magic.",
     "A goddess of holy light who shields her followers and smites the unholy.", AB_P_DIVSHIELD, AB_P_HALO, AB_P_CLEANSE,
     AB_P_BLESSEDBALL, AB_P_ANGEL);
  PT(PT_ANCESTOR, "The Ancestor", "Voice of the Past", 0xa0d0ff, "Your ancestor's deeds (the damage its ball deals).", "Nothing.",
     "The spirit of a legendary pachinko master who plays beside you with a ball of its own.", AB_P_ANCESTOR, AB_P_ANCBLESS,
     AB_P_IDEALIZE, AB_P_ANCBOND, AB_P_ANCWRATH);
  PT(PT_VOIDMAW, "Voidmaw", "the Hungering Dark", 0x9060f0, "Slaying monsters, and feeding balls to the void.", "Nothing.",
     "A god of the Abyss who bends space and devours all.", AB_P_BENDSPACE, AB_P_BANISH, AB_P_CORRUPT, AB_P_ENTERVOID, AB_P_HUNGER);
  PT(PT_BRAKKA, "Brakka", "the Duelist", 0xd0a060, "Slaying elites and bosses.", "Summoning allies.",
     "A god of heroes who favors skill over tricks, and rewards those who fight the strongest.", AB_P_HEROISM, AB_P_FINESSE,
     AB_P_DUEL, AB_P_SPOILS, AB_P_UNSTOPPABLE);
  PT(PT_SIFRA, "Sifra", "the Sage", 0xa0c0ff, "Spending MP on spells.", "Nothing.", "A goddess of wisdom and spellcraft.",
     AB_P_CHANNEL, AB_P_DIVKNOW, AB_P_SCHOLAR, AB_P_SPELLECHO, AB_P_FLOOD);
}

// ================================================================ branches / modifiers
static void appendRoster(int biome, std::initializer_list<int> ids) {
  BiomeDef& b = BIOME[biome];
  int n = 0;
  while (n < 16 && b.roster[n] != M_COUNT) n++;
  for (int id : ids)
    if (n < 16) b.roster[n++] = (uint16_t)id;
}

void initWorld2() {
  auto BI = [](int id, const char* name, const char* sn, uint32_t top, uint32_t bot, uint32_t pin, uint32_t acc, uint32_t wall,
               int mood, std::initializer_list<int> roster, std::initializer_list<int> elites, std::initializer_list<int> bosses,
               float bumpers, float spinners, float water, float wind, float wells, float lava, float ramps, float movers,
               const char* flavor) {
    BiomeDef& b = BIOME[id];
    b.id = (uint8_t)id;
    b.name = name;
    b.shortName = sn;
    b.bgTop = top;
    b.bgBot = bot;
    b.pin = pin;
    b.accent = acc;
    b.wall = wall;
    b.mood = mood;
    for (int i = 0; i < 16; ++i) b.roster[i] = M_COUNT;
    int i = 0;
    for (int m : roster) if (i < 16) b.roster[i++] = (uint16_t)m;
    for (int k = 0; k < 3; ++k) b.elites[k] = M_COUNT;
    i = 0;
    for (int m : elites) if (i < 3) b.elites[i++] = (uint16_t)m;
    b.bosses[0] = b.bosses[1] = M_COUNT;
    i = 0;
    for (int m : bosses) if (i < 2) b.bosses[i++] = (uint16_t)m;
    b.bumpers = bumpers;
    b.spinners = spinners;
    b.water = water;
    b.wind = wind;
    b.wells = wells;
    b.lava = lava;
    b.ramps = ramps;
    b.movers = movers;
    b.flavor = flavor;
  };
  BI(BI_SLIME, "The Slime Pits", "Slime", 0x16281a, 0x060c06, 0xc0e8a0, 0x9cff60, 0x3e5a2a, 10,
     {M_ACIDBLOB, M_SLIMEBAT, M_OOZE, M_ACIDJELLY, M_SLIMECREATURE, M_AZUREJELLY, M_DEATHOOZE, M_SPORELING},
     {M_GREATSLIME, M_DEATHOOZE, M_SLIMECREATURE}, {M_ROYALJELLY}, 0.8f, 0.2f, 0.3f, 0, 0.4f, 0, 0.4f, 0.3f,
     "Acid pools and quivering walls of jelly. The pegs here are sticky.");
  BI(BI_ABYSS, "The Abyss", "Abyss", 0x1a1028, 0x050308, 0xd0c0e8, 0xc080ff, 0x40305a, 11,
     {M_VOIDSPAWN, M_ABOMINATION, M_WRETCHEDSTAR, M_ABYSSEYE, M_STARCURSED, M_HORROR, M_CHAOSSPAWN, M_SHADOW},
     {M_TENTACLED, M_HORROR, M_STARCURSED}, {M_MAW}, 0.5f, 0.5f, 0, 0.3f, 1.0f, 0, 0.5f, 0.8f,
     "An ever-shifting nightmare where space itself is broken.");
  appendRoster(BI_HALLS, {M_GNOLL, M_TRICKSTER, M_ACOLYTE, M_EGGSAC});
  appendRoster(BI_LAIR, {M_KILLERBEE, M_DRYAD, M_SPORELING, M_EGGSAC});
  appendRoster(BI_DROWNED, {M_NAGA, M_ANGLER, M_SEASERPENT});
  appendRoster(BI_MINES, {M_DRONE, M_SENTRY, M_CANNON});
  appendRoster(BI_CRYPT, {M_MUMMY, M_SHADOW});
  appendRoster(BI_FORGE, {M_EMBERSWARM, M_FIREELEM, M_HELLKNIGHT});
  appendRoster(BI_FROZEN, {M_SNOWSPRITE, M_POLARBEAR});
  appendRoster(BI_CORE, {M_CROUPIER, M_CHAOSSPAWN, M_JACKPOTGOLEM});
  BIOME[BI_CRYPT].elites[2] = M_BONEDRAGON;
  BIOME[BI_FROZEN].elites[2] = M_ICEDRAGON;

  auto MO = [](int id, const char* name, uint32_t col, const char* desc) {
    MODS[id].id = (uint8_t)id;
    MODS[id].name = name;
    MODS[id].color = col;
    MODS[id].desc = desc;
  };
  MO(MOD_TULIPS, "Tulip Garden", 0xff80c0, "Rows of tulips bloom here. Catch your ball in one for power and gold.");
  MO(MOD_CASINO, "Casino Night", 0xffd700, "Slot machines line the board, a free spin is queued every turn, and a Lottery pocket appears.");
  MO(MOD_CONVEYORS, "Conveyor Belts", 0xc0a060, "Moving belts carry your ball sideways.");
  MO(MOD_ANTIGRAV, "Anti-gravity", 0xa0c0ff, "Bubbles of reversed gravity float balls upward.");
  MO(MOD_STORMFRONT, "Stormfront", 0xfff4a0, "Each turn lightning strikes two monsters, and extra Spark pegs appear.");
  MO(MOD_TREMORS, "Tremors", 0xc8a070, "Each turn the pins shift and stone blocks fall.");
  MO(MOD_PLAYGROUND, "Tumbler's Playground", 0xff80ff, "The Tumbler meddles every single turn, and Chaos pegs abound.");
  MO(MOD_BLOODMOON, "Blood Moon", 0xe03848, "Monsters deal +1 damage, but your hits make them bleed and kills heal you 2 HP.");
  MO(MOD_GOLDRUSH, "Gold Rush", 0xffd040, "Coin stacks and Gold pegs everywhere, and monsters drop double gold.");
  MO(MOD_MIRRORS, "Hall of Mirrors", 0xe0f0ff, "Mirror fields and Mirror pegs bounce your ball around.");
  MO(MOD_SPRINGS, "Hot Springs", 0x70ffd0, "Springs launch your ball upward, and a healing spring bubbles.");
  MO(MOD_WARPED, "Warped Space", 0xb060ff, "Rifts tear through the board, and Warp pegs appear.");
  MO(MOD_GEYSERS, "Geysers", 0xa0e0ff, "Geysers erupt every few seconds, blasting balls upward.");
  MO(MOD_MINEFIELD, "Minefield", 0xff8020, "Bombs are everywhere. Watch the chain reactions.");
  MO(MOD_BOUNTY, "Bounty", 0xffd040, "One monster carries a bounty: slay it for gold and a prize.");
}
