// Dropcrawl - run progression: acts, stairs, shops, rest, altars, rewards, scoring
#include "rules.h"

// Act layout: act 0 = Upper Halls (7 rooms), act 1 = first branch (6), act 2 = second branch (6), act 3 = Core (4)
int actLength(int act) {
  switch (act) {
    case 0: return 7;
    case 1: return 6;
    case 2: return 6;
    default: return 4;
  }
}

static int actBiome(const World& w, int act) {
  switch (act) {
    case 0: return BI_HALLS;
    case 1: return w.branchA;
    case 2: return w.branchB;
    default: return BI_CORE;
  }
}

const char* locationName(const World& w) {
  static char buf[64];
  const BiomeDef& b = BIOME[actBiome(w, w.act)];
  snprintf(buf, sizeof(buf), "%s:%d", b.shortName, w.step + 1);
  return buf;
}

const char* descentText(int dl) {
  static const char* T[MAX_DESCENT + 1] = {
      "The standard descent.",
      "Monsters have 8% more HP and hit 6% harder (per level).",
      "...and you recover less HP between floors.",
      "...and elite lairs appear more often.",
      "...and shops charge 15% more.",
      "...and floors carry more hazards.",
      "...and rest sites heal less.",
      "...and monsters start each floor with a little Block.",
      "...and you start with 5 less max HP.",
      "...and Guardians act one turn sooner.",
      "The deepest descent. Good luck."};
  return T[clampv(dl, 0, MAX_DESCENT)];
}

static int randomWandId(Rng& r) {
  static const int W[] = {IT_W_FLAME, IT_W_ICE, IT_W_LIGHTNING, IT_W_DIGGING, IT_W_POLYMORPH, IT_W_CHARMING, IT_W_ACID,
                          IT_W_BUMPERS, IT_W_PARALYSIS, IT_W_ROOTS};
  return W[r.range(0, 9)];
}

static void joinPatron(World& w, int p, int piety) {
  w.pl.patron = p;
  w.pl.piety = piety;
  w.pl.pietyMax = piety;
  recalcStats(w);
}

// Wanderer, DCSS style: a practised "good" ability from the species' favored schools, one or two "decent" ones,
// twelve random stat points, and a random mix of consumables and gear. Every Wanderer plays differently.
static void setupWanderer(World& w) {
  Rng& R = w.rng;
  const SpeciesDef& sp = SPECIES[w.pl.species];
  w.pl.abil.clear();
  auto pickAbility = [&](bool affinity, bool active) {
    std::vector<int> pool;
    for (int i = 0; i < AB_FIRST_INNATE; ++i) {
      const AbilityDef& d = ABIL[i];
      if (d.rarity == R_RARE || abLevel(w, i)) continue;
      if (active && d.timing == T_PASSIVE) continue;
      if (affinity) {
        bool ok = false;
        for (int k = 0; k < 3; ++k)
          if (sp.aff[k] == d.school) ok = true;
        if (!ok) continue;
      }
      pool.push_back(i);
    }
    if (pool.empty()) return -1;
    return pool[R.range(0, (int)pool.size() - 1)];
  };
  int good = pickAbility(R.chance(0.6f), R.chance(0.5f));
  if (good < 0) good = pickAbility(false, false);
  if (good >= 0) {
    OwnedAb o;
    o.id = (uint16_t)good;
    o.lvl = (uint8_t)std::min(2, (int)ABIL[good].maxLvl);
    w.pl.abil.push_back(o);
  }
  int decent = R.range(1, 2);
  for (int k = 0; k < decent; ++k) {
    int a = pickAbility(false, false);
    if (a < 0) break;
    OwnedAb o;
    o.id = (uint16_t)a;
    o.lvl = 1;
    w.pl.abil.push_back(o);
  }
  // twelve random stat points
  for (int k = 0; k < 12; ++k) {
    int r = R.range(0, 99);
    if (r < 45) w.pl.bonusMaxHp += 3;
    else if (r < 75) w.pl.bonusMp += 1;
    else if (r < 90) w.pl.bonusPower += (R.chance(0.5f) ? 1 : 0);
    else w.pl.gold += 10;
  }
  w.pl.gold += R.range(0, 60);
  recalcStats(w);
  // consumables: one good, one or two random; maybe a wand or a relic
  static const int GOOD[] = {IT_HEALING, IT_HEALING, IT_MANA, IT_MIGHT, IT_AMBROSIA, IT_LUCK, IT_ENCHANT};
  gainItem(w, GOOD[R.range(0, 6)]);
  int extra = R.range(1, 2);
  for (int k = 0; k < extra; ++k) {
    int it = R.range(0, IT_W_FLAME - 1);
    if (ITEM[it].rarity == R_RARE && R.chance(0.7f)) it = IT_HEALING;
    gainItem(w, it);
  }
  int gear = R.range(0, 2);
  if (gear == 0) gainItem(w, randomWandId(R));
  else if (gear == 1) {
    std::vector<int> pool;
    for (int i = 0; i < RL_COUNT; ++i)
      if (RELIC[i].rarity == R_COMMON) pool.push_back(i);
    gainRelic(w, pool[R.range(0, (int)pool.size() - 1)]);
  }
}

void newRun(World& w, uint64_t seed, int species, int bg, int descent) {
  w = World();
  w.seed = seed;
  w.descent = clampv(descent, 0, MAX_DESCENT);
  w.rng.reseed(seed);
  w.pl = Player();
  w.pl.species = (uint8_t)species;
  w.pl.bg = (uint8_t)bg;
  w.pl.xl = 1;
  rollStartingStats(w);
  const BackgroundDef& B = BGS[bg];
  if (bg == BG_WANDERER) {
    setupWanderer(w);
  } else {
    int ab = B.ability;
    if (ab == AB_COUNT) {
      std::vector<int> pool;
      for (int i = 0; i < AB_FIRST_INNATE; ++i)
        if (ABIL[i].rarity == R_COMMON) pool.push_back(i);
      ab = pool[w.rng.range(0, (int)pool.size() - 1)];
    }
    OwnedAb o;
    o.id = (uint16_t)ab;
    o.lvl = 1;
    w.pl.abil.push_back(o);
  }
  w.pl.gold += B.gold + (species == SP_GILDED ? 60 : 0);
  if (w.descent >= 8) w.pl.bonusMaxHp -= 5;
  switch (species) {
    case SP_FIEND: rollDemonspawn(w); break;
    case SP_FELID: w.pl.lives = 1; break;
    default: break;
  }
  if (bg == BG_SHAPESHIFTER) {
    int m = randomMutation(w, false, true);
    if (m >= 0) gainMutation(w, m, true);
  }
  recalcStats(w);
  w.pl.hp = w.st.maxHp;
  w.pl.mp = w.st.maxMp;
  if (bg != BG_WANDERER) {
    for (int k = 0; k < 2; ++k) {
      int it = B.items[k];
      if (it == -2) {
        static const int R[] = {IT_HEALING, IT_MANA, IT_MIGHT, IT_RESIST, IT_FEAR, IT_IMMOLATION, IT_ENCHANT, IT_TELEPORT};
        it = R[w.rng.range(0, 7)];
      }
      if (it == -3) it = randomWandId(w.rng);
      if (it >= 0) gainItem(w, it);
    }
    if (bg == BG_ARTIFICER) gainItem(w, randomWandId(w.rng));
  }
  if (B.patron != -1) {
    int p = B.patron;
    if (p == -2) p = w.rng.range(0, PT_COUNT - 1);
    joinPatron(w, p, PIETY_STAR[0]);
    if (p == PT_ANCESTOR) w.pl.piety = std::max(w.pl.piety, PIETY_STAR[0]);
  }
  w.pl.hp = w.st.maxHp;
  w.pl.mp = w.st.maxMp;
  w.act = 0;
  w.step = 0;
  w.depth = 0;
  w.branchA = BI_LAIR;
  w.branchB = BI_CRYPT;
  FloorSpec spec = makeFloorSpec(w, FK_NORMAL, BI_HALLS, 0, 0, 1);
  w.depth = 1;
  w.screen = RS_FLOOR;
  logMsg(w, 0xffffff, "Welcome, %s %s. Descend, find the Orb of Chance, and beat the House!", SPECIES[species].name, BGS[bg].name);
  if (w.pl.patron >= 0) logMsg(w, PATRON[w.pl.patron].color, "You begin as a follower of %s %s.", PATRON[w.pl.patron].name, PATRON[w.pl.patron].title);
  if (species == SP_FIEND && w.pl.dsMonstrous) logMsg(w, 0xff6040, "Your demonic heritage is monstrous.");
  floorBegin(w, spec);
}

static int pickEvent(World& w) { return w.rng.range(0, NUM_EVENTS - 1); }

void genStairs(World& w) {
  w.stairs.clear();
  int len = actLength(w.act);
  // finished the act's boss?
  if (w.step >= len - 1) {
    if (w.act == 0 || w.act == 1) {
      std::vector<int> opts = w.act == 0 ? std::vector<int>{BI_LAIR, BI_DROWNED, BI_MINES, BI_SLIME}
                                         : std::vector<int>{BI_CRYPT, BI_FORGE, BI_FROZEN, BI_ABYSS};
      w.rng.shuffle(opts);
      int n = hasRelic(w, RL_DEPTHMAP) ? 4 : 3;
      for (int i = 0; i < n; ++i) {
        StairOpt o;
        o.kind = ST_BRANCH;
        o.biome = (uint8_t)opts[i];
        o.branch = opts[i];
        o.spec = makeFloorSpec(w, FK_NORMAL, opts[i], w.act + 1, 0, 10 * (w.act + 1) + i);
        w.stairs.push_back(o);
      }
    } else {
      StairOpt o;
      o.kind = ST_BRANCH;
      o.biome = BI_CORE;
      o.branch = BI_CORE;
      o.spec = makeFloorSpec(w, FK_NORMAL, BI_CORE, 3, 0, 30);
      w.stairs.push_back(o);
    }
    return;
  }
  int next = w.step + 1;
  int biome = actBiome(w, w.act);
  if (next == len - 1) {
    StairOpt o;
    o.kind = ST_BOSS;
    o.biome = (uint8_t)biome;
    o.spec = makeFloorSpec(w, FK_BOSS, biome, w.act, next, 40);
    w.stairs.push_back(o);
    return;
  }
  int count = hasRelic(w, RL_COMPASS) ? 3 : (w.rng.chance(0.7f) ? 3 : 2);
  if (hasRelic(w, RL_DEPTHMAP)) count++;
  std::vector<int> kinds;
  if (next == len - 2) {
    kinds.push_back(ST_REST);
    kinds.push_back(w.rng.chance(0.5f) ? ST_FLOOR : ST_ELITE);
    if (count >= 3) kinds.push_back(w.rng.chance(0.5f) ? ST_SHOP : ST_FLOOR);
    if (count >= 4) kinds.push_back(ST_EVENT);
  } else {
    std::vector<int> pool = {ST_FLOOR, ST_ELITE, ST_SHOP, ST_REST, ST_TREASURE, ST_EVENT, ST_ALTAR};
    std::vector<float> wt = {5.f, (w.act == 0 && next <= 1) ? 0.f : (w.descent >= 3 ? 3.2f : 2.2f), 1.6f, 1.0f, 0.9f, 1.8f,
                             (w.pl.patron < 0 && w.act <= 2) ? (w.act == 0 && next >= 2 ? 3.0f : 1.4f) : 0.f};
    if (w.lastNonCombat == ST_SHOP) wt[2] *= 0.3f;
    kinds.push_back(ST_FLOOR);
    for (int k = 1; k < count; ++k) {
      int i = w.rng.weighted(wt);
      if (i < 0) break;
      kinds.push_back(pool[i]);
      if (pool[i] != ST_FLOOR) wt[i] = 0;
      else wt[i] *= 0.5f;
    }
  }
  w.rng.shuffle(kinds);
  int salt = 50;
  for (int k : kinds) {
    StairOpt o;
    o.kind = (uint8_t)k;
    o.biome = (uint8_t)biome;
    int fk = k == ST_ELITE ? FK_ELITE : (k == ST_TREASURE ? FK_VAULT : FK_NORMAL);
    if (k == ST_FLOOR || k == ST_ELITE || k == ST_TREASURE) o.spec = makeFloorSpec(w, fk, biome, w.act, next, salt++);
    w.stairs.push_back(o);
  }
}

static int randartPrice(const World& w, float mul) { return (int)((150 + 6 * w.depth) * mul); }

static void genShop(World& w) {
  w.shop.clear();
  float mul = (1.f + 0.15f * w.act) * w.st.shopMul * (w.descent >= 4 ? 1.15f : 1.f);
  std::vector<int> abPool;
  for (int i = 0; i < AB_FIRST_INNATE; ++i) {
    int lvl = abLevel(w, i);
    if (lvl >= ABIL[i].maxLvl) continue;
    abPool.push_back(i);
  }
  w.rng.shuffle(abPool);
  for (int i = 0; i < 3 && i < (int)abPool.size(); ++i) {
    ShopEntry e;
    e.type = 0;
    e.id = abPool[i];
    int base = ABIL[e.id].rarity == R_COMMON ? 70 : ABIL[e.id].rarity == R_UNCOMMON ? 100 : 140;
    e.price = (int)(base * mul);
    w.shop.push_back(e);
  }
  for (int i = 0; i < 2; ++i) {
    int rl = -1;
    if (i == 1 && w.rng.chance(0.12f + w.st.magicFind * 0.2f)) rl = randomUniqueRelic(w);
    if (rl < 0) rl = randomRelicFor(w, false, false);
    if (rl < 0) break;
    bool dup = false;
    for (auto& o : w.shop)
      if (o.type == 1 && o.id == rl) dup = true;
    if (dup) continue;
    ShopEntry e;
    e.type = 1;
    e.id = rl;
    e.seed = RELIC[rl].tier == 0 ? rollRelicQuality(w, false) : 0u;
    int base = RELIC[rl].tier == 1 ? 280 : RELIC[rl].tier == 2 ? 150
             : RELIC[rl].rarity == R_COMMON ? 90 : RELIC[rl].rarity == R_UNCOMMON ? 130 : 180;
    if (e.seed) base = base * 3 / 2;
    e.price = (int)(base * mul);
    w.shop.push_back(e);
  }
  if (hasRelic(w, RL_MERCHANT) || w.rng.chance(0.6f)) {
    ShopEntry e;
    e.type = 6;
    e.id = (int)newRandartSeed(w);
    e.price = randartPrice(w, mul);
    w.shop.push_back(e);
  }
  for (int i = 0; i < 3; ++i) {
    ShopEntry e;
    e.type = 2;
    int roll = w.rng.range(0, 99);
    if (roll < 26) e.id = IT_HEALING;
    else if (roll < 42) e.id = randomWandId(w.rng);
    else {
      e.id = w.rng.range(0, IT_COUNT - 1);
      if (ITEM[e.id].rarity == R_RARE && w.rng.chance(0.6f)) e.id = IT_MANA;
    }
    e.price = (int)(ITEM[e.id].price * mul);
    w.shop.push_back(e);
  }
  ShopEntry heal;
  heal.type = 3;
  heal.price = (int)(35 * mul);
  w.shop.push_back(heal);
  ShopEntry train;
  train.type = 4;
  train.price = (int)(90 * mul);
  w.shop.push_back(train);
}

void enterStairs(World& w, int idx) {
  if (idx < 0 || idx >= (int)w.stairs.size()) return;
  StairOpt o = w.stairs[idx];
  w.stairs.clear();
  w.relicOffers.clear();
  if (o.kind == ST_BRANCH) {
    w.act++;
    w.step = 0;
    if (w.act == 1) w.branchA = o.biome;
    if (w.act == 2) w.branchB = o.biome;
  } else {
    w.step++;
  }
  w.depth++;
  w.rs.floors++;
  w.lastNonCombat = -1;
  switch (o.kind) {
    case ST_FLOOR:
    case ST_ELITE:
    case ST_BOSS:
    case ST_TREASURE:
    case ST_BRANCH:
      o.spec.depth = w.depth;
      w.screen = RS_FLOOR;
      floorBegin(w, o.spec);
      break;
    case ST_SHOP:
      genShop(w);
      w.screen = RS_SHOP;
      w.lastNonCombat = ST_SHOP;
      logMsg(w, 0xffd040, "You find a shop.");
      break;
    case ST_REST:
      w.restUsed = false;
      w.screen = RS_REST;
      w.lastNonCombat = ST_REST;
      break;
    case ST_ALTAR: {
      std::vector<int> p;
      for (int i = 0; i < PT_COUNT; ++i) p.push_back(i);
      w.rng.shuffle(p);
      w.altarChoices.assign(p.begin(), p.begin() + 3);
      w.screen = RS_ALTAR;
      w.lastNonCombat = ST_ALTAR;
      break;
    }
    case ST_EVENT:
      w.eventId = pickEvent(w);
      w.eventStage = 0;
      w.eventResult.clear();
      w.screen = RS_EVENT;
      w.lastNonCombat = ST_EVENT;
      break;
  }
  w.autosaveWanted = true;
}

static void pushRelicChoices(World& w, bool boss, int n) { pushRelicOffersN(w, n, boss, true); }

void floorCleared(World& w) {
  Floor& f = w.fl;
  FOR_EFF0(floorEnd);
  sweepLoot(w);
  w.relicOffers.clear();
  bool boss = f.spec.kind == FK_BOSS, elite = f.spec.kind == FK_ELITE;
  if (boss && w.act == 3) {
    w.won = true;
    w.screen = RS_VICTORY;
    logMsg(w, 0xffd700, "You have beaten the House! The Orb of Chance is yours!");
    fxSound(w, S_WIN, 1.f);
    w.autosaveWanted = true;
    return;
  }
  int heal = boss ? w.st.maxHp * 30 / 100 : w.st.maxHp / 10;
  if (w.descent >= 2) heal = heal * 6 / 10;
  if (!f.isVault && heal > 0 && w.pl.hp < w.st.maxHp) {
    healPlayer(w, heal);
    logMsg(w, 0x80ff90, "You catch your breath.");
  }
  if (boss && (w.act == 1 || w.act == 2)) {
    w.runes++;
    recalcStats(w);
    logMsg(w, 0xffd040, "You found a Rune of the %s! (%d/2)", BIOME[f.spec.biome].shortName, w.runes);
  }
  if (boss || elite) {
    bool randart = w.rng.chance(boss ? 0.5f : 0.35f);
    pushRelicChoices(w, boss, randart ? 2 : 3);
    if (randart) {
      Offer o;
      o.type = 2;
      o.id = (int)newRandartSeed(w);
      w.relicOffers.insert(w.relicOffers.begin() + w.rng.range(0, (int)w.relicOffers.size()), o);
    }
    if (abLevel(w, AB_P_SPOILS)) {
      Offer o;
      o.type = 2;
      o.id = (int)newRandartSeed(w);
      w.relicOffers.push_back(o);
    }
  } else if (!f.isVault && w.rng.chance(0.28f)) {
    static const int L[] = {IT_HEALING, IT_HEALING, IT_MANA, IT_MIGHT, IT_RESIST, IT_FEAR, IT_IMMOLATION, IT_ENCHANT, IT_TELEPORT,
                            IT_VULN, IT_BRAND, IT_REVEAL, IT_LUCK, IT_FLIGHT, IT_UPHEAVAL, IT_BUTTERFLIES};
    int it = w.rng.chance(0.2f) ? randomWandId(w.rng) : L[w.rng.range(0, 15)];
    if (gainItem(w, it)) {
      w.rewardItems.push_back(it);
      logMsg(w, ITEM[it].color, "You find a %s.", ITEM[it].name);
    }
  }
  w.rewardGold = std::max(0, w.pl.gold - w.rewardGold);
  w.screen = RS_REWARD;
  w.autosaveWanted = true;
}

void finishReward(World& w) {
  w.relicOffers.clear();
  genStairs(w);
  w.screen = RS_STAIRS;
  w.autosaveWanted = true;
}

void leaveRoom(World& w) {
  w.relicOffers.clear();
  genStairs(w);
  w.screen = RS_STAIRS;
  w.autosaveWanted = true;
}

void shopBuy(World& w, int idx) {
  if (idx < 0 || idx >= (int)w.shop.size()) return;
  ShopEntry& e = w.shop[idx];
  if (e.sold || w.pl.gold < e.price) return;
  switch (e.type) {
    case 0:
      if (abLevel(w, e.id) >= ABIL[e.id].maxLvl) return;
      learnAbility(w, e.id);
      break;
    case 1: gainRelic(w, e.id, e.seed); break;
    case 2:
      if (!gainItem(w, e.id)) return;
      break;
    case 3:
      if (w.pl.hp >= w.st.maxHp) return;
      healPlayer(w, w.st.maxHp * 4 / 10);
      break;
    case 6:
      if (w.pl.randarts.size() >= 24) return;
      gainRandart(w, (uint32_t)e.id);
      break;
    default: return;
  }
  w.pl.gold -= e.price;
  e.sold = true;
  fxSound(w, S_BUY, 0.9f);
  w.autosaveWanted = true;
}

void shopTrain(World& w, int shopIdx, int abIdx) {
  if (shopIdx < 0 || shopIdx >= (int)w.shop.size()) return;
  ShopEntry& e = w.shop[shopIdx];
  if (e.sold || e.type != 4 || w.pl.gold < e.price) return;
  if (abIdx < 0 || abIdx >= (int)w.pl.abil.size()) return;
  OwnedAb& a = w.pl.abil[abIdx];
  if (a.lvl >= ABIL[a.id].maxLvl) return;
  learnAbility(w, a.id);
  w.pl.gold -= e.price;
  e.sold = true;
  fxSound(w, S_BUY, 0.9f);
  w.autosaveWanted = true;
}

// option 0 rest, 1 train an ability, 2 pray, 3 sacrifice to Ruun
void restChoose(World& w, int option, int abIdx) {
  if (w.restUsed) return;
  switch (option) {
    case 0:
      healPlayer(w, w.st.maxHp * (w.descent >= 6 ? 3 : 4) / 10);
      logMsg(w, 0x80ff90, "You rest by the fire and recover.");
      break;
    case 1: {
      if (abIdx < 0 || abIdx >= (int)w.pl.abil.size()) return;
      OwnedAb& a = w.pl.abil[abIdx];
      if (a.lvl >= ABIL[a.id].maxLvl) return;
      learnAbility(w, a.id);
      break;
    }
    case 2:
      if (w.pl.patron < 0) return;
      gainPiety(w, 40);
      logMsg(w, PATRON[w.pl.patron].color, "You pray to %s.", PATRON[w.pl.patron].name);
      break;
    case 3:
      if (w.pl.patron != PT_RUUN) return;
      offerSacrifices(w);
      if (w.relicOffers.empty()) return;
      logMsg(w, 0xe0c090, "Ruun asks what you will give up.");
      break;
    default: return;
  }
  w.restUsed = true;
  fxSound(w, S_HEAL, 0.7f, 0.8f);
  w.autosaveWanted = true;
}

void altarChoose(World& w, int idx) {
  if (idx < 0 || idx >= (int)w.altarChoices.size() || w.pl.patron >= 0) return;
  int p = w.altarChoices[idx];
  w.pl.patron = p;
  w.pl.piety = 15;
  switch (p) {
    case PT_VRASK: w.pl.bonusMaxHp += 10; w.pl.hp += 10; break;
    case PT_AURUM: w.pl.gold += 30; break;
    case PT_VERDANA: healPlayer(w, w.st.maxHp); break;
    case PT_TOCK: w.pl.bonusMp += 1; break;
    case PT_MORGRAVE: gainItem(w, IT_HEALING); break;
    case PT_ASHKA: gainItem(w, IT_IMMOLATION); break;
    case PT_MIRRA: gainItem(w, IT_ENCHANT); break;
    case PT_TUMBLER: w.pl.gold += w.rng.range(10, 60); break;
    case PT_ARCANA: gainItem(w, IT_LUCK); break;
    case PT_RUUN: offerSacrifices(w); break;
    case PT_GLUB: {
      healPlayer(w, w.st.maxHp);
      int m = randomMutation(w, false, true);
      if (m >= 0) gainMutation(w, m, false);
      break;
    }
    case PT_TEMPESTRA: gainItem(w, IT_UPHEAVAL); break;
    case PT_AURELIA: w.pl.bonusMaxHp += 5; healPlayer(w, 20); break;
    case PT_ANCESTOR: w.pl.piety = PIETY_STAR[0]; break;
    case PT_VOIDMAW: gainItem(w, IT_W_DIGGING); break;
    case PT_BRAKKA: gainItem(w, IT_MIGHT); break;
    case PT_SIFRA: w.pl.bonusMp += 2; break;
  }
  recalcStats(w);
  logMsg(w, PATRON[p].color, "You kneel before the altar of %s %s.", PATRON[p].name, PATRON[p].title);
  fxSound(w, S_LEVEL, 1.f, 0.7f);
  w.autosaveWanted = true;
}

int runScore(const World& w) {
  int s = w.depth * 50 + w.pl.xl * 100 + w.runes * 1000 + w.rs.kills * 10 + w.pl.gold;
  if (w.won) s += 10000 + std::max(0, 3000 - w.rs.turns * 5);
  return (int)(s * (1.f + 0.25f * w.descent));
}

std::string morgueText(const World& w) {
  std::string s;
  s += "Dropcrawl character file\n========================\n\n";
  s += fmt("%s the %s %s (XL %d)\n", w.won ? "Victorious" : "Fallen", SPECIES[w.pl.species].name, BGS[w.pl.bg].name, w.pl.xl);
  s += fmt("Score: %d    Seed: %llu    Descent level: %d\n", runScore(w), (unsigned long long)w.seed, w.descent);
  if (w.won) s += "Escaped with the Orb of Chance!\n";
  else s += fmt("Killed by %s on %s (Depth %d)\n", w.rs.killer.c_str(), locationName(w), w.depth);
  s += fmt("Runes: %d   Gold: %d   Kills: %d (%d elite)   Turns: %d   Shots: %d\n", w.runes, w.pl.gold, w.rs.kills, w.rs.eliteKills,
           w.rs.turns, w.rs.shots);
  s += fmt("Damage dealt: %d   Biggest hit: %d   Best shot: %d   Pegs hit: %d\n", w.rs.damage, w.rs.biggestHit, w.rs.bestShot, w.rs.pegHits);
  s += fmt("Cards drawn: %d   Tumbler meddling: %d   Jackpots: %d\n\n", w.rs.cards, w.rs.tumbles, w.rs.jackpots);
  s += fmt("HP %d/%d  MP %d/%d  Base power %d  Armor %d\n", w.pl.hp, w.st.maxHp, w.pl.mp, w.st.maxMp, w.st.basePower, w.st.armor);
  s += fmt("STR %d  DEX %d  INT %d  VIT %d  LCK %d   (crit %d%%, dodge %d%%)\n", w.st.stat[STAT_STR], w.st.stat[STAT_DEX],
           w.st.stat[STAT_INT], w.st.stat[STAT_VIT], w.st.stat[STAT_LCK], (int)std::lround(w.st.critChance * 100),
           (int)std::lround(w.st.dodge * 100));
  if (w.pl.species == SP_FELID) s += fmt("Extra lives left: %d\n", w.pl.lives);
  if (w.pl.draconic >= 0) s += fmt("Draconic color: %s\n", DRACO_NAME[w.pl.draconic]);
  s += "\nAbilities:\n";
  for (auto& a : w.pl.abil) s += fmt("  %-22s lvl %d  (%s)\n", ABIL[a.id].name, a.lvl, SCHOOL_NAME[ABIL[a.id].school]);
  s += "\nRelics:\n";
  for (size_t i = 0; i < w.pl.relics.size(); ++i) {
    int r = w.pl.relics[i];
    std::string tag = RELIC[r].tier == 1 ? " [unique]" : RELIC[r].tier == 2 ? " [set]" : "";
    std::string af;
    if (i < w.pl.relicAffix.size() && w.pl.relicAffix[i].n > 0) {
      af = randartDesc(w.pl.relicAffix[i]);
      for (auto& c : af)
        if (c == '\n') c = ';';
      af = " {" + af + "}";
      tag = " [magic]";
    }
    s += fmt("  %s%s - %s%s\n", relicName(w, (int)i).c_str(), tag.c_str(), RELIC[r].desc, af.c_str());
  }
  if (w.pl.shards > 0) s += fmt("  (%d relic shard%s)\n", w.pl.shards, w.pl.shards == 1 ? "" : "s");
  if (!w.pl.randarts.empty()) {
    s += "\nRandarts:\n";
    for (auto& r : w.pl.randarts) {
      std::string d = randartDesc(r);
      for (auto& c : d)
        if (c == '\n') c = ';';
      s += fmt("  %s {%s}\n", r.name, d.c_str());
    }
  }
  bool anyMut = false;
  for (int m = 0; m < MUT_COUNT; ++m) anyMut |= w.pl.mut[m] > 0;
  if (anyMut) {
    s += "\nMutations:\n";
    for (int m = 0; m < MUT_COUNT; ++m)
      if (w.pl.mut[m]) s += fmt("  %s %d\n", MUTS[m].name, w.pl.mut[m]);
  }
  if (w.pl.sacrifices) {
    s += "\nSacrifices:\n";
    for (int i = 0; i < SAC_COUNT; ++i)
      if (hasSacrifice(w, i)) s += fmt("  %s\n", SACRIFICE_NAME[i]);
  }
  if (w.pl.patron >= 0) s += fmt("\nPatron: %s %s (piety %d, %d stars)\n", PATRON[w.pl.patron].name, PATRON[w.pl.patron].title, w.pl.piety, pietyStars(w));
  s += "\nLast messages:\n";
  int start = std::max(0, (int)w.log.size() - 25);
  for (int i = start; i < (int)w.log.size(); ++i) s += "  " + w.log[i].text + "\n";
  return s;
}
