// Dropcrawl - screens: title, new run, overlays, rooms, end screens, help, settings
#include "app.h"
#include <fstream>
#include <filesystem>

static const float BX = BOARD_X0 + 10, BW = BOARD_X1 - BOARD_X0 - 20;  // content area over the board

static void dimBoard(App& a, float alpha = 0.72f) { a.g.fillRect(BOARD_X0, 0, BOARD_X1 - BOARD_X0, SCR_H, 0x05060a, alpha); }

static void roomBackground(App& a, uint32_t accent) {
  Gfx& g = a.g;
  const BiomeDef& B = BIOME[a.w.act == 0 ? BI_HALLS : a.w.act == 1 ? a.w.branchA : a.w.act == 2 ? a.w.branchB : BI_CORE];
  g.vgrad(BOARD_X0, 0, BOARD_X1 - BOARD_X0, SCR_H, B.bgTop, B.bgBot);
  g.additive(true);
  g.glow(V2(LAUNCH_X, 300), 500, accent, 0.08f);
  g.additive(false);
  g.fillRect(BOARD_X0, 0, PX0 - BOARD_X0, SCR_H, B.wall, 1);
  g.fillRect(PX1, 0, BOARD_X1 - PX1, SCR_H, B.wall, 1);
}

static void heading(App& a, const std::string& t, const std::string& sub, uint32_t col, float y = 40) {
  a.g.textSh(t, BX, y, BW, 44, 34, col, 1.f, F_TITLE, AL_C, VA_M);
  if (!sub.empty()) a.g.text(sub, BX + 20, y + 46, BW - 40, 44, 15, 0xb8c0d0, 1.f, F_UI, AL_C, VA_T);
}

static float wrapText(App& a, const std::string& s, float x, float y, float w, float size, uint32_t col, int font = F_UI,
                      int align = AL_L) {
  float h = a.g.measure(s, size, font, w).y;
  a.g.text(s, x, y, w, h + 4, size, col, 1.f, font, align);
  return h;
}

// ------------------------------------------------------------------ ability / relic cards
static bool abilityCard(App& a, float x, float y, float w, float h, int ab, int curLvl) {
  Gfx& g = a.g;
  const AbilityDef& d = ABIL[ab];
  uint32_t sc = SCHOOL_COLOR[d.school];
  bool hov = mouseIn(a, x, y, w, h);
  g.fillRRect(x + 4, y + 6, w, h, 10, 0x000000, 0.45f);
  g.fillRRect(x, y, w, h, 10, hov ? 0x1c2233 : 0x121620, 1.f);
  g.fillRRect(x, y, w, 34, 10, sc, 0.22f);
  g.rrect(x, y, w, h, 10, sc, hov ? 1.f : 0.55f, hov ? 2.5f : 1.5f);
  g.text(SCHOOL_NAME[d.school], x + 12, y + 6, w - 24, 22, 13, sc, 1.f, F_UIB, AL_L, VA_M);
  g.text(d.rarity == R_RARE ? "RARE" : d.rarity == R_UNCOMMON ? "UNCOMMON" : "", x + 12, y + 6, w - 24, 22, 11, 0xffd060, 1.f, F_UIB,
         AL_R, VA_M);
  float yy = y + 44;
  yy += wrapText(a, d.name, x + 12, yy, w - 24, 20, 0xffffff, F_UIB) + 4;
  std::string lv = curLvl > 0 ? fmt("Upgrade: level %d > %d", curLvl, curLvl + 1) : std::string("NEW");
  g.text(lv, x + 12, yy, w - 24, 18, 13, curLvl > 0 ? 0x80ffb0 : 0xffe070, 1.f, F_UIB);
  yy += 20;
  std::string type;
  if (d.timing == T_PASSIVE) type = "Passive";
  else {
    int c = d.cost[clampv(curLvl, 0, 4)];
    type = fmt("Active · %s", d.timing == T_AIM ? "before launch" : d.timing == T_FLIGHT ? "during flight" : "any time");
    if (d.goldCost) type += " · costs gold";
    else type += fmt(" · %d MP", c);
    if (d.cooldown) type += fmt(" · cooldown %d", d.cooldown);
  }
  yy += wrapText(a, type, x + 12, yy, w - 24, 12, 0x98a0b0) + 8;
  g.line(V2(x + 12, yy), V2(x + w - 12, yy), sc, 0.3f, 1);
  yy += 8;
  wrapText(a, abilityDesc(ab, curLvl + 1, curLvl > 0), x + 12, yy, w - 24, 14, 0xdde2ec);
  if (hov) g.text("click to choose", x, y + h - 26, w, 20, 12, 0x8890a0, 1.f, F_UI, AL_C, VA_M);
  if (hov && a.in.lPressed && !a.in.consumed) {
    a.in.consumed = true;
    return true;
  }
  return false;
}

static bool offerCard(App& a, float x, float y, float w, float h, const Offer& o) {
  Gfx& g = a.g;
  std::string name, sub, desc, glyph;
  uint32_t col = 0xffffff, subCol = 0x98a0b0;
  if (o.type == 2) {
    Randart r = makeRandart((uint32_t)o.id);
    name = r.name;
    sub = fmt("Randart  -  %d properties", (int)r.n);
    subCol = 0xffd060;
    desc = randartDesc(r);
    glyph = randartGlyph(r);
    col = r.color;
  } else if (o.type == 3) {
    name = SACRIFICE_NAME[o.id];
    sub = "Sacrifice to Ruun (+55 piety)";
    subCol = 0xe0c090;
    desc = SACRIFICE_DESC[o.id];
    glyph = "X";
    col = 0xe0c090;
  } else {
    const RelicDef& r = RELIC[o.id];
    name = offerRelicName(o.id, o.seed);
    if (r.tier == 1) {
      sub = "UNIQUE relic";
      subCol = 0xffa838;
    } else if (r.tier == 2) {
      sub = std::string("Set: ") + RELIC_SET_NAME[r.set];
      subCol = 0x5ee06a;
    } else if (o.seed) {
      sub = "Magic relic";
      subCol = 0x6aa0ff;
    } else {
      sub = r.rarity == R_RARE ? "Rare relic" : r.rarity == R_UNCOMMON ? "Uncommon relic" : "Common relic";
      subCol = r.rarity == R_RARE ? 0xffd060 : 0x98a0b0;
    }
    desc = offerRelicDesc(o.id, o.seed);
    glyph = r.glyph;
    col = r.tier == 1 ? 0xffa838 : r.tier == 2 ? 0x5ee06a : o.seed ? 0x6aa0ff : r.color;
  }
  bool hov = mouseIn(a, x, y, w, h);
  g.fillRRect(x + 4, y + 6, w, h, 10, 0x000000, 0.45f);
  g.fillRRect(x, y, w, h, 10, hov ? 0x1c2233 : 0x121620, 1.f);
  g.rrect(x, y, w, h, 10, col, hov ? 1.f : 0.55f, hov ? 2.5f : 1.5f);
  if (o.type == 2) g.rrect(x + 4, y + 4, w - 8, h - 8, 8, 0xffd060, 0.35f, 1.f);
  if (o.type == 1 && (RELIC[o.id].tier || o.seed)) g.rrect(x + 4, y + 4, w - 8, h - 8, 8, col, 0.35f, 1.f);
  g.additive(true);
  g.glow(V2(x + w / 2, y + 58), 44, col, 0.5f);
  g.additive(false);
  g.fillRRect(x + w / 2 - 26, y + 32, 52, 52, 10, 0x0c0e14, 1.f);
  g.rrect(x + w / 2 - 26, y + 32, 52, 52, 10, col, 1.f, 2);
  g.text(glyph, x + w / 2 - 26, y + 32, 52, 52, 30, col, 1.f, F_MONOB, AL_C, VA_M);
  float yy = y + 96;
  yy += wrapText(a, name, x + 12, yy, w - 24, 18, 0xffffff, F_UIB, AL_C) + 4;
  g.text(sub, x, yy, w, 18, 12, subCol, 1.f, F_UI, AL_C);
  yy += 24;
  float dfs = o.type == 2 ? 13.f : (o.type == 1 && RELIC[o.id].tier == 2) ? 11.5f : (o.type == 1 && o.seed) ? 13.f : 14.f;
  wrapText(a, desc, x + 14, yy, w - 28, dfs, 0xdde2ec, F_UI, AL_C);
  if (hov && a.in.lPressed && !a.in.consumed) {
    a.in.consumed = true;
    return true;
  }
  return false;
}

static const char* offersTitle(const World& w) {
  bool rel = false, ra = false, sac = false;
  for (auto& o : w.relicOffers) {
    if (o.type == 1) rel = true;
    if (o.type == 2) ra = true;
    if (o.type == 3) sac = true;
  }
  if (sac) return "Ruun demands a sacrifice";
  if (ra && !rel) return "Choose a randart";
  if (ra && rel) return "Choose a relic or randart";
  return "Choose a relic";
}

static void drawOfferRow(App& a, float y, float ch) {
  World& w = a.w;
  int n = (int)w.relicOffers.size();
  float cw = n >= 4 ? 196.f : 240.f;
  float gap = n >= 4 ? 10.f : 18.f;
  float total = n * cw + (n - 1) * gap;
  float x0 = BX + (BW - total) / 2;
  for (int i = 0; i < n; ++i)
    if (offerCard(a, x0 + i * (cw + gap), y, cw, ch, w.relicOffers[i])) {
      chooseRelicOffer(w, i);
      audio::play(S_CHEST, 0.8f);
      return;
    }
}

static void drawStatOverlay(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  dimBoard(a, 0.82f);
  heading(a, "Raise a stat!", fmt("Every third level you raise one stat by 2. Choose what this %s %s needs.", SPECIES[w.pl.species].name,
                                  BGS[w.pl.bg].name), 0xffe070, 60);
  int n = (int)w.offers.size();
  float gap = 10, cw = (BW - gap * (n - 1)) / n, ch = 330;
  float x0 = BX;
  for (int i = 0; i < n; ++i) {
    int st = w.offers[i].id;
    float x = x0 + i * (cw + gap), y = 170;
    uint32_t c = STAT_COLOR[st];
    bool hov = mouseIn(a, x, y, cw, ch);
    g.fillRRect(x + 4, y + 6, cw, ch, 10, 0x000000, 0.45f);
    g.fillRRect(x, y, cw, ch, 10, hov ? 0x1c2233 : 0x121620, 1.f);
    g.rrect(x, y, cw, ch, 10, c, hov ? 1.f : 0.55f, hov ? 2.5f : 1.5f);
    g.additive(true);
    g.glow(V2(x + cw / 2, y + 50), 40, c, 0.5f);
    g.additive(false);
    g.text(STAT_ABBR[st], x, y + 22, cw, 50, 30, c, 1.f, F_TITLE, AL_C, VA_M);
    g.text(STAT_NAME[st], x, y + 74, cw, 22, 16, 0xffffff, 1.f, F_UIB, AL_C, VA_M);
    int cur = w.st.stat[st];
    g.text(fmt("%d  >  %d", cur, cur + 2), x, y + 100, cw, 24, 19, c, 1.f, F_UIB, AL_C, VA_M);
    float yy = y + 134;
    g.text("now", x + 10, yy, cw - 20, 14, 10.5f, 0x7880a0, 1.f, F_UI, AL_C);
    yy += 14;
    yy += wrapText(a, statEffectText(st, cur), x + 10, yy, cw - 20, 11.5f, 0xa8b0c0, F_UI, AL_C) + 8;
    g.text("after", x + 10, yy, cw - 20, 14, 10.5f, 0x7880a0, 1.f, F_UI, AL_C);
    yy += 14;
    wrapText(a, statEffectText(st, cur + 2), x + 10, yy, cw - 20, 12, 0xe8ecf4, F_UI, AL_C);
    if (hov) {
      setTip(a, STAT_NAME[st], statTooltip(w, st), c);
      if (a.in.lPressed && !a.in.consumed) {
        a.in.consumed = true;
        chooseOffer(w, i);
        audio::play(S_LEVEL, 0.6f, 1.3f);
        return;
      }
    }
  }
  if (w.pl.statPoints > 1) g.text(fmt("%d more stat raises to choose after this one.", w.pl.statPoints - 1), BX, 516, BW, 20, 13, 0x98a0b0, 1.f, F_UI, AL_C);
}

static void drawOffersOverlay(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  if (!w.offers.empty() && w.offers[0].type == 4) {
    drawStatOverlay(a);
    return;
  }
  dimBoard(a, 0.8f);
  heading(a, fmt("Level %d!", w.pl.xl - std::max(0, w.pendingLevels - 1)), "Choose a new ability or an upgrade.", 0xffe070, 60);
  int n = (int)w.offers.size();
  float cw = std::min(250.f, (BW - 16.f * (n - 1)) / n), ch = 380;
  float total = n * cw + (n - 1) * 16.f;
  float x0 = BX + (BW - total) / 2;
  for (int i = 0; i < n; ++i) {
    int ab = w.offers[i].id;
    if (abilityCard(a, x0 + i * (cw + 16), 170, cw, ch, ab, abLevel(w, ab))) {
      chooseOffer(w, i);
      audio::play(S_LEVEL, 0.6f, 1.2f);
      return;
    }
  }
  if (button(a, LAUNCH_X - 120, 580, 240, 36, "Skip: +4 max HP instead", true, 0x707888, 14)) chooseOffer(w, -1);
  if (w.pendingLevels > 1) g.text(fmt("%d more level-ups to choose after this one.", w.pendingLevels - 1), BX, 626, BW, 20, 13, 0x98a0b0, 1.f, F_UI, AL_C);
}

static void drawRelicOverlay(App& a) {
  World& w = a.w;
  dimBoard(a, 0.82f);
  bool sac = !w.relicOffers.empty() && w.relicOffers[0].type == 3;
  heading(a, offersTitle(w), sac ? "Give up part of yourself for Ruun's favor." : "Choose one.", sac ? 0xe0c090 : 0xffd040, 60);
  drawOfferRow(a, 170, 350);
  if (w.relicOffers.empty()) return;
  if (button(a, LAUNCH_X - 90, 550, 180, 34, sac ? "Refuse" : "Take nothing", true, 0x707888, 14)) chooseRelicOffer(w, -1);
}

// ------------------------------------------------------------------ rooms
static void drawReward(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  roomBackground(a, 0x80ffb0);
  if (!w.offers.empty()) {
    drawOffersOverlay(a);
    return;
  }
  bool boss = w.fl.spec.kind == FK_BOSS, vault = w.fl.isVault;
  heading(a, boss ? "Guardian defeated!" : vault ? "Vault looted!" : "Floor cleared!", "", boss ? 0xffd040 : 0x80ffb0, 50);
  float y = 110;
  std::string s = fmt("Gold gained: %d", w.rewardGold);
  g.text(s, BX, y, BW, 24, 17, 0xffd84a, 1.f, F_UIB, AL_C);
  y += 28;
  if (!w.rewardItems.empty()) {
    std::string it = "Found: ";
    for (size_t i = 0; i < w.rewardItems.size(); ++i) it += (i ? ", " : "") + std::string(ITEM[w.rewardItems[i]].name);
    y += wrapText(a, it, BX + 40, y, BW - 80, 15, 0xd0d8e8, F_UI, AL_C) + 6;
  }
  if (boss && (w.act == 1 || w.act == 2)) {
    g.text(fmt("You claim a Rune! (%d/2)", w.runes), BX, y, BW, 26, 20, 0xffd040, 1.f, F_TITLE, AL_C);
    y += 30;
  }
  if (!w.relicOffers.empty()) {
    g.text(std::string(offersTitle(w)) + ":", BX, y + 6, BW, 24, 17, 0xffffff, 1.f, F_UIB, AL_C);
    drawOfferRow(a, y + 40, 340);
    bool done = w.relicOffers.empty();
    if (!done && button(a, LAUNCH_X - 90, y + 396, 180, 34, "Take nothing", true, 0x707888, 14)) {
      w.relicOffers.clear();
      done = true;
    }
    if (done && w.offers.empty()) {
      // the choice was the whole point of this screen: go straight on to the stairs
      finishReward(w);
      audio::play(S_STAIRS, 0.8f);
    }
    return;
  }
  if (button(a, LAUNCH_X - 110, 520, 220, 46, "Continue", true, 0x80ffb0, 18)) {
    finishReward(w);
    audio::play(S_STAIRS, 0.8f);
  }
}

static const char* stairName(const StairOpt& o) {
  switch (o.kind) {
    case ST_FLOOR: return "Monster Den";
    case ST_ELITE: return "Elite Lair";
    case ST_BOSS: return "The Guardian";
    case ST_SHOP: return "Shop";
    case ST_REST: return "Rest Site";
    case ST_TREASURE: return "Treasure Vault";
    case ST_ALTAR: return "Altar";
    case ST_EVENT: return "Strange Passage";
    case ST_BRANCH: return BIOME[o.biome].name;
  }
  return "?";
}
static const char* stairDesc(const StairOpt& o) {
  switch (o.kind) {
    case ST_FLOOR: return "A board full of monsters. XP and gold.";
    case ST_ELITE: return "A tougher fight led by an elite monster. Reward: choose a relic.";
    case ST_BOSS: return "The guardian of this area. Defeat it to move on.";
    case ST_SHOP: return "Spend your gold on abilities, relics, potions and scrolls.";
    case ST_REST: return "Heal, train an ability, or pray.";
    case ST_TREASURE: return "No monsters: 5 shots at a board full of gold, chests and a sealed relic.";
    case ST_ALTAR: return "Pledge yourself to a patron god for powerful gifts. (Once per run.)";
    case ST_EVENT: return "Something unusual lies ahead...";
    case ST_BRANCH: return BIOME[o.biome].flavor;
  }
  return "";
}
static uint32_t stairColor(const StairOpt& o) {
  switch (o.kind) {
    case ST_FLOOR: return 0x9fc0ff;
    case ST_ELITE: return 0xffb040;
    case ST_BOSS: return 0xff4050;
    case ST_SHOP: return 0xffd040;
    case ST_REST: return 0x80ff90;
    case ST_TREASURE: return 0xffe070;
    case ST_ALTAR: return 0xfff0c0;
    case ST_EVENT: return 0xc080ff;
    case ST_BRANCH: return BIOME[o.biome].accent;
  }
  return 0xffffff;
}

static void drawStairs(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  roomBackground(a, 0x9fc0ff);
  if (!w.offers.empty()) {
    drawOffersOverlay(a);
    return;
  }
  bool branch = !w.stairs.empty() && w.stairs[0].kind == ST_BRANCH;
  heading(a, branch ? "Choose your branch" : "Choose your descent",
          branch ? "Each branch holds different monsters, hazards and a Guardian with a Rune."
                 : fmt("%s  ·  room %d of %d", BIOME[w.act == 0 ? BI_HALLS : w.act == 1 ? w.branchA : w.act == 2 ? w.branchB : BI_CORE].name,
                       w.step + 2, actLength(w.act)),
          0xe8ecf4, 40);
  int n = (int)w.stairs.size();
  float cw = n >= 3 ? 250.f : 290.f, ch = 520;
  float total = n * cw + (n - 1) * 16.f;
  float x0 = BX + (BW - total) / 2;
  for (int i = 0; i < n; ++i) {
    const StairOpt& o = w.stairs[i];
    float x = x0 + i * (cw + 16), y = 150;
    uint32_t col = stairColor(o);
    bool hov = mouseIn(a, x, y, cw, ch);
    g.fillRRect(x + 4, y + 6, cw, ch, 12, 0x000000, 0.45f);
    g.fillRRect(x, y, cw, ch, 12, hov ? 0x1a2030 : 0x10141c, 1.f);
    g.rrect(x, y, cw, ch, 12, col, hov ? 1.f : 0.5f, hov ? 2.5f : 1.5f);
    g.additive(true);
    g.glow(V2(x + cw / 2, y + 60), 50, col, 0.45f);
    g.additive(false);
    g.text(">", x, y + 26, cw, 64, 54, col, 1.f, F_MONOB, AL_C, VA_M);
    float yy = y + 100;
    yy += wrapText(a, stairName(o), x + 12, yy, cw - 24, 20, 0xffffff, F_UIB, AL_C) + 6;
    yy += wrapText(a, stairDesc(o), x + 16, yy, cw - 32, 13.5f, 0xb8c0d0, F_UI, AL_C) + 12;
    bool fight = o.kind == ST_FLOOR || o.kind == ST_ELITE || o.kind == ST_BOSS || o.kind == ST_BRANCH || o.kind == ST_TREASURE;
    if (fight) {
      int fm = clampv((int)o.spec.format, 0, FORMAT_COUNT - 1);
      g.text(std::string(FORMAT_NAME[fm]) + " board", x + 16, yy, cw - 32, 18, 13, 0x9fc8e0, 1.f, F_UIB);
      if (mouseIn(a, x + 16, yy, cw - 32, 18)) setTip(a, std::string(FORMAT_NAME[fm]) + " board", FORMAT_DESC[fm], 0x9fc8e0);
      yy += 22;
    }
    if (fight && o.spec.nMons > 0) {
      g.text("Monsters:", x + 16, yy, cw - 32, 18, 13, 0x8890a0, 1.f, F_UIB);
      yy += 20;
      for (int k = 0; k < o.spec.nMons && k < 7; ++k) {
        const MonDef& d = MON[o.spec.mons[k]];
        g.fillCircle(V2(x + 28, yy + 9), 9, rgbLerp(0x0c0e14, d.color, 0.2f), 1.f);
        g.circle(V2(x + 28, yy + 9), 9, d.color, 1.f, 1.2f);
        g.text(d.glyph, x + 19, yy, 18, 18, 11, d.color, 1.f, F_MONOB, AL_C, VA_M);
        std::string nm = d.name;
        if (k == 0 && o.spec.kind == FK_ELITE && !(d.traits & TR_ELITE)) nm = "elite " + nm;
        g.text(nm, x + 44, yy, cw - 56, 18, 13, 0xe0e4ec, 1.f, F_UI, AL_L, VA_M);
        if (mouseIn(a, x + 16, yy, cw - 32, 18)) setTip(a, d.name, d.desc, d.color);
        yy += 21;
      }
      if (o.spec.nMons > 7) {
        g.text(fmt("+%d more", o.spec.nMons - 7), x + 44, yy, cw - 56, 18, 12, 0x8890a0);
        yy += 20;
      }
    }
    if (fight && o.spec.nMods > 0) {
      yy += 6;
      for (int k = 0; k < o.spec.nMods; ++k) {
        const ModDef& m = MODS[o.spec.mods[k]];
        g.text(m.name, x + 16, yy, cw - 32, 18, 13, m.color, 1.f, F_UIB);
        yy += 17;
        yy += wrapText(a, m.desc, x + 16, yy, cw - 32, 12, 0x98a0b0) + 6;
      }
    }
    if (hov && a.in.lPressed && !a.in.consumed) {
      a.in.consumed = true;
      audio::play(S_STAIRS, 0.9f);
      clearPresentation(a);
      enterStairs(w, i);
      return;
    }
  }
}

static void chooseAbilityList(App& a, const char* title, int* chosen) {
  World& w = a.w;
  Gfx& g = a.g;
  dimBoard(a, 0.85f);
  heading(a, title, "Pick an ability to improve by one level.", 0xa0e8ff, 60);
  float y = 160;
  for (int i = 0; i < (int)w.pl.abil.size(); ++i) {
    const OwnedAb& o = w.pl.abil[i];
    const AbilityDef& d = ABIL[o.id];
    bool can = o.lvl < d.maxLvl;
    std::string lbl = can ? fmt("%s  (level %d > %d)", d.name, o.lvl, o.lvl + 1) : fmt("%s  (max level)", d.name);
    if (button(a, LAUNCH_X - 220, y, 440, 32, lbl, can, SCHOOL_COLOR[d.school], 14)) *chosen = i;
    if (mouseIn(a, LAUNCH_X - 220, y, 440, 32) && can) setTip(a, d.name, abilityDesc(o.id, o.lvl + 1, true), SCHOOL_COLOR[d.school]);
    y += 36;
  }
  (void)g;
}

static void drawShop(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  roomBackground(a, 0xffd040);
  if (!w.offers.empty()) {
    drawOffersOverlay(a);
    return;
  }
  if (a.trainShop >= 0) {
    int chosen = -1;
    chooseAbilityList(a, "Training", &chosen);
    if (chosen >= 0) {
      shopTrain(w, a.trainShop, chosen);
      a.trainShop = -1;
    }
    if (button(a, LAUNCH_X - 70, 800, 140, 34, "Cancel", true, 0x707888)) a.trainShop = -1;
    return;
  }
  heading(a, "The Shop", fmt("You have %d gold.", w.pl.gold), 0xffd040, 30);
  float cw = 250, ch = w.shop.size() > 9 ? 118.f : 124.f;
  for (int i = 0; i < (int)w.shop.size(); ++i) {
    const ShopEntry& e = w.shop[i];
    int col = i % 3, row = i / 3;
    float x = BX + 20 + col * (cw + 15), y = 120 + row * (ch + 10);
    bool afford = w.pl.gold >= e.price && !e.sold;
    std::string name, desc, tag;
    uint32_t c = 0xffffff;
    switch (e.type) {
      case 0: {
        const AbilityDef& d = ABIL[e.id];
        int lv = abLevel(w, e.id);
        name = d.name;
        tag = std::string(SCHOOL_NAME[d.school]) + (lv ? fmt(" · upgrade to %d", lv + 1) : (d.timing == T_PASSIVE ? " · passive" : " · active"));
        desc = abilityDesc(e.id, lv + 1, lv > 0);
        c = SCHOOL_COLOR[d.school];
        break;
      }
      case 1: {
        const RelicDef& r = RELIC[e.id];
        name = offerRelicName(e.id, e.seed);
        tag = r.tier == 1 ? "UNIQUE relic" : r.tier == 2 ? std::string("Set relic: ") + RELIC_SET_NAME[r.set] : e.seed ? "Magic relic" : "Relic";
        desc = offerRelicDesc(e.id, e.seed);
        c = r.tier == 1 ? 0xffa838 : r.tier == 2 ? 0x5ee06a : e.seed ? 0x6aa0ff : r.color;
        break;
      }
      case 2:
        name = ITEM[e.id].name;
        tag = ITEM[e.id].potion ? "Potion" : ITEM[e.id].wand ? fmt("Wand (%d charges)", ITEM[e.id].charges) : "Scroll";
        desc = ITEM[e.id].desc;
        c = ITEM[e.id].color;
        break;
      case 6: {
        Randart r = makeRandart((uint32_t)e.id);
        name = r.name;
        tag = fmt("Randart - %d properties", (int)r.n);
        desc = randartDesc(r);
        c = r.color;
        break;
      }
      case 3: name = "Healing"; tag = "Service"; desc = "Restore 40% of your max HP."; c = 0x70ff90; break;
      case 4: name = "Training"; tag = "Service"; desc = "Improve one of your abilities by a level."; c = 0xa0e8ff; break;
    }
    bool hov = mouseIn(a, x, y, cw, ch);
    g.fillRRect(x, y, cw, ch, 8, hov && afford ? 0x1c2233 : 0x121620, e.sold ? 0.5f : 1.f);
    g.rrect(x, y, cw, ch, 8, c, e.sold ? 0.2f : (hov ? 1.f : 0.5f), 1.5f);
    g.text(name, x + 10, y + 6, cw - 80, 20, 15, e.sold ? 0x606878 : 0xffffff, 1.f, F_UIB);
    g.text(e.sold ? "SOLD" : fmt("%d g", e.price), x + cw - 80, y + 6, 70, 20, 15, e.sold ? 0x606878 : (afford ? 0xffd84a : 0xa06050), 1.f,
           F_UIB, AL_R);
    g.text(tag, x + 10, y + 26, cw - 20, 16, 12, c, e.sold ? 0.4f : 1.f, F_UI);
    g.pushClip(x + 8, y + 44, cw - 16, ch - 50);
    wrapText(a, desc, x + 10, y + 46, cw - 20, 12.5f, e.sold ? 0x505868 : 0xc8d0dc);
    g.popClip();
    if (hov) {
      setTip(a, name, desc, c);
      if (a.in.lPressed && !a.in.consumed && !e.sold) {
        a.in.consumed = true;
        if (!afford) audio::play(S_DENY, 0.6f);
        else if (e.type == 4) a.trainShop = i;
        else {
          int before = w.pl.gold;
          shopBuy(w, i);
          if (w.pl.gold == before) audio::play(S_DENY, 0.6f);
        }
      }
    }
  }
  if (button(a, LAUNCH_X - 100, 800, 200, 44, "Leave the shop", true, 0x9fc0ff, 16)) {
    leaveRoom(w);
    audio::play(S_STAIRS, 0.7f);
  }
}

static void drawRest(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  roomBackground(a, 0x80ff90);
  if (!w.offers.empty()) {
    drawOffersOverlay(a);
    return;
  }
  if (a.restTrain) {
    int chosen = -1;
    chooseAbilityList(a, "Train", &chosen);
    if (chosen >= 0) {
      restChoose(w, 1, chosen);
      a.restTrain = false;
    }
    if (button(a, LAUNCH_X - 70, 800, 140, 34, "Cancel", true, 0x707888)) a.restTrain = false;
    return;
  }
  if (!w.relicOffers.empty()) {
    drawRelicOverlay(a);
    return;
  }
  if (w.restUsed) {
    leaveRoom(w);
    audio::play(S_STAIRS, 0.7f);
    return;
  }
  heading(a, "A Quiet Campfire", "The flames crackle. You may do one thing here.", 0xffb060, 60);
  // campfire
  V2 c(LAUNCH_X, 260);
  g.additive(true);
  g.glow(c, 120 + 10 * std::sin(a.time * 7), 0xff8030, 0.55f);
  g.glow(c + V2(0, -10), 50, 0xffd060, 0.7f);
  g.additive(false);
  for (int k = 0; k < 3; ++k) g.line(c + V2(-40 + k * 30, 30), c + V2(40 - k * 30, 20), 0x6a4020, 1.f, 8);
  if (!w.restUsed) {
    int heal = w.st.maxHp * 4 / 10;
    if (button(a, LAUNCH_X - 180, 380, 360, 50, fmt("Rest  (heal %d HP)", heal), w.pl.hp < w.st.maxHp, 0x80ff90, 17)) restChoose(w, 0, -1);
    bool canTrain = false;
    for (auto& o : w.pl.abil)
      if (o.lvl < ABIL[o.id].maxLvl) canTrain = true;
    if (button(a, LAUNCH_X - 180, 442, 360, 50, "Train  (upgrade an ability)", canTrain, 0xa0e8ff, 17)) a.restTrain = true;
    if (w.pl.patron >= 0 && button(a, LAUNCH_X - 180, 504, 360, 50, fmt("Pray to %s  (+40 piety)", PATRON[w.pl.patron].name), true,
                                   PATRON[w.pl.patron].color, 17))
      restChoose(w, 2, -1);
    if (w.pl.patron == PT_RUUN && button(a, LAUNCH_X - 180, 566, 360, 50, "Make a sacrifice to Ruun  (+55 piety)", true, 0xe0c090, 17))
      restChoose(w, 3, -1);
  } else {
    g.text("You feel ready to go on.", BX, 400, BW, 30, 18, 0xd0d8e8, 1.f, F_UI, AL_C);
  }
  if (button(a, LAUNCH_X - 100, 800, 200, 44, w.restUsed ? "Continue" : "Leave without resting", true, 0x9fc0ff, 15)) {
    leaveRoom(w);
    audio::play(S_STAIRS, 0.7f);
  }
}

static void drawAltar(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  roomBackground(a, 0xfff0c0);
  if (!w.relicOffers.empty()) {
    drawRelicOverlay(a);
    return;
  }
  if (w.pl.patron >= 0) {
    const PatronDef& P = PATRON[w.pl.patron];
    heading(a, fmt("You now follow %s", P.name), P.title, P.color, 120);
    wrapText(a, P.desc, BX + 60, 240, BW - 120, 16, 0xd0d8e8, F_UI, AL_C);
    wrapText(a, fmt("Gain piety by: %s\nGifts unlock at %d, %d, %d, %d and %d piety. Invocations cost piety: use them from the Invoke window (G).", P.likes, PIETY_STAR[0],
                    PIETY_STAR[1], PIETY_STAR[2], PIETY_STAR[3], PIETY_STAR[4]),
             BX + 60, 320, BW - 120, 15, 0xb0b8c8, F_UI, AL_C);
    if (button(a, LAUNCH_X - 100, 800, 200, 44, "Continue", true, P.color, 16)) leaveRoom(w);
    return;
  }
  heading(a, "An Ancient Altar", "Three gods offer you their favor. You may follow only one, for the rest of the run.", 0xfff0c0, 30);
  float cw = 262, ch = 680;
  for (int i = 0; i < (int)w.altarChoices.size(); ++i) {
    const PatronDef& P = PATRON[w.altarChoices[i]];
    float x = BX + 4 + i * (cw + 8), y = 104;
    g.fillRRect(x, y, cw, ch, 10, 0x10141c, 1.f);
    g.rrect(x, y, cw, ch, 10, P.color, mouseIn(a, x, y, cw, ch) ? 1.f : 0.5f, 1.5f);
    g.additive(true);
    g.glow(V2(x + cw / 2, y + 34), 34, P.color, 0.5f);
    g.additive(false);
    float yy = y + 56;
    yy += wrapText(a, P.name, x + 10, yy, cw - 20, 21, P.color, F_TITLE, AL_C);
    yy += wrapText(a, P.title, x + 10, yy, cw - 20, 13, 0xd0d0d0, F_UI, AL_C) + 6;
    yy += wrapText(a, P.desc, x + 12, yy, cw - 24, 11.5f, 0xc8d0dc, F_UI, AL_C) + 6;
    yy += wrapText(a, std::string("Likes: ") + P.likes, x + 12, yy, cw - 24, 11, 0x90e0a0) + 2;
    yy += wrapText(a, std::string("Dislikes: ") + P.dislikes, x + 12, yy, cw - 24, 11, 0xff9090) + 8;
    for (int k = 0; k < 5; ++k) {
      const AbilityDef& d = ABIL[P.gifts[k]];
      g.text(fmt("%d: %s", PIETY_STAR[k], d.name), x + 12, yy, cw - 24, 15, 11.5f, P.color, 1.f, F_UIB);
      yy += 15;
      if (mouseIn(a, x + 8, yy - 15, cw - 16, 15)) setTip(a, d.name, abilityDesc(d.id, 1, false), P.color);
      yy += wrapText(a, abilityDesc(d.id, 1, false), x + 12, yy, cw - 24, 10.5f, 0xb0b8c8) + 4;
    }
    if (button(a, x + 30, y + ch - 46, cw - 60, 36, "Worship", true, P.color, 16)) altarChoose(w, i);
  }
  if (button(a, LAUNCH_X - 80, 846, 160, 34, "Walk away", true, 0x707888, 14)) leaveRoom(w);
}

static void drawEvent(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  roomBackground(a, 0xc080ff);
  if (!w.offers.empty()) {
    drawOffersOverlay(a);
    return;
  }
  if (w.eventId < 0 || w.eventId >= NUM_EVENTS) {
    leaveRoom(w);
    return;
  }
  if (!w.relicOffers.empty()) {
    drawRelicOverlay(a);
    return;
  }
  const EventDef& e = EVENTS[w.eventId];
  heading(a, e.title, "", 0xd0a0ff, 80);
  float y = 170;
  y += wrapText(a, e.text, BX + 60, y, BW - 120, 17, 0xe0e4ec, F_UI, AL_C) + 40;
  if (w.eventResult.empty()) {
    for (int o = 0; o < e.nOpt; ++o) {
      std::string why;
      bool ok = eventOptionAvailable(w, w.eventId, o, &why);
      std::string lbl = e.opt[o];
      if (button(a, BX + 60, y, BW - 120, 46, lbl, ok, 0xc080ff, 15)) {
        eventResolve(w, w.eventId, o);
        if (w.eventResult.empty()) w.eventResult = "...";
        w.autosaveWanted = true;
      }
      if (!ok && mouseIn(a, BX + 60, y, BW - 120, 46)) setTip(a, "Unavailable", why, 0xff9090);
      y += 56;
    }
  } else {
    y += wrapText(a, w.eventResult, BX + 60, y, BW - 120, 17, 0xffe8a0, F_UI, AL_C) + 40;
    if (button(a, LAUNCH_X - 100, y, 200, 44, "Continue", true, 0xc080ff, 16)) {
      leaveRoom(w);
      audio::play(S_STAIRS, 0.7f);
    }
  }
  (void)g;
}

static void drawEndScreen(App& a) {
  World& w = a.w;
  Gfx& g = a.g;
  g.vgrad(0, 0, SCR_W, SCR_H, w.won ? 0x2a2208 : 0x200a0e, 0x050507);
  g.additive(true);
  g.glow(V2(SCR_W / 2, 140), 520, w.won ? 0xffd040 : 0xff3040, 0.18f);
  g.additive(false);
  g.textSh(w.won ? "VICTORY" : "You have died", 0, 50, SCR_W, 70, 60, w.won ? 0xffd040 : 0xff5060, 1.f, F_TITLE, AL_C, VA_M);
  std::string sub = w.won ? "You beat the House and escaped with the Orb of Chance!"
                          : fmt("Killed by %s on %s (Depth %d)", w.rs.killer.c_str(), locationName(w), w.depth);
  g.text(sub, 0, 124, SCR_W, 30, 20, 0xe0e4ec, 1.f, F_UI, AL_C, VA_M);
  g.text(fmt("Score %d", runScore(w)), 0, 156, SCR_W, 30, 22, 0xffe070, 1.f, F_UIB, AL_C, VA_M);
  panelBox(a, 260, 200, 1080, 600, w.won ? 0xffd040 : 0xff5060);
  g.pushClip(270, 210, 1060, 580);
  g.text(a.lastMorgue.empty() ? morgueText(w) : a.lastMorgue, 290, 220 - a.logScroll * 16, 1020, 4000, 13.5f, 0xd0d8e4, 1.f, F_MONO);
  g.popClip();
  if (mouseIn(a, 260, 200, 1080, 600) && a.in.wheel != 0) a.logScroll = clampv(a.logScroll - a.in.wheel * 3, 0.f, 80.f);
  if (button(a, SCR_W / 2 - 230, 822, 220, 48, "New Run", true, 0x80ffb0, 18)) {
    a.ui = UI_NEWRUN;
    a.logScroll = 0;
  }
  if (button(a, SCR_W / 2 + 10, 822, 220, 48, "Title Screen", true, 0x9fc0ff, 18)) {
    a.ui = UI_TITLE;
    a.logScroll = 0;
  }
}

// ------------------------------------------------------------------ in-game composition
static void drawPause(App& a) {
  Gfx& g = a.g;
  g.fillRect(0, 0, SCR_W, SCR_H, 0x000000, 0.6f);
  panelBox(a, SCR_W / 2 - 180, 220, 360, 420, 0x9fc0ff, 0.97f);
  g.text("Paused", SCR_W / 2 - 180, 236, 360, 40, 30, 0xffffff, 1.f, F_TITLE, AL_C, VA_M);
  float y = 300;
  if (a.confirmAbandon) {
    g.text("Abandon this run? It will count as a death.", SCR_W / 2 - 160, y, 320, 50, 15, 0xffb0b0, 1.f, F_UI, AL_C);
    if (button(a, SCR_W / 2 - 150, y + 70, 300, 44, "Yes, abandon it", true, 0xff5060)) {
      a.w.dead = true;
      a.w.rs.killer = "giving up";
      a.w.screen = RS_DEATH;
      a.paused = false;
      a.confirmAbandon = false;
      recordRunEnd(a);
    }
    if (button(a, SCR_W / 2 - 150, y + 124, 300, 44, "No, keep playing", true, 0x9fc0ff)) a.confirmAbandon = false;
    return;
  }
  if (button(a, SCR_W / 2 - 150, y, 300, 44, "Resume", true, 0x80ffb0)) a.paused = false;
  if (button(a, SCR_W / 2 - 150, y + 56, 300, 44, "How to Play", true, 0x9fc0ff)) {
    a.ui = UI_HELP;
    a.settingsReturn = UI_GAME;
  }
  if (button(a, SCR_W / 2 - 150, y + 112, 300, 44, "Settings", true, 0x9fc0ff)) {
    a.settingsReturn = UI_GAME;
    a.ui = UI_SETTINGS;
  }
  if (button(a, SCR_W / 2 - 150, y + 168, 300, 44, "Save & Quit to Title", true, 0xffd040)) {
    writeSave(a);
    a.paused = false;
    a.ui = UI_TITLE;
    a.hasSave = true;
  }
  if (button(a, SCR_W / 2 - 150, y + 250, 300, 44, "Abandon Run", true, 0xff5060)) a.confirmAbandon = true;
}

void drawGame(App& a) {
  World& w = a.w;
  if (w.screen == RS_VICTORY || w.screen == RS_DEATH) {
    drawEndScreen(a);
    return;
  }
  drawLeftPanel(a);
  drawRightPanel(a);
  switch (w.screen) {
    case RS_FLOOR: {
      drawBoard(a, w, !a.paused);
      bool calm = w.fl.phase == PH_AIM || w.fl.phase == PH_CLEARED;
      if (!w.offers.empty() && calm) drawOffersOverlay(a);
      else if (!w.relicOffers.empty() && w.fl.phase == PH_AIM) drawRelicOverlay(a);
      else if (w.fl.phase == PH_DEAD) {
        a.invokeOpen = false;
        a.g.fillRect(BOARD_X0, 0, BOARD_X1 - BOARD_X0, SCR_H, 0x200000, clampv(a.deathT * 0.4f, 0.f, 0.6f));
        a.g.textSh("You die...", BOARD_X0, 380, BOARD_X1 - BOARD_X0, 80, 50, 0xff4050, clampv(a.deathT, 0.f, 1.f), F_TITLE, AL_C, VA_M);
      } else if (!a.paused) {
        drawInvocations(a);  // before the board takes its clicks
      }
      if (!a.paused) boardInput(a);
      break;
    }
    case RS_REWARD: drawReward(a); break;
    case RS_STAIRS: drawStairs(a); break;
    case RS_SHOP: drawShop(a); break;
    case RS_REST: drawRest(a); break;
    case RS_ALTAR: drawAltar(a); break;
    case RS_EVENT: drawEvent(a); break;
    default: break;
  }
  if (a.paused) drawPause(a);
}

// ------------------------------------------------------------------ title
static void stepDemo(App& a, float dt) {
  World& d = a.demo;
  if (!a.demoReady) {
    uint64_t seed = a.demoRng.next();
    newRun(d, seed, a.demoRng.range(0, SP_COUNT - 1), a.demoRng.range(0, BG_COUNT - 1));
    // jump to a random biome for variety
    int bi = a.demoRng.range(0, BI_COUNT - 1);
    d.act = bi == BI_HALLS ? 0 : (bi == BI_CORE ? 3 : ((bi <= BI_MINES || bi == BI_SLIME) ? 1 : 2));
    d.depth = 3 + d.act * 6;
    FloorSpec s = makeFloorSpec(d, FK_NORMAL, bi, d.act, 2, a.demoRng.range(1, 999));
    floorBegin(d, s);
    d.log.clear();
    a.demoReady = true;
    a.demoAimT = 0;
    clearPresentation(a);
  }
  if (!d.offers.empty()) chooseOffer(d, 0);
  if (!d.relicOffers.empty()) chooseRelicOffer(d, 0);
  if (d.fl.phase == PH_AIM) {
    a.demoAimT += dt;
    if (a.demoAimT > 1.0f) {
      a.demoAimT = 0;
      launch(d, a.demoRng.rangef(0.35f, PI - 0.35f), d.fl.launchSpeed);
    }
  }
  int steps = 0;
  static float acc = 0;
  acc += dt;
  while (acc >= TICK && steps < 30) {
    floorUpdate(d, TICK);
    acc -= TICK;
    steps++;
  }
  if (d.fl.phase == PH_CLEARED || d.fl.phase == PH_DEAD || d.dead || d.fl.turn > 14) a.demoReady = false;
  d.pl.hp = std::max(d.pl.hp, 1);
  playFx(a, d, false);
}

void drawTitle(App& a) {
  Gfx& g = a.g;
  float dt = 1.f / 60.f;
  stepDemo(a, dt);
  g.vgrad(0, 0, SCR_W, SCR_H, 0x0c0f18, 0x040508);
  if (a.demoReady) drawBoard(a, a.demo, false);
  g.fillRect(0, 0, SCR_W, SCR_H, 0x05060a, 0.55f);
  g.additive(true);
  g.glow(V2(SCR_W / 2, 200), 460, 0x6090ff, 0.16f);
  g.additive(false);
  float bob = std::sin(a.time * 1.3f) * 4;
  g.textSh("DROPCRAWL", 0, 110 + bob, SCR_W, 120, 104, 0xffe6a0, 1.f, F_TITLE, AL_C, VA_M);
  g.text("a roguelike pachinko descent", 0, 228, SCR_W, 30, 20, 0xb8c8e8, 1.f, F_UI, AL_C, VA_M);
  float y = 320;
  float bx = SCR_W / 2 - 150;
  if (a.hasSave) {
    if (button(a, bx, y, 300, 52, "Continue Run", true, 0x80ffb0, 19)) {
      if (tryContinue(a)) a.ui = UI_GAME;
    }
    y += 62;
  }
  if (button(a, bx, y, 300, 52, "New Run", true, 0xffe070, 19)) {
    a.ui = UI_NEWRUN;
    a.seedText.clear();
  }
  y += 62;
  if (button(a, bx, y, 300, 46, "How to Play", true, 0x9fc0ff, 17)) {
    a.ui = UI_HELP;
    a.settingsReturn = UI_TITLE;
    a.helpPage = 0;
  }
  y += 56;
  if (button(a, bx, y, 300, 46, "Hall of Fame", true, 0x9fc0ff, 17)) {
    loadScores(a);
    a.ui = UI_HALL;
  }
  y += 56;
  if (button(a, bx, y, 300, 46, "Settings", true, 0x9fc0ff, 17)) {
    a.settingsReturn = UI_TITLE;
    a.ui = UI_SETTINGS;
  }
  y += 56;
  if (button(a, bx, y, 300, 46, "Quit", true, 0x707888, 17)) a.quit = true;
  g.text("Inspired by Dungeon Crawl Stone Soup", 16, 850, 340, 20, 12, 0x5a6278, 1.f, F_UI, AL_L);
  g.text("v3.0 - Stats, Loot & Guardians", 16, 868, 340, 20, 12, 0x5a6278, 1.f, F_UI, AL_L);
}

// ------------------------------------------------------------------ new run
void startNewRun(App& a, uint64_t seed) {
  newRun(a.w, seed, a.selSpecies, a.selBg, std::min(a.selDescent, a.set.maxDescent));
  clearPresentation(a);
  a.ui = UI_GAME;
  a.paused = false;
  a.deathT = 0;
  a.deathHandled = false;
  a.lastMorgue.clear();
  a.logScroll = 0;
  a.targetAb = a.targetItem = -1;
  // the first-floor hints appear on one run only, ever
  a.tutorialRun = !a.set.tutorialDone;
  if (a.tutorialRun) {
    a.set.tutorialDone = true;
    saveSettings(a);
  }
  writeSave(a);
  a.hasSave = true;
}

void drawNewRun(App& a) {
  Gfx& g = a.g;
  g.vgrad(0, 0, SCR_W, SCR_H, 0x111624, 0x05060a);
  g.textSh("Choose your ball and your background", 0, 16, SCR_W, 44, 32, 0xffe6a0, 1.f, F_TITLE, AL_C, VA_M);
  // species: 6 columns
  g.text("BALL (SPECIES)", 30, 66, 400, 20, 14, 0x8890a8, 1.f, F_UIB);
  g.text("gold border = exotic: plays very differently", 560, 66, 400, 20, 12, 0xc0a060, 1.f, F_UI, AL_R);
  const float SW = 153, SH = 72;
  for (int i = 0; i < SP_COUNT; ++i) {
    const SpeciesDef& s = SPECIES[i];
    float x = 30 + (i % 6) * (SW + 6), y = 88 + (i / 6) * (SH + 6);
    bool sel = a.selSpecies == i, hov = mouseIn(a, x, y, SW, SH);
    g.fillRRect(x, y, SW, SH, 8, sel ? 0x1e2a40 : (hov ? 0x1a2030 : 0x121620), 1.f);
    g.rrect(x, y, SW, SH, 8, s.color, sel ? 1.f : 0.4f, sel ? 2.5f : 1.2f);
    if (s.exotic) g.rrect(x + 3, y + 3, SW - 6, SH - 6, 6, 0xffc040, sel ? 0.9f : 0.45f, 1.f);
    g.additive(true);
    g.glow(V2(x + 22, y + 26), 18, s.color, 0.5f);
    g.additive(false);
    g.fillCircle(V2(x + 22, y + 26), 11, s.color, 1.f);
    g.fillCircle(V2(x + 19, y + 23), 3.5f, 0xffffff, 0.7f);
    g.text(s.name, x + 38, y + 6, SW - 42, 36, 13.5f, 0xffffff, 1.f, F_UIB, AL_L, VA_M);
    g.text(fmt("HP %d  MP %d", previewStartHp(i, BG_WANDERER), previewStartMp(i, BG_WANDERER)), x + 10, y + 46, SW - 16, 18, 11, 0xa8b0c0);
    std::string aff;
    for (int k = 0; k < 3; ++k)
      if (s.aff[k] < SCH_COUNT) aff += (aff.empty() ? "" : ", ") + std::string(SCHOOL_NAME[s.aff[k]]);
    if (hov) {
      std::string stl;
      if (i == SP_CHAOS) stl = "Stats: rolled at random, and grow at random.";
      else {
        float tot = 0;
        for (int k = 0; k < STAT_COUNT; ++k) tot += s.growth[k];
        stl = "Stats:";
        for (int k = 0; k < STAT_COUNT; ++k) stl += fmt(" %s %d", STAT_ABBR[k], s.stat[k]);
        stl += "\nGrowth:";
        for (int k = 0; k < STAT_COUNT; ++k) stl += fmt(" %s %d%%", STAT_ABBR[k], (int)std::lround(100.f * s.growth[k] / std::max(0.1f, tot)));
      }
      setTip(a, s.name, std::string(s.desc) + "\n\n" + stl + "\n\nFavored schools: " + aff + " (offered more often at level-up).", s.color);
      if (a.in.lPressed && !a.in.consumed) {
        a.in.consumed = true;
        a.selSpecies = i;
        audio::play(S_CLICK, 0.6f);
      }
    }
  }
  // backgrounds: 5 columns
  float by0 = 88 + 3 * (SH + 6) + 18;
  g.text("BACKGROUND", 30, by0 - 22, 400, 20, 14, 0x8890a8, 1.f, F_UIB);
  const float BW2 = 184, BH2 = 54;
  for (int i = 0; i < BG_COUNT; ++i) {
    const BackgroundDef& b = BGS[i];
    float x = 30 + (i % 5) * (BW2 + 6), y = by0 + (i / 5) * (BH2 + 6);
    bool sel = a.selBg == i, hov = mouseIn(a, x, y, BW2, BH2);
    uint32_t sc = b.ability < AB_COUNT ? SCHOOL_COLOR[ABIL[b.ability].school] : 0xffffff;
    if (b.patron >= 0) sc = PATRON[b.patron].color;
    g.fillRRect(x, y, BW2, BH2, 8, sel ? 0x1e2a40 : (hov ? 0x1a2030 : 0x121620), 1.f);
    g.rrect(x, y, BW2, BH2, 8, sc, sel ? 1.f : 0.4f, sel ? 2.5f : 1.2f);
    if (b.exotic) g.rrect(x + 3, y + 3, BW2 - 6, BH2 - 6, 6, 0xffc040, sel ? 0.9f : 0.45f, 1.f);
    g.text(b.name, x + 10, y + 5, BW2 - 16, 20, 14, 0xffffff, 1.f, F_UIB);
    std::string sub = b.ability < AB_COUNT ? ABIL[b.ability].name : "Random abilities";
    if (b.patron >= 0) sub += std::string(" + ") + PATRON[b.patron].name;
    if (b.patron == -2) sub += " + a random god";
    g.text(sub, x + 10, y + 28, BW2 - 16, 20, 11.5f, sc, 1.f, F_UI);
    if (hov) {
      std::string mods;
      for (int k = 0; k < STAT_COUNT; ++k)
        if (b.stat[k]) mods += fmt("%s%s %+d", mods.empty() ? "" : ", ", STAT_ABBR[k], (int)b.stat[k]);
      setTip(a, b.name, std::string(b.desc) + (mods.empty() ? "" : "\n\nStats: " + mods), sc);
      if (a.in.lPressed && !a.in.consumed) {
        a.in.consumed = true;
        a.selBg = i;
        audio::play(S_CLICK, 0.6f);
      }
    }
  }
  // details
  const SpeciesDef& s = SPECIES[a.selSpecies];
  const BackgroundDef& b = BGS[a.selBg];
  panelBox(a, 990, 66, 580, 714, s.color);
  float y = 80;
  g.text(std::string(s.name) + " " + b.name, 1010, y, 540, 34, 24, 0xffffff, 1.f, F_TITLE);
  y += 40;
  y += wrapText(a, s.desc, 1010, y, 540, 13.5f, 0xc8d0dc) + 8;
  y += wrapText(a, b.desc, 1010, y, 540, 13.5f, 0xc8d0dc) + 12;
  g.text(fmt("Starting HP %d   MP %d   Power %d   Armor %d   Gold %d", previewStartHp(a.selSpecies, a.selBg),
             previewStartMp(a.selSpecies, a.selBg), s.power, s.armor, b.gold + (a.selSpecies == SP_GILDED ? 60 : 0)),
         1010, y, 540, 20, 13.5f, 0xffe070, 1.f, F_UIB);
  y += 24;
  {
    bool rnd = a.selSpecies == SP_CHAOS || a.selBg == BG_WANDERER;
    float sx = 1010;
    for (int k = 0; k < STAT_COUNT; ++k) {
      int v = std::max(1, s.stat[k] + b.stat[k]);
      std::string lab = fmt("%s %s", STAT_ABBR[k], rnd ? "?" : std::to_string(v).c_str());
      g.fillRRect(sx, y, 70, 22, 5, STAT_COLOR[k], 0.14f);
      g.rrect(sx, y, 70, 22, 5, STAT_COLOR[k], 0.55f, 1);
      g.text(lab, sx, y, 70, 22, 13, STAT_COLOR[k], 1.f, F_UIB, AL_C, VA_M);
      if (mouseIn(a, sx, y, 70, 22))
        setTip(a, STAT_NAME[k], rnd ? std::string("Rolled at random when the run begins.") : statEffectText(k, v), STAT_COLOR[k]);
      sx += 76;
    }
    y += 32;
  }
  if (b.ability < AB_COUNT && a.selBg != BG_WANDERER) {
    const AbilityDef& d = ABIL[b.ability];
    g.text("Starting ability: " + std::string(d.name), 1010, y, 540, 22, 15, SCHOOL_COLOR[d.school], 1.f, F_UIB);
    y += 22;
    y += wrapText(a, abilityDesc(b.ability, 1, false), 1010, y, 540, 13, 0xdde2ec) + 8;
  } else {
    g.text("Starting abilities: random (one already practised)", 1010, y, 540, 22, 15, 0xffffff, 1.f, F_UIB);
    y += 28;
  }
  if (b.patron >= 0) {
    const PatronDef& P = PATRON[b.patron];
    g.text(fmt("Patron: %s %s (first gift: %s)", P.name, P.title, ABIL[P.gifts[0]].name), 1010, y, 540, 20, 13, P.color, 1.f, F_UIB);
    y += 24;
  } else if (b.patron == -2) {
    g.text("Patron: a random god (first gift unlocked)", 1010, y, 540, 20, 13, 0xfff0c0, 1.f, F_UIB);
    y += 24;
  }
  std::string items;
  for (int k = 0; k < 2; ++k) {
    if (b.items[k] >= 0) items += (items.empty() ? "" : ", ") + std::string(ITEM[b.items[k]].name);
    if (b.items[k] == -2) items += (items.empty() ? "" : ", ") + std::string("a random item");
  }
  if (a.selBg == BG_ARTIFICER) items = "three random wands";
  if (a.selBg == BG_WANDERER) items = "random potions, scrolls and gear";
  if (!items.empty()) {
    y += wrapText(a, "Items: " + items, 1010, y, 540, 13, 0xb8c0d0) + 8;
  }
  y += 6;
  wrapText(a,
           "Every level-up offers a choice of new abilities or upgrades and raises a stat; every third level you pick a "
           "stat to raise by 2. Each run is seeded: the same seed and choices always produce the same dungeon.",
           1010, y, 540, 12, 0x8890a0);
  // descent level
  a.selDescent = clampv(a.selDescent, 0, a.set.maxDescent);
  g.text("Descent level:", 1010, 646, 200, 26, 14, 0xa8b0c0, 1.f, F_UI, AL_L, VA_M);
  if (button(a, 1150, 644, 30, 30, "-", a.selDescent > 0, 0x9fc0ff, 16)) a.selDescent--;
  g.text(std::to_string(a.selDescent), 1184, 644, 40, 30, 18, a.selDescent ? 0xff9060 : 0xffffff, 1.f, F_UIB, AL_C, VA_M);
  if (button(a, 1228, 644, 30, 30, "+", a.selDescent < a.set.maxDescent, 0x9fc0ff, 16)) a.selDescent++;
  g.text(a.set.maxDescent == 0 ? std::string("Win a run to unlock harder descents.") : std::string(descentText(a.selDescent)), 1270, 638, 290,
         44, 12, 0x98a0b0, 1.f, F_UI, AL_L, VA_M);
  g.text("Seed (optional):", 1010, 700, 200, 22, 14, 0xa8b0c0, 1.f, F_UI, AL_L, VA_M);
  bool hov = mouseIn(a, 1150, 696, 400, 30);
  if (hov && a.in.lPressed && !a.in.consumed) {
    a.in.consumed = true;
    a.seedFocus = true;
  } else if (a.in.lPressed && !hov) a.seedFocus = false;
  g.fillRRect(1150, 696, 400, 30, 5, 0x0a0c12, 1.f);
  g.rrect(1150, 696, 400, 30, 5, a.seedFocus ? 0xffe070 : 0x505868, 1.f, 1.2f);
  std::string st = a.seedText.empty() && !a.seedFocus ? "random" : a.seedText + (a.seedFocus && std::fmod(a.time, 1.f) < 0.5f ? "|" : "");
  g.text(st, 1160, 696, 380, 30, 15, a.seedText.empty() ? 0x606878 : 0xffffff, 1.f, F_MONO, AL_L, VA_M);
  if (a.seedFocus) {
    for (char c : a.in.chars)
      if (c >= '0' && c <= '9' && a.seedText.size() < 18) a.seedText += c;
    if (a.in.keyPressed[KEY_BACK] && !a.seedText.empty()) a.seedText.pop_back();
  }
  if (button(a, 990, 800, 170, 52, "Back", true, 0x707888, 17)) a.ui = UI_TITLE;
  if (button(a, 1170, 800, 170, 52, "Random", true, 0x9fc0ff, 17)) {
    a.selSpecies = (int)(a.demoRng.next() % SP_COUNT);
    a.selBg = (int)(a.demoRng.next() % BG_COUNT);
  }
  if (button(a, 1350, 800, 220, 52, "Begin!", true, 0xffe070, 20) || (a.in.keyPressed[KEY_ENTER] && !a.seedFocus)) {
    uint64_t seed = 0;
    if (!a.seedText.empty()) seed = std::strtoull(a.seedText.c_str(), nullptr, 10);
    if (seed == 0) seed = (mix64((uint64_t)tickCount()) % 999999999ull) + 1;
    startNewRun(a, seed);
  }
}

// ------------------------------------------------------------------ hall of fame
void loadScores(App& a) {
  a.scores.clear();
  std::ifstream f(std::filesystem::path(a.baseDir + L"\\scores.txt"));
  std::string line;
  while (std::getline(f, line)) {
    if (line.empty()) continue;
    ScoreEntry e;
    e.score = atoi(line.c_str());
    size_t p = line.find('|');
    e.line = p == std::string::npos ? line : line.substr(p + 1);
    a.scores.push_back(e);
  }
  std::sort(a.scores.begin(), a.scores.end(), [](const ScoreEntry& x, const ScoreEntry& y) { return x.score > y.score; });
}

void drawHall(App& a) {
  Gfx& g = a.g;
  g.vgrad(0, 0, SCR_W, SCR_H, 0x141a28, 0x05060a);
  g.textSh("Hall of Fame", 0, 30, SCR_W, 60, 44, 0xffe6a0, 1.f, F_TITLE, AL_C, VA_M);
  panelBox(a, 200, 110, 1200, 680, 0xffd040);
  if (a.scores.empty()) g.text("No runs recorded yet. Go make some history!", 200, 400, 1200, 40, 18, 0xa8b0c0, 1.f, F_UI, AL_C);
  float y = 130;
  for (size_t i = 0; i < a.scores.size() && i < 24; ++i) {
    const ScoreEntry& e = a.scores[i];
    g.text(fmt("%2d.", (int)i + 1), 220, y, 50, 24, 15, 0x8890a0, 1.f, F_MONO);
    g.text(fmt("%7d", e.score), 270, y, 110, 24, 15, 0xffe070, 1.f, F_MONOB);
    g.text(e.line, 400, y, 980, 24, 14, 0xd0d8e4, 1.f, F_UI);
    y += 27;
  }
  g.text("Character files of every run are saved in the 'morgue' folder next to the game.", 200, 800, 1200, 20, 13, 0x707888, 1.f,
         F_UI, AL_C);
  if (button(a, SCR_W / 2 - 100, 832, 200, 46, "Back", true, 0x9fc0ff, 17)) a.ui = UI_TITLE;
}

// ------------------------------------------------------------------ settings
static bool slider(App& a, float x, float y, float w, const std::string& label, float& v) {
  Gfx& g = a.g;
  g.text(label, x, y, 200, 26, 15, 0xd0d8e4, 1.f, F_UI, AL_L, VA_M);
  float bx = x + 210, bw = w - 280;
  bool hov = mouseIn(a, bx - 8, y, bw + 16, 26);
  g.fillRRect(bx, y + 10, bw, 6, 3, 0x2a3040, 1.f);
  g.fillRRect(bx, y + 10, bw * v, 6, 3, 0x6090ff, 1.f);
  g.fillCircle(V2(bx + bw * v, y + 13), hov ? 10 : 8, 0xe0e8ff, 1.f);
  g.text(fmt("%d%%", (int)std::lround(v * 100)), bx + bw + 14, y, 60, 26, 14, 0xa8b0c0, 1.f, F_UI, AL_L, VA_M);
  if (hov && a.in.lDown) {
    v = clampv((a.in.mouse.x - bx) / bw, 0.f, 1.f);
    return true;
  }
  return false;
}

static bool toggle(App& a, float x, float y, const std::string& label, bool& v) {
  Gfx& g = a.g;
  bool hov = mouseIn(a, x, y, 400, 28);
  g.fillRRect(x, y + 3, 22, 22, 5, v ? 0x3a70e0 : 0x1a1e28, 1.f);
  g.rrect(x, y + 3, 22, 22, 5, 0x9fc0ff, hov ? 1.f : 0.6f, 1.2f);
  if (v) g.text("x", x, y + 3, 22, 22, 15, 0xffffff, 1.f, F_MONOB, AL_C, VA_M);
  g.text(label, x + 34, y, 360, 28, 15, 0xd0d8e4, 1.f, F_UI, AL_L, VA_M);
  if (hov && a.in.lPressed && !a.in.consumed) {
    a.in.consumed = true;
    v = !v;
    audio::play(S_CLICK, 0.6f);
    return true;
  }
  return false;
}

void drawSettings(App& a) {
  Gfx& g = a.g;
  g.vgrad(0, 0, SCR_W, SCR_H, 0x141a28, 0x05060a);
  g.textSh("Settings", 0, 40, SCR_W, 60, 44, 0xffe6a0, 1.f, F_TITLE, AL_C, VA_M);
  panelBox(a, 450, 130, 700, 560, 0x9fc0ff);
  float x = 490, y = 170;
  bool ch = false;
  ch |= slider(a, x, y, 620, "Master volume", a.set.master);
  ch |= slider(a, x, y + 44, 620, "Sound effects", a.set.sfx);
  ch |= slider(a, x, y + 88, 620, "Music", a.set.music);
  ch |= toggle(a, x, y + 150, "Screen shake", a.set.shake);
  ch |= toggle(a, x, y + 190, "Floating damage numbers", a.set.numbers);
  bool fs = a.set.fullscreen;
  if (toggle(a, x, y + 230, "Fullscreen (F11)", fs)) {
    setFullscreen(a, fs);
    ch = true;
  }
  bool fast = a.set.speed >= 2;
  if (toggle(a, x, y + 270, "Start games in fast mode (x2)", fast)) {
    a.set.speed = fast ? 2 : 1;
    ch = true;
  }
  bool tut = !a.set.tutorialDone;
  if (toggle(a, x, y + 310, "Show the tutorial hints on the next run", tut)) {
    a.set.tutorialDone = !tut;
    ch = true;
  }
  g.text("Controls", x, y + 360, 400, 24, 16, 0xffe070, 1.f, F_UIB);
  wrapText(a,
           "Mouse: aim, click to launch. Right-click a monster to focus it.\n1-9, 0, -, =: abilities   G: invocations   Z-N: items   Tab: focus\n"
           "A / D or Left / Right: flippers   Hold Space: fast-forward   F: toggle speed\nEsc: pause menu   F11: fullscreen   F12: screenshot",
           x, y + 390, 620, 14, 0xb8c0d0);
  if (ch) {
    applySettings(a);
    saveSettings(a);
  }
  if (button(a, SCR_W / 2 - 100, 720, 200, 46, "Back", true, 0x9fc0ff, 17)) a.ui = a.settingsReturn;
}

// ------------------------------------------------------------------ help
void drawHelp(App& a) {
  Gfx& g = a.g;
  g.vgrad(0, 0, SCR_W, SCR_H, 0x141a28, 0x05060a);
  static const char* TITLES[] = {"The Basics",  "Special Pegs",            "More Pegs & Board Toys",        "Monsters",
                                 "Stats & Loot", "Growing Stronger",       "Boards, Runes & Champions",     "Gods, Chaos & Strange Balls",
                                 "Tips"};
  const int NP = 9;
  a.helpPage = clampv(a.helpPage, 0, NP - 1);
  g.textSh("How to Play: " + std::string(TITLES[a.helpPage]), 0, 24, SCR_W, 54, 38, 0xffe6a0, 1.f, F_TITLE, AL_C, VA_M);
  panelBox(a, 140, 96, 1320, 700, 0x9fc0ff);
  float x = 180, y = 120, w = 1240;
  switch (a.helpPage) {
    case 0:
      wrapText(a,
               "Dropcrawl is a pachinko roguelike. You descend through a dungeon made of pachinko boards, fighting the monsters "
               "that live on them, until you reach the Core and beat the House.\n\n"
               "AIMING: Move the mouse to aim the launcher at the top of the board, and click to launch a ball. The dotted guide shows "
               "the ball's path up to its first bounce (abilities and relics can show more; some monsters can blind you).\n\n"
               "POWER: Your ball starts with your base power and gains +1 for every pin it hits. Special pegs and board toys add more, "
               "or multiply it.\n\n"
               "DAMAGE: When the ball hits a monster, it deals damage equal to its current power, then its power resets. When a ball "
               "leaves the board, it discharges HALF its remaining power into your focus target (all of it, from a Strike pocket). "
               "Right-click a monster to choose your focus target. A ball that keeps bouncing on a monster without touching any peg "
               "loses force (glancing blows), so build power between hits!\n\n"
               "TURNS: After your shot, monsters act. Each monster shows its next action (its intent) above it, with a countdown. "
               "A red countdown means it acts after your next shot. Everything is visible: plan around it!\n\n"
               "Clear a floor by killing every monster. Then pick your next room from the stairs: fights, elites, shops, rest sites, "
               "treasure vaults, altars and events. Each area ends with a Guardian. After the first area you choose which branches "
               "to explore. Collect two Runes, then descend to the Core.",
               x, y, w, 16, 0xdde2ec);
      break;
    case 1: {
      static const int KS[] = {PK_PIN,  PK_CRIT,  PK_GOLD,    PK_HEAL,  PK_MANA,   PK_MULTI,  PK_FIRE,    PK_ICE,   PK_POISON,
                               PK_SPARK, PK_CRYSTAL, PK_BOMB, PK_CURSE, PK_XP,    PK_REFRESH, PK_TELEPORT, PK_JELLY, PK_MIRROR,
                               PK_VAMPIRE, PK_CHAOS, PK_FREEZE, PK_CLOVER, PK_ANVIL, PK_FEATHER, PK_VOID, PK_SHIELD, PK_SEED, PK_RUNE};
      int n = sizeof(KS) / sizeof(KS[0]);
      for (int i = 0; i < n; ++i) {
        float cx = x + (i % 2) * 620, cy = y + (i / 2) * 42;
        Peg p;
        p.kind = (uint8_t)KS[i];
        p.p = V2(cx + 18, cy + 16);
        p.r = KS[i] == PK_BOMB ? 9.f : PIN_R + 1;
        p.hp = 3;
        p.val = 3;
        drawPeg(a, p, 1.f, 0xc6cfdb);
        g.text(PEG_NAME[KS[i]], cx + 44, cy, 150, 32, 14, PEG_COLOR[KS[i]], 1.f, F_UIB, AL_L, VA_M);
        g.text(PEG_DESC[KS[i]], cx + 190, cy, 420, 32, 12.5f, 0xc8d0dc, 1.f, F_UI, AL_L, VA_M);
      }
      wrapText(a, "Special pegs are used up when hit and turn back into plain pins at the end of your shot. New ones appear every turn, "
                  "and every floor features a few rarer kinds, so no two boards play alike.",
               x, y + 600, w, 14, 0xdde2ec);
      break;
    }
    case 2: {
      static const int KS[] = {PK_BUMPER, PK_TULIP,  PK_CHUCKER, PK_TARGET, PK_MAGNET, PK_SPRING,   PK_COINS, PK_BELL,  PK_GHOST,
                               PK_FIREFLY, PK_EGG,   PK_MBOMB,   PK_CHEST,  PK_KEY,    PK_LOOT,     PK_SHRINE, PK_WELL, PK_MIMIC,
                               PK_SHARD,  PK_PINATA, PK_GEM,     PK_PRISM,  PK_DICE,   PK_STAR,     PK_MOON,  PK_HOURGLASS,
                               PK_BLOOD,  PK_CANNON, PK_ROD,     PK_COMBO,  PK_SNOWBALL, PK_ECHO,   PK_BRAND, PK_JACKPOT};
      int n = sizeof(KS) / sizeof(KS[0]);
      for (int i = 0; i < n; ++i) {
        float cx = x + (i % 2) * 620, cy = y + (i / 2) * 39;
        Peg p;
        p.kind = (uint8_t)KS[i];
        p.p = V2(cx + 18, cy + 16);
        bool big = KS[i] == PK_BUMPER || KS[i] == PK_CHEST || KS[i] == PK_SHRINE || KS[i] == PK_WELL || KS[i] == PK_MIMIC;
        p.r = big ? 12.f : isEnchant(KS[i]) ? PIN_R + 1.f : 9.f;
        p.hp = 3;
        p.val = KS[i] == PK_LOOT ? 1 : 3;
        p.aux = KS[i] == PK_MBOMB ? 1 : 2;
        drawPeg(a, p, 1.f, 0xc6cfdb);
        bool mim = KS[i] == PK_MIMIC;
        g.text(mim ? "Mimic" : PEG_NAME[KS[i]], cx + 44, cy, 150, 32, 13.5f, PEG_COLOR[KS[i]], 1.f, F_UIB, AL_L, VA_M);
        g.text(mim ? "Looks just like a treasure chest - until you hit it. Kill it for its loot." : PEG_DESC[KS[i]], cx + 190, cy, 420, 34,
               11.5f, 0xc8d0dc, 1.f, F_UI, AL_L, VA_M);
      }
      break;
    }
    case 3: {
      static const int IK[] = {IN_ATTACK, IN_HEAVY, IN_BLOCK, IN_HEAL, IN_BUFF, IN_SUMMON, IN_HEX, IN_BOMB, IN_WALL, IN_DRAIN,
                               IN_POISON, IN_WEAKEN, IN_TOTEM, IN_CURSEPOCKET, IN_EGGS, IN_WEB, IN_BLIND, IN_CURSEBALL, IN_ENRAGE,
                               IN_BEAM, IN_ACID, IN_MUTATEPEGS, IN_SWAP, IN_DECOY, IN_FREEZEPOCKET, IN_DEVOUR, IN_GRAVITY, IN_RANDOM,
                               IN_QUAKE, IN_LIFEDRAIN, IN_DISPEL, IN_EXECUTE, IN_SUNDER, IN_METEOR};
      static const char* ID[] = {"Attack: deals damage to you (reduced by armor).",
                                 "Heavy attack: big damage that ignores armor.",
                                 "Block: absorbs damage from your next shot.",
                                 "Heal: restores HP to all monsters.",
                                 "Rally: all monsters deal more damage from now on.",
                                 "Summon: calls reinforcements (they give no XP).",
                                 "Hex: turns pins into Curse pegs that halve your power.",
                                 "Bomb: plants a bomb that explodes on you unless you hit it.",
                                 "Barrier: raises walls around itself; break them with balls.",
                                 "Drain: steals your MP.",
                                 "Poison: damages you each turn (halving each time).",
                                 "Weaken / Sap / Slow: lowers your power or MP regeneration.",
                                 "Totem: shields its master until you break it.",
                                 "Curse pocket: turns a pocket into one that hurts you.",
                                 "Eggs: they hatch into monsters unless you smash them.",
                                 "Webs: sticky zones that slow your ball.",
                                 "Blind: hides your aiming guide for a while.",
                                 "Drain ball: your next ball starts with half power.",
                                 "Enrage: its next attack deals double damage.",
                                 "Beam: a big blast - deal enough damage to interrupt it!",
                                 "Acid: dissolves pins and corrodes your armor.",
                                 "Warp pegs: turns your special pegs into curses.",
                                 "Swap: trades places with another monster.",
                                 "Mirror images: illusions that die in one hit.",
                                 "Freeze pocket: a pocket stops working for 2 turns.",
                                 "Devour: eats nearby special pegs to heal.",
                                 "Gravity well: bends your ball's path.",
                                 "Chaos: anything at all!",
                                 "Quake: heavy damage, and the board's magic shakes loose.",
                                 "Drain life: hurts you and heals it twice as much.",
                                 "Dispel: strips your Block, Guardian and charged shots.",
                                 "Execute: hits harder the more HP you are missing.",
                                 "Sunder: damage, and your armor drops for 3 turns.",
                                 "Meteor: smash its burning marker (3 hits) before it lands!"};
      int n = sizeof(IK) / sizeof(IK[0]);
      for (int i = 0; i < n; ++i) {
        float cx = x + (i % 2) * 620, cy = y + (i / 2) * 31;
        drawIcon(g, IK[i], V2(cx + 16, cy + 13), 10, 0xffa0a0);
        g.text(ID[i], cx + 40, cy, 570, 26, 13, 0xdde2ec, 1.f, F_UI, AL_L, VA_M);
      }
      wrapText(a,
               "GUARDIANS act every turn and often do two things at once (\"summon, then attack\"). Their biggest blows show a "
               "longer countdown, so you can prepare: block them, interrupt them or kill the Guardian first. They change tactics as "
               "they lose health, and after 12 turns they become enraged (+50% damage). Traits: Ethereal, Evasive, Flying, Armored, "
               "Hardened, Regenerating, Undying, Splitting, Volatile, Acidic, Blinking, healing Auras, Undead and Demonic.",
               x, y + 548, w, 14, 0xdde2ec);
      break;
    }
    case 4:
      wrapText(a,
               "STATS: Every ball has five stats. Values above 5 give bonuses, values below 5 give penalties:\n"
               "  STRENGTH - +4% ball damage per point.\n"
               "  DEXTERITY - 2% chance per point for each ball hit to be a critical hit (x1.5 damage), and +1% per point above 5 "
               "to dodge an attack entirely.\n"
               "  INTELLIGENCE - +1 max MP per 2 points, +1 MP regeneration per 3 points, +6% spell damage and +4% ally damage per point.\n"
               "  VITALITY - +3 max HP and +2% healing per point.\n"
               "  LUCK - +4% gold, better loot, +1% critical hits, and a chance for special pegs to trigger twice.\n"
               "Every level raises one stat (weighted by your ball's growth); every third level you choose a stat to raise by 2. "
               "Gems, shrines, relics and the Tumbler can change them too. Hover the stat boxes for details.\n\n"
               "LOOT: Relics come in grades, shown by colour. White relics are plain. BLUE (magic) relics roll one or two random "
               "affixes, like \"Mighty Iron Ring of the Fox\". YELLOW randarts roll two to six properties. ORANGE uniques are curated "
               "legendaries built around a school or mechanic (the Crown of the Tempest, Heart of the Inferno, Voidheart...). GREEN "
               "set relics grant extra bonuses when you own two or three pieces of the same set. Luck improves your odds.\n\n"
               "Monsters sometimes drop LOOT ORBS onto the board: hit one to grab it right away (anything left is collected when the "
               "floor ends). RELIC SHARDS fuse into a relic of your choice when you have three. TREASURE IMPS run away with their "
               "hoard after four turns - catch them! And beware of treasure chests with teeth.",
               x, y, w, 16, 0xdde2ec);
      break;
    case 5:
      wrapText(a,
               "LEVELS: Killing monsters grants XP. Every level gives +1 base power, more HP, a stat increase, and a choice of new "
               "abilities or upgrades. There are about 160 abilities across fourteen schools: Force, Flame, Frost, Storm, Earth, "
               "Arcane, Life, Fortune, Shadow, Clockwork, Blood (paid for with HP), Chaos, Summoning and Void. Your ball type makes "
               "some schools appear more often.\n\n"
               "ACTIVE abilities cost MP (you regain MP every turn). Some are used before launching, others while the ball is flying. "
               "PASSIVE abilities are always on. Guardian Spirit only protects you during the enemy phase right after you cast it - "
               "save it for the big hits.\n\n"
               "RELICS are permanent items from elite fights, Guardians, shops, chests, events and loot. ITEMS: potions and scrolls are "
               "single-use; WANDS have charges and are aimed at a target. Use items before launching.\n\n"
               "MUTATIONS change your ball permanently. Some come from potions, pools of chaos and demons; the Fiendball grows a whole "
               "set of demonic facets as it levels.\n\n"
               "BRANCHES: After the Upper Halls, choose one of the Fungal Lair, the Drowned Halls, the Clockwork Mines or the Slime "
               "Pits (three are offered). After that, one of the Crypt, the Ember Forge, the Frozen Vaults or the Abyss.",
               x, y, w, 16, 0xdde2ec);
      break;
    case 6:
      wrapText(a,
               "BOARD FORMATS: Every floor has a shape - an open Classic board, a Funnel, a Split, stacked Tiers, a Plinko grid, an "
               "Arena ring, an Hourglass, a rocky Cavern, Zigzag ramps, Islands, a Bumper Bowl, a moving Carnival, a Pachislot "
               "machine or a symmetrical Temple. The stairs tell you which one is coming. Then 25 kinds of pin layouts and over "
               "fifty set pieces are thrown on top: tulips, slot machines, drop targets, rollover lanes, kickers, pendulums, "
               "windmills, gear towers, geysers, rifts, shrines, healing wells, pinatas, dice tables, cannon batteries, lightning "
               "rods, constellations, rune roads, gem clusters, locked cages...\n\n"
               "RUNES: A ball crossing a rune circle gains a random rune. Runes of a school you study (Pyromancer, Winter, Tempest, "
               "Mountain, Arcanist, Life, Fortune, Shadows, Gears, Blood Moon, Mayhem, Pack, Abyss, Force) appear more often and grow "
               "with your levels in that school. A ball that collects two runes can spell a RUNEWORD: Fire + Storms = Plasma, Frost + "
               "Iron = Glacier, Venom + Thorns = Pestilence, Luck + Gold = Fortune's Favor, Power + Might = Titan, Magic + Echoes = "
               "Resonance, Light + Iron = Aegis, Void + Chaos = Oblivion, Splitting + Precision = Barrage, Blood + Growth = Vitality, "
               "Wisdom + Magic = Enlightenment, Fire + Growth = Wildfire. Rune pegs grant a minor rune too.\n\n"
               "CHAMPIONS (blue names) and UNIQUE monsters (gold names) carry random affixes - Extra Strong, Extra Fast, Stone Skin, "
               "Vampiric, Regenerating, Shielded, Teleporting, Thorny, Cursed, Mana Burn, Splitting, Horde, Healing Aura, Multishot, "
               "Berserker, Fire or Cold Enchanted - and give more XP, gold and loot.\n\n"
               "POCKETS (7-9 per board, from 37 kinds): Free Turn, Strike, Heal, Mana, Gold, Charge, Double, Refresh, Wisdom, Shield, "
               "Multiball, Bomb, Freeze, Burn, Plague, Lottery, Chaos, Bank, Loot, Shrine, Relaunch, Summon, Smite, Scatter, "
               "Training, Delay, Gamble, Shard, Slots and Prayer - and, deeper down, Empty, Void, Trap and Tax.",
               x, y, w, 15, 0xdde2ec);
      break;
    case 7:
      wrapText(a,
               "PATRONS: At an altar you may pledge yourself to one of seventeen gods. Each has likes and dislikes, earns you piety, "
               "and grants five gifts as your piety grows: invocations (which cost piety, and live in their own window: press G or "
               "click Invoke under your god) and passive blessings. Arcana deals "
               "cards from the Deck of Fates; Ruun trades your sacrifices for raw power; Glub reshapes you with slime; the Ancestor "
               "launches a ball beside yours; Voidmaw bends space; Aurelia smites the unholy; Brakka rewards duels with the strongest; "
               "Sifra empowers spellcraft; Tempestra tears up the board with storms.\n\n"
               "THE TUMBLER, Lord of Chance, is a capricious god in the spirit of Xom. It watches its worshippers, Chaos Orbs, and "
               "anyone carrying chaotic trinkets. When amused it meddles kindly; when bored, cruelly. It can heal you, smite monsters, "
               "rain bombs, rebuild the whole board into a new shape, mirror it, polymorph and charm monsters, crown champions, "
               "summon new foes, drop loot and pinatas, swap your stats, repaint every pocket, snatch your ball mid-flight and drop "
               "it somewhere else, turn it into a comet, flip gravity, and much more - about ninety tricks in all.\n\n"
               "EXOTIC BALLS (gold border) play very differently: the Fiendball grows unique demonic facets; the Drakeball takes a "
               "random draconic color with a breath weapon at XL 5; the Djinn has no MP and casts with HP; the Nine-Lives Ball "
               "returns from death; the Changeling becomes a different ball on every floor; the Chaos Orb rolls random stats, "
               "mutates and entertains the Tumbler. The WANDERER background starts with a random, practised mix of skills, stats "
               "and gear.",
               x, y, w, 16, 0xdde2ec);
      break;
    case 8:
      wrapText(a,
               "- Read the intents. Kill (or Freeze, Chill, Bribe...) the monster about to hit hardest. Interrupt beams and smash "
               "meteor markers!\n"
               "- Guardians hit hard and fast. Go in with high HP, and save Guardian Spirit, Block and Sanctuary for the telegraphed "
               "big blows.\n"
               "- The Free Turn pocket is huge: monsters skip their turn. Rotor and Lucky Coin help you aim for it.\n"
               "- Long bounce chains build power. Aim through tulips, kickers and dense pins before reaching a monster.\n"
               "- Crit pegs multiply everything the ball has so far. Hit them late in the path for the biggest effect.\n"
               "- Grab loot orbs, gems and shrines early: their bonuses help for the rest of the floor.\n"
               "- Kill champions and treasure imps for loot. Magic, unique and set relics are how builds get strong.\n"
               "- Your stats shape your build: Strength for ball damage, Dexterity for crits and dodging, Intelligence for "
               "spells and summons, Vitality to survive, Luck for loot.\n"
               "- Hold Space to fast-forward long shots. Press F to toggle double speed.\n"
               "- Every run is seeded. The dungeon is fair: everything a monster will do is shown before it happens. Only the "
               "Tumbler is truly unpredictable - and you chose to let it watch you. When you die, look back at your choices!\n\n"
               "Your run is saved automatically. Character files (morgue) of every run are written to the 'morgue' folder.",
               x, y, w, 16, 0xdde2ec);
      break;
  }
  if (button(a, 140, 820, 180, 46, "< Previous", a.helpPage > 0, 0x9fc0ff, 16)) a.helpPage--;
  if (button(a, 1280, 820, 180, 46, "Next >", a.helpPage < NP - 1, 0x9fc0ff, 16)) a.helpPage++;
  if (button(a, SCR_W / 2 - 100, 820, 200, 46, "Back", true, 0x9fc0ff, 17)) a.ui = a.settingsReturn;
  g.text(fmt("Page %d / %d", a.helpPage + 1, NP), 0, 876, SCR_W, 20, 12, 0x707888, 1.f, F_UI, AL_C);
}
