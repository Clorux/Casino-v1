// Dropcrawl - procedural board generation, special peg tables, floor modifiers, floor specs
#include "rules.h"

bool hasMod(const World& w, int mod) {
  for (int i = 0; i < w.fl.spec.nMods; ++i)
    if (w.fl.spec.mods[i] == mod) return true;
  return false;
}

// ---------------------------------------------------------------- pockets
void layoutPockets(World& w) {
  Floor& f = w.fl;
  int n = (int)f.pockets.size();
  if (n == 0) return;
  std::vector<float> wt(n);
  float tot = 0;
  for (int i = 0; i < n; ++i) {
    float x = 1.f;
    switch (f.pockets[i].kind) {
      case PO_RECALL: x = 0.72f * w.st.recallWidth; break;
      case PO_JACKPOT: x = 0.8f; break;
      case PO_STRIKE: x = w.st.strikeWidth; break;
      case PO_DOUBLE: case PO_FREEZE: x = 0.85f; break;
      case PO_MULTI: case PO_CHAOS: x = 0.9f; break;
      case PO_VOID: x = 0.7f; break;
    }
    wt[i] = x;
    tot += x;
  }
  float x = PX0;
  for (int i = 0; i < n; ++i) {
    float wdt = (PX1 - PX0) * wt[i] / tot;
    f.pockets[i].x0 = x;
    f.pockets[i].x1 = x + wdt;
    x += wdt;
  }
  for (int i = 0; i < n - 1 && i < MAX_POCKETS; ++i) {
    int si = f.dividerSeg[i];
    if (si < 0 || si >= (int)f.segs.size()) continue;
    float dx = f.pockets[i].x1;
    f.segs[si].a = V2(dx, POCKET_TOP);
    f.segs[si].b = V2(dx, 900);
    f.segs[si].c = V2(dx, (POCKET_TOP + 900) * 0.5f);
  }
}

static void setupPockets(World& w) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  int depth = f.spec.depth;
  std::vector<uint8_t> k;
  if (f.spec.kind == FK_VAULT) {
    k = {PO_GOLD, PO_JACKPOT, PO_GOLD, PO_RECALL, PO_GOLD, PO_JACKPOT, PO_GOLD};
    if (R.chance(0.5f)) k.insert(k.begin() + 5, (uint8_t)PO_LOTTERY);
  } else {
    int n = depth < 4 ? 7 : depth < 11 ? R.range(7, 8) : R.range(8, 9);
    bool noRecall = w.st.noRecall;
    k = {PO_STRIKE, PO_STRIKE};
    if (!noRecall) k.push_back(PO_RECALL);
    struct PW {
      uint8_t kind;
      float w;
      int minDepth;
    };
    std::vector<PW> pool = {{PO_HEAL, 3.f, 1},    {PO_MANA, 3.f, 1},    {PO_GOLD, 3.f, 1},    {PO_POWER, 3.f, 1},
                            {PO_DOUBLE, 1.5f, 2}, {PO_REFRESH, 1.2f, 1}, {PO_XP, 1.2f, 1},     {PO_SHIELD, 1.5f, 1},
                            {PO_MULTI, 1.f, 3},   {PO_BOMB, 1.2f, 2},   {PO_FREEZE, 0.7f, 4}, {PO_BURN, 1.f, 2},
                            {PO_POISON, 1.f, 2},  {PO_LOTTERY, 1.2f, 1}, {PO_CHAOS, 0.8f, 3}, {PO_BANK, 0.8f, 3},
                            {PO_EMPTY, 1.f, 10},  {PO_VOID, 0.5f, 12},
                            {PO_LOOT, 1.1f, 1},   {PO_SHRINE, 0.5f, 2}, {PO_RELAUNCH, 0.9f, 1}, {PO_SUMMON, 0.7f, 2},
                            {PO_SMITE, 0.8f, 3},  {PO_SCATTER, 0.8f, 3}, {PO_TRAINING, 0.3f, 3}, {PO_DELAY, 0.45f, 5},
                            {PO_GAMBLE, 0.7f, 2}, {PO_SHARD, 0.45f, 2}, {PO_SLOTS, 0.5f, 2}, {PO_PRAYER, 0.6f, 2},
                            {PO_TRAP, 0.7f, 8},   {PO_TAX, 0.5f, 6}};
    std::vector<float> wt;
    for (auto& p : pool) {
      float x = depth >= p.minDepth ? p.w : 0.f;
      if (p.kind == PO_CHAOS && (w.pl.patron == PT_TUMBLER || w.st.tumblerWatch > 0)) x *= 2.f;
      if (p.kind == PO_PRAYER && w.pl.patron < 0) x *= 0.5f;
      wt.push_back(x);
    }
    if (hasMod(w, MOD_CASINO)) k.push_back(PO_LOTTERY);
    while ((int)k.size() < n) {
      int i = R.weighted(wt);
      if (i < 0) break;
      k.push_back(pool[i].kind);
      wt[i] *= 0.3f;
    }
    R.shuffle(k);
    int n2 = (int)k.size();
    for (int i = 0; i < n2; ++i)
      if (k[i] == PO_RECALL && (i == 0 || i == n2 - 1)) std::swap(k[i], k[R.range(1, n2 - 2)]);
  }
  f.pockets.clear();
  for (auto kind : k) {
    if ((int)f.pockets.size() >= MAX_POCKETS) break;
    Pocket p;
    p.kind = kind;
    p.orig = kind;
    f.pockets.push_back(p);
  }
  for (int i = 0; i < MAX_POCKETS; ++i) f.dividerSeg[i] = -1;
  for (int i = 0; i < (int)f.pockets.size() - 1; ++i) {
    int si = addSeg(w, SK_DIVIDER, V2(0, POCKET_TOP), V2(0, 900), 4);
    if (si >= 0) {
      f.segs[si].rest = 0.45f;
      f.dividerSeg[i] = si;
    }
  }
  layoutPockets(w);
}

void setupDevices(World& w) {
  Floor& f = w.fl;
  int pl = abLevel(w, AB_PINBALL);
  if (pl > 0) {
    float L = pl <= 1 ? 82.f : pl == 2 ? 96.f : 110.f;
    f.hasFlippers = true;
    for (int side = 0; side < 2; ++side) {
      V2 pivot(side == 0 ? PX0 + 118 : PX1 - 118, 802);
      float rest = side == 0 ? 0.52f : PI - 0.52f;
      float up = side == 0 ? -0.42f : PI + 0.42f;
      int si = f.flipSeg[side];
      if (si < 0 || si >= (int)f.segs.size() || f.segs[si].kind != SK_FLIPPER) {
        si = addSeg(w, SK_FLIPPER, pivot, pivot + fromAng(rest) * L, 6);
        f.flipSeg[side] = si;
      }
      if (si >= 0) {
        Seg& s = f.segs[si];
        s.c = pivot;
        s.len = L;
        s.restAng = rest;
        s.upAng = up;
        s.ang = rest;
        s.link = side;
        s.rest = 0.5f;
        s.a = pivot;
        s.b = pivot + fromAng(rest) * L;
      }
    }
  }
  if (abLevel(w, AB_CATCHER) > 0) f.hasCatcher = true;
}

// ---------------------------------------------------------------- specials
void refreshSpecials(World& w) {
  Floor& f = w.fl;
  static const int KINDS[] = {PK_CRIT,   PK_GOLD,   PK_HEAL,    PK_MANA,  PK_MULTI,  PK_FIRE,   PK_ICE,    PK_POISON,
                              PK_SPARK,  PK_CRYSTAL, PK_XP,     PK_REFRESH, PK_BOMB, PK_TELEPORT, PK_JELLY, PK_MIRROR,
                              PK_VAMPIRE, PK_CHAOS, PK_FREEZE, PK_CLOVER, PK_ANVIL, PK_FEATHER, PK_VOID,  PK_SHIELD,
                              PK_SEED,   PK_RUNE,   PK_CURSE,  PK_LIFE, PK_PRISM, PK_DICE, PK_STAR, PK_MOON,
                              PK_HOURGLASS, PK_BLOOD, PK_CANNON, PK_ROD, PK_COMBO, PK_SNOWBALL, PK_ECHO, PK_BRAND,
                              PK_JACKPOT};
  for (int k : KINDS) {
    int target = f.baseSpecials[k] + w.st.specials[k];
    if (k == PK_GOLD && hasMod(w, MOD_TREASURE)) target += 4;
    if (k == PK_GOLD && hasMod(w, MOD_GOLDRUSH)) target += 4;
    if (k == PK_HEAL && hasMod(w, MOD_BLESSED)) target += 2;
    if (k == PK_SPARK && hasMod(w, MOD_MAGSTORM)) target += 3;
    if (k == PK_SPARK && hasMod(w, MOD_STORMFRONT)) target += 2;
    if (k == PK_MIRROR && hasMod(w, MOD_MIRRORS)) target += 3;
    if (k == PK_TELEPORT && hasMod(w, MOD_WARPED)) target += 2;
    if (k == PK_BOMB && hasMod(w, MOD_MINEFIELD)) target += 4;
    if (k == PK_CHAOS && hasMod(w, MOD_PLAYGROUND)) target += 3;
    if (f.shrine == 8 && (k == PK_CRIT || k == PK_GOLD || k == PK_HEAL)) target += 2 * (1 + w.st.shrineBonus);
    if (target <= 0) continue;
    target = std::min(target, 24);
    int have = countKind(w, k);
    if (have < target) convertPins(w, k, target - have);
  }
}

// ---------------------------------------------------------------- per-turn modifiers
void applyTurnModifiers(World& w) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  for (int i = 0; i < f.spec.nMods; ++i) {
    switch (f.spec.mods[i]) {
      case MOD_SHIFTING: {
        float sh = (f.turn % 2 == 0) ? 26.f : -26.f;
        for (auto& p : f.pegs) {
          if (p.dead || p.motion || (p.kind != PK_PIN && !isEnchant(p.kind))) continue;
          float dx = (p.row % 2 == 0) ? sh : -sh;
          V2 np(p.p.x + dx, p.p.y);
          if (np.x < PX0 + 14) np.x += (PX1 - PX0 - 28);
          if (np.x > PX1 - 14) np.x -= (PX1 - PX0 - 28);
          bool ok = true;
          for (auto& c : f.clearings)
            if (c.mon >= 0 && dist2(c.p, np) < (c.r + 10) * (c.r + 10)) ok = false;
          for (auto& m : f.mons)
            if (!m.dead && dist2(m.p, np) < (m.r + 16) * (m.r + 16)) ok = false;
          for (auto& k : f.keepOut)
            if (dist2(k.p, np) < k.r * k.r) ok = false;
          if (ok) {
            p.p = np;
            p.anchor = np;
          }
        }
        break;
      }
      case MOD_RISINGWATER: {
        if (f.waterLevel <= 0) f.waterLevel = POCKET_TOP;
        f.waterLevel = std::max(520.f, f.waterLevel - 34.f);
        bool found = false;
        for (auto& z : f.zones)
          if (!z.dead && z.kind == ZK_WATER && z.link == -7) {
            z.p = V2((PX0 + PX1) * 0.5f, (f.waterLevel + POCKET_TOP) * 0.5f);
            z.half = V2((PX1 - PX0) * 0.5f, (POCKET_TOP - f.waterLevel) * 0.5f);
            found = true;
          }
        if (!found) {
          int zi = addZone(w, ZK_WATER, V2((PX0 + PX1) * 0.5f, (f.waterLevel + POCKET_TOP) * 0.5f),
                           V2((PX1 - PX0) * 0.5f, (POCKET_TOP - f.waterLevel) * 0.5f), false);
          if (zi >= 0) f.zones[zi].link = -7;
        }
        break;
      }
      case MOD_CRUMBLING: {
        std::vector<int> c;
        for (int k = 0; k < (int)f.pegs.size(); ++k)
          if (!f.pegs[k].dead && f.pegs[k].kind == PK_PIN && !f.pegs[k].motion) c.push_back(k);
        R.shuffle(c);
        for (int k = 0; k < 4 && k < (int)c.size(); ++k) {
          f.pegs[c[k]].dead = true;
          fxBurst(w, f.pegs[c[k]].p, 0xa08060, 6, 90);
        }
        break;
      }
      case MOD_OVERGROWN:
        growPins(w, 4, V2(-1, -1), 0, false);
        clearWedges(w);
        break;
      case MOD_WINDY:
        for (auto& z : f.zones)
          if (!z.dead && z.kind == ZK_WIND && z.link == -8) z.dir = V2(-z.dir.x, 0);
        break;
      case MOD_GRAVITY: f.gravNow = R.rangef(0.7f, 1.3f); break;
      case MOD_HAUNTED: convertPins(w, PK_CURSE, 2); break;
      case MOD_ROTPOCKETS: rotatePockets(w, 1); break;
      case MOD_SWARMING:
        if (f.turn % 3 == 0 && f.swarmSpawned < 3) {
          const BiomeDef& b = BIOME[f.spec.biome];
          int n = 0;
          while (n < 16 && b.roster[n] != M_COUNT) n++;
          int def = b.roster[R.range(0, std::max(0, std::min(n, 4) - 1))];
          int cl = freeClearing(w, V2(-1, -1), true);
          if (cl >= 0 && spawnMonster(w, def, cl, false) >= 0) {
            f.swarmSpawned++;
            logMsg(w, 0xff7070, "A %s joins the fight!", MON[def].name);
          }
        }
        break;
      case MOD_STORMFRONT: {
        for (int k = 0; k < 2; ++k) {
          int t = pickRandomHostile(w);
          if (t < 0) break;
          fxZap(w, V2(f.mons[t].p.x + R.rangef(-50, 50), 0), f.mons[t].p, 0xfff4a0);
          damageMonster(w, t, 3 + w.depth / 3, DS_ZAP);
        }
        fxSound(w, S_ZAP, 0.6f, 0.7f);
        break;
      }
      case MOD_TREMORS: {
        for (auto& p : f.pegs) {
          if (p.dead || p.kind != PK_PIN || p.motion) continue;
          V2 np = p.p + V2(R.rangef(-7, 7), R.rangef(-7, 7));
          if (np.x > PX0 + 14 && np.x < PX1 - 14 && np.y > FIELD_Y0 - 10 && np.y < FIELD_Y1 + 10) {
            bool ok = true;
            for (auto& m : f.mons)
              if (!m.dead && dist2(m.p, np) < (m.r + 12) * (m.r + 12)) ok = false;
            if (ok) {
              p.p = np;
              p.anchor = np;
            }
          }
        }
        for (int k = 0; k < 2; ++k) {
          V2 p = randomFieldSpot(w, 10, 10, FIELD_Y0 + 40, FIELD_Y1 - 40);
          if (p.x >= 0) addPeg(w, PK_STONE, p, 10);
        }
        fxShake(w, 6);
        break;
      }
      case MOD_CASINO: queueSlotSpin(w); break;
    }
  }
}

// ---------------------------------------------------------------- generation helpers
static bool clearOfClearings(const Floor& f, V2 p, float pad) {
  for (auto& c : f.clearings)
    if (dist2(c.p, p) < (c.r + pad) * (c.r + pad)) return false;
  return true;
}

static bool clearOfFeatures(const World& w, V2 p, float r) {
  const Floor& f = w.fl;
  for (auto& pg : f.pegs)
    if (!pg.dead && pg.kind != PK_PIN && dist2(pg.p, p) < (pg.r + r + 20) * (pg.r + r + 20)) return false;
  for (auto& s : f.segs) {
    if (s.dead || s.kind == SK_DIVIDER || s.kind == SK_FLIPPER) continue;
    if (s.kind == SK_SPINNER || s.kind == SK_PENDULUM) {
      float rr = (s.kind == SK_PENDULUM ? s.len * 2 : s.len) + r + 16;
      if (dist2(s.c, p) < rr * rr) return false;
    } else {
      V2 cp = closestOnSeg(p, s.a, s.b);
      if (dist2(cp, p) < (s.th + r + 18) * (s.th + r + 18)) return false;
    }
  }
  for (auto& z : f.zones)
    if (!z.dead && (z.kind == ZK_WELL || z.kind == ZK_BOOST) && dist2(z.p, p) < (z.half.x * 0.45f + r) * (z.half.x * 0.45f + r))
      return false;
  for (auto& k : f.keepOut)
    if (dist2(k.p, p) < (k.r + r) * (k.r + r)) return false;
  return true;
}

static bool clearingFits(const Floor& f, V2 p, float r) {
  for (auto& s : f.segs) {
    if (s.dead || s.kind == SK_DIVIDER || s.kind == SK_FLIPPER) continue;
    if (dist(closestOnSeg(p, s.a, s.b), p) < r + s.th + 22) return false;
  }
  for (auto& k : f.keepOut)
    if (dist(k.p, p) < k.r + r + 6) return false;
  for (auto& pg : f.pegs)
    if (!pg.dead && pg.kind != PK_PIN && dist(pg.p, p) < pg.r + r + 16) return false;
  return true;
}

static void makeClearings(World& w, int count, bool boss, float bossR) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  f.clearings.clear();
  if (boss) {
    Clearing c;
    // never exactly under the launcher, so the opening shot can't juggle on the boss
    float side = R.chance(0.5f) ? -1.f : 1.f;
    c.p = V2(LAUNCH_X + side * R.rangef(70, 170), R.rangef(360, 420));
    c.r = bossR + 22;
    for (int t = 0; t < 300 && !clearingFits(f, c.p, c.r); ++t)
      c.p = V2(R.rangef(PX0 + c.r + 20, PX1 - c.r - 20), R.rangef(300, 560));
    f.clearings.push_back(c);
  }
  for (int tries = 0; tries < 3000 && (int)f.clearings.size() < count; ++tries) {
    Clearing c;
    c.r = 40;
    c.p = V2(R.rangef(PX0 + 64, PX1 - 64), R.rangef(FIELD_Y0 + 120, FIELD_Y1 - 56));
    bool ok = clearingFits(f, c.p, c.r);
    for (auto& o : f.clearings)
      if (dist(o.p, c.p) < o.r + c.r + 62) ok = false;
    if (ok) f.clearings.push_back(c);
  }
}

static void addFeatures(World& w) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  const BiomeDef& B = BIOME[f.spec.biome];
  auto rollCount = [&](float wgt, float lo, float hi) {
    float x = wgt * R.rangef(lo, hi);
    int n = (int)x;
    if (R.f() < x - n) n++;
    return n;
  };
  auto randSpot = [&](float r, float pad, V2& out) {
    for (int t = 0; t < 300; ++t) {
      V2 p(R.rangef(PX0 + r + 20, PX1 - r - 20), R.rangef(FIELD_Y0 + 20, FIELD_Y1 - 20));
      if (!clearOfClearings(f, p, r + pad)) continue;
      if (!clearOfFeatures(w, p, r + pad)) continue;
      out = p;
      return true;
    }
    return false;
  };
  int nb = rollCount(B.bumpers, 1.2f, 2.6f);
  for (int i = 0; i < nb; ++i) {
    bool mush = f.spec.biome == BI_LAIR;
    float r = mush ? R.rangef(11, 15) : 15;
    V2 p;
    if (randSpot(r, 24, p)) addPeg(w, mush ? PK_MUSHROOM : PK_BUMPER, p, r);
  }
  if (f.spec.biome == BI_LAIR) {
    int extra = R.range(2, 4);
    for (int i = 0; i < extra; ++i) {
      V2 p;
      if (randSpot(10, 20, p)) addPeg(w, PK_MUSHROOM, p, 10);
    }
  }
  int ns = rollCount(B.spinners, 0.6f, 2.0f);
  for (int i = 0; i < ns; ++i) {
    V2 p;
    if (!randSpot(44, 18, p)) continue;
    int si = addSeg(w, SK_SPINNER, p, p, 5);
    if (si < 0) continue;
    Seg& s = f.segs[si];
    s.c = p;
    s.len = R.rangef(36, 46);
    s.angVel = (R.chance(0.5f) ? 1 : -1) * R.rangef(2.2f, 4.2f);
    s.ang = R.rangef(0, TAU);
    s.rest = 0.8f;
  }
  int nr = rollCount(B.ramps, 0.8f, 2.4f);
  for (int i = 0; i < nr; ++i) {
    V2 p;
    if (!randSpot(50, 16, p)) continue;
    float L = R.rangef(34, 52);
    float a = (R.chance(0.5f) ? 1 : -1) * R.rangef(0.25f, 0.55f);
    V2 d = fromAng(a) * L;
    int si = addSeg(w, SK_RAMP, p - d, p + d, 4);
    if (si >= 0) f.segs[si].rest = 0.6f;
  }
  if (f.spec.biome == BI_HALLS || f.spec.biome == BI_CRYPT || f.spec.biome == BI_MINES || f.spec.biome == BI_ABYSS) {
    int n = R.range(0, 3);
    for (int i = 0; i < n; ++i) {
      V2 p;
      if (randSpot(11, 18, p)) addPeg(w, PK_STONE, p, 11);
    }
  }
  if (B.water > 0 && R.f() < B.water) {
    Zone z;
    z.kind = ZK_WATER;
    if (R.chance(0.5f)) {
      z.p = V2((PX0 + PX1) * 0.5f, R.rangef(640, 720));
      z.half = V2((PX1 - PX0) * 0.5f, R.rangef(40, 60));
    } else {
      bool left = R.chance(0.5f);
      z.p = V2(left ? PX0 + 120 : PX1 - 120, R.rangef(400, 650));
      z.half = V2(120, R.rangef(90, 150));
    }
    f.zones.push_back(z);
  }
  int nw = rollCount(B.wells, 0.5f, 2.0f);
  for (int i = 0; i < nw; ++i) {
    V2 p;
    if (!randSpot(40, 10, p)) continue;
    int zi = addZone(w, ZK_WELL, p, V2(R.rangef(70, 95), 0), true);
    if (zi >= 0) f.zones[zi].str = R.rangef(700, 1000);
  }
  if (B.wind > 0 && R.f() < B.wind * 0.6f) {
    int zi = addZone(w, ZK_WIND, V2((PX0 + PX1) * 0.5f, R.rangef(300, 600)), V2((PX1 - PX0) * 0.5f, R.rangef(50, 90)), false);
    if (zi >= 0) {
      f.zones[zi].dir = V2(R.chance(0.5f) ? 1.f : -1.f, 0);
      f.zones[zi].str = R.rangef(220, 360);
    }
  }
  int nl = rollCount(B.lava, 0.8f, 2.2f);
  for (int i = 0; i < nl; ++i) {
    V2 p(R.rangef(PX0 + 120, PX1 - 120), R.rangef(560, 760));
    V2 half(R.rangef(60, 110), R.rangef(18, 30));
    if (!clearOfClearings(f, p, half.x * 0.5f)) continue;
    addZone(w, ZK_LAVA, p, half, false);
  }
  if (f.spec.biome == BI_MINES || R.chance(0.15f)) {
    int nbst = R.range(0, 2);
    for (int i = 0; i < nbst; ++i) {
      V2 p;
      if (!randSpot(26, 20, p)) continue;
      int zi = addZone(w, ZK_BOOST, p, V2(22, 0), true);
      if (zi < 0) continue;
      f.zones[zi].dir = fromAng(R.chance(0.5f) ? -PI * 0.5f + R.rangef(-0.6f, 0.6f) : R.rangef(0.3f, PI - 0.3f));
      f.zones[zi].str = 700;
    }
  }
  if (f.spec.biome == BI_SLIME) {
    int n = R.range(1, 2);
    for (int i = 0; i < n; ++i) {
      V2 p;
      if (!randSpot(50, 10, p)) continue;
      addZone(w, ZK_MIST, p, V2(R.rangef(46, 60), 0), true);
    }
  }
  if (f.spec.biome == BI_ABYSS) {
    if (R.chance(0.6f)) {
      V2 p;
      if (randSpot(60, 10, p)) addZone(w, ZK_FOG, p, V2(R.rangef(70, 100), 0), true);
    }
  }
}

static void addMovers(World& w) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  const BiomeDef& B = BIOME[f.spec.biome];
  if (R.f() < B.movers * 0.7f) {
    float band = R.rangef(FIELD_Y0 + 80, FIELD_Y1 - 80);
    float sp = R.rangef(0.8f, 1.6f), amp = R.rangef(10, 16);
    for (auto& p : f.pegs) {
      if (p.dead || p.kind != PK_PIN || std::fabs(p.p.y - band) > 12) continue;
      bool nearCl = false;
      for (auto& c : f.clearings)
        if (dist(c.p, p.p) < c.r + amp + 24) nearCl = true;
      for (auto& k : f.keepOut)
        if (dist(k.p, p.p) < k.r + amp + 10) nearCl = true;
      if (nearCl) continue;
      p.motion = 2;
      p.mA = amp;
      p.mSpeed = sp;
      p.mPhase = 0;
    }
  }
  bool carnival = f.spec.format == 11;
  if (hasMod(w, MOD_GEARWORKS) || carnival || R.f() < B.movers * 0.35f) {
    int rings = (hasMod(w, MOD_GEARWORKS) || carnival) ? R.range(2, 3) : 1;
    for (int k = 0; k < rings; ++k) {
      for (int t = 0; t < 200; ++t) {
        V2 c(R.rangef(PX0 + 100, PX1 - 100), R.rangef(FIELD_Y0 + 90, FIELD_Y1 - 90));
        float rr = R.rangef(52, 66);
        if (!clearOfClearings(f, c, rr + 20)) continue;
        bool blocked = false;
        for (auto& p : f.pegs)
          if (!p.dead && p.kind != PK_PIN && dist(p.p, c) < rr + p.r + 24) blocked = true;
        for (auto& s : f.segs)
          if (!s.dead && s.kind != SK_DIVIDER && dist(closestOnSeg(c, s.a, s.b), c) < rr + 24) blocked = true;
        for (auto& ko : f.keepOut)
          if (dist(ko.p, c) < ko.r + rr + 10) blocked = true;
        if (blocked) continue;
        for (auto& p : f.pegs)
          if (!p.dead && p.kind == PK_PIN && dist(p.p, c) < rr + 26) p.dead = true;
        int n = (int)(TAU * rr / 38);
        float sp = (R.chance(0.5f) ? 1 : -1) * R.rangef(0.6f, 1.1f);
        for (int i = 0; i < n; ++i) {
          int pi = addPeg(w, PK_PIN, c + fromAng(i * TAU / n) * rr, PIN_R);
          if (pi < 0) break;
          Peg& p = f.pegs[pi];
          p.motion = 1;
          p.anchor = c;
          p.mA = rr;
          p.mSpeed = sp;
          p.mPhase = i * TAU / n;
        }
        addPeg(w, PK_BUMPER, c, 13);
        f.keepOut.push_back({c, rr + 10, -1});
        break;
      }
    }
  }
}

static void addVaultTreasure(World& w) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  V2 c(R.chance(0.5f) ? PX0 + 140 : PX1 - 140, R.rangef(520, 700));
  for (auto& p : f.pegs)
    if (!p.dead && dist(p.p, c) < 70) p.dead = true;
  int chest = addPeg(w, PK_CHEST, c, 17);
  if (chest >= 0) {
    f.pegs[chest].hp = 2;
    f.pegs[chest].val = 99;  // relic / randart chest
  }
  float s = 36;
  V2 corners[4] = {c + V2(-s, -s), c + V2(s, -s), c + V2(s, s), c + V2(-s, s)};
  for (int i = 0; i < 4; ++i) {
    int si = addSeg(w, SK_GATE, corners[i], corners[(i + 1) % 4], 4);
    if (si >= 0) f.segs[si].link = 1;
  }
  for (int t = 0; t < 300; ++t) {
    V2 p(R.rangef(PX0 + 60, PX1 - 60), R.rangef(FIELD_Y0 + 40, 420));
    if (dist(p, c) < 200) continue;
    if (!spotFree(w, p, 9, 8)) continue;
    int k = addPeg(w, PK_KEY, p, 9);
    if (k >= 0) f.pegs[k].link = 1;
    break;
  }
  int nch = R.range(2, 3);
  for (int i = 0; i < nch; ++i)
    for (int t = 0; t < 200; ++t) {
      V2 p(R.rangef(PX0 + 60, PX1 - 60), R.rangef(FIELD_Y0 + 60, FIELD_Y1 - 40));
      if (!spotFree(w, p, 15, 10)) continue;
      addPeg(w, PK_CHEST, p, 15);
      break;
    }
}

void generateBoard(World& w) {
  Floor& f = w.fl;
  const FloorSpec& sp = f.spec;
  Rng& R = f.rng;
  f.pegs.reserve(1600);
  f.segs.reserve(320);
  f.zones.reserve(64);
  f.mons.reserve(64);
  f.balls.reserve(64);
  f.newBalls.reserve(64);
  f.clearings.reserve(32);
  f.keepOut.reserve(32);
  f.bouncy = hasMod(w, MOD_BOUNCY);
  f.dark = hasMod(w, MOD_DARKNESS);
  f.gravNow = 1.f;
  setupPockets(w);

  bool boss = sp.kind == FK_BOSS, vault = sp.kind == FK_VAULT;
  float bossR = 0;
  if (boss && sp.nMons > 0) bossR = MON[sp.mons[0]].r;
  int nClear = vault ? 0 : std::max(7, sp.nMons + 4);
  if (boss) nClear = 7;
  buildFormat(w);
  if (vault || !formatClearings(w, nClear, boss, bossR)) makeClearings(w, nClear, boss, bossR);
  if (boss && !f.clearings.empty()) {
    // make sure no format wall or rock ends up inside the guardian's arena
    const Clearing& bc = f.clearings[0];
    for (auto& s : f.segs)
      if (!s.dead && s.link == -20 && dist(closestOnSeg(bc.p, s.a, s.b), bc.p) < bc.r + s.th + 10) s.dead = true;
    std::vector<Clearing> keep;
    for (auto& k : f.keepOut)
      if (!(k.mon == -20 && dist(k.p, bc.p) < k.r + bc.r)) keep.push_back(k);
    f.keepOut = keep;
  }

  // modifier zones
  if (hasMod(w, MOD_WINDY)) {
    int zi = addZone(w, ZK_WIND, V2((PX0 + PX1) * 0.5f, (FIELD_Y0 + FIELD_Y1) * 0.5f), V2((PX1 - PX0) * 0.5f, (FIELD_Y1 - FIELD_Y0) * 0.5f), false);
    if (zi >= 0) {
      f.zones[zi].link = -8;
      f.zones[zi].dir = V2(R.chance(0.5f) ? 1.f : -1.f, 0);
      f.zones[zi].str = 150;
    }
  }
  if (hasMod(w, MOD_MOLTEN)) {
    for (int i = 0; i < 2; ++i) {
      V2 p(i == 0 ? R.rangef(PX0 + 130, 760) : R.rangef(840, PX1 - 130), R.rangef(600, 760));
      addZone(w, ZK_LAVA, p, V2(R.rangef(70, 110), R.rangef(20, 30)), false);
    }
  }
  addFeatures(w);
  placeSetPieces(w);
  addPinPattern(w, formatPinPattern(w));
  addMovers(w);
  if (sp.format == 10) {  // bumper bowl: thin the pins out
    for (auto& p : f.pegs)
      if (!p.dead && p.kind == PK_PIN && !p.motion && R.chance(0.4f)) p.dead = true;
  }
  if (vault) addVaultTreasure(w);
  else if (R.chance(0.25f)) {
    for (int t = 0; t < 200; ++t) {
      V2 p(R.rangef(PX0 + 60, PX1 - 60), R.rangef(FIELD_Y0 + 60, FIELD_Y1 - 40));
      if (!spotFree(w, p, 15, 6)) continue;
      int ci = addPeg(w, (sp.depth >= 4 && R.chance(0.15f)) ? PK_MIMIC : PK_CHEST, p, 15);
      if (ci >= 0) f.pegs[ci].hp = 3;
      break;
    }
  }
  if (!vault) {
    // loose treasures: relic shards and gems
    if (sp.depth >= 2 && R.chance(0.14f)) {
      V2 p = randomFieldSpot(w, 10, 14, FIELD_Y0 + 60, FIELD_Y1 - 60);
      if (p.x >= 0) addPeg(w, PK_SHARD, p, 9);
    }
    if (R.chance(0.22f)) {
      int n = R.range(1, 2);
      for (int k = 0; k < n; ++k) {
        V2 p = randomFieldSpot(w, 9, 14, FIELD_Y0 + 60, FIELD_Y1 - 60);
        if (p.x >= 0) placeGem(w, p);
      }
    }
  }
  if (hasMod(w, MOD_SPRINGS))
    for (int k = 0; k < 2; ++k) {
      V2 p = randomFieldSpot(w, 10, 16, 500, FIELD_Y1 - 20);
      if (p.x >= 0) addPeg(w, PK_SPRING, p, 10);
    }
  if (hasMod(w, MOD_GOLDRUSH))
    for (int k = 0; k < 4; ++k) {
      V2 p = randomFieldSpot(w, 9, 14, FIELD_Y0 + 40, FIELD_Y1 - 30);
      if (p.x >= 0) addPeg(w, PK_COINS, p, 9);
    }
  clearWedges(w);
  // spawn monsters
  std::vector<int> order;
  for (int i = 0; i < (int)f.clearings.size(); ++i) order.push_back(i);
  if (!boss) R.shuffle(order);
  int oi = 0;
  for (int k = 0; k < sp.nMons && oi < (int)order.size(); ++k) {
    int cl = order[oi++];
    int mi = spawnMonster(w, sp.mons[k], cl, false);
    if (mi >= 0 && k == 0 && sp.kind == FK_ELITE && !(MON[sp.mons[k]].traits & TR_ELITE)) {
      Monster& m = f.mons[mi];
      m.elite = true;
      m.maxHp = m.hp = (int)(m.maxHp * 1.8f);
      m.hpDisp = (float)m.hp;
      m.atkBonus += 2;
    }
  }
  rollChampions(w);
  // base specials
  memset(f.baseSpecials, 0, sizeof(f.baseSpecials));
  auto& S = f.baseSpecials;
  int depth = sp.depth;
  S[PK_CRIT] = 2;
  S[PK_GOLD] = 2;
  S[PK_HEAL] = 1;
  S[PK_MANA] = 1;
  if (depth >= 2) S[PK_BOMB] = 1;
  if (depth >= 3) S[PK_MULTI] = 1;
  if (depth >= 14) S[PK_REFRESH] = 1;
  switch (sp.biome) {
    case BI_LAIR: S[PK_POISON] = 2; S[PK_HEAL] += 1; S[PK_SEED] = 1; break;
    case BI_DROWNED: S[PK_ICE] = 1; S[PK_MANA] += 1; S[PK_JELLY] = 1; break;
    case BI_MINES: S[PK_BOMB] += 1; S[PK_SPARK] = 1; S[PK_ANVIL] = 1; break;
    case BI_CRYPT: S[PK_XP] = 1; S[PK_VAMPIRE] = 1; break;
    case BI_FORGE: S[PK_FIRE] = 2; S[PK_BOMB] += 1; break;
    case BI_FROZEN: S[PK_ICE] = 2; S[PK_FREEZE] = 1; break;
    case BI_CORE: S[PK_CRIT] += 1; S[PK_GOLD] += 1; S[PK_MULTI] += 1; S[PK_CLOVER] = 1; break;
    case BI_SLIME: S[PK_JELLY] = 2; S[PK_POISON] = 1; break;
    case BI_ABYSS: S[PK_VOID] = 1; S[PK_CHAOS] = 1; S[PK_TELEPORT] = 1; break;
  }
  // every floor features a few of the rarer special pegs, so no two boards play alike
  if (!vault) {
    static const int FEAT[] = {PK_TELEPORT, PK_JELLY, PK_MIRROR,  PK_VAMPIRE, PK_CHAOS, PK_FREEZE, PK_CLOVER, PK_ANVIL,
                               PK_FEATHER,  PK_VOID,  PK_SHIELD,  PK_SEED,    PK_RUNE,  PK_PRISM,  PK_DICE,   PK_STAR,
                               PK_MOON,     PK_HOURGLASS, PK_BLOOD, PK_CANNON, PK_ROD,  PK_COMBO,  PK_SNOWBALL, PK_ECHO,
                               PK_BRAND,    PK_JACKPOT};
    std::vector<int> pool(FEAT, FEAT + sizeof(FEAT) / sizeof(FEAT[0]));
    R.shuffle(pool);
    int nf = 3 + (depth >= 4 ? 1 : 0) + (R.chance(0.35f) ? 1 : 0);
    for (int i = 0, got = 0; i < (int)pool.size() && got < nf; ++i) {
      int k = pool[i];
      if ((k == PK_VOID || k == PK_JACKPOT || k == PK_CANNON) && depth < 4) continue;
      if (k == PK_STAR) {
        S[k] += 3;
        got++;
        continue;
      }
      S[k] += (k == PK_JACKPOT || k == PK_ROD) ? 1 : R.range(1, 2);
      got++;
    }
  }
  if (vault) {
    S[PK_GOLD] = 12;
    S[PK_CRIT] = 3;
    S[PK_MULTI] = 2;
    S[PK_BOMB] = 1;
    S[PK_CLOVER] = 2;
  }
}

// ---------------------------------------------------------------- floor specs
FloorSpec makeFloorSpec(World& w, int kind, int biome, int act, int step, int salt) {
  FloorSpec s;
  s.kind = (uint8_t)kind;
  s.biome = (uint8_t)biome;
  s.depth = w.depth + 1;
  s.seed = mix64(w.seed ^ mix64((uint64_t)(s.depth * 131 + salt * 7919 + act * 17)));
  Rng R(s.seed ^ 0xABCDEF);
  const BiomeDef& B = BIOME[biome];
  // modifiers
  int nm = 0;
  if (kind != FK_VAULT) {
    if (s.depth >= 2 && R.chance(0.45f)) nm = 1;
    if (s.depth >= 5 && R.chance(0.7f)) nm = 1;
    if (s.depth >= 10 && R.chance(0.35f)) nm = 2;
    if (w.descent >= 5 && nm < 2 && s.depth >= 4 && R.chance(0.5f)) nm++;
  }
  auto in = [&](std::initializer_list<int> l) {
    for (int b : l)
      if (b == biome) return true;
    return false;
  };
  std::vector<int> pool;
  for (int m = 0; m < MOD_COUNT; ++m) {
    if (m == MOD_RISINGWATER && !in({BI_DROWNED, BI_LAIR, BI_SLIME})) continue;
    if (m == MOD_MOLTEN && !in({BI_FORGE, BI_CORE})) continue;
    if (m == MOD_GEARWORKS && !in({BI_MINES, BI_CORE, BI_HALLS})) continue;
    if (m == MOD_DARKNESS && !in({BI_CRYPT, BI_CORE, BI_ABYSS})) continue;
    if (m == MOD_HAUNTED && !in({BI_CRYPT, BI_CORE, BI_ABYSS})) continue;
    if (m == MOD_SWARMING && kind == FK_BOSS) continue;
    if (m == MOD_BOUNTY && kind == FK_BOSS) continue;
    if (m == MOD_CONVEYORS && !in({BI_MINES, BI_CORE, BI_HALLS, BI_FORGE})) continue;
    if (m == MOD_GEYSERS && !in({BI_FORGE, BI_DROWNED, BI_SLIME, BI_FROZEN})) continue;
    if (m == MOD_BLOODMOON && !in({BI_CRYPT, BI_LAIR, BI_ABYSS, BI_FORGE})) continue;
    if (m == MOD_WARPED && !in({BI_ABYSS, BI_CORE, BI_CRYPT}) && s.depth < 8) continue;
    if (m == MOD_TREMORS && !in({BI_MINES, BI_HALLS, BI_LAIR, BI_FROZEN, BI_ABYSS})) continue;
    if (m == MOD_PLAYGROUND && s.depth < 3) continue;
    if (m == MOD_MINEFIELD && s.depth < 3) continue;
    pool.push_back(m);
  }
  R.shuffle(pool);
  for (int i = 0; i < nm && i < (int)pool.size(); ++i) s.mods[s.nMods++] = (uint8_t)pool[i];
  s.format = (uint8_t)pickFormat(w, s, R);
  // monsters
  int nRoster = 0;
  while (nRoster < 16 && B.roster[nRoster] != M_COUNT) nRoster++;
  auto addMon = [&](int id) {
    if (s.nMons < 10 && id >= 0 && id < M_COUNT) s.mons[s.nMons++] = (uint16_t)id;
  };
  if (kind == FK_BOSS) {
    int nb = B.bosses[1] != M_COUNT ? 2 : 1;
    addMon(B.bosses[R.range(0, nb - 1)]);
  } else if (kind != FK_VAULT) {
    int budget;
    switch (act) {
      case 0: budget = 6 + 3 * step; break;
      case 1: budget = 20 + 4 * step; break;
      case 2: budget = 34 + 5 * step; break;
      default: budget = 58 + 7 * step; break;
    }
    int avail = act == 0 ? std::min(nRoster, 4 + 2 * step) : std::min(nRoster, 3 + step + step / 2);
    if (kind == FK_ELITE) {
      int ne = 0;
      while (ne < 3 && B.elites[ne] != M_COUNT) ne++;
      addMon(B.elites[R.range(0, ne - 1)]);
      budget = budget * 2 / 5;
    }
    int maxMons = act == 0 ? 4 : (act == 1 ? 5 : 6);
    int guard = 0;
    while (budget > 0 && s.nMons < maxMons && guard++ < 50) {
      int id = B.roster[R.range(0, std::max(0, avail - 1))];
      int cost = std::max(1, MON[id].xp);
      if (cost > budget && s.nMons >= (kind == FK_ELITE ? 1 : 2)) break;
      addMon(id);
      budget -= cost;
      if ((MON[id].traits & TR_SWARM) && s.nMons < maxMons && budget > 0) {
        addMon(id);
        budget -= cost;
      }
    }
  }
  return s;
}
