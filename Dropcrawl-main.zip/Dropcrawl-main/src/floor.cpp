// Dropcrawl - core rules: fx/log, player, stats, monsters, board helpers
// (ball events live in floor_ball.cpp, turn flow / abilities / items in floor_turn.cpp)
#include "rules.h"
#include <cstdlib>

// ================================================================ fx / log
void logMsg(World& w, uint32_t col, const char* f, ...) {
  if (w.quiet) return;
  char buf[512];
  va_list ap;
  va_start(ap, f);
  vsnprintf(buf, sizeof(buf), f, ap);
  va_end(ap);
  LogLine l;
  l.text = buf;
  l.col = col;
  l.turn = w.fl.turn;
  w.log.push_back(l);
  if (w.log.size() > 300) w.log.erase(w.log.begin(), w.log.begin() + 100);
}
Fx& pushFx(World& w, int kind) {
  w.fx.emplace_back();
  Fx& e = w.fx.back();
  e.kind = (uint8_t)kind;
  return e;
}
void fxText(World& w, V2 p, uint32_t col, const std::string& s, float size) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_TEXT);
  e.a = p;
  e.col = col;
  e.v = size;
  snprintf(e.text, sizeof(e.text), "%s", s.c_str());
}
void fxSound(World& w, int sfx, float vol, float pitch, float x) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_SOUND);
  e.i = sfx;
  e.v = vol;
  e.v2 = pitch;
  e.a = V2(x, 0);
}
void fxBurst(World& w, V2 p, uint32_t col, int n, float speed, float size) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_BURST);
  e.a = p;
  e.col = col;
  e.i = n;
  e.v = speed;
  e.v2 = size;
}
void fxZap(World& w, V2 a, V2 b, uint32_t col) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_ZAP);
  e.a = a;
  e.b = b;
  e.col = col;
}
void fxRing(World& w, V2 p, float r, uint32_t col) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_RING);
  e.a = p;
  e.v = r;
  e.col = col;
}
void fxShake(World& w, float amt) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_SHAKE);
  e.v = amt;
}
void fxAttack(World& w, V2 from, uint32_t col, int dmg) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_ATTACK);
  e.a = from;
  e.col = col;
  e.i = dmg;
}
void fxBanner(World& w, const std::string& s, uint32_t col) {
  if (w.quiet) return;
  Fx& e = pushFx(w, FX_BANNER);
  e.col = col;
  snprintf(e.text, sizeof(e.text), "%s", s.c_str());
}

std::string withArt(const char* n) {
  std::string s = n;
  if (s.rfind("The ", 0) == 0) return s;
  char c = (char)tolower(s[0]);
  bool v = c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
  return std::string(v ? "an " : "a ") + s;
}

// Sentence-start name: "The goblin", but bosses keep their proper names ("Gorlag, Goblin King", "The House").
std::string The(const MonDef& d) {
  std::string n = d.name;
  if ((d.traits & TR_BOSS) || n.rfind("The ", 0) == 0) return n;
  return "The " + n;
}
std::string TheM(const Monster& m) { return The(monLook(m)); }

// ================================================================ queries
int pietyStarsFor(int piety) {
  int n = 0;
  for (int k = 0; k < 5; ++k)
    if (piety >= PIETY_STAR[k]) n = k + 1;
  return n;
}
int pietyStars(const World& w) { return w.pl.patron < 0 ? 0 : pietyStarsFor(w.pl.piety); }

int abLevel(const World& w, int ab) {
  if (ab >= AB_FIRST_DIVINE) {
    if (w.pl.patron < 0) return 0;
    const PatronDef& p = PATRON[w.pl.patron];
    for (int k = 0; k < 5; ++k)
      if (p.gifts[k] == ab) return w.pl.piety >= PIETY_STAR[k] ? 1 : 0;
    return 0;
  }
  for (auto& a : w.pl.abil)
    if (a.id == ab) return a.lvl;
  return 0;
}
bool hasRelic(const World& w, int rl) {
  for (auto r : w.pl.relics)
    if (r == rl) return true;
  return false;
}
bool isEnchant(int k) {
  switch (k) {
    case PK_PRISM: case PK_DICE: case PK_STAR: case PK_MOON: case PK_HOURGLASS: case PK_BLOOD: case PK_CANNON:
    case PK_ROD: case PK_COMBO: case PK_SNOWBALL: case PK_ECHO: case PK_BRAND: case PK_JACKPOT:
    case PK_CRIT: case PK_GOLD: case PK_HEAL: case PK_MANA: case PK_MULTI: case PK_FIRE: case PK_ICE: case PK_POISON:
    case PK_SPARK: case PK_CRYSTAL: case PK_CURSE: case PK_XP: case PK_REFRESH: case PK_LIFE:
    case PK_TELEPORT: case PK_JELLY: case PK_MIRROR: case PK_VAMPIRE: case PK_CHAOS: case PK_FREEZE: case PK_CLOVER:
    case PK_ANVIL: case PK_FEATHER: case PK_VOID: case PK_SHIELD: case PK_SEED: case PK_RUNE:
      return true;
  }
  return false;
}
bool isAllyPeg(int k) {
  switch (k) {
    case PK_SKELETON: case PK_IMP: case PK_HOUND: case PK_FAMILIAR: case PK_ANGEL: case PK_TESLA:
      return true;
  }
  return false;
}
bool isMonsterAlly(const World& w, int mi) {
  const Monster& m = w.fl.mons[mi];
  return m.charmed || (MON[m.def].traits & TR_ALLY) != 0;
}
bool isHostile(const World& w, int mi) { return !w.fl.mons[mi].dead && !isMonsterAlly(w, mi); }
bool isUndeadOrDemon(const Monster& m) { return (MON[m.def].traits & (TR_UNDEAD | TR_DEMONIC)) != 0; }

int aliveMonsterCount(const World& w) {
  int n = 0;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i) && !(MON[w.fl.mons[i].def].traits & TR_DECOY)) n++;
  return n;
}
int summonedAlive(const World& w) {
  int n = 0;
  for (auto& o : w.fl.mons)
    if (!o.dead && o.summoned && !o.charmed) n++;
  return n;
}
int nearestMonster(const World& w, V2 p, int exclude) {
  int best = -1;
  float bd = 1e18f;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
    if (i == exclude || !isHostile(w, i)) continue;
    float d = dist2(p, w.fl.mons[i].p);
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}
int lowestHpMonster(const World& w) {
  int best = -1;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
    if (!isHostile(w, i)) continue;
    if (best < 0 || w.fl.mons[i].hp < w.fl.mons[best].hp) best = i;
  }
  return best;
}
int highestHpMonster(const World& w) {
  int best = -1;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
    if (!isHostile(w, i)) continue;
    if (best < 0 || w.fl.mons[i].hp > w.fl.mons[best].hp) best = i;
  }
  return best;
}
int pickRandomHostile(World& w) {
  std::vector<int> v;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i)) v.push_back(i);
  if (v.empty()) return -1;
  return v[w.fl.rng.range(0, (int)v.size() - 1)];
}
std::vector<int> monstersSorted(const World& w, bool byHpDesc) {
  std::vector<int> v;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i)) v.push_back(i);
  std::stable_sort(v.begin(), v.end(), [&](int a, int b) {
    return byHpDesc ? w.fl.mons[a].hp > w.fl.mons[b].hp : w.fl.mons[a].hp < w.fl.mons[b].hp;
  });
  return v;
}
int hitMonstersInRadius(World& w, V2 p, float r, int dmg, int src, int exclude) {
  int n = 0;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
    if (i == exclude || !isHostile(w, i)) continue;
    if (dist(w.fl.mons[i].p, p) - w.fl.mons[i].r < r) {
      damageMonster(w, i, dmg, src);
      n++;
    }
  }
  return n;
}
int countKind(const World& w, int kind) {
  int n = 0;
  for (auto& p : w.fl.pegs)
    if (!p.dead && !p.used && p.kind == kind) n++;
  return n;
}
int allyPegCount(const World& w) {
  int n = 0;
  for (auto& p : w.fl.pegs)
    if (!p.dead && (isAllyPeg(p.kind) || (p.kind == PK_FIREFLY && p.temp))) n++;
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (!w.fl.mons[i].dead && w.fl.mons[i].charmed) n++;
  return n;
}
int effPower(const World& w) {
  int p = w.st.basePower + w.fl.cardPower;
  if (w.pl.sapped > 0) p -= 2;
  if (w.pl.weak > 0) p = p / 2;
  return std::max(1, p);
}
V2 launcherPos() { return V2(LAUNCH_X, LAUNCH_Y); }
float launchAngleFromMouse(V2 m) {
  V2 d = m - launcherPos();
  if (d.y < 8) d.y = 8;
  float a = std::atan2(d.y, d.x);
  return clampv(a, 0.12f, PI - 0.12f);
}

// ================================================================ stats
static void speciesTraits(Stats& s, int sp) {
  switch (sp) {
    case SP_IRON: s.offers = std::max(s.offers, 4); break;
    case SP_GLASS: s.restBonus += 0.12f; s.dmgMul *= 1.2f; break;
    case SP_LEAD: s.gravMul *= 1.15f; break;
    case SP_WISP: s.gravMul *= 0.82f; s.mpRegen += 1; break;
    case SP_GILDED: s.goldMul *= 1.5f; s.shopMul *= 0.9f; break;
    case SP_BONE: s.killHeal += 3; s.poisonRes = true; break;
    case SP_MOSS: s.hpRegen += 1; break;
    case SP_RUBBER: s.restBonus += 0.1f; s.wallPower = true; break;
    case SP_CRYSTAL: s.preview += 2; s.keenEye = true; s.keenDepth = 2; break;
    case SP_MAGNET: s.homing = std::max(s.homing, 170); break;
    case SP_SLIME: s.poisonRes = true; break;
    case SP_DJINN: s.hpForMp = true; s.hpRegen += 2; break;
    case SP_FELID: s.noPotions = true; s.xpMul *= 1.15f; break;
    case SP_CHAOS: s.tumblerWatch += 0.15f; s.offers += 1; break;
  }
}

void recalcStats(World& w) {
  Player& pl = w.pl;
  const SpeciesDef& sp = SPECIES[pl.species];
  const BackgroundDef& bg = BGS[pl.bg];
  int oldMax = w.st.maxHp;
  bool initialized = w.effs.size() > 0 || oldMax > 0;
  Stats s;
  s.maxHp = sp.hp + bg.hp + (pl.xl - 1) * sp.hpPerLvl + pl.bonusMaxHp;
  s.maxMp = sp.mp + bg.mp + (pl.xl - 1) / 3 + pl.bonusMp;
  s.basePower = sp.power + (pl.xl - 1) + pl.bonusPower;
  s.armor = sp.armor + pl.bonusArmor;
  s.mpRegen = 1;
  speciesTraits(s, pl.species);
  if (pl.species == SP_CHANGELING && pl.form >= 0 && pl.form < SP_COUNT) {
    speciesTraits(s, pl.form);
    const SpeciesDef& f = SPECIES[pl.form];
    s.maxHp += (f.hp - 40) / 2;
    s.maxMp += (f.mp - 5) / 2;
    s.basePower += f.power - 1;
    s.armor += f.armor;
  }
  w.st = s;
  w.effs.clear();
  for (auto& a : pl.abil) w.effs.push_back({&ABIL[a.id].h, a.lvl});
  for (auto r : pl.relics) w.effs.push_back({&RELIC[r].h, 1});
  if (pl.patron >= 0)
    for (int k = 0; k < 5; ++k)
      if (pl.piety >= PIETY_STAR[k]) w.effs.push_back({&ABIL[PATRON[pl.patron].gifts[k]].h, 1});
  for (int m = 0; m < MUT_COUNT; ++m)
    if (pl.mut[m] > 0) w.effs.push_back({&MUTS[m].h, pl.mut[m]});
  if (const Hooks* h = speciesHooks(pl.species)) w.effs.push_back({h, 1});
  if (pl.species == SP_CHANGELING && pl.form >= 0)
    if (const Hooks* h = speciesHooks(pl.form)) w.effs.push_back({h, 1});
  if (pl.draconic >= 0)
    if (const Hooks* h = dracoHooks(pl.draconic)) w.effs.push_back({h, 1});
  if (pl.relicAffix.size() != pl.relics.size()) pl.relicAffix.resize(pl.relics.size());
  if (anyAffixes(w)) w.effs.push_back({&RANDART_HOOKS, 1});
  bool anySet = false;
  for (auto r : pl.relics)
    if (RELIC[r].tier == 2) anySet = true;
  if (anySet) w.effs.push_back({&SET_HOOKS, 1});
  if (pl.sacrifices) w.effs.push_back({sacrificeHooks(), 1});
  FOR_EFF0(stats);
  applyStatEffects(w);
  if (pl.species == SP_DJINN) w.st.maxMp = 0;
  w.st.maxHp = std::max(1, w.st.maxHp);
  w.st.maxMp = std::max(0, w.st.maxMp);
  w.st.basePower = std::max(1, w.st.basePower);
  w.st.slots = clampv(w.st.slots, 1, 8);
  w.st.offers = clampv(w.st.offers, 1, 6);
  if (initialized && w.st.maxHp > oldMax && oldMax > 0) pl.hp += w.st.maxHp - oldMax;
  pl.hp = std::min(pl.hp, w.st.maxHp);
  pl.mp = std::min(pl.mp, w.st.maxMp);
  if ((int)pl.items.size() != w.st.slots) {
    std::vector<InvItem> it;
    for (auto& x : pl.items)
      if (x.id >= 0) it.push_back(x);
    pl.items.assign(w.st.slots, InvItem());
    for (int i = 0; i < (int)it.size() && i < w.st.slots; ++i) pl.items[i] = it[i];
  }
}

// ================================================================ player
void gainPiety(World& w, int amt) {
  Player& pl = w.pl;
  if (pl.patron < 0 || amt == 0) return;
  int oldStars = pietyStarsFor(pl.piety);
  pl.piety = clampv(pl.piety + amt, 0, PIETY_MAX);
  pl.pietyMax = std::max(pl.pietyMax, pl.piety);
  int newStars = pietyStarsFor(pl.piety);
  if (newStars != oldStars) {
    recalcStats(w);
    const PatronDef& P = PATRON[pl.patron];
    if (newStars > oldStars) {
      for (int k = oldStars; k < newStars; ++k) {
        logMsg(w, P.color, "%s grants you a gift: %s!", P.name, ABIL[P.gifts[k]].name);
        fxBanner(w, std::string(P.name) + " is pleased: " + ABIL[P.gifts[k]].name, P.color);
      }
      fxSound(w, S_LEVEL, 0.8f, 0.8f);
    } else {
      logMsg(w, 0xff8080, "You feel %s's favor slipping away.", P.name);
    }
  }
}

void healPlayer(World& w, int amt, bool) {
  if (amt <= 0 || w.dead) return;
  amt = (int)std::lround(amt * w.st.healMul);
  int actual = std::min(amt, w.st.maxHp - w.pl.hp);
  if (actual <= 0) return;
  w.pl.hp += actual;
  fxText(w, V2(200, 118), 0x60ff80, fmt("+%d", actual), 16);
  if (w.pl.patron == PT_VERDANA) {
    w.fl.pietyAcc += actual;
    if (w.fl.pietyAcc >= 3) {
      gainPiety(w, w.fl.pietyAcc / 3);
      w.fl.pietyAcc %= 3;
    }
  }
  if (hasRelic(w, RL_ROSE) && actual >= 2) w.pl.block += actual / 2;
  int ll = abLevel(w, AB_LIFELINK);
  if (ll && !w.fl.inLifelink && w.screen == RS_FLOOR) {
    int t = nearestMonster(w, V2(800, 300));
    if (t >= 0) {
      w.fl.inLifelink = true;
      int d = std::max(1, actual * (ll <= 1 ? 50 : ll == 2 ? 75 : 100) / 100);
      fxZap(w, V2(200, 118), w.fl.mons[t].p, 0x70ff90);
      damageMonster(w, t, d, DS_SPELL);
      w.fl.inLifelink = false;
    }
  }
}

void gainMp(World& w, int amt) {
  if (amt <= 0) return;
  int before = w.pl.mp;
  w.pl.mp = std::min(w.st.maxMp, w.pl.mp + amt);
  if (w.pl.mp > before) fxText(w, V2(200, 150), 0x70a8ff, fmt("+%d MP", w.pl.mp - before), 14);
}

void addBlock(World& w, int n) {
  if (n <= 0) return;
  w.pl.block += n;
  fxText(w, V2(200, 180), 0xc0c8ff, fmt("+%d Block", n), 14);
}

void gainGold(World& w, int amt, V2 at) {
  if (amt <= 0) return;
  amt = std::max(1, (int)std::lround(amt * w.st.goldMul));
  w.pl.gold += amt;
  w.rs.goldEarned += amt;
  if (!w.quiet) {
    Fx& e = pushFx(w, FX_COIN);
    e.a = at;
    e.i = amt;
  }
  if (w.pl.patron == PT_AURUM) {
    w.fl.pietyAcc += amt;
    if (w.fl.pietyAcc >= 4) {
      gainPiety(w, w.fl.pietyAcc / 4);
      w.fl.pietyAcc %= 4;
    }
  }
}

int xpForLevel(int xl) { return 6 + 5 * (xl - 1) + (int)std::lround(0.6 * (xl - 1) * (xl - 1)); }

void gainXp(World& w, int amt) {
  if (amt <= 0 || w.dead) return;
  amt = std::max(1, (int)std::lround(amt * w.st.xpMul));
  w.pl.xp += amt;
  while (w.pl.xp >= xpForLevel(w.pl.xl) && w.pl.xl < 27) {
    w.pl.xp -= xpForLevel(w.pl.xl);
    w.pl.xl++;
    w.pendingLevels++;
    recalcStats(w);
    logMsg(w, 0xffe070, "Welcome to experience level %d!", w.pl.xl);
    fxBanner(w, fmt("Level %d!", w.pl.xl), 0xffe070);
    fxSound(w, S_LEVEL, 0.9f);
    speciesLevelUp(w);
    statLevelUp(w);
  }
  if (needsOffers(w) && w.offers.empty()) generateOffers(w);
}

void selfDamage(World& w, int amt, const char* why) {
  if (amt <= 0 || w.dead) return;
  int before = w.pl.hp;
  w.pl.hp = std::max(1, w.pl.hp - amt);
  int lost = before - w.pl.hp;
  if (lost <= 0) return;
  fxText(w, V2(200, 118), 0xff6060, fmt("-%d", lost), 18);
  if (why) logMsg(w, 0xff9090, "%s costs you %d HP.", why, lost);
  FOR_EFF(hurt, lost);
}

void damagePlayer(World& w, int amt, int srcMon, bool ignoreArmor, const char* srcName) {
  if (w.dead) return;
  Floor& f = w.fl;
  if (!ignoreArmor) {
    int ar = w.st.armor - (w.pl.corrode > 0 ? 2 : 0);
    if (ar < 0) ar = std::max(-3, ar);
    amt -= ar;
  }
  amt = std::max(0, amt);
  if (amt > 0 && w.st.dmgTaken != 1.f) amt = std::max(1, (int)std::ceil(amt * w.st.dmgTaken));
  if (srcMon >= 0 && srcMon < (int)f.mons.size()) {
    if (f.sanctuaryT > 0 && amt > 0) amt = (amt + 1) / 2;
    if (f.firstAttackBlocked) {
      f.firstAttackBlocked = 0;
      if (amt > 0) fxText(w, V2(200, 180), 0xc0d0ff, "Aegis!", 18);
      amt = 0;
    }
    if (amt > 0 && w.pl.guardBlocks > 0) {
      w.pl.guardBlocks--;
      fxText(w, V2(200, 180), 0xa0e0ff, "Guardian!", 18);
      fxSound(w, S_BLOCK, 0.8f, 1.3f);
      amt = 0;
    }
    if (amt > 0 && w.st.dodge > 0 && f.rng.chance(w.st.dodge)) {
      fxText(w, V2(200, 180), 0x6ee89a, "Dodged!", 18);
      fxSound(w, S_WHOOSH, 0.6f, 1.7f);
      amt = 0;
    }
    if (amt > 0 && f.mons[srcMon].boss && w.st.bossDmgTaken != 1.f) amt = (int)std::ceil(amt * w.st.bossDmgTaken);
    int gm = w.pl.mut[MUT_GUARDIAN];
    if (amt > 0 && gm > 0 && f.rng.chance(gm == 1 ? 0.15f : 0.25f)) {
      fxText(w, V2(200, 180), 0xffa0a0, "Spirit guard!", 16);
      amt = 0;
    }
    if (amt > 0 && abLevel(w, AB_P_RECKONING) && f.rng.chance(0.25f) && !f.mons[srcMon].dead) {
      fxText(w, V2(200, 180), 0xe0c090, "Reckoning!", 16);
      fxZap(w, V2(200, 118), f.mons[srcMon].p, 0xe0c090);
      damageMonster(w, srcMon, amt * 2, DS_SPELL);
      amt = 0;
    }
    int raw = amt;
    FOR_EFF(attacked, srcMon, amt);
    if (w.st.thornsDmg > 0 && !f.mons[srcMon].dead) {
      damageMonster(w, srcMon, w.st.thornsDmg, DS_THORNS);
      if (hasRelic(w, RL_MAIDEN)) applyBleed(w, srcMon, 2);
    }
    if (w.st.reflectPct > 0 && raw > 0 && !f.mons[srcMon].dead)
      damageMonster(w, srcMon, std::max(1, (int)(raw * w.st.reflectPct)), DS_THORNS);
  }
  if (w.pl.block > 0 && amt > 0) {
    int a = std::min(w.pl.block, amt);
    w.pl.block -= a;
    amt -= a;
    fxText(w, V2(200, 180), 0xc0c8ff, fmt("Blocked %d", a), 14);
    fxSound(w, S_BLOCK, 0.6f);
  }
  if (amt > 0 && w.st.mpShield > 0 && w.pl.mp > 0) {
    int absorb = std::min((amt + 1) / 2, w.pl.mp * w.st.mpShield);
    int used = (absorb + w.st.mpShield - 1) / w.st.mpShield;
    w.pl.mp -= used;
    amt -= absorb;
    fxText(w, V2(200, 150), 0x70a8ff, fmt("Mana shield -%d MP", used), 14);
  }
  if (amt <= 0) {
    fxText(w, V2(200, 118), 0xa0a8b8, "0", 16);
    return;
  }
  w.pl.hp -= amt;
  f.tookDamageThisTurn = true;
  fxText(w, V2(200, 118), 0xff5050, fmt("-%d", amt), 22);
  fxShake(w, std::min(16.f, 3.f + amt * 0.6f));
  fxSound(w, S_HURT, 0.8f);
  if (w.pl.hp > 0) {
    FOR_EFF(hurt, amt);
    if (w.pl.hp * 4 < w.st.maxHp) tumblerExcite(w, 3);
  }
  if (w.pl.hp <= 0) {
    if (w.pl.deathsDoor > 0) {
      w.pl.hp = 1;
      fxBanner(w, "Death's Door holds!", 0xc0c0ff);
      return;
    }
    if (abLevel(w, AB_P_FAVOR) && !f.favorUsed) {
      f.favorUsed = true;
      w.pl.hp = 1;
      fxBanner(w, "The Tumbler catches you!", 0xff80ff);
      logMsg(w, 0xff80ff, "Fortune favors you: you survive with 1 HP!");
      tumblerExcite(w, 15);
      return;
    }
    if (abLevel(w, AB_PHOENIX) && !w.pl.phoenixUsed) {
      w.pl.phoenixUsed = true;
      w.pl.hp = std::max(1, w.st.maxHp / 2);
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) applyBurn(w, i, 10);
      fxBanner(w, "Reborn from the ashes!", 0xff8040);
      logMsg(w, 0xff8040, "Your Phoenix Feather bursts into flame. You are reborn!");
      fxSound(w, S_FIRE, 1.f, 0.6f);
      return;
    }
    if (w.pl.lives > 0) {
      w.pl.lives--;
      w.pl.hp = std::max(1, w.st.maxHp / 2);
      w.pl.poison = 0;
      w.pl.block = 0;
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (isHostile(w, i)) f.mons[i].cd += 1;
      fxBanner(w, fmt("You lose a life! (%d left)", w.pl.lives), 0xffd0a0);
      logMsg(w, 0xffd0a0, "You die... and land on your feet. (%d extra %s left)", w.pl.lives, w.pl.lives == 1 ? "life" : "lives");
      fxSound(w, S_LEVEL, 1.f, 0.5f);
      return;
    }
    w.pl.hp = 0;
    w.dead = true;
    f.phase = PH_DEAD;
    if (srcName) w.rs.killer = srcName;
    else if (srcMon >= 0) {
      const MonDef& md = monLook(f.mons[srcMon]);
      w.rs.killer = (md.traits & TR_BOSS) ? std::string(md.name) : withArt(md.name);
    } else w.rs.killer = "something";
    logMsg(w, 0xff4040, "You die...");
    fxSound(w, S_LOSE, 1.f);
  }
}

// ================================================================ monsters
const Intent* monsterScript(const Monster& m, int* len) {
  const MonDef& d = MON[m.def];
  const Intent* s = m.phase == 0 ? d.s1 : (m.phase == 1 ? d.s2 : d.s3);
  if (s[0].kind == IN_NONE) s = d.s1;
  int n = 0;
  while (n < 5 && s[n].kind != IN_NONE) n++;
  if (len) *len = n;
  return s;
}

int numPhases(const MonDef& d) { return d.s3[0].kind != IN_NONE ? 3 : (d.s2[0].kind != IN_NONE ? 2 : 1); }

void setIntent(World& w, Monster& m, int pos, int extraDelay) {
  int n = 0;
  const Intent* s = monsterScript(m, &n);
  if (n == 0) return;
  pos %= n;
  m.spos = pos;
  m.intent = s[pos].kind;
  m.ival = s[pos].val;
  m.iarg = s[pos].arg;
  m.cd = std::max(1, (int)(s[pos].delay & 0x7f) + extraDelay);
  if (hasAffix(m, AF_FAST)) m.cd = std::max(1, m.cd - 1);
  if (m.intent == IN_BEAM) m.beamHp = std::max(1, (int)(s[pos].arg * (1.f + 0.08f * w.descent)));
  else m.beamHp = 0;
}

const MonDef& monLook(const Monster& m) { return MON[(m.look >= 0 && m.look < M_COUNT) ? m.look : m.def]; }

// Global difficulty knobs (tuned with the headless simulator; DC_* environment overrides exist for tuning runs)
static float envKnob(const char* n, float d) {
  const char* v = getenv(n);
  return v ? (float)atof(v) : d;
}
static const float MON_HP_MUL = envKnob("DC_HP", 2.6f);       // regular monsters
static const float ELITE_HP_MUL = envKnob("DC_EHP", 2.2f);    // monsters defined as elites
static const float BOSS_HP_MUL = envKnob("DC_BHP", 1.15f);
static const float MON_DMG_MUL = envKnob("DC_DMG", 2.2f);
static const float DEPTH_DMG = envKnob("DC_DDMG", 0.028f);   // extra monster damage per depth
static const float DEPTH_HP = envKnob("DC_DHP", 0.015f);    // extra monster HP per depth

static bool dmgIntent(int k) {
  switch (k) {
    case IN_ATTACK: case IN_HEAVY: case IN_MULTI: case IN_BEAM: case IN_QUAKE: case IN_LIFEDRAIN: case IN_DISPEL:
    case IN_EXECUTE: case IN_SUNDER: return true;
  }
  return false;
}
int scaledMonsterValue(const World& w, int v) {
  return std::max(1, (int)std::lround(v * MON_DMG_MUL * (1.f + 0.06f * w.descent) * (1.f + DEPTH_DMG * std::max(0, w.depth - 1))));
}
int intentDamage(const World& w, const Monster& m) {
  if (!dmgIntent(m.intent)) return 0;
  float mul = m.boss ? MON_DMG_MUL : (m.elite ? MON_DMG_MUL : MON_DMG_MUL * 1.06f);
  mul *= 1.f + 0.06f * w.descent;
  mul *= 1.f + DEPTH_DMG * std::max(0, w.depth - 1);
  int d = std::max(0, (int)std::lround(m.ival * mul) + m.atkBonus + w.st.monsterAtkBonus);
  if (hasMod(w, MOD_BLOODMOON)) d += 1;
  if (hasAffix(m, AF_STRONG)) d = (int)std::lround(d * 1.4f);
  if (m.boss && w.fl.bossEnraged) d = (int)std::lround(d * 1.5f);
  if (hasAffix(m, AF_MULTISHOT) && d > 0) d = std::max(1, (int)std::lround(d * 0.6f));
  if (m.enraged) d *= 2;
  return d;
}

static std::string intentText1(const World& w, const Monster& m, bool sf);
std::string intentText(const World& w, const Monster& m, bool sf) {
  std::string s = intentText1(w, m, sf);
  if (m.dead || m.intent == IN_RANDOM) return s;
  int n = 0;
  const Intent* sc = monsterScript(m, &n);
  Monster t = m;
  for (int k = 0; k < 2 && n > 1; ++k) {
    if (t.spos >= n || !(sc[t.spos].delay & INTENT_CHAIN) || sc[t.spos].kind != t.intent) break;
    int p = (t.spos + 1) % n;
    t.spos = p;
    t.intent = sc[p].kind;
    t.ival = sc[p].val;
    t.iarg = sc[p].arg;
    std::string nx = intentText1(w, t, sf);
    if (sf) s += nx.empty() ? "+" : "+" + nx;
    else {
      if (!nx.empty()) nx[0] = (char)tolower((unsigned char)nx[0]);
      s += ", then " + nx;
    }
  }
  return s;
}
static std::string intentText1(const World& w, const Monster& m, bool sf) {
  int dmg = intentDamage(w, m);
  bool multi = hasAffix(m, AF_MULTISHOT);
  if (multi && (m.intent == IN_ATTACK || m.intent == IN_HEAVY)) {
    if (sf) return fmt("%dx2", dmg);
    return fmt("%s for %d, twice (multishot)%s", m.intent == IN_HEAVY ? "Heavy attack" : "Attack", dmg, m.enraged ? " (enraged!)" : "");
  }
  switch (m.intent) {
    case IN_ATTACK: return sf ? fmt("%d", dmg) : fmt("Attack for %d%s", dmg, m.enraged ? " (enraged!)" : "");
    case IN_HEAVY: return sf ? fmt("%d!", dmg) : fmt("Heavy attack for %d (ignores armor)%s", dmg, m.enraged ? " (enraged!)" : "");
    case IN_MULTI: return sf ? fmt("%dx%d", dmg, std::max(1, m.iarg)) : fmt("Attack %d times for %d", std::max(1, m.iarg), dmg);
    case IN_BLOCK: return sf ? fmt("+%d", m.ival) : fmt("Gain %d Block", m.ival);
    case IN_HEAL: return sf ? fmt("+%d", m.ival) : fmt("Heal all monsters for %d", m.ival);
    case IN_BUFF: return sf ? fmt("+%d", m.ival) : fmt("Rally: all monsters deal +%d damage", m.ival);
    case IN_SUMMON: return sf ? "" : fmt("Summon %s%s", std::max(1, (int)m.iarg) > 1 ? fmt("%d ", m.iarg).c_str() : "a ",
                                         MON[clampv(m.ival, 0, M_COUNT - 1)].name);
    case IN_HEX: return sf ? fmt("%d", m.ival) : fmt("Curse %d pins (Curse pegs halve your power)", m.ival);
    case IN_BOMB: return sf ? fmt("%d", m.ival) : fmt("Plant a bomb (%d damage in %d turns unless defused)", m.ival, m.iarg > 0 ? m.iarg : 3);
    case IN_WALL: return sf ? "" : "Raise barriers";
    case IN_TELEPORT: return sf ? "" : "Teleport";
    case IN_DRAIN: return sf ? fmt("%d", m.ival) : fmt("Drain %d MP", m.ival);
    case IN_POISON: return sf ? fmt("%d", m.ival) : (w.st.poisonRes ? std::string("Poison you (you are immune)") : fmt("Poison you (%d)", m.ival));
    case IN_WEAKEN: return sf ? fmt("%d", m.ival) : fmt("Weaken you for %d turns (half base power)", m.ival);
    case IN_GROW: return sf ? fmt("+%d", m.ival) : fmt("Grow +%d max HP", m.ival);
    case IN_EAT: return sf ? fmt("%d", m.ival) : fmt("Devour %d pins and heal", m.ival);
    case IN_TOTEM: return sf ? "" : fmt("Raise a totem (+%d Block each turn)", m.ival);
    case IN_CURSEPOCKET: return sf ? "" : "Curse a pocket";
    case IN_STEAL: return sf ? fmt("%d", m.ival) : fmt("Steal %d gold", m.ival);
    case IN_CHARGE: return sf ? "..." : "Gathering strength";
    case IN_SHUFFLE: return sf ? "" : "Shuffle the pockets";
    case IN_RISE: return sf ? "" : (w.fl.spec.biome == BI_FORGE ? "Raise the lava" : "Raise the water");
    case IN_EGGS: return sf ? fmt("%d", std::max(1, (int)m.ival)) : fmt("Lay %d eggs (they hatch into %s in 3 turns unless smashed)", std::max(1, (int)m.ival), MON[m.iarg > 0 ? m.iarg : M_SPIDERLING].name);
    case IN_WEB: return sf ? fmt("%d", m.ival) : fmt("Spin %d webs that slow your balls", m.ival);
    case IN_BLIND: return sf ? "" : fmt("Blind you: no aiming guide for %d turns", m.ival);
    case IN_CURSEBALL: return sf ? "" : "Drain your next ball (it starts with half power)";
    case IN_SHIELDALLY: return sf ? fmt("+%d", m.ival) : fmt("Shield its weakest ally (+%d Block)", m.ival);
    case IN_ENRAGE: return sf ? "!!" : "Enrage: its next attack deals double damage";
    case IN_BURROW: return sf ? "" : fmt("Burrow to a new spot (+%d Block)", m.ival);
    case IN_BEAM:
      if (m.beamHp <= 0) return sf ? "x" : "Charging beam - interrupted!";
      return sf ? fmt("%d!", dmg) : fmt("Charging a beam for %d (ignores armor) - deal %d more damage to interrupt it", dmg, m.beamHp);
    case IN_ACID: return sf ? "" : fmt("Spit acid: dissolve %d pins and corrode you (-2 armor for 2 turns)", m.ival);
    case IN_MUTATEPEGS: return sf ? fmt("%d", m.ival) : fmt("Warp %d special pegs into Curse pegs", m.ival);
    case IN_SWAP: return sf ? "" : "Swap places with another monster";
    case IN_DECOY: return sf ? "" : fmt("Create %d mirror image%s", std::max(1, (int)m.ival), m.ival > 1 ? "s" : "");
    case IN_FREEZEPOCKET: return sf ? "" : "Freeze a pocket solid for 2 turns";
    case IN_DEVOUR: return sf ? "" : "Devour nearby special pegs and heal";
    case IN_GRAVITY: return sf ? "" : "Open a gravity well on the board";
    case IN_RANDOM: return sf ? "???" : "Something chaotic";
    case IN_SLOW: return sf ? fmt("%d", m.ival) : fmt("Slow you: no MP regeneration for %d turns", m.ival);
    case IN_SAP: return sf ? fmt("%d", m.ival) : fmt("Sap you: -2 base power for %d turns", m.ival);
    case IN_CALL: return sf ? "" : "Call a monster from the depths";
    case IN_QUAKE: return sf ? fmt("%d!", dmg) : fmt("Quake: %d damage (ignores armor), and the board shakes loose", dmg);
    case IN_LIFEDRAIN: return sf ? fmt("%d", dmg) : fmt("Drain life: %d damage, and it heals double what it takes", dmg);
    case IN_DISPEL: return sf ? fmt("%d", dmg) : fmt("Dispel: strips your Block, Guardian and charged shots, then hits for %d", dmg);
    case IN_EXECUTE: return sf ? fmt("%d+", dmg) : fmt("Execute: %d damage plus 25%% of your missing HP", dmg);
    case IN_SUNDER: return sf ? fmt("%d", dmg) : fmt("Sunder: %d damage and -2 armor for 3 turns", dmg);
    case IN_FLEE: return sf ? fmt("%d", m.escapeT) : fmt("Escapes in %d turn%s!", m.escapeT, m.escapeT == 1 ? "" : "s");
    case IN_METEOR: {
      int d = scaledMonsterValue(w, m.ival);
      return sf ? fmt("%d", d) : fmt("Call a meteor: %d damage in %d turns unless you smash its marker (3 hits)", d, m.iarg > 0 ? m.iarg : 2);
    }
  }
  return "";
}

int monsterScaledHp(const World& w, int def) {
  const MonDef& d = MON[def];
  float hp = d.hp * ((d.traits & TR_BOSS) ? BOSS_HP_MUL : (d.traits & TR_ELITE) ? ELITE_HP_MUL : MON_HP_MUL);
  if (!(d.traits & (TR_BOSS | TR_ELITE))) hp *= 1.0f + 0.07f * std::max(0, w.step);
  hp *= 1.f + 0.08f * w.descent;
  hp *= 1.f + DEPTH_HP * std::max(0, w.depth - 1);
  return std::max(1, (int)std::lround(hp));
}

int freeClearing(World& w, V2 near, bool randomPick) {
  Floor& f = w.fl;
  std::vector<int> fr;
  for (int i = 0; i < (int)f.clearings.size(); ++i)
    if (f.clearings[i].mon == -1) fr.push_back(i);
  if (fr.empty()) return -1;
  if (randomPick || near.x < 0) return fr[f.rng.range(0, (int)fr.size() - 1)];
  int best = fr[0];
  for (int i : fr)
    if (dist2(f.clearings[i].p, near) < dist2(f.clearings[best].p, near)) best = i;
  return best;
}

int spawnMonster(World& w, int def, int cl, bool summoned) {
  Floor& f = w.fl;
  if ((int)f.mons.size() >= MAX_MONS) return -1;
  if (cl < 0 || cl >= (int)f.clearings.size() || f.clearings[cl].mon != -1) return -1;
  const MonDef& d = MON[def];
  Monster m;
  m.id = f.nextId++;
  m.def = (uint16_t)def;
  m.p = f.clearings[cl].p;
  m.moveFrom = m.p;
  m.r = std::min((d.traits & TR_BOSS) ? d.r : d.r * 1.2f, f.clearings[cl].r - 3);
  m.maxHp = m.hp = monsterScaledHp(w, def);
  if (summoned && hasRelic(w, RL_RATSKULL)) m.maxHp = m.hp = std::max(1, m.hp * 7 / 10);
  m.hpDisp = (float)m.hp;
  m.armor = d.armor;
  m.boss = (d.traits & TR_BOSS) != 0;
  m.elite = (d.traits & TR_ELITE) != 0;
  m.summoned = summoned;
  m.clearing = cl;
  m.reflectUp = (d.traits & TR_REFLECT) != 0;
  m.fresh = f.phase == PH_ENEMY;
  setIntent(w, m, 0, summoned ? 0 : f.rng.range(0, 1));
  if (def == M_TREASURE) m.escapeT = 4;
  f.clearings[cl].mon = (int)f.mons.size();
  f.mons.push_back(m);
  return (int)f.mons.size() - 1;
}

void teleportMonster(World& w, int mi) {
  Floor& f = w.fl;
  Monster& m = f.mons[mi];
  if (m.dead || (MON[m.def].traits & TR_STATIONARY) || m.boss) return;
  std::vector<int> fr;
  for (int i = 0; i < (int)f.clearings.size(); ++i)
    if (f.clearings[i].mon == -1 && f.clearings[i].r >= m.r + 4) fr.push_back(i);
  if (fr.empty()) return;
  int nc = fr[f.rng.range(0, (int)fr.size() - 1)];
  if (m.clearing >= 0) f.clearings[m.clearing].mon = -1;
  f.clearings[nc].mon = mi;
  m.clearing = nc;
  m.moveFrom = m.p;
  m.moveT = 0;
  m.p = f.clearings[nc].p;
  if (w.quiet) m.moveT = 1;
}

void polymorphMonster(World& w, int mi, int nd) {
  Floor& f = w.fl;
  if (mi < 0 || mi >= (int)f.mons.size() || nd < 0 || nd >= M_COUNT) return;
  Monster& m = f.mons[mi];
  if (m.dead || m.boss || (MON[nd].traits & TR_BOSS)) return;
  float frac = m.hp / (float)std::max(1, m.maxHp);
  const MonDef& d = MON[nd];
  m.def = (uint16_t)nd;
  m.maxHp = monsterScaledHp(w, nd);
  if (m.elite && !(d.traits & TR_ELITE)) m.maxHp = m.maxHp * 3 / 2;
  m.hp = std::max(1, (int)std::lround(m.maxHp * frac));
  m.hpDisp = (float)m.hp;
  m.armor = d.armor;
  float cr = (m.clearing >= 0 && m.clearing < (int)f.clearings.size()) ? f.clearings[m.clearing].r - 3 : d.r;
  m.r = std::min(d.r * 1.2f, cr);
  m.phase = 0;
  m.look = -1;
  m.split = m.blinked = false;
  m.reflectUp = (d.traits & TR_REFLECT) != 0;
  m.undyingUsed = false;
  setIntent(w, m, 0, 1);
  m.flash = 1.f;
  fxBurst(w, m.p, d.color, 30, 220, 4);
  fxRing(w, m.p, m.r * 2, 0xff60ff);
  fxSound(w, S_CAST, 0.8f, 1.6f, m.p.x);
}

int randomRosterMonster(World& w, int strength) {
  const BiomeDef& b = BIOME[w.fl.spec.biome];
  std::vector<int> ids;
  for (int i = 0; i < 16 && b.roster[i] != M_COUNT; ++i) ids.push_back(b.roster[i]);
  if (ids.empty()) ids.push_back(M_RAT);
  std::stable_sort(ids.begin(), ids.end(), [](int a, int c) { return MON[a].xp < MON[c].xp; });
  int n = (int)ids.size();
  int lo = 0, hi = n - 1;
  if (strength < 0) hi = std::max(0, n / 2 - 1);
  if (strength > 0) lo = n / 2;
  if (strength > 0 && w.depth >= 4 && w.fl.rng.chance(0.3f)) {
    std::vector<int> el;
    for (int k = 0; k < 3; ++k)
      if (b.elites[k] != M_COUNT) el.push_back(b.elites[k]);
    if (!el.empty()) return el[w.fl.rng.range(0, (int)el.size() - 1)];
  }
  return ids[w.fl.rng.range(lo, std::max(lo, hi))];
}

static void checkPhase(World& w, int mi) {
  Monster& m = w.fl.mons[mi];
  if (m.dead || m.hp <= 0) return;
  const MonDef& d = MON[m.def];
  int np = numPhases(d);
  if (np <= 1 || m.phase >= np - 1) return;
  float frac = m.hp / (float)m.maxHp;
  float thr = np == 2 ? 0.5f : (m.phase == 0 ? 0.66f : 0.33f);
  if (frac <= thr) {
    m.phase++;
    setIntent(w, m, 0, 0);
    m.cd = 1;
    fxBanner(w, std::string(d.name) + (m.phase == 1 ? " grows desperate!" : " goes all in!"), d.color);
    logMsg(w, d.color, "%s enters a new phase!", d.name);
    fxShake(w, 12);
    fxSound(w, S_GROWL, 1.f, 0.6f, m.p.x);
  }
}

int damageMonster(World& w, int mi, int dmg, int src, int ball) {
  Floor& f = w.fl;
  if (mi < 0 || mi >= (int)f.mons.size()) return 0;
  if (f.mons[mi].dead || dmg <= 0) return 0;
  {
    const MonDef& d = MON[f.mons[mi].def];
    if (d.traits & TR_DECOY) {
      Monster& m = f.mons[mi];
      fxText(w, m.p + V2(0, -m.r - 10), 0xff90ff, "an illusion!", 15);
      fxBurst(w, m.p, 0xff90ff, 24, 200);
      killMonster(w, mi, src);
      return 1;
    }
  }
  Monster& m = f.mons[mi];
  const MonDef& d = MON[m.def];
  if (src == DS_ZAP) dmg += w.st.zapBonus;
  if (src == DS_SPELL && w.st.spellDmgMul != 1.f) dmg = std::max(1, (int)std::lround(dmg * w.st.spellDmgMul));
  if (src == DS_EXPLOSION && w.st.explosionMul != 1.f) dmg = std::max(1, (int)std::lround(dmg * w.st.explosionMul));
  if ((m.chilled > 0 || m.frozen > 0) && w.st.chillDmg > 0) dmg += w.st.chillDmg;
  if (src == DS_BURN && w.st.burnMul != 1.f) dmg = std::max(1, (int)std::lround(dmg * w.st.burnMul));
  if ((m.chilled > 0 || m.frozen > 0) && w.st.chillVuln > 0) dmg = (int)std::lround(dmg * (1.f + w.st.chillVuln));
  if (m.corruptT > 0) dmg += m.corruptAmt;
  if (src == DS_HOLY && isUndeadOrDemon(m)) dmg *= 2;
  if (src == DS_BALL) {
    dmg -= m.armor;
    if (dmg <= 0) {
      fxText(w, m.p + V2(0, -m.r - 8), 0x9098a8, "armored", 13);
      return 0;
    }
    if (d.traits & TR_HARDENED) dmg = std::min(dmg, d.tval);
  }
  if (m.shield > 0) {
    int a = std::min(m.shield, dmg);
    m.shield -= a;
    dmg -= a;
    if (m.shield == 0) fxSound(w, S_SHATTER, 0.5f, 1.2f, m.p.x);
    if (dmg <= 0) {
      fxText(w, m.p + V2(0, -m.r - 8), 0xb0c0ff, fmt("-%d block", a), 13);
      return 0;
    }
  }
  m.hp -= dmg;
  m.flash = 1.f;
  m.turnDamage += dmg;
  w.rs.damage += dmg;
  if (m.intent == IN_BEAM && m.beamHp > 0) {
    m.beamHp -= dmg;
    if (m.beamHp <= 0 && m.hp > 0) {
      fxText(w, m.p + V2(0, -m.r - 24), 0xfff0a0, "Beam interrupted!", 16);
      fxSound(w, S_SHATTER, 0.7f, 0.7f, m.p.x);
      logMsg(w, 0xfff0a0, "You interrupt %s's beam!", TheM(m).c_str());
    }
  }
  uint32_t col = 0xffffff;
  switch (src) {
    case DS_BURN: col = 0xff8040; break;
    case DS_POISON: col = 0x90e040; break;
    case DS_SPELL: col = 0xd0a0ff; break;
    case DS_ZAP: col = 0xfff080; break;
    case DS_EXPLOSION: col = 0xffa040; break;
    case DS_THORNS: col = 0x90c060; break;
    case DS_ALLY: col = 0xe0d0b0; break;
    case DS_POCKET: col = 0xff6070; break;
    case DS_DISCHARGE: col = 0xa8d0ff; break;
    case DS_BLEED: col = 0xe03848; break;
    case DS_HOLY: col = 0xfff0a0; break;
  }
  if (src != DS_BALL) fxText(w, m.p + V2(f.rng.rangef(-10, 10), -m.r - 6), col, fmt("%d", dmg), 15);
  (void)ball;
  checkPhase(w, mi);
  if (f.mons[mi].hp <= 0) {
    int over = -f.mons[mi].hp;
    V2 at = f.mons[mi].p;
    killMonster(w, mi, src);
    if (over > 0 && src == DS_BALL && w.st.overkill > 0) {
      int o = nearestMonster(w, at, mi);
      if (o >= 0) {
        fxZap(w, at, f.mons[o].p, 0xff9060);
        damageMonster(w, o, std::max(1, (int)std::lround(over * w.st.overkill)), DS_EXPLOSION);
      }
    }
    return dmg;
  }
  // traits that react to damage (may push new monsters: take no references past this point)
  if ((d.traits & TR_BLINKER) && !f.mons[mi].blinked && f.mons[mi].hp * 2 < f.mons[mi].maxHp) {
    f.mons[mi].blinked = true;
    fxText(w, f.mons[mi].p + V2(0, -f.mons[mi].r - 10), 0xc0a0ff, "blinks away!", 14);
    teleportMonster(w, mi);
  }
  if (((d.traits & TR_SPLITHIT) || hasAffix(f.mons[mi], AF_SPLITTING)) && !f.mons[mi].split && dmg * 4 >= f.mons[mi].maxHp && f.mons[mi].hp >= 6 &&
      (int)f.mons.size() < MAX_MONS) {
    int cl = freeClearing(w, f.mons[mi].p, false);
    if (cl >= 0) {
      V2 from = f.mons[mi].p;
      int ni = spawnMonster(w, f.mons[mi].def, cl, true);
      if (ni >= 0) {
        Monster& a = f.mons[mi];
        Monster& b = f.mons[ni];
        int half = a.hp / 2;
        b.maxHp = std::max(1, a.maxHp / 2);
        b.hp = std::max(1, half);
        b.hpDisp = (float)b.hp;
        a.maxHp = std::max(1, a.maxHp - b.maxHp);
        a.hp = std::max(1, a.hp - half);
        a.split = b.split = true;
        b.moveFrom = from;
        b.moveT = w.quiet ? 1.f : 0.f;
        fxText(w, from + V2(0, -a.r - 12), d.color, "splits!", 15);
        logMsg(w, d.color, "%s splits in two!", The(d).c_str());
      }
    }
  }
  return dmg;
}

void killMonster(World& w, int mi, int src) {
  Floor& f = w.fl;
  Monster& m = f.mons[mi];
  if (m.dead) return;
  const MonDef& d = MON[m.def];
  if ((d.traits & TR_UNDYING) && !m.undyingUsed) {
    m.undyingUsed = true;
    m.hp = std::max(1, m.maxHp / 2);
    m.burn = m.poison = m.bleed = 0;
    fxText(w, m.p + V2(0, -m.r - 10), 0xe8e8d8, "rises again!", 15);
    logMsg(w, 0xe8e8d8, "%s reassembles itself!", The(d).c_str());
    fxSound(w, S_SPAWN, 0.7f, 0.8f, m.p.x);
    return;
  }
  m.dead = true;
  m.hp = 0;
  if (m.clearing >= 0 && m.clearing < (int)f.clearings.size() && f.clearings[m.clearing].mon == mi) f.clearings[m.clearing].mon = -1;
  bool decoy = (d.traits & TR_DECOY) != 0;
  // snapshot: hooks below may add monsters and invalidate references
  const V2 pos = m.p;
  const float rad = m.r;
  const bool boss = m.boss, elite = m.elite, summoned = m.summoned, bounty = m.bounty, burning = m.burn > 0;
  const bool poisoned = m.poison > 0, marked = m.markT > 0;
  const int markGold = m.markGold, def = m.def;
  const Monster snap = m;
  if (decoy) {
    fxSound(w, S_SHATTER, 0.6f, 1.5f, pos.x);
    return;
  }
  f.kills++;
  w.rs.kills++;
  f.shot.kills++;
  f.lastKillPos = pos;
  f.lastKillDef = def;
  if (boss || elite) w.rs.eliteKills++;
  bool promoted = elite && !(d.traits & TR_ELITE);
  if (!summoned) {
    int xp = d.xp;
    if (promoted) xp = xp * 5 / 2;
    if (marked) xp = xp * 3 / 2;
    if (snap.champ == 1) xp = xp * 3 / 2;
    if (snap.champ == 2) xp *= 3;
    gainXp(w, xp);
    int gold = d.gold + w.st.killGold + (marked ? markGold : 0);
    if (promoted) gold *= 2;
    if (snap.champ) gold *= snap.champ == 2 ? 3 : 2;
    if (hasMod(w, MOD_GOLDRUSH)) gold *= 2;
    gainGold(w, gold, pos);
  }
  if (bounty) {
    int g = 30 + 5 * w.depth;
    gainGold(w, g, pos);
    fxBanner(w, fmt("Bounty collected! +%d gold", g), 0xffd040);
    static const int L[] = {IT_HEALING, IT_MANA, IT_MIGHT, IT_RESIST, IT_ENCHANT, IT_W_FLAME, IT_W_ICE, IT_LUCK};
    int it = L[f.rng.range(0, 7)];
    if (gainItem(w, it)) logMsg(w, ITEM[it].color, "The bounty includes a %s.", ITEM[it].name);
  }
  if (w.st.killHeal > 0) healPlayer(w, w.st.killHeal);
  if (w.st.killMp > 0) gainMp(w, w.st.killMp);
  if (hasMod(w, MOD_BLOODMOON)) healPlayer(w, 2);
  // patron piety
  bool big = boss || elite;
  switch (w.pl.patron) {
    case PT_VRASK: gainPiety(w, big ? 8 : 4); break;
    case PT_MORGRAVE: gainPiety(w, 3 + ((burning || poisoned) ? 2 : 0)); break;
    case PT_ASHKA: gainPiety(w, burning || src == DS_BURN ? 4 : 1); break;
    case PT_ARCANA: gainPiety(w, big ? 6 : 3); break;
    case PT_GLUB: gainPiety(w, (d.traits & TR_SLIMY) ? 5 : 2); break;
    case PT_TEMPESTRA: gainPiety(w, big ? 6 : 3); break;
    case PT_AURELIA: gainPiety(w, (d.traits & (TR_UNDEAD | TR_DEMONIC)) ? 7 : 3); break;
    case PT_ANCESTOR: gainPiety(w, 2); break;
    case PT_VOIDMAW: gainPiety(w, src == DS_DISCHARGE ? 5 : 3); break;
    case PT_BRAKKA: gainPiety(w, big ? 12 : 2); break;
    case PT_RUUN: gainPiety(w, big ? 3 : 1); break;
    case PT_SIFRA: if (src == DS_SPELL) gainPiety(w, 2); break;
  }
  tumblerExcite(w, boss ? 20 : elite ? 10 : 4);
  logMsg(w, 0xffb060, boss ? "You have defeated %s!" : "You kill the %s!", d.name);
  fxBurst(w, pos, d.color, boss ? 80 : 30, boss ? 420 : 260, 4);
  fxRing(w, pos, rad * 2.2f, d.color);
  fxSound(w, S_KILL, boss ? 1.f : 0.75f, boss ? 0.7f : 1.f, pos.x);
  fxShake(w, boss ? 22 : 6);
  // remove owned totems
  for (auto& p : f.pegs)
    if (!p.dead && p.kind == PK_TOTEM && p.link == mi) {
      p.dead = true;
      fxBurst(w, p.p, PEG_COLOR[PK_TOTEM], 10, 150);
    }
  FOR_EFF(kill, mi);
  if (w.st.killPower > 0 && f.phase == PH_FLIGHT) allBallsPower(w, w.st.killPower);
  monsterDiedLoot(w, snap, pos);
  if (snap.champ == 2) fxBanner(w, std::string(snap.uname) + " is slain!", 0xffc040);
  // traits
  if ((d.traits & TR_SPLIT) && d.splitInto >= 0) {
    for (int k = 0; k < 2; ++k) {
      int cl = freeClearing(w, pos, false);
      if (cl < 0) break;
      int ni = spawnMonster(w, d.splitInto, cl, summoned);
      if (ni >= 0) {
        f.mons[ni].moveFrom = pos;
        f.mons[ni].moveT = w.quiet ? 1.f : 0.f;
      }
    }
    logMsg(w, d.color, "%s splits apart!", The(d).c_str());
  }
  if (d.traits & TR_VOLATILE) {
    fxBurst(w, pos, 0xffa040, 30, 280, 4);
    fxRing(w, pos, 110, 0xffa040);
    fxSound(w, S_BOOM, 0.7f, 1.2f, pos.x);
    convertPins(w, PK_FIRE, 3, pos, 110);
    hitMonstersInRadius(w, pos, 110, std::max(1, d.tval), DS_EXPLOSION, mi);
  }
  for (int i = 0; i < (int)f.mons.size(); ++i) {
    Monster& o = f.mons[i];
    if (!o.dead && (MON[o.def].traits & TR_ENRAGE)) o.atkBonus += 2;
  }
}

void applyBurn(World& w, int mi, int n) {
  if (mi < 0 || mi >= (int)w.fl.mons.size() || n <= 0) return;
  Monster& m = w.fl.mons[mi];
  if (m.dead) return;
  n += w.st.burnBonus;
  if (hasRelic(w, RL_BRIMSTONE)) n = (n * 3 + 1) / 2;
  m.burn += n;
}
void applyPoison(World& w, int mi, int n) {
  if (mi < 0 || mi >= (int)w.fl.mons.size() || n <= 0) return;
  Monster& m = w.fl.mons[mi];
  if (m.dead || (MON[m.def].traits & TR_SLIMY)) return;
  if (hasRelic(w, RL_FANG)) n = (n * 3 + 1) / 2;
  m.poison += n;
}
void applyChill(World& w, int mi, int n) {
  if (mi < 0 || mi >= (int)w.fl.mons.size() || n <= 0) return;
  Monster& m = w.fl.mons[mi];
  if (m.dead) return;
  if (m.boss && m.chilled > 0) {
    fxText(w, m.p + V2(0, -m.r - 16), 0xa0c8e0, "shrugs off the chill", 12);
    return;
  }
  if (m.boss) n = 1;
  m.cd += n;
  m.chilled = 2;
  fxText(w, m.p + V2(0, -m.r - 16), 0xa0e8ff, "chilled", 13);
}
void applyBleed(World& w, int mi, int n) {
  if (mi < 0 || mi >= (int)w.fl.mons.size() || n <= 0) return;
  Monster& m = w.fl.mons[mi];
  if (m.dead || (MON[m.def].traits & (TR_SLIMY | TR_UNDEAD))) return;
  m.bleed += n;
}
void applyCorrupt(World& w, int mi, int amt, int turns) {
  if (mi < 0 || mi >= (int)w.fl.mons.size()) return;
  Monster& m = w.fl.mons[mi];
  if (m.dead) return;
  m.corruptAmt = std::max(m.corruptAmt, amt);
  m.corruptT = std::max(m.corruptT, turns);
  fxBurst(w, m.p, 0x8040e0, 14, 150);
}
void freezeMonster(World& w, int mi) {
  if (mi < 0 || mi >= (int)w.fl.mons.size()) return;
  Monster& m = w.fl.mons[mi];
  if (m.dead || m.frozen > 0 || m.freezeImmune > 0) return;
  m.frozen = 1;
  fxText(w, m.p + V2(0, -m.r - 16), 0xc0f0ff, "FROZEN", 15);
  fxBurst(w, m.p, 0xc0f0ff, 16, 160);
  fxSound(w, S_FREEZE, 0.7f, 1.f, m.p.x);
}

// ================================================================ pegs / board helpers
int addPeg(World& w, int kind, V2 p, float r) {
  Floor& f = w.fl;
  if ((int)f.pegs.size() >= MAX_PEGS) return -1;
  Peg pg;
  pg.id = f.nextId++;
  pg.kind = (uint8_t)kind;
  pg.p = pg.anchor = p;
  pg.r = r > 0 ? r : PIN_R;
  pg.hp = 1;
  switch (kind) {
    case PK_STONE: case PK_CHEST: case PK_TOTEM: pg.hp = 3; break;
    case PK_PILLAR: pg.hp = 4; break;
    case PK_BOMB: pg.val = 8 + w.depth; break;
    case PK_COINS: pg.hp = 5; break;
    case PK_EGG: pg.val = 3; pg.aux = M_SPIDERLING; break;
    case PK_WELL: case PK_PINATA: case PK_MIMIC: pg.hp = 3; break;
  }
  pg.row = (int)std::lround((p.y - FIELD_Y0) / 44.f);
  f.pegs.push_back(pg);
  return (int)f.pegs.size() - 1;
}

int addSeg(World& w, int kind, V2 a, V2 b, float th) {
  Floor& f = w.fl;
  if ((int)f.segs.size() >= MAX_SEGS) return -1;
  Seg s;
  s.id = f.nextId++;
  s.kind = (uint8_t)kind;
  s.a = a;
  s.b = b;
  s.c = (a + b) * 0.5f;
  s.th = th;
  s.len = len(b - a) * 0.5f;
  s.ang = std::atan2(b.y - a.y, b.x - a.x);
  if (kind == SK_KICKER) {
    s.rest = 1.0f;
    s.kick = 520;
  }
  f.segs.push_back(s);
  return (int)f.segs.size() - 1;
}

int addZone(World& w, int kind, V2 p, V2 half, bool circle) {
  Floor& f = w.fl;
  if ((int)f.zones.size() >= MAX_ZONES) return -1;
  Zone z;
  z.kind = (uint8_t)kind;
  z.p = p;
  z.half = half;
  z.circle = circle;
  z.phase = f.rng.rangef(0, 3);
  f.zones.push_back(z);
  return (int)f.zones.size() - 1;
}

bool spotFree(const World& w, V2 p, float r, float margin) {
  const Floor& f = w.fl;
  if (p.x - r < PX0 + 4 || p.x + r > PX1 - 4 || p.y - r < FIELD_Y0 - 40 || p.y + r > POCKET_TOP - 14) return false;
  for (auto& pg : f.pegs)
    if (!pg.dead && dist2(pg.p, p) < (r + pg.r + margin) * (r + pg.r + margin)) return false;
  for (auto& m : f.mons)
    if (!m.dead && dist2(m.p, p) < (r + m.r + margin + 6) * (r + m.r + margin + 6)) return false;
  for (auto& c : f.clearings)
    if (c.mon >= 0 && dist2(c.p, p) < (r + c.r) * (r + c.r)) return false;
  for (auto& s : f.segs) {
    if (s.dead || s.kind == SK_FLIPPER) continue;
    if (s.kind == SK_SPINNER) {
      float lim = r + s.len + 4;
      if (dist2(s.c, p) < lim * lim) return false;
      continue;
    }
    if (s.kind == SK_PENDULUM) {
      float lim = r + s.len * 2 + 8;
      if (dist2(s.c, p) < lim * lim) return false;
      continue;
    }
    V2 cp = closestOnSeg(p, s.a, s.b);
    float lim = r + s.th + margin;
    if (dist2(cp, p) < lim * lim) return false;
  }
  for (auto& z : f.zones)
    if (!z.dead && (z.kind == ZK_PORTAL || z.kind == ZK_RIFT || z.kind == ZK_BLACKHOLE) &&
        dist2(z.p, p) < (r + z.half.x + 6) * (r + z.half.x + 6))
      return false;
  return true;
}

// inside the solid rock of a board format (keep-out circles tagged -20 by formats.cpp; the circles only
// approximate the rock, so they are padded to close the gaps between them)
bool inRock(const World& w, V2 p, float r) {
  for (auto& k : w.fl.keepOut)
    if (k.mon == -20 && dist2(k.p, p) < (k.r + r + 12) * (k.r + r + 12)) return true;
  return false;
}

V2 randomFieldSpot(World& w, float r, float margin, float y0, float y1) {
  Floor& f = w.fl;
  for (int t = 0; t < 250; ++t) {
    V2 p(f.rng.rangef(PX0 + r + 16, PX1 - r - 16), f.rng.rangef(y0, y1));
    if (spotFree(w, p, r, margin) && !inRock(w, p, r)) return p;
  }
  return V2(-1, -1);
}

// the nearest open spot to a stuck ball - first level with it or lower, so it can't roll straight back into the
// same wedge - or (-1, -1) if there is none
V2 freeSpotNear(const World& w, V2 p, float r) {
  for (int pass = 0; pass < 2; ++pass)
    for (float rad = 32; rad <= 260; rad += 24)
      for (int k = 0; k < 16; ++k) {
        // angles fan out from straight down, alternating sides
        float a = PI / 2 + (k % 2 ? 1.f : -1.f) * ((k + 1) / 2) * (PI / 8);
        V2 q = p + fromAng(a) * rad;
        if (q.y > POCKET_TOP - 20 || (pass == 0 && q.y < p.y - 4)) continue;
        if (spotFree(w, q, r + 2, 3) && !inRock(w, q, r)) return q;
      }
  return V2(-1, -1);
}

// A ball must never be able to wedge itself between a small peg and a surface it rolls along. Pegs just above a
// ramp or shelf (closer than a big ball can pass) are removed if plain pins or pushed clear otherwise, and pegs a
// little way off a side wall are moved flush against it.
void clearWedges(World& w) {
  Floor& f = w.fl;
  const float PASS = 2 * 15.f + 6;  // room for the biggest usual ball (a boulder) to roll through
  auto roomFor = [&](const Peg& self, V2 q) {
    if (q.x - self.r < PX0 || q.x + self.r > PX1 || q.y < FIELD_Y0 - 40 || q.y > POCKET_TOP - 20) return false;
    for (auto& o : f.pegs)
      if (!o.dead && &o != &self && dist2(o.p, q) < (o.r + self.r + 8) * (o.r + self.r + 8)) return false;
    for (auto& s : f.segs)
      if (!s.dead && dist(closestOnSeg(q, s.a, s.b), q) < s.th + self.r + 8) return false;
    for (auto& m : f.mons)
      if (!m.dead && dist(m.p, q) < m.r + self.r + 8) return false;
    return !inRock(w, q, self.r);
  };
  for (auto& p : f.pegs) {
    if (p.dead || p.motion || p.r > 10) continue;
    for (int side = 0; side < 2; ++side) {
      float gap = side == 0 ? p.p.x - p.r - PX0 : PX1 - (p.p.x + p.r);
      if (gap <= 3 || gap >= PASS) continue;
      V2 q(side == 0 ? PX0 + p.r : PX1 - p.r, p.p.y);
      if (roomFor(p, q)) p.p = p.anchor = q;
      else if (p.kind == PK_PIN) p.dead = true;
    }
    for (auto& s : f.segs) {
      if (p.dead || s.dead || (s.kind != SK_WALL && s.kind != SK_RAMP)) continue;
      V2 ab = s.b - s.a;
      if (len2(ab) < 1) continue;
      V2 up = norm(V2(ab.y, -ab.x));
      if (up.y > 0) up = up * -1.f;
      if (up.y > -0.25f) continue;  // too steep to roll along
      V2 cp = closestOnSeg(p.p, s.a, s.b);
      V2 d = p.p - cp;
      float gap = len(d) - p.r - s.th;
      if (gap <= 0 || gap >= PASS || dot(d, up) <= 0) continue;
      V2 q = cp + norm(d) * (s.th + p.r + PASS + 2);
      if (p.kind == PK_PIN) p.dead = true;
      else if (roomFor(p, q)) p.p = p.anchor = q;
    }
  }
}

int convertPins(World& w, int kind, int count, V2 near, float radius) {
  Floor& f = w.fl;
  std::vector<int> cand;
  for (int i = 0; i < (int)f.pegs.size(); ++i) {
    const Peg& p = f.pegs[i];
    if (p.dead || p.used || p.kind != PK_PIN || p.motion) continue;
    if (near.x >= 0 && dist(p.p, near) > radius) continue;
    cand.push_back(i);
  }
  f.rng.shuffle(cand);
  int n = 0;
  for (int i : cand) {
    if (n >= count) break;
    Peg& p = f.pegs[i];
    p.kind = (uint8_t)kind;
    p.flash = 1.f;
    if (kind == PK_BOMB) p.val = 8 + w.depth;
    n++;
  }
  return n;
}

void growPins(World& w, int n, V2 near, float radius, bool temp) {
  Floor& f = w.fl;
  int placed = 0;
  for (int tries = 0; tries < n * 40 && placed < n; ++tries) {
    V2 p;
    if (near.x < 0) p = V2(f.rng.rangef(PX0 + 16, PX1 - 16), f.rng.rangef(FIELD_Y0, FIELD_Y1));
    else p = near + fromAng(f.rng.rangef(0, TAU)) * (radius * std::sqrt(f.rng.f()));
    if (p.x < PX0 + 14 || p.x > PX1 - 14 || p.y < FIELD_Y0 - 20 || p.y > FIELD_Y1 + 10) continue;
    if (!spotFree(w, p, PIN_R, 22)) continue;
    bool nearBall = false;
    for (auto& b : f.balls)
      if (b.alive && dist2(b.p, p) < 40 * 40) nearBall = true;
    if (nearBall) continue;
    int pi = addPeg(w, PK_PIN, p, PIN_R);
    if (pi < 0) break;
    f.pegs[pi].temp = temp;
    f.pegs[pi].flash = 1.f;
    placed++;
  }
}

void explodeAt(World& w, V2 p, float radius, int dmg, int srcBall) {
  Floor& f = w.fl;
  fxBurst(w, p, 0xffa040, 36, 320, 4);
  fxRing(w, p, radius, 0xffa040);
  fxShake(w, 9);
  fxSound(w, S_BOOM, 0.8f, 1.f, p.x);
  for (int i = 0; i < (int)f.mons.size(); ++i) {
    if (!isHostile(w, i)) continue;
    if (dist(f.mons[i].p, p) - f.mons[i].r < radius) damageMonster(w, i, dmg, DS_EXPLOSION);
  }
  // chain: other bombs, defuse monster bombs, smash eggs, trigger nearby specials for the ball
  std::vector<int> chainBombs, trig;
  for (int i = 0; i < (int)f.pegs.size(); ++i) {
    Peg& pg = f.pegs[i];
    if (pg.dead || pg.used) continue;
    float d = dist(pg.p, p);
    if (pg.kind == PK_BOMB && d < radius * 0.75f) {
      pg.dead = true;
      chainBombs.push_back(i);
    } else if (pg.kind == PK_MBOMB && d < radius) {
      pg.dead = true;
      fxText(w, pg.p, 0xc0ffc0, "defused", 13);
    } else if (pg.kind == PK_EGG && d < radius) {
      pg.dead = true;
      fxText(w, pg.p, 0xe0d0a0, "splat", 12);
    } else if (srcBall >= 0 && isEnchant(pg.kind) && pg.kind != PK_CURSE && pg.kind != PK_VOID && pg.kind != PK_TELEPORT &&
               d < 70) {
      trig.push_back(i);
    }
  }
  if (srcBall >= 0 && srcBall < (int)f.balls.size() && f.balls[srcBall].alive)
    for (int i : trig)
      if (!f.pegs[i].dead && !f.pegs[i].used) {
        pegTriggerEffect(w, srcBall, i, false);
        f.pegs[i].used = true;
      }
  for (int i : chainBombs) explodeAt(w, f.pegs[i].p, 110, f.pegs[i].val, srcBall);
}

void placeWormhole(World& w, V2 a, V2 b, int ttl) {
  Floor& f = w.fl;
  int ex = addZone(w, ZK_PORTAL, b, V2(22, 22), true);
  if (ex < 0) return;
  f.zones[ex].link = -1;
  f.zones[ex].ttl = ttl;
  int en = addZone(w, ZK_PORTAL, a, V2(22, 22), true);
  if (en < 0) return;
  f.zones[en].link = ex;
  f.zones[en].ttl = ttl;
}

void placeRift(World& w, V2 a, V2 b, int ttl) {
  Floor& f = w.fl;
  int za = addZone(w, ZK_RIFT, a, V2(24, 24), true);
  if (za < 0) return;
  int zb = addZone(w, ZK_RIFT, b, V2(24, 24), true);
  if (zb < 0) {
    f.zones[za].dead = true;
    return;
  }
  f.zones[za].link = zb;
  f.zones[zb].link = za;
  f.zones[za].ttl = f.zones[zb].ttl = ttl;
  f.zones[za].dmg = f.zones[zb].dmg = 2;
}

void rotatePockets(World& w, int dir) {
  Floor& f = w.fl;
  int n = (int)f.pockets.size();
  if (n < 2) return;
  std::vector<Pocket> old = f.pockets;
  for (int i = 0; i < n; ++i) {
    int src = ((i - dir) % n + n) % n;
    f.pockets[i].kind = old[src].kind;
    f.pockets[i].orig = old[src].orig;
    f.pockets[i].val = old[src].val;
    f.pockets[i].flash = 1.f;
  }
  layoutPockets(w);
}

void cleanseCurses(World& w, bool pockets) {
  Floor& f = w.fl;
  for (auto& p : f.pegs)
    if (!p.dead && p.kind == PK_CURSE) {
      p.kind = PK_PIN;
      p.flash = 1.f;
    }
  if (pockets) {
    bool any = false;
    for (auto& pk : f.pockets)
      if (pk.kind == PO_CURSED || pk.kind == PO_FROZEN) {
        pk.kind = pk.orig;
        pk.val = 0;
        pk.flash = 1.f;
        any = true;
      }
    if (any) layoutPockets(w);
  }
}

int abilityGoldCost(const World& w, int ab, int lvl) {
  switch (ab) {
    case AB_BRIBE: return (lvl <= 1 ? 12 : lvl == 2 ? 10 : 8) + w.depth;
    case AB_COINTOSS: return 5 + w.depth / 2;
    case AB_P_TOLL: return 15 + w.depth;
    case AB_P_GOLDTOUCH: return 40;
    case AB_P_BUYOUT: return 120;
    case AB_P_GOLDSTORM: return 60;
  }
  return ABIL[ab].goldCost;
}

void spawnBallDeferred(World& w, const Ball& b) {
  if ((int)(w.fl.balls.size() + w.fl.newBalls.size()) >= MAX_BALLS) return;
  w.fl.newBalls.push_back(b);
}

int spawnBall(World& w, V2 p, V2 v, int power, uint32_t flags, int gen) {
  Ball b;
  b.id = w.fl.nextId++;
  b.p = p;
  b.v = v;
  b.r = w.st.ballR * ((flags & BF_PHANTOM) ? 0.8f : 1.f);
  b.power = power;
  b.flags = flags;
  b.gen = gen;
  b.stuckRef = p;
  spawnBallDeferred(w, b);
  return b.id;
}

void splitBall(World& w, int bi, float powerFrac, int copies) {
  Floor& f = w.fl;
  if (bi < 0 || bi >= (int)f.balls.size() || !f.balls[bi].alive) return;
  for (int k = 0; k < copies; ++k) {
    Ball b = f.balls[bi];
    b.id = f.nextId++;
    b.power = std::max(1, (int)std::lround(b.power * powerFrac));
    float ang = (k % 2 == 0 ? 1.f : -1.f) * (0.35f + 0.2f * (k / 2));
    b.v = rot(b.v, ang) * 1.02f;
    if (len(b.v) < 250) b.v = norm(b.v) * 250;
    b.flags &= ~(BF_CAUGHT);
    b.gen++;
    b.lastMon = -1;
    b.catches = 0;
    b.stuckT = 0;
    b.stuckCount = 0;
    b.staleHits = 0;
    spawnBallDeferred(w, b);
  }
  fxBurst(w, f.balls[bi].p, 0xd080ff, 10, 200);
  if (w.pl.patron == PT_MIRRA) gainPiety(w, copies);
}

int placeAlly(World& w, int kind, V2 near, int dmg, int ttl) {
  Floor& f = w.fl;
  V2 spot(-1, -1);
  for (int t = 0; t < 300; ++t) {
    float rad = 20.f + t * 0.8f;
    V2 p = near.x < 0 ? V2(f.rng.rangef(PX0 + 50, PX1 - 50), f.rng.rangef(FIELD_Y0 + 60, FIELD_Y1 - 80))
                      : near + fromAng(f.rng.rangef(0, TAU)) * f.rng.rangef(0, rad);
    if (p.x < PX0 + 30 || p.x > PX1 - 30 || p.y < FIELD_Y0 || p.y > FIELD_Y1 - 20) continue;
    if (!spotFree(w, p, 13, 6)) continue;
    spot = p;
    break;
  }
  if (spot.x < 0) return -1;
  int pi = addPeg(w, kind, spot, 13);
  if (pi < 0) return -1;
  Peg& p = f.pegs[pi];
  p.val = dmg;
  p.ttl = ttl > 0 ? ttl + w.st.allyTurns : 0;
  p.temp = true;
  p.flash = 1.f;
  fxBurst(w, spot, PEG_COLOR[kind], 20, 180);
  fxSound(w, S_SPAWN, 0.7f, 1.2f, spot.x);
  return pi;
}

float allyDamageMul(const World& w) { return w.st.allyDmgMul; }

void discharge(World& w, V2 from, int dmg, uint32_t col) {
  Floor& f = w.fl;
  if (dmg <= 0) return;
  int t = focusTarget(w);
  if (t < 0) return;
  V2 tp = f.mons[t].p;
  fxZap(w, from, tp, col);
  damageMonster(w, t, dmg, DS_DISCHARGE);
  if (hasRelic(w, RL_CHAIN)) {
    int o = nearestMonster(w, tp, t);
    if (o >= 0) {
      fxZap(w, tp, f.mons[o].p, col);
      damageMonster(w, o, std::max(1, dmg / 2), DS_DISCHARGE);
    }
  }
}

void noteDamageDealt(World& w, int dealt) {
  if (dealt >= 100) tumblerExcite(w, 10);
  else if (dealt >= 50) tumblerExcite(w, 5);
}

void conductSpell(World& w, int ab, int mpCost) {
  const AbilityDef& d = ABIL[ab];
  if (d.school == SCH_DIVINE) return;
  if (mpCost > 0 && relicSetCount(w, 3) >= 3) allBallsPower(w, 4);
  switch (w.pl.patron) {
    case PT_VRASK:
      if (mpCost > 0) {
        gainPiety(w, -6);
        logMsg(w, 0xff6040, "Vrask scowls at your sorcery.");
      }
      break;
    case PT_VERDANA:
      if (d.school == SCH_FLAME) {
        gainPiety(w, -5);
        logMsg(w, 0x70e070, "Verdana recoils from your flames.");
      }
      break;
    case PT_ASHKA:
      if (d.school == SCH_FROST) {
        gainPiety(w, -5);
        logMsg(w, 0xff8030, "Ashka hisses at your frost.");
      }
      break;
    case PT_TOCK:
      if (ab == AB_HASTE) gainPiety(w, -15);
      break;
    case PT_AURELIA:
      if (d.school == SCH_BLOOD || d.school == SCH_SHADOW || d.school == SCH_CHAOS) {
        gainPiety(w, -5);
        logMsg(w, 0xfff0a0, "Aurelia's light dims at your unholy magic.");
      }
      break;
    case PT_BRAKKA:
      if (d.school == SCH_SUMMON) {
        gainPiety(w, -8);
        logMsg(w, 0xd0a060, "Brakka wants you to fight your own battles.");
      }
      break;
    case PT_GLUB:
      if (d.school == SCH_FLAME) gainPiety(w, -3);
      break;
    case PT_SIFRA:
      if (mpCost > 0) gainPiety(w, mpCost);
      break;
    case PT_MIRRA:
      if (ab == AB_WORMHOLE || ab == AB_RIFT) gainPiety(w, 2);
      break;
  }
}
