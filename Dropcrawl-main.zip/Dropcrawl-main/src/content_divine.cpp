// Dropcrawl - patron gifts for the new gods, and the fifth (capstone) gift of the original eight
#include "rules.h"

static AbilityDef& GIFT(int id, const char* name, int timing, int target, int piety, const char* desc) {
  AbilityDef& a = ABIL[id];
  a.id = (uint16_t)id;
  a.name = name;
  a.school = SCH_DIVINE;
  a.timing = (uint8_t)timing;
  a.target = (uint8_t)target;
  a.rarity = R_COMMON;
  a.maxLvl = 1;
  for (int i = 0; i < 5; ++i) a.cost[i] = (int8_t)piety;
  a.cooldown = 0;
  a.goldCost = 0;
  a.desc = desc;
  a.cast = nullptr;
  a.h = Hooks();
  a.hpCost[0] = a.hpCost[1] = a.hpCost[2] = 0;
  a.innate = false;
  return a;
}

static void allHostile(World& w, void (*fn)(World&, int)) {
  for (int i = 0; i < (int)w.fl.mons.size(); ++i)
    if (isHostile(w, i)) fn(w, i);
}

void initDivine() {
  // =========================================================== capstones of the original gods
  {
    auto& a = GIFT(AB_P_UNBREAKABLE, "Unbreakable", T_PASSIVE, TG_NONE, 0,
                   "+8 max HP. The first time each floor you fall below 30% HP, you gain Block equal to 30% of your max HP.");
    a.h.stats = [](World& w, int) { w.st.maxHp += 8; };
    a.h.hurt = [](World& w, int, int) {
      if ((w.fl.onceFlags & OF_UNBREAK) || w.pl.hp * 10 >= w.st.maxHp * 3) return;
      w.fl.onceFlags |= OF_UNBREAK;
      addBlock(w, w.st.maxHp * 3 / 10);
      fxBanner(w, "Unbreakable!", 0xff6040);
    };
  }
  {
    auto& a = GIFT(AB_P_GOLDSTORM, "Gold Storm", T_AIM, TG_NONE, 0,
                   "Pay 60 gold: coins rain down, dealing 10 + 10% of your remaining gold (max 80) to every monster.");
    a.cast = [](World& w, int, V2, V2, int) {
      int d = std::min(80, 10 + (w.pl.gold - 60) / 10);
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) {
          fxBurst(w, w.fl.mons[i].p, 0xffd040, 24, 240);
          damageMonster(w, i, d, DS_SPELL);
        }
      fxSound(w, S_COIN, 1.f, 0.7f);
      fxShake(w, 8);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_CHAOSSTORM, "Storm of Chaos", T_AIM, TG_NONE, 60, "The Tumbler meddles three times in a row, very kindly.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int k = 0; k < 3; ++k) tumblerInvoke(w, 3);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_EVERGREEN, "Evergreen", T_PASSIVE, TG_NONE, 0,
                   "+2 HP regeneration. Pins you hit have a 4% chance to blossom into Heal pegs.");
    a.h.stats = [](World& w, int) { w.st.hpRegen += 2; };
    a.h.pegHit = [](World& w, int, int pi, int) {
      Peg& p = w.fl.pegs[pi];
      if (!p.dead && p.kind == PK_PIN && w.fl.rng.chance(0.04f)) {
        p.kind = PK_HEAL;
        p.flash = 1.f;
      }
    };
  }
  {
    auto& a = GIFT(AB_P_TIMESTOP, "Time Stop", T_AIM, TG_NONE, 80, "Stop time: your next two shots are free turns.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.timeStop > 0) return false;
      w.fl.timeStop = 2;
      fxBanner(w, "Time stops.", 0xc8b890);
      fxSound(w, S_TICK, 1.f, 0.4f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_ARMY, "Army of the Dead", T_AIM, TG_NONE, 70,
                   "Three skeletons rise to fight for you for the rest of the floor. Each strikes a random monster for 4 (+1 per "
                   "2 depth) after every enemy phase.");
    a.cast = [](World& w, int, V2, V2, int) {
      int made = 0;
      for (int k = 0; k < 3; ++k)
        if (placeAlly(w, PK_SKELETON, V2(-1, -1), 0, 0) >= 0) made++;
      fxSound(w, S_SPAWN, 1.f, 0.6f);
      return made > 0;
    };
  }
  {
    auto& a = GIFT(AB_P_RAINFIRE, "Rain of Fire", T_AIM, TG_NONE, 40,
                   "Fire rains down: 12 pins become Fire pegs, and every monster takes 5 (+1 per 2 depth) damage and 4 Burn.");
    a.cast = [](World& w, int, V2, V2, int) {
      convertPins(w, PK_FIRE, 12);
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) {
          damageMonster(w, i, 5 + w.depth / 2, DS_SPELL);
          applyBurn(w, i, 4);
        }
      fxSound(w, S_FIRE, 1.f, 0.6f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_MIRRORHALL, "Hall of Mirrors", T_AIM, TG_NONE, 50,
                   "The board is mirrored left to right, and this shot your ball splits in two on its first peg hit.");
    a.cast = [](World& w, int, V2, V2, int) {
      mirrorBoard(w);
      w.fl.shot.mirrorSplit = true;
      return true;
    };
  }
  // =========================================================== Arcana, the Fatebinder
  {
    auto& a = GIFT(AB_P_DRAW, "Draw a Card", T_AIM, TG_NONE, 15, "Draw a card from the Deck of Fates: 19 cards, mostly helpful.");
    a.cast = [](World& w, int, V2, V2, int) {
      drawCard(w, abLevel(w, AB_P_STACKED) > 0);
      return true;
    };
  }
  GIFT(AB_P_STACKED, "Stacked Deck", T_PASSIVE, TG_NONE, 0, "Harmful cards (Hanged Man, Fool, Devil) are discarded and redrawn once.");
  {
    auto& a = GIFT(AB_P_TRIPLEDRAW, "Triple Draw", T_AIM, TG_NONE, 35, "Draw three cards and play them all.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int k = 0; k < 3; ++k) drawCard(w, abLevel(w, AB_P_STACKED) > 0);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_FATEDRAW, "Fate's Hand", T_PASSIVE, TG_NONE, 0, "At the start of every floor, draw a free card.");
    a.h.floorStart = [](World& w, int) {
      if (!w.fl.isVault) drawCard(w, abLevel(w, AB_P_STACKED) > 0);
    };
  }
  {
    auto& a = GIFT(AB_P_WHEEL, "Wheel of Fortune", T_AIM, TG_NONE, 60,
                   "Every monster takes 6 damage per card drawn on this floor (max 60), then you draw a card.");
    a.cast = [](World& w, int, V2, V2, int) {
      int d = std::min(60, 6 * std::max(1, w.fl.cardsDrawn));
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) damageMonster(w, i, d, DS_SPELL);
      fxRing(w, V2(800, 450), 380, 0xe0c0ff);
      drawCard(w, abLevel(w, AB_P_STACKED) > 0);
      return true;
    };
  }
  // =========================================================== Ruun, the Unburdened
  {
    auto& a = GIFT(AB_P_RUUNPOWER, "Power of the Unburdened", T_PASSIVE, TG_NONE, 0,
                   "+1 base power and +3 max HP for every sacrifice you have made.");
    a.h.stats = [](World& w, int) {
      int n = sacrificeCount(w);
      w.st.basePower += n;
      w.st.maxHp += 3 * n;
    };
  }
  GIFT(AB_P_RECKONING, "Aura of Reckoning", T_PASSIVE, TG_NONE, 0,
       "Each monster attack has a 25% chance to be turned back on its attacker for double damage.");
  {
    auto& a = GIFT(AB_P_POWERLEAP, "Power Leap", T_AIM, TG_NONE, 20,
                   "This shot, your first monster hit erupts, dealing its damage to every other monster within 130 px.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.powerLeap) return false;
      w.fl.shot.powerLeap = 1;
      fxSound(w, S_GROWL, 0.8f, 0.8f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_UNBURDENED, "Unburdened", T_PASSIVE, TG_NONE, 0, "+5% damage and +1 armor for every sacrifice you have made.");
    a.h.stats = [](World& w, int) {
      int n = sacrificeCount(w);
      w.st.dmgMul *= 1.f + 0.05f * n;
      w.st.armor += n;
    };
  }
  {
    auto& a = GIFT(AB_P_RUUNEND, "Apocalypse of Ruun", T_AIM, TG_NONE, 60,
                   "Every monster loses 20% of its max HP (10% for bosses) plus 5 per sacrifice, and is Chilled.");
    a.cast = [](World& w, int, V2, V2, int) {
      int extra = 5 * sacrificeCount(w);
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (!isHostile(w, i)) continue;
        Monster& m = w.fl.mons[i];
        int d = (int)(m.maxHp * (m.boss ? 0.1f : 0.2f)) + extra;
        fxBurst(w, m.p, 0xe0c090, 30, 260);
        applyChill(w, i, 1);
        damageMonster(w, i, d, DS_SPELL);
      }
      fxShake(w, 16);
      fxSound(w, S_BOOM, 1.f, 0.5f);
      return true;
    };
  }
  // =========================================================== Glub, the Oozing One
  {
    auto& a = GIFT(AB_P_JELLYPEGS, "Jelly Pegs", T_PASSIVE, TG_NONE, 0, "3 Jelly pegs appear each turn (sticky, +4 power).");
    a.h.stats = [](World& w, int) { w.st.specials[PK_JELLY] += 3; };
  }
  {
    auto& a = GIFT(AB_P_OOZE, "Oozing Body", T_PASSIVE, TG_NONE, 0, "+1 HP and +1 MP regeneration, and you are immune to poison.");
    a.h.stats = [](World& w, int) {
      w.st.hpRegen += 1;
      w.st.mpRegen += 1;
      w.st.poisonRes = true;
    };
  }
  {
    auto& a = GIFT(AB_P_MUTATE, "Reshape", T_AIM, TG_NONE, 40, "Glub reshapes you: one bad mutation is cured, or you gain a random good one.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int m = 0; m < MUT_COUNT; ++m)
        if (MUTS[m].tier == 9 && w.pl.mut[m] > 0) {
          w.pl.mut[m]--;
          recalcStats(w);
          logMsg(w, 0x60f0a0, "Glub dissolves your %s.", MUTS[m].name);
          return true;
        }
      int m = randomMutation(w, false, true);
      if (m < 0) return false;
      gainMutation(w, m, false);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_ACIDRAIN, "Acid Rain", T_AIM, TG_NONE, 35,
                   "Acid rain: every monster takes 8 (+1 per depth) damage and loses 2 armor for this floor; 10 pins dissolve.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) {
          w.fl.mons[i].armor = std::max(0, w.fl.mons[i].armor - 2);
          damageMonster(w, i, 8 + w.depth, DS_SPELL);
        }
      std::vector<int> c;
      for (int k = 0; k < (int)w.fl.pegs.size(); ++k)
        if (!w.fl.pegs[k].dead && w.fl.pegs[k].kind == PK_PIN && !w.fl.pegs[k].motion) c.push_back(k);
      w.fl.rng.shuffle(c);
      for (int k = 0; k < 10 && k < (int)c.size(); ++k) w.fl.pegs[c[k]].dead = true;
      fxSound(w, S_POISON, 1.f, 0.5f);
      return true;
    };
  }
  GIFT(AB_P_SLIMETIDE, "Slime Tide", T_PASSIVE, TG_NONE, 0, "Your ball splits into two slimes (70% power each) on its first monster hit each shot.");
  // =========================================================== Tempestra, Eye of the Storm
  {
    auto& a = GIFT(AB_P_STORMAURA, "Storm Aura", T_PASSIVE, TG_NONE, 0,
                   "At the start of each turn, lightning strikes a random monster for 3 (+1 per 3 depth).");
    a.h.turnStart = [](World& w, int) {
      int t = pickRandomHostile(w);
      if (t < 0) return;
      fxZap(w, V2(w.fl.mons[t].p.x, 0), w.fl.mons[t].p, 0xfff4a0);
      damageMonster(w, t, 3 + w.depth / 3, DS_ZAP);
    };
  }
  {
    auto& a = GIFT(AB_P_UPHEAVAL, "Upheaval", T_AIM, TG_POINT, 20,
                   "The ground erupts at a spot: monsters within 130 px take 12 (+1 per depth), and the pins there are hurled into "
                   "a new arrangement.");
    a.cast = [](World& w, int, V2 pt, V2, int) {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i) && dist(w.fl.mons[i].p, pt) - w.fl.mons[i].r < 130) damageMonster(w, i, 12 + w.depth, DS_SPELL);
      for (auto& p : w.fl.pegs)
        if (!p.dead && p.kind == PK_PIN && !p.motion && dist2(p.p, pt) < 130 * 130) p.dead = true;
      growPins(w, 10, pt, 130, false);
      fxRing(w, pt, 130, 0xc8a070);
      fxShake(w, 14);
      fxSound(w, S_BOOM, 1.f, 0.5f, pt.x);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_EYESTORM, "Eye of the Storm", T_PASSIVE, TG_NONE, 0,
                   "Monsters that attack you have a 30% chance to be struck by lightning for 6 (+1 per 2 depth).");
    a.h.attacked = [](World& w, int mi, int&, int) {
      if (w.fl.mons[mi].dead || !w.fl.rng.chance(0.3f)) return;
      fxZap(w, V2(w.fl.mons[mi].p.x, 0), w.fl.mons[mi].p, 0xfff4a0);
      damageMonster(w, mi, 6 + w.depth / 2, DS_ZAP);
    };
  }
  {
    auto& a = GIFT(AB_P_ELEMENTAL, "Elemental Force", T_AIM, TG_NONE, 30,
                   "This shot, your ball's hits Burn, Chill, and arc lightning to another monster for half damage.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.elemental) return false;
      w.fl.shot.elemental = true;
      fxSound(w, S_ZAP, 0.8f, 1.2f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_DISASTER, "Disaster Area", T_AIM, TG_NONE, 90,
                   "Every monster takes 25 (+2 per depth) damage, and the board is torn apart and rebuilt.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) damageMonster(w, i, 25 + 2 * w.depth, DS_SPELL);
      regenLayout(w, false);
      fxShake(w, 22);
      fxSound(w, S_BOOM, 1.f, 0.4f);
      return true;
    };
  }
  // =========================================================== Aurelia, the Shining
  {
    auto& a = GIFT(AB_P_DIVSHIELD, "Divine Shield", T_AIM, TG_NONE, 15, "Gain 12 Block (+1 per depth) that lasts for two enemy phases.");
    a.cast = [](World& w, int, V2, V2, int) {
      addBlock(w, 12 + w.depth);
      w.fl.blockKeep = std::max(w.fl.blockKeep, 1);
      fxRing(w, V2(200, 118), 70, 0xfff0a0);
      fxSound(w, S_BLOCK, 1.f, 1.3f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_HALO, "Halo", T_PASSIVE, TG_NONE, 0, "Your balls deal +50% damage to undead and demons, and you regenerate 1 HP per turn.");
    a.h.stats = [](World& w, int) { w.st.hpRegen += 1; };
    a.h.monHit = [](World& w, HitCtx& c, int) {
      if (isUndeadOrDemon(w.fl.mons[c.mon])) c.mult *= 1.5f;
    };
  }
  {
    auto& a = GIFT(AB_P_CLEANSE, "Cleansing Flame", T_AIM, TG_NONE, 20,
                   "Every monster takes 10 (+1 per depth) holy damage (doubled against undead and demons), and all curses are lifted.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (isHostile(w, i)) {
          fxBurst(w, w.fl.mons[i].p, 0xfff0a0, 20, 220);
          damageMonster(w, i, 10 + w.depth, DS_HOLY);
        }
      cleanseCurses(w, true);
      w.pl.cursedBall = false;
      fxSound(w, S_HEAL, 1.f, 1.5f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_BLESSEDBALL, "Blessed Ball", T_AIM, TG_NONE, 25,
                   "This shot your ball deals +5 damage per hit (x1.5 against undead and demons), and each hit heals you 1 HP.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.blessed) return false;
      w.fl.shot.blessed = true;
      fxSound(w, S_HEAL, 0.8f, 1.7f);
      return true;
    };
    a.h.monDamaged = [](World& w, int bi, int, int dmg, int) {
      if (dmg > 0 && (w.fl.balls[bi].flags & BF_HOLY)) healPlayer(w, 1);
    };
  }
  {
    auto& a = GIFT(AB_P_ANGEL, "Divine Warrior", T_AIM, TG_NONE, 70,
                   "An angel joins you for the rest of the floor, smiting the strongest monster for 10 (+1 per depth) after each "
                   "enemy phase (double against undead and demons).");
    a.cast = [](World& w, int, V2, V2, int) { return placeAlly(w, PK_ANGEL, V2(-1, -1), 10 + w.depth, 0) >= 0; };
  }
  // =========================================================== The Ancestor
  GIFT(AB_P_ANCESTOR, "Ancestral Ball", T_PASSIVE, TG_NONE, 0,
       "Every shot, your ancestor launches a spectral ball beside yours (half your base power +2). It deals full damage but "
       "never enters pockets.");
  GIFT(AB_P_ANCBLESS, "Ancestral Blessing", T_PASSIVE, TG_NONE, 0,
       "The ancestor's ball gains +50% power, and heals you 1 HP for every monster hit it lands.");
  {
    auto& a = GIFT(AB_P_IDEALIZE, "Idealize", T_AIM, TG_NONE, 25, "This shot the ancestor's ball starts with +15 power and its hits Chill.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.idealize) return false;
      w.fl.shot.idealize = 1;
      fxSound(w, S_CAST, 0.8f, 1.1f);
      return true;
    };
  }
  GIFT(AB_P_ANCBOND, "Transference", T_PASSIVE, TG_NONE, 0, "Whenever the ancestor's ball hits a monster, your own balls gain +3 power.");
  {
    auto& a = GIFT(AB_P_ANCWRATH, "Ancestral Wrath", T_FLIGHT, TG_NONE, 60,
                   "Three ancestral balls fall from the top of the board, each with your base power +10.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int k = 0; k < 3; ++k) {
        float x = PX0 + 120 + (PX1 - PX0 - 240) * (k + 0.5f) / 3.f;
        spawnBall(w, V2(x, 26), V2(w.fl.rng.rangef(-60, 60), 120), w.st.basePower + 10, BF_PHANTOM | BF_ANCESTOR);
      }
      fxSound(w, S_SPAWN, 1.f, 0.8f);
      return true;
    };
  }
  // =========================================================== Voidmaw, the Hungering Dark
  {
    auto& a = GIFT(AB_P_BENDSPACE, "Bend Space", T_FLIGHT, TG_NONE, 8, "Your lowest ball warps to a random spot on the upper board with +4 power.");
    a.cast = [](World& w, int, V2, V2, int) {
      int best = -1;
      for (int i = 0; i < (int)w.fl.balls.size(); ++i)
        if (w.fl.balls[i].alive && (best < 0 || w.fl.balls[i].p.y > w.fl.balls[best].p.y)) best = i;
      if (best < 0) return false;
      V2 np = randomFieldSpot(w, w.fl.balls[best].r + 4, 4, FIELD_Y0, 420);
      if (np.x < 0) return false;
      Ball& b = w.fl.balls[best];
      fxBurst(w, b.p, 0x6030c0, 16, 200);
      b.p = np;
      b.stuckRef = np;
      b.power += 4;
      fxBurst(w, np, 0x6030c0, 16, 200);
      fxSound(w, S_PORTAL, 0.8f, 0.6f, np.x);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_BANISH, "Banishment", T_AIM, TG_MONSTER, 30, "Cast a non-boss monster into the Abyss. (You gain no XP for it.)");
    a.cast = [](World& w, int, V2, V2, int mon) {
      if (mon < 0 || w.fl.mons[mon].boss) return false;
      fxBurst(w, w.fl.mons[mon].p, 0x6030c0, 40, 260, 4);
      fxSound(w, S_PORTAL, 1.f, 0.4f, w.fl.mons[mon].p.x);
      w.fl.mons[mon].summoned = true;
      killMonster(w, mon, DS_SPELL);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_CORRUPT, "Corrupt", T_AIM, TG_NONE, 40,
                   "The board twists into a new shape full of Void pegs and rifts, and every monster is Corrupted (+3 damage "
                   "taken, no healing) for 3 turns.");
    a.cast = [](World& w, int, V2, V2, int) {
      regenLayout(w, true);
      allHostile(w, [](World& ww, int i) { applyCorrupt(ww, i, 3, 3); });
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_ENTERVOID, "Abyssal Pull", T_PASSIVE, TG_NONE, 0,
                   "Swallowed balls discharge +100% more, and 2 Void pegs appear each turn.");
    a.h.stats = [](World& w, int) {
      w.st.voidMul += 1.f;
      w.st.specials[PK_VOID] += 2;
    };
  }
  {
    auto& a = GIFT(AB_P_HUNGER, "The Hunger", T_PASSIVE, TG_NONE, 0, "Kills restore 3 HP and 1 MP.");
    a.h.stats = [](World& w, int) {
      w.st.killHeal += 3;
      w.st.killMp += 1;
    };
  }
  // =========================================================== Brakka, the Duelist
  {
    auto& a = GIFT(AB_P_HEROISM, "Heroism", T_AIM, TG_NONE, 10, "This shot deals +40% damage and your ball is 20% bigger.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.heroism) return false;
      w.fl.shot.heroism = true;
      fxSound(w, S_GROWL, 0.8f, 1.2f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_FINESSE, "Finesse", T_PASSIVE, TG_NONE, 0, "Your first monster hit each shot deals double damage.");
    a.h.stats = [](World& w, int) { w.st.finesse = true; };
  }
  {
    auto& a = GIFT(AB_P_DUEL, "Duel", T_AIM, TG_MONSTER, 40,
                   "Challenge a monster: every other monster's countdown increases by 1, and your foe takes +50% damage this turn.");
    a.cast = [](World& w, int, V2, V2, int mon) {
      if (mon < 0) return false;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (i != mon && isHostile(w, i)) w.fl.mons[i].cd += 1;
      Monster& m = w.fl.mons[mon];
      m.hexT = std::max(m.hexT, 1);
      m.hexPct = std::max(m.hexPct, 50);
      fxRing(w, m.p, m.r * 2.5f, 0xd0a060);
      fxSound(w, S_GROWL, 1.f, 0.9f, m.p.x);
      return true;
    };
  }
  GIFT(AB_P_SPOILS, "Spoils of War", T_PASSIVE, TG_NONE, 0, "Elite and boss floors offer an extra reward choice, usually a randart.");
  {
    auto& a = GIFT(AB_P_UNSTOPPABLE, "Unstoppable", T_AIM, TG_NONE, 50,
                   "This shot your balls smash through monsters without bouncing, keeping 70% of their power.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.unstoppable) return false;
      w.fl.shot.unstoppable = true;
      fxSound(w, S_GROWL, 1.f, 0.7f);
      return true;
    };
  }
  // =========================================================== Sifra, the Sage
  {
    auto& a = GIFT(AB_P_CHANNEL, "Channel Magic", T_AIM, TG_NONE, 10, "Restore 4 MP (+1 per 5 XL).");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.pl.mp >= w.st.maxMp) return false;
      gainMp(w, 4 + w.pl.xl / 5);
      fxSound(w, S_MANA, 1.f, 0.9f);
      return true;
    };
  }
  {
    auto& a = GIFT(AB_P_DIVKNOW, "Divine Knowledge", T_PASSIVE, TG_NONE, 0, "Your spells cost 1 less MP (minimum 1).");
    a.h.stats = [](World& w, int) { w.st.costReduce += 1; };
  }
  {
    auto& a = GIFT(AB_P_SCHOLAR, "Sage's Scholarship", T_PASSIVE, TG_NONE, 0, "+1 choice at level-ups and +2 max MP.");
    a.h.stats = [](World& w, int) {
      w.st.offers += 1;
      w.st.maxMp += 2;
    };
  }
  GIFT(AB_P_SPELLECHO, "Spell Echo", T_PASSIVE, TG_NONE, 0, "The first spell you cast each turn is cast a second time for free.");
  {
    auto& a = GIFT(AB_P_FLOOD, "Font of Power", T_AIM, TG_NONE, 70, "Restore all MP, and your spells cost no MP for the rest of this turn.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.freeCasts) return false;
      gainMp(w, w.st.maxMp);
      w.fl.freeCasts = true;
      fxBanner(w, "Font of Power!", 0xa0c0ff);
      fxSound(w, S_MANA, 1.f, 0.6f);
      return true;
    };
  }
}
