// Dropcrawl - core character stats: Strength, Dexterity, Intelligence, Vitality and Luck.
// Every ball and background starts with its own spread. Levels grow them automatically (weighted by the ball's
// growth), and every third level the player picks a stat to raise by 2. Stats above 5 give bonuses, below 5 penalties.
#include "rules.h"

const char* STAT_NAME[STAT_COUNT] = {"Strength", "Dexterity", "Intelligence", "Vitality", "Luck"};
const char* STAT_ABBR[STAT_COUNT] = {"STR", "DEX", "INT", "VIT", "LCK"};
const uint32_t STAT_COLOR[STAT_COUNT] = {0xff7a50, 0x6ee89a, 0x78a8ff, 0xff6a8a, 0xffd24a};

struct SpStat {
  int8_t s[STAT_COUNT];
  float g[STAT_COUNT];
};
// STR DEX INT VIT LCK  |  growth weights
static const SpStat SP_STATS[SP_COUNT] = {
    {{7, 4, 4, 7, 3}, {3, 1, 1, 3, 1}},        // Iron Ball: a bruiser
    {{4, 7, 7, 2, 5}, {1, 3, 3, 0.5f, 2}},     // Glass Ball: precise and fragile
    {{8, 3, 3, 8, 3}, {4, 0.5f, 0.5f, 3, 1}},  // Lead Ball: raw weight
    {{3, 6, 8, 3, 5}, {0.5f, 2, 4, 1, 2}},     // Wisp: a born caster
    {{5, 5, 5, 3, 7}, {1, 1, 1, 1, 4}},        // Gilded Ball: lucky
    {{6, 5, 6, 5, 3}, {2, 1, 2, 2, 0.5f}},     // Bone Ball
    {{6, 6, 6, 3, 4}, {2, 2, 3, 1, 1}},        // Ember
    {{4, 4, 6, 8, 3}, {1, 1, 2, 4, 1}},        // Mossball: hardy
    {{5, 8, 3, 5, 4}, {1, 4, 0.5f, 2, 2}},     // Rubber Ball: nimble
    {{4, 5, 9, 3, 4}, {1, 2, 4, 1, 1.5f}},     // Crystal Ball
    {{7, 6, 4, 5, 3}, {3, 3, 1, 1, 1}},        // Magnet Ball
    {{5, 4, 5, 8, 3}, {1, 1, 2, 4, 1}},        // Slime Ball
    {{7, 5, 6, 4, 3}, {3, 1, 3, 1, 0.5f}},     // Fiendball
    {{6, 5, 6, 5, 3}, {2, 2, 2, 2, 1}},        // Drakeball (its colour adds growth)
    {{3, 5, 9, 5, 3}, {0.5f, 1, 4, 2, 1}},     // Djinn Ball
    {{4, 8, 5, 3, 5}, {1, 3, 1, 1, 3}},        // Nine-Lives Ball
    {{5, 5, 5, 5, 5}, {1, 1, 1, 1, 1}},        // Changeling (grows like its current form)
    {{5, 5, 5, 5, 5}, {1, 1, 1, 1, 1}},        // Chaos Orb (random, see below)
};
static const int8_t BG_STATS[BG_COUNT][STAT_COUNT] = {
    {3, 0, -1, 2, 0},   // Fighter
    {-1, 0, 4, 0, 1},   // Wizard
    {0, 2, 2, 0, 0},    // Tinkerer
    {1, 0, 3, 0, 0},    // Pyromancer
    {0, 0, 3, 1, 0},    // Iceweaver
    {0, 2, 2, 0, 0},    // Stormcaller
    {0, 1, 0, 0, 3},    // Gambler
    {0, 0, 3, 0, 1},    // Necromancer
    {1, 2, 0, 1, 0},    // Monk
    {0, 4, 0, 0, 0},    // Pinballer
    {0, 0, 2, 2, 0},    // Druid
    {0, 0, 2, 0, 2},    // Alchemist
    {0, 0, 0, 0, 0},    // Wanderer (random)
    {2, 0, 0, 0, 2},    // Chaos Knight
    {2, 0, 2, 0, 0},    // Void Knight
    {4, 0, -1, 1, 0},   // Berserker
    {0, 2, 2, 0, 0},    // Artificer
    {0, 0, 3, 0, 1},    // Summoner
    {0, 2, 2, 0, 0},    // Hexslinger
    {2, 0, 0, 2, 0},    // Earth Shaper
    {0, 4, 0, 0, 0},    // Hunter
    {0, 0, 1, 3, 0},    // Blood Mage
    {2, 0, 0, 2, 0},    // Shapeshifter
    {0, 1, 0, 0, 3},    // Card Sharp
    {0, 0, 0, 2, 2},    // Pilgrim
};
// extra growth from a Drakeball's scale colour (red, white, green, yellow, black, purple, pale, grey)
static const float DRACO_GROWTH[DRACO_COUNT][STAT_COUNT] = {
    {2, 0, 1, 0, 0}, {0, 0, 1, 2, 0}, {0, 1, 0, 2, 0}, {2, 1, 0, 0, 0},
    {0, 2, 1, 0, 0}, {0, 0, 3, 0, 0}, {0, 1, 1, 1, 0}, {1, 0, 0, 2, 0}};

static int floorDiv(int a, int b) { return a >= 0 ? a / b : -((-a + b - 1) / b); }

void initStatTables() {
  for (int i = 0; i < SP_COUNT; ++i) {
    SpeciesDef& s = SPECIES[i];
    for (int k = 0; k < STAT_COUNT; ++k) {
      s.stat[k] = SP_STATS[i].s[k];
      s.growth[k] = SP_STATS[i].g[k];
    }
    // keep a ball's starting HP / MP where it was before stats existed: the stat bonus is folded out of the base
    s.hp -= 3 * (s.stat[STAT_VIT] - STAT_BASE);
    s.mp -= floorDiv(s.stat[STAT_INT] - STAT_BASE, 2);
    if (i == SP_DJINN) s.mp = 0;
  }
  for (int b = 0; b < BG_COUNT; ++b)
    for (int k = 0; k < STAT_COUNT; ++k) BGS[b].stat[k] = BG_STATS[b][k];
}

int previewStartHp(int sp, int bg) {
  int vit = std::max(1, SPECIES[sp].stat[STAT_VIT] + BGS[bg].stat[STAT_VIT]);
  return std::max(1, SPECIES[sp].hp + BGS[bg].hp + 3 * (vit - STAT_BASE));
}
int previewStartMp(int sp, int bg) {
  if (sp == SP_DJINN) return 0;
  int in = std::max(1, SPECIES[sp].stat[STAT_INT] + BGS[bg].stat[STAT_INT]);
  return std::max(0, SPECIES[sp].mp + BGS[bg].mp + floorDiv(in - STAT_BASE, 2));
}

void rollStartingStats(World& w) {
  Player& pl = w.pl;
  const SpeciesDef& sp = SPECIES[pl.species];
  int v[STAT_COUNT];
  for (int k = 0; k < STAT_COUNT; ++k) v[k] = sp.stat[k] + BGS[pl.bg].stat[k];
  if (pl.species == SP_CHAOS) {
    // a Chaos Orb's stats are a roll of the dice: 25 points thrown about wildly
    for (int k = 0; k < STAT_COUNT; ++k) v[k] = 1 + BGS[pl.bg].stat[k];
    for (int n = 0; n < 20; ++n) v[w.rng.range(0, STAT_COUNT - 1)]++;
  }
  if (pl.bg == BG_WANDERER) {
    // DCSS-style wanderer: shuffle a few points around and add four more at random
    for (int n = 0; n < 4; ++n) {
      int a = w.rng.range(0, STAT_COUNT - 1), b = w.rng.range(0, STAT_COUNT - 1);
      if (v[a] > 2) {
        v[a]--;
        v[b]++;
      }
    }
    for (int n = 0; n < 4; ++n) v[w.rng.range(0, STAT_COUNT - 1)]++;
  }
  for (int k = 0; k < STAT_COUNT; ++k) pl.stat[k] = (uint8_t)clampv(v[k], 1, 40);
  pl.statPoints = 0;
}

int effStat(const World& w, int s) {
  if (s < 0 || s >= STAT_COUNT) return 0;
  return w.st.stat[s];
}

void applyStatEffects(World& w) {
  Stats& st = w.st;
  const Player& pl = w.pl;
  bool onFloor = w.screen == RS_FLOOR;
  int shrineStat = (onFloor && w.fl.shrine == 7) ? 2 * (1 + st.shrineBonus) : 0;
  for (int k = 0; k < STAT_COUNT; ++k) {
    int v = pl.stat[k] + st.statBonus[k] + (onFloor ? w.fl.tempStat[k] : 0) + shrineStat;
    st.stat[k] = clampv(v, 1, 99);
  }
  if (onFloor && w.fl.shrine >= 0) {
    int m = 1 + st.shrineBonus;
    switch (w.fl.shrine) {
      case 0: st.dmgMul *= 1.f + 0.3f * m; break;
      case 1: st.goldMul *= 1.f + 0.6f * m; break;
      case 2: st.xpMul *= 1.f + 0.5f * m; break;
      case 5: st.mpRegen += m; st.costReduce += 1; break;
      case 9: st.armor += 3 * m; break;
    }
  }
  int STR = st.stat[STAT_STR], DEX = st.stat[STAT_DEX], INT = st.stat[STAT_INT], VIT = st.stat[STAT_VIT], LCK = st.stat[STAT_LCK];
  // Strength: ball damage
  st.dmgMul *= std::max(0.7f, 1.f + (STR >= STAT_BASE ? 0.04f : 0.03f) * (STR - STAT_BASE));
  // Dexterity: critical hits and dodging attacks (Luck helps crits too)
  st.critChance += 0.02f * DEX + 0.01f * std::max(0, LCK - STAT_BASE);
  st.dodge += 0.01f * std::max(0, DEX - STAT_BASE);
  st.critChance = clampv(st.critChance, 0.f, 0.75f);
  st.dodge = clampv(st.dodge, 0.f, 0.3f);
  // Intelligence: magic
  st.maxMp += floorDiv(INT - STAT_BASE, 2);
  if (INT > STAT_BASE) st.mpRegen += (INT - STAT_BASE) / 3;
  st.spellDmgMul *= std::max(0.6f, 1.f + 0.06f * (INT - STAT_BASE));
  st.allyDmgMul *= std::max(0.7f, 1.f + 0.04f * (INT - STAT_BASE));
  // Vitality: health
  st.maxHp += 3 * (VIT - STAT_BASE);
  st.healMul = std::max(0.3f, st.healMul + 0.02f * (VIT - STAT_BASE));
  // Luck: gold, loot and lucky double triggers
  st.goldMul *= std::max(0.6f, 1.f + 0.04f * (LCK - STAT_BASE));
  st.magicFind += 0.03f * (LCK - STAT_BASE);
  st.luckyPct += 0.025f * std::max(0, LCK - STAT_BASE);
  st.luckyPct = std::min(st.luckyPct, 0.35f);
}

std::string statEffectText(int s, int v) {
  int d = v - STAT_BASE;
  auto sg = [](int x) { return x >= 0 ? fmt("+%d", x) : fmt("%d", x); };
  switch (s) {
    case STAT_STR: return fmt("%s%% ball damage", sg(std::max(-30, d >= 0 ? 4 * d : 3 * d)).c_str());
    case STAT_DEX:
      return fmt("%d%% critical hits (x1.5), %d%% dodge", std::min(75, 2 * v), std::min(30, std::max(0, d)));
    case STAT_INT: {
      int mp = floorDiv(d, 2);
      std::string r = fmt("%s max MP, %s%% spell & %s%% ally damage", sg(mp).c_str(), sg(std::max(-40, 6 * d)).c_str(), sg(std::max(-30, 4 * d)).c_str());
      if (d >= 3) r += fmt(", +%d MP regen", d / 3);
      return r;
    }
    case STAT_VIT: return fmt("%s max HP, %s%% healing", sg(3 * d).c_str(), sg(2 * d).c_str());
    case STAT_LCK: {
      std::string r = fmt("%s%% gold, %s%% better loot", sg(std::max(-40, 4 * d)).c_str(), sg(3 * d).c_str());
      if (d > 0) r += fmt(", %.1f%% lucky pegs, +%d%% crit chance", std::min(35.f, 2.5f * d), d);
      return r;
    }
  }
  return "";
}

static const char* STAT_BLURB[STAT_COUNT] = {
    "Strength: +4% ball damage per point above 5 (-3% per point below).",
    "Dexterity: 2% chance per point for a ball hit to be a critical hit (x1.5 damage), and 1% per point above 5 to dodge a "
    "monster's attack entirely (max 30%).",
    "Intelligence: +1 max MP per 2 points above 5, +1 MP regeneration per 3 points above 5, and +6% spell damage and +4% "
    "ally damage per point above 5.",
    "Vitality: +3 max HP and +2% healing per point above 5.",
    "Luck: +4% gold, +3% better loot (magic relics, uniques) and +1% critical hit chance per point above 5, and 2.5% per "
    "point that a special peg triggers twice."};

std::string statTooltip(const World& w, int s) {
  int base = w.pl.stat[s], eff = w.st.stat[s];
  std::string t = fmt("%s %d", STAT_NAME[s], eff);
  if (eff != base) t += fmt(" (base %d, %s%d from items and effects)", base, eff >= base ? "+" : "", eff - base);
  t += "\n" + statEffectText(s, eff) + "\n\n" + STAT_BLURB[s];
  const SpeciesDef& sp = SPECIES[w.pl.species];
  float tot = 0;
  for (int k = 0; k < STAT_COUNT; ++k) tot += sp.growth[k];
  if (tot > 0 && w.pl.species != SP_CHAOS)
    t += fmt("\n\n%s growth: %d%% of level-ups.", sp.name, (int)std::lround(100.f * sp.growth[s] / tot));
  t += "\nEvery level raises a stat; every third level you choose one to raise by 2.";
  return t;
}

void addTempStat(World& w, int s, int amt, const char* why) {
  if (s < 0 || s >= STAT_COUNT || amt == 0) return;
  w.fl.tempStat[s] += amt;
  recalcStats(w);
  if (why) logMsg(w, STAT_COLOR[s], "%s: %s %s%d for this floor.", why, STAT_NAME[s], amt > 0 ? "+" : "", amt);
  fxText(w, V2(200, 150), STAT_COLOR[s], fmt("%s %s%d", STAT_ABBR[s], amt > 0 ? "+" : "", amt), 15);
}

bool needsOffers(const World& w) { return w.pendingLevels > 0 || w.pl.statPoints > 0; }

void statLevelUp(World& w) {
  Player& pl = w.pl;
  if (pl.xl % 3 == 0) {
    pl.statPoints++;
    logMsg(w, 0xffe070, "You may raise a stat by 2!");
    return;
  }
  float g[STAT_COUNT];
  int src = pl.species;
  if (pl.species == SP_CHANGELING && pl.form >= 0 && pl.form < SP_COUNT) src = pl.form;
  for (int k = 0; k < STAT_COUNT; ++k) g[k] = SPECIES[src].growth[k];
  if (pl.species == SP_DRAKE && pl.draconic >= 0 && pl.draconic < DRACO_COUNT)
    for (int k = 0; k < STAT_COUNT; ++k) g[k] += DRACO_GROWTH[pl.draconic][k];
  if (pl.species == SP_CHAOS)
    for (int k = 0; k < STAT_COUNT; ++k) g[k] = w.rng.rangef(0.2f, 3.f);
  std::vector<float> wt(g, g + STAT_COUNT);
  int s = w.rng.weighted(wt);
  if (s < 0) s = 0;
  pl.stat[s] = (uint8_t)std::min(60, pl.stat[s] + 1);
  pl.statGrowthLog++;
  recalcStats(w);
  logMsg(w, STAT_COLOR[s], "Your %s grows to %d.", STAT_NAME[s], w.st.stat[s]);
}

void chooseStat(World& w, int s) {
  if (s < 0 || s >= STAT_COUNT || w.pl.statPoints <= 0) return;
  w.pl.statPoints--;
  w.pl.stat[s] = (uint8_t)std::min(60, w.pl.stat[s] + 2);
  recalcStats(w);
  logMsg(w, STAT_COLOR[s], "You raise your %s to %d. (%s)", STAT_NAME[s], w.st.stat[s], statEffectText(s, w.st.stat[s]).c_str());
  fxBanner(w, fmt("%s +2", STAT_NAME[s]), STAT_COLOR[s]);
  fxSound(w, S_LEVEL, 0.7f, 1.3f);
}
