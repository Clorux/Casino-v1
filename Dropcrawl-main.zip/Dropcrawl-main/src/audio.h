// Dropcrawl - software mixer with synthesized sound effects and generative music
#pragma once
#include <cstdint>
#include <string>
#include <vector>

enum Sfx {
  S_PEG = 0, S_PEG_SPECIAL, S_BUMP, S_HIT, S_CRIT, S_KILL, S_COIN, S_HEAL, S_MANA, S_LAUNCH, S_POCKET,
  S_CAST, S_ZAP, S_BOOM, S_HURT, S_LEVEL, S_CLICK, S_HOVER, S_GROWL, S_FREEZE, S_FIRE, S_POISON, S_PORTAL,
  S_BLOCK, S_WIN, S_LOSE, S_BUY, S_STAIRS, S_SPAWN, S_TICK, S_WALL, S_SHATTER, S_FLIP, S_WHOOSH, S_CHEST,
  S_DENY, S_COUNT
};

namespace audio {
bool init();
void shutdown();
// pitch: playback rate multiplier; pan: -1 (left) .. 1 (right)
void play(int sfx, float vol = 1.f, float pitch = 1.f, float pan = 0.f);
void setVolumes(float master, float sfx, float music);
// Generative music. Call every frame; it is cheap. Whenever the mood changes (and again every
// ~1.5-3 minutes while it plays) a new song is composed for it; changes take effect at the next
// beat with a short crossfade, and -1 / unknown ids fade to silence.
//   mood ids:  -1 silence
//      0 title (picks among several title themes)   10 Slime Pits
//      1 The Upper Halls                             11 The Abyss
//      2 The Fungal Lair                             12 rest site (campfire, acoustic)
//      3 The Drowned Halls                           13 altar / temple
//      4 The Clockwork Mines                         14 strange passage / event
//      5 The Crypt                                   15 treasure vault
//      6 The Ember Forge                             16 victory (loops)
//      7 The Frozen Vaults                           17 death / game over (short cycles)
//      8 The Core                                    18 carnival: the Tumbler's Playground (3/4 circus waltz)
//      9 shop / calm                                 19 title theme B
// intensity 0..1 re-arranges the CURRENT mood at the next bar instead of switching tracks:
// ~0.5 (elite fights) adds drums and a busier bass, 1.0 (boss fights) adds a driving groove,
// faster rhythms, a slightly faster tempo and darker harmony.
void setMusic(int mood, float intensity = 0.f);
float semis(float s);  // 2^(s/12)

// ---- testing / tools (not needed by the game) --------------------------------------------
struct MusicStats {
  int songs = 0, sections = 0, bars = 0, notes = 0;
  int peakVoices = 0, steals = 0;
  int limited = 0;     // samples where the music-bus limiter reduced gain
  int nonFinite = 0;   // NaN/inf samples caught on the music bus (should be 0)
  float peakBus = 0;   // peak |sample| of the music bus before its limiter (full scale = 1)
  std::string log;     // one line per composed song
};
// Renders music only (no SFX, no audio device) exactly as it would reach the speakers with the
// current volume settings. Safe to call without init(); do not call while the game is running.
void renderMusicOffline(int mood, float intensity, float seconds, std::vector<short>& stereoOut,
                        uint32_t seed = 1, MusicStats* stats = nullptr);
// Same, but ctl(tSeconds, mood, intensity) is called before every 512-frame block so a test can
// script mood / intensity changes over time.
void renderMusicScript(float seconds, std::vector<short>& stereoOut, uint32_t seed,
                       void (*ctl)(float t, int& mood, float& intensity), MusicStats* stats = nullptr);
// Time spent synthesizing all SFX + instruments (ms); 0 until init() or an offline render ran.
double synthesisTimeMs();
}  // namespace audio
