// Dropcrawl - turn flow: player turns, enemy phases & intents, allies, launching, abilities, items, offers, floor setup
#include "rules.h"

void ensureCapacity(World& w) {
  Floor& f = w.fl;
  if (f.pegs.capacity() < 1600) f.pegs.reserve(1600);
  if (f.segs.capacity() < 320) f.segs.reserve(320);
  if (f.zones.capacity() < 64) f.zones.reserve(64);
  if (f.mons.capacity() < 64) f.mons.reserve(64);
  if (f.balls.capacity() < 64) f.balls.reserve(64);
  if (f.newBalls.capacity() < 64) f.newBalls.reserve(64);
  if (f.clearings.capacity() < 32) f.clearings.reserve(32);
}

// ================================================================ turn flow
void thawAndReset(World& w) {
  Floor& f = w.fl;
  bool relayout = false;
  for (auto& p : f.pockets)
    if (p.kind == PO_FROZEN && --p.val <= 0) {
      p.kind = p.orig;
      p.val = 0;
      p.flash = 1.f;
      relayout = true;
    }
  if (relayout) layoutPockets(w);
  for (auto& p : f.pegs) {
    if (p.dead) continue;
    if (p.kind == PK_TARGET && p.val) {
      p.val = 0;
      p.flash = 1.f;
    }
  }
  f.ghostSolid = !f.ghostSolid;
  if (f.blindTurns > 0) f.blindTurns--;
  if (!hasMod(w, MOD_GRAVITY)) f.gravNow = approach(f.gravNow, 1.f, 0.15f);
}

void startPlayerTurn(World& w, bool afterEnemies) {
  Floor& f = w.fl;
  if (w.dead) return;
  ensureCapacity(w);
  f.shot = ShotState();
  f.turnPegHits = 0;
  f.tookDamageThisTurn = false;
  f.phase = PH_AIM;
  if (afterEnemies) {
    f.turn++;
    w.rs.turns++;
    if (f.blockKeep > 0) f.blockKeep--;
    else w.pl.block = 0;
    w.pl.guardBlocks = 0;  // a guardian spirit only watches over one enemy phase
    f.vulnTurn = false;
    f.freeCasts = false;
    recalcStats(w);
    if (w.pl.slowed <= 0) gainMp(w, w.st.mpRegen);
    if (w.st.hpRegen > 0) healPlayer(w, w.st.hpRegen);
    for (auto& a : w.pl.abil)
      if (a.cd > 0) a.cd--;
    for (auto& m : f.mons) {
      if (m.dead) continue;
      if (m.hexT > 0 && --m.hexT == 0) m.hexPct = 0;
      m.markT = 0;
    }
    thawAndReset(w);
    refreshSpecials(w);
    if (f.shrine == 4) addBlock(w, (4 + w.depth / 4) * (1 + w.st.shrineBonus));
    if (f.shrine == 6)
      for (auto& a : w.pl.abil)
        if (a.cd > 0) a.cd--;
    if (f.spec.kind == FK_BOSS) {
      f.bossTurns++;
      if (!f.bossEnraged && f.bossTurns >= 12) {
        f.bossEnraged = true;
        for (auto& m : f.mons)
          if (!m.dead && m.boss) {
            fxBanner(w, std::string(MON[m.def].name) + " is ENRAGED!", 0xff4040);
            logMsg(w, 0xff4040, "%s grows impatient and enraged: +50%% damage from now on!", MON[m.def].name);
          }
        fxShake(w, 14);
        fxSound(w, S_GROWL, 1.f, 0.5f);
      }
    }
    FOR_EFF0(turnStart);
    if (w.pl.patron == PT_RUUN && f.turn % 2 == 0) gainPiety(w, 1);
    if (w.pl.patron == PT_TUMBLER) {
      gainPiety(w, 1);
      if (w.pl.hp * 4 < w.st.maxHp) gainPiety(w, 5);
    }
    tumblerTurn(w);
    if (!f.isVault && aliveMonsterCount(w) == 0) {
      floorWon(w);
      return;
    }
  }
  w.autosaveWanted = true;
  if (needsOffers(w) && w.offers.empty()) generateOffers(w);
}

void startEnemyPhase(World& w) {
  Floor& f = w.fl;
  f.phase = PH_ENEMY;
  f.enemyStage = 0;
  f.enemyIdx = 0;
  f.enemyTimer = 0.25f;
}

void floorWon(World& w) {
  Floor& f = w.fl;
  if (f.phase == PH_CLEARED) return;
  f.phase = PH_CLEARED;
  f.cleared = true;
  f.clearT = 0;
  // charmed thralls and illusions wander off
  for (auto& m : f.mons)
    if (!m.dead) m.dead = true;
  if (!f.isVault) {
    fxBanner(w, "Floor cleared!", 0x80ffb0);
    fxSound(w, S_WIN, 0.8f);
  }
}

void endShot(World& w) {
  Floor& f = w.fl;
  FOR_EFF0(shotEnd);
  flushSlots(w);
  if (f.shot.doubleDown && !f.shot.anyMonHit && f.shot.ddPenalty > 0 && !w.dead)
    damagePlayer(w, f.shot.ddPenalty, -1, true, "a bad bet");
  closeTulips(w);
  for (auto& p : f.pegs) {
    if (p.dead) continue;
    if (p.kind == PK_BELL) p.val = 0;
    if (!p.used) continue;
    if (isEnchant(p.kind)) {
      p.kind = PK_PIN;
      p.used = false;
    } else p.used = false;
  }
  for (int i = 0; i < (int)f.mons.size(); ++i)
    if (!f.mons[i].dead && (f.mons[i].shotFlags & 2)) teleportMonster(w, i);
  // tesla coils discharge after each of your shots
  for (int i = 0; i < (int)f.pegs.size(); ++i) {
    if (f.pegs[i].dead || f.pegs[i].kind != PK_TESLA) continue;
    V2 c = f.pegs[i].p;
    int dmg = std::max(1, (int)std::lround(f.pegs[i].val * allyDamageMul(w)));
    if (hasRelic(w, RL_U_GEARHEART)) dmg *= 2;
    int a = nearestMonster(w, c);
    int b = a >= 0 ? nearestMonster(w, c, a) : -1;
    for (int t : {a, b}) {
      if (t < 0 || f.mons[t].dead) continue;
      fxZap(w, c, f.mons[t].p, 0xffe060);
      damageMonster(w, t, dmg, DS_ZAP);
    }
  }
  // hot streak
  int hs = abLevel(w, AB_HOTSTREAK);
  if (f.shot.anyMonHit) f.streak++;
  else f.streak = 0;
  f.streakPower = hs ? std::min(f.streak * (hs <= 1 ? 10 : hs == 2 ? 15 : 20), hs <= 1 ? 50 : hs == 2 ? 75 : 100) : 0;
  f.balls.clear();
  f.newBalls.clear();
  w.rs.bestShot = std::max(w.rs.bestShot, f.shot.damage);
  if (w.pl.patron == PT_TUMBLER && f.shot.pegHits >= 25) gainPiety(w, 3);
  if (w.pl.patron == PT_TEMPESTRA && f.shot.pegHits >= 25) gainPiety(w, f.shot.pegHits / 25);
  tumblerEndShot(w);
  if (w.dead) {
    f.phase = PH_DEAD;
    return;
  }
  if (f.isVault) {
    bool free = f.shot.freeTurn;
    if (!free) f.vaultShots--;
    if (f.vaultShots <= 0) {
      floorWon(w);
      return;
    }
    startPlayerTurn(w, false);
    return;
  }
  if (aliveMonsterCount(w) == 0) {
    floorWon(w);
    return;
  }
  bool free = f.shot.freeTurn || f.pendingFree;
  if (f.pendingFree) f.pendingFree = false;
  if (!free && f.timeStop > 0) {
    f.timeStop--;
    free = true;
    fxBanner(w, "Time stands still!", 0xc8b890);
  }
  if (!free && hasRelic(w, RL_AGES) && f.turn % 7 == 0) {
    free = true;
    fxText(w, V2(800, 300), 0xe0c080, "The Sands of Ages grant a free turn", 16);
  }
  if (free) {
    if (!f.shot.freeTurn) fxBanner(w, "Free turn!", 0x60ffa0);
    logMsg(w, 0x60ffb0, "Free turn! The monsters hesitate.");
    startPlayerTurn(w, false);
  } else {
    startEnemyPhase(w);
  }
}

// ================================================================ enemy intents
static bool resists(World& w, int mi, bool curse, bool mind) {
  if ((curse && w.st.warded) || (mind && w.pl.mut[MUT_DEMONWILL] > 0)) {
    Monster& m = w.fl.mons[mi];
    fxText(w, m.p + V2(0, -m.r - 10), 0xe0e0ff, "you resist", 13);
    return true;
  }
  return false;
}

void hatchEgg(World& w, int pi) {
  Floor& f = w.fl;
  Peg& p = f.pegs[pi];
  if (p.dead) return;
  p.dead = true;
  V2 pos = p.p;
  int def = clampv(p.aux, 0, M_COUNT - 1);
  int cl = freeClearing(w, pos, false);
  if (cl < 0 || summonedAlive(w) >= 5) {
    fxText(w, pos, 0xa09070, "the egg rots", 12);
    return;
  }
  int ni = spawnMonster(w, def, cl, true);
  if (ni >= 0) {
    f.mons[ni].moveFrom = pos;
    f.mons[ni].moveT = w.quiet ? 1.f : 0.f;
    logMsg(w, 0xe0d0a0, "An egg hatches into %s!", withArt(MON[def].name).c_str());
    fxSound(w, S_SPAWN, 0.7f, 1.3f, pos.x);
  }
}

static void execIntent(World& w, int mi, int depthGuard = 0);

static void doRandomIntent(World& w, int mi, int depthGuard) {
  Floor& f = w.fl;
  Monster& m = f.mons[mi];
  static const uint8_t K[] = {IN_ATTACK, IN_ATTACK, IN_HEAVY, IN_BLOCK, IN_HEAL, IN_HEX, IN_SHUFFLE, IN_TELEPORT, IN_BUFF,
                              IN_WEB, IN_BLIND, IN_CURSEBALL, IN_MUTATEPEGS, IN_CALL, IN_GRAVITY, IN_SWAP, IN_FREEZEPOCKET,
                              IN_DECOY, IN_SLOW, IN_SAP, IN_ENRAGE, IN_ACID};
  int k = K[f.rng.range(0, (int)(sizeof(K) / sizeof(K[0])) - 1)];
  int base = std::max(3, (int)m.ival);
  m.intent = (uint8_t)k;
  switch (k) {
    case IN_BLOCK: m.ival = base * 2; break;
    case IN_HEAL: m.ival = base; break;
    case IN_HEX: case IN_MUTATEPEGS: case IN_ACID: m.ival = 3; break;
    case IN_BUFF: case IN_DECOY: case IN_BLIND: m.ival = 1; break;
    case IN_WEB: case IN_SLOW: case IN_SAP: m.ival = 2; break;
    default: m.ival = base; break;
  }
  m.iarg = 0;
  fxText(w, m.p + V2(0, -m.r - 26), 0xff60ff, INTENT_NAME[k], 14);
  execIntent(w, mi, depthGuard + 1);
  if (!f.mons[mi].dead) {
    f.mons[mi].intent = IN_RANDOM;
  }
}

static void execIntent(World& w, int mi, int depthGuard) {
  Floor& f = w.fl;
  Monster& m = f.mons[mi];
  const MonDef& d = MON[m.def];
  const MonDef& L = monLook(m);
  m.act = 1.f;
  switch (m.intent) {
    case IN_ATTACK:
    case IN_HEAVY:
    case IN_MULTI: {
      int dmg = intentDamage(w, m);
      int hits = m.intent == IN_MULTI ? std::max(1, (int)m.iarg) : 1;
      if (hasAffix(m, AF_MULTISHOT)) hits *= 2;
      bool pierce = m.intent == IN_HEAVY || hasAffix(m, AF_FIRE);
      for (int k = 0; k < hits && !w.dead; ++k) {
        fxAttack(w, f.mons[mi].p, L.color, dmg);
        int before = w.pl.hp;
        damagePlayer(w, dmg, mi, pierce);
        int dealt = std::max(0, before - w.pl.hp);
        if (dealt > 0 && hasAffix(f.mons[mi], AF_MANABURN) && w.pl.mp > 0) {
          int b = std::min(w.pl.mp, 2);
          w.pl.mp -= b;
          fxText(w, V2(200, 150), 0x7080ff, fmt("-%d MP", b), 14);
        }
        if (((d.traits & TR_LIFESTEAL) || hasAffix(f.mons[mi], AF_VAMPIRIC)) && dealt > 0 && !f.mons[mi].dead) {
          Monster& mm = f.mons[mi];
          if (mm.corruptT <= 0) {
            mm.hp = std::min(mm.maxHp, mm.hp + dealt);
            fxText(w, mm.p + V2(0, -mm.r - 8), 0xff6080, fmt("+%d", dealt), 13);
          }
        }
      }
      if (!f.mons[mi].dead) f.mons[mi].enraged = false;
      if (hasAffix(f.mons[mi], AF_COLD) && !w.dead) {
        w.pl.sapped = std::max(w.pl.sapped, 1);
        fxText(w, V2(200, 180), 0xa0e0ff, "chilled!", 14);
      }
      logMsg(w, 0xff9090, "%s %s you%s.", The(L).c_str(), f.mons[mi].intent == IN_HEAVY ? "smashes" : "hits",
             hits > 1 ? fmt(" %d times", hits).c_str() : "");
      fxSound(w, S_GROWL, 0.6f, 1.f, f.mons[mi].p.x);
      break;
    }
    case IN_BEAM: {
      if (m.beamHp <= 0) {
        fxText(w, m.p + V2(0, -m.r - 10), 0xa0a0b0, "the beam fizzles", 14);
        break;
      }
      int dmg = intentDamage(w, m);
      fxZap(w, m.p, V2(200, 118), 0xffe080);
      fxZap(w, m.p + V2(4, 0), V2(204, 118), 0xffffff);
      fxAttack(w, m.p, 0xffe080, dmg);
      damagePlayer(w, dmg, mi, true);
      if (!f.mons[mi].dead) f.mons[mi].enraged = false;
      logMsg(w, 0xffd080, "%s fires its beam!", The(L).c_str());
      fxSound(w, S_ZAP, 1.f, 0.5f, m.p.x);
      fxShake(w, 10);
      break;
    }
    case IN_BLOCK:
      m.shield += m.ival;
      fxText(w, m.p + V2(0, -m.r - 10), 0xb0c0ff, fmt("+%d block", m.ival), 14);
      fxSound(w, S_BLOCK, 0.6f, 1.f, m.p.x);
      break;
    case IN_HEAL: {
      for (auto& o : f.mons) {
        if (o.dead || o.charmed || o.corruptT > 0) continue;
        int h = std::min(m.ival, o.maxHp - o.hp);
        if (h > 0) {
          o.hp += h;
          fxText(w, o.p + V2(0, -o.r - 8), 0x70ff90, fmt("+%d", h), 13);
        }
      }
      fxSound(w, S_HEAL, 0.5f, 0.7f, m.p.x);
      logMsg(w, 0x90e0a0, "%s heals its allies.", The(L).c_str());
      break;
    }
    case IN_BUFF:
      for (auto& o : f.mons)
        if (!o.dead && !o.charmed) o.atkBonus += m.ival;
      fxRing(w, m.p, 140, 0xff6060);
      fxSound(w, S_GROWL, 0.8f, 0.8f, m.p.x);
      logMsg(w, 0xff9090, "%s rallies the monsters! (+%d damage)", The(L).c_str(), m.ival);
      break;
    case IN_SUMMON:
    case IN_CALL: {
      int n = m.intent == IN_CALL ? 1 : std::max(1, (int)m.iarg);
      int def = m.intent == IN_CALL ? randomRosterMonster(w, m.boss ? 0 : -1) : clampv((int)m.ival, 0, M_COUNT - 1);
      V2 mp = m.p;
      float mr = m.r;
      int made = 0;
      n = std::min(n, std::max(0, 3 - summonedAlive(w)));
      if (n == 0) fxText(w, mp + V2(0, -mr - 10), 0xa0a0a0, "no reinforcements", 13);
      for (int k = 0; k < n; ++k) {
        int cl = freeClearing(w, mp, false);
        if (cl < 0) break;
        int ni = spawnMonster(w, def, cl, true);
        if (ni >= 0) {
          f.mons[ni].moveFrom = mp;
          f.mons[ni].moveT = w.quiet ? 1.f : 0.f;
          made++;
        }
      }
      if (made) {
        logMsg(w, 0xffa0a0, "%s %s %s!", The(L).c_str(), f.mons[mi].intent == IN_CALL ? "calls up" : "summons", withArt(MON[def].name).c_str());
        fxSound(w, S_SPAWN, 0.8f, 1.f, mp.x);
      }
      break;
    }
    case IN_HEX: {
      if (resists(w, mi, true, false)) break;
      int n = convertPins(w, PK_CURSE, m.ival);
      if (n) {
        logMsg(w, 0xc080ff, "%s curses %d pins.", The(L).c_str(), n);
        fxSound(w, S_CAST, 0.6f, 0.5f, m.p.x);
      }
      break;
    }
    case IN_BOMB: {
      V2 mp = m.p;
      for (int tries = 0; tries < 80; ++tries) {
        V2 p = mp + fromAng(f.rng.rangef(0, TAU)) * f.rng.rangef(m.r + 30, m.r + 150);
        if (!spotFree(w, p, 10, 10)) continue;
        int pi = addPeg(w, PK_MBOMB, p, 10);
        if (pi >= 0) {
          f.pegs[pi].hp = m.ival;
          f.pegs[pi].val = m.iarg > 0 ? m.iarg : 3;
          f.pegs[pi].link = mi;
          logMsg(w, 0xff8060, "%s plants a bomb! (%d damage in %d turns)", The(L).c_str(), m.ival, f.pegs[pi].val);
          fxSound(w, S_TICK, 0.8f, 0.8f, p.x);
        }
        break;
      }
      break;
    }
    case IN_WALL: {
      int n = std::max(1, (int)m.ival);
      float rr = m.r + 26;
      int segsN = std::max(n, 6);
      float arc = TAU / segsN;
      float start = f.rng.rangef(0, TAU);
      V2 c = m.p;
      for (int k = 0; k < n; ++k) {
        float a0 = start + k * arc + arc * 0.12f, a1 = start + (k + 1) * arc - arc * 0.12f;
        int si = addSeg(w, SK_BARRIER, c + fromAng(a0) * rr, c + fromAng(a1) * rr, 4);
        if (si >= 0) {
          f.segs[si].hp = 2;
          f.segs[si].ttl = 3;
          f.segs[si].rest = 0.6f;
        }
      }
      logMsg(w, 0xa0d080, "%s raises barriers.", The(L).c_str());
      fxSound(w, S_BLOCK, 0.7f, 0.7f, c.x);
      break;
    }
    case IN_TELEPORT: teleportMonster(w, mi); fxSound(w, S_PORTAL, 0.6f, 1.f, f.mons[mi].p.x); break;
    case IN_DRAIN: {
      if (resists(w, mi, false, true)) break;
      int d0 = std::min(w.pl.mp, (int)m.ival);
      w.pl.mp -= d0;
      if (d0) fxText(w, V2(200, 150), 0x7080ff, fmt("-%d MP", d0), 16);
      logMsg(w, 0x9090ff, "%s drains your magic.", The(L).c_str());
      fxSound(w, S_MANA, 0.6f, 0.5f, m.p.x);
      break;
    }
    case IN_POISON:
      if (w.st.poisonRes) {
        fxText(w, V2(200, 118), 0xa0a0a0, "immune", 14);
      } else {
        w.pl.poison += m.ival;
        fxText(w, V2(200, 118), 0x90e040, fmt("+%d poison", m.ival), 14);
        logMsg(w, 0x90e040, "%s poisons you!", The(L).c_str());
      }
      fxSound(w, S_POISON, 0.7f, 1.f, m.p.x);
      break;
    case IN_WEAKEN:
      if (resists(w, mi, false, true)) break;
      w.pl.weak = std::max(w.pl.weak, (int)m.ival);
      logMsg(w, 0xb0b0ff, "%s saps your strength! (Weakened)", The(L).c_str());
      fxSound(w, S_GROWL, 0.6f, 0.6f, m.p.x);
      break;
    case IN_GROW:
      m.maxHp += m.ival;
      m.hp += m.ival;
      fxText(w, m.p + V2(0, -m.r - 8), 0x70ff90, fmt("+%d", m.ival), 13);
      break;
    case IN_EAT: {
      V2 c = m.p;
      std::vector<std::pair<float, int>> cand;
      for (int i = 0; i < (int)f.pegs.size(); ++i) {
        const Peg& p = f.pegs[i];
        if (p.dead || p.kind != PK_PIN || p.motion) continue;
        float dd = dist2(p.p, c);
        if (dd < 260 * 260) cand.push_back({dd, i});
      }
      std::sort(cand.begin(), cand.end());
      int n = 0;
      for (auto& pr : cand) {
        if (n >= m.ival) break;
        f.pegs[pr.second].dead = true;
        fxZap(w, f.pegs[pr.second].p, c, 0xe080ff);
        n++;
      }
      Monster& mm = f.mons[mi];
      if (mm.corruptT <= 0) mm.hp += std::min(mm.maxHp - mm.hp, n * 2);
      if (n) {
        logMsg(w, 0xe080ff, "%s devours %d pins.", The(L).c_str(), n);
        fxSound(w, S_GROWL, 0.7f, 0.5f, c.x);
      }
      break;
    }
    case IN_TOTEM: {
      V2 mp = m.p;
      for (int tries = 0; tries < 80; ++tries) {
        V2 p = mp + fromAng(f.rng.rangef(0, TAU)) * f.rng.rangef(m.r + 30, m.r + 120);
        if (!spotFree(w, p, 11, 8)) continue;
        int pi = addPeg(w, PK_TOTEM, p, 11);
        if (pi >= 0) {
          f.pegs[pi].link = mi;
          f.pegs[pi].val = m.ival;
          logMsg(w, 0xc09060, "%s raises a totem.", The(L).c_str());
        }
        break;
      }
      break;
    }
    case IN_CURSEPOCKET: {
      if (resists(w, mi, true, false)) break;
      std::vector<int> good;
      for (int i = 0; i < (int)f.pockets.size(); ++i)
        if (f.pockets[i].kind != PO_CURSED && f.pockets[i].kind != PO_FROZEN) good.push_back(i);
      int cursed = 0;
      for (auto& p : f.pockets)
        if (p.kind == PO_CURSED) cursed++;
      if (cursed >= 3) {
        fxText(w, m.p + V2(0, -m.r - 10), 0xa0a0a0, "the pockets resist", 13);
        break;
      }
      if (!good.empty()) {
        int i = good[f.rng.range(0, (int)good.size() - 1)];
        f.pockets[i].orig = f.pockets[i].kind;
        f.pockets[i].kind = PO_CURSED;
        f.pockets[i].flash = 1.f;
        layoutPockets(w);
        logMsg(w, 0xc080ff, "%s curses a pocket!", The(L).c_str());
        fxSound(w, S_CAST, 0.7f, 0.4f, m.p.x);
      }
      break;
    }
    case IN_STEAL: {
      int g = std::min(w.pl.gold, (int)m.ival);
      w.pl.gold -= g;
      if (g) logMsg(w, 0xffd060, "%s steals %d gold!", The(L).c_str(), g);
      break;
    }
    case IN_CHARGE:
      fxText(w, m.p + V2(0, -m.r - 10), 0xff8080, "gathering strength...", 13);
      break;
    case IN_SHUFFLE: {
      std::vector<Pocket> k = f.pockets;
      f.rng.shuffle(k);
      for (int i = 0; i < (int)f.pockets.size(); ++i) {
        f.pockets[i].kind = k[i].kind;
        f.pockets[i].orig = k[i].orig;
        f.pockets[i].val = k[i].val;
        f.pockets[i].flash = 1.f;
      }
      layoutPockets(w);
      logMsg(w, 0xffd040, "%s shuffles the pockets!", The(L).c_str());
      fxSound(w, S_FLIP, 0.9f, 0.8f);
      break;
    }
    case IN_RISE: {
      bool lava = f.spec.biome == BI_FORGE;
      float& lvl = lava ? f.lavaLevel : f.waterLevel;
      if (lvl <= 0) lvl = POCKET_TOP;
      lvl = std::max(560.f, lvl - (float)m.ival);
      int zk = lava ? ZK_LAVA : ZK_WATER;
      bool found = false;
      for (auto& z : f.zones)
        if (!z.dead && z.kind == zk && z.link == -7) {
          z.p = V2((PX0 + PX1) * 0.5f, (lvl + POCKET_TOP) * 0.5f);
          z.half = V2((PX1 - PX0) * 0.5f, (POCKET_TOP - lvl) * 0.5f);
          found = true;
        }
      if (!found) {
        int zi = addZone(w, zk, V2((PX0 + PX1) * 0.5f, (lvl + POCKET_TOP) * 0.5f), V2((PX1 - PX0) * 0.5f, (POCKET_TOP - lvl) * 0.5f), false);
        if (zi >= 0) f.zones[zi].link = -7;
      }
      logMsg(w, lava ? 0xff7040 : 0x60c8ff, lava ? "The lava rises!" : "The water rises!");
      fxSound(w, S_WHOOSH, 0.8f, 0.5f);
      break;
    }
    // ---------------------------------------------------------- expansion intents
    case IN_EGGS: {
      int n = std::max(1, (int)m.ival);
      int def = m.iarg > 0 ? m.iarg : M_SPIDERLING;
      V2 mp = m.p;
      float mr = m.r;
      int laid = 0;
      for (int k = 0; k < n; ++k)
        for (int tries = 0; tries < 60; ++tries) {
          V2 p = mp + fromAng(f.rng.rangef(0, TAU)) * f.rng.rangef(mr + 26, mr + 130);
          if (!spotFree(w, p, 9, 8)) continue;
          int pi = addPeg(w, PK_EGG, p, 9);
          if (pi >= 0) {
            f.pegs[pi].val = 3;
            f.pegs[pi].aux = def;
            f.pegs[pi].link = mi;
            laid++;
          }
          break;
        }
      if (laid) {
        logMsg(w, 0xe0d0a0, "%s lays %d egg%s! Smash them before they hatch.", The(L).c_str(), laid, laid > 1 ? "s" : "");
        fxSound(w, S_SPAWN, 0.6f, 1.5f, mp.x);
      }
      break;
    }
    case IN_WEB: {
      int n = std::max(1, (int)m.ival);
      for (int k = 0; k < n; ++k) {
        V2 p(f.rng.rangef(PX0 + 90, PX1 - 90), f.rng.rangef(260, 720));
        int zi = addZone(w, ZK_WEB, p, V2(f.rng.rangef(40, 56), 0), true);
        if (zi >= 0) f.zones[zi].ttl = 3;
      }
      logMsg(w, 0xd0d0d0, "%s spins sticky webs across the board.", The(L).c_str());
      fxSound(w, S_WHOOSH, 0.6f, 1.4f, m.p.x);
      break;
    }
    case IN_BLIND:
      if (resists(w, mi, true, false)) break;
      f.blindTurns = std::max(f.blindTurns, std::max(1, (int)m.ival));
      logMsg(w, 0x9090a0, "%s blinds you! Your aiming guide is gone.", The(L).c_str());
      fxSound(w, S_CAST, 0.6f, 0.4f, m.p.x);
      break;
    case IN_CURSEBALL:
      if (resists(w, mi, true, false)) break;
      w.pl.cursedBall = true;
      logMsg(w, 0xb080ff, "%s drains your next ball. (It starts with half power.)", The(L).c_str());
      fxSound(w, S_CAST, 0.6f, 0.6f, m.p.x);
      break;
    case IN_SHIELDALLY: {
      int t = -1;
      for (int i = 0; i < (int)f.mons.size(); ++i) {
        if (i == mi || !isHostile(w, i)) continue;
        if (t < 0 || f.mons[i].hp < f.mons[t].hp) t = i;
      }
      if (t < 0) t = mi;
      f.mons[t].shield += m.ival;
      fxZap(w, m.p, f.mons[t].p, 0xb0c0ff);
      fxText(w, f.mons[t].p + V2(0, -f.mons[t].r - 10), 0xb0c0ff, fmt("+%d block", m.ival), 14);
      fxSound(w, S_BLOCK, 0.6f, 1.2f, m.p.x);
      break;
    }
    case IN_ENRAGE:
      m.enraged = true;
      fxText(w, m.p + V2(0, -m.r - 10), 0xff4040, "ENRAGED!", 16);
      fxRing(w, m.p, m.r * 2, 0xff4040);
      fxSound(w, S_GROWL, 1.f, 0.7f, m.p.x);
      logMsg(w, 0xff6060, "%s flies into a rage!", The(L).c_str());
      break;
    case IN_BURROW:
      teleportMonster(w, mi);
      f.mons[mi].shield += m.ival;
      fxSound(w, S_BLOCK, 0.6f, 0.5f, f.mons[mi].p.x);
      break;
    case IN_ACID: {
      std::vector<int> c;
      for (int i = 0; i < (int)f.pegs.size(); ++i)
        if (!f.pegs[i].dead && f.pegs[i].kind == PK_PIN && !f.pegs[i].motion) c.push_back(i);
      f.rng.shuffle(c);
      for (int k = 0; k < std::max(1, (int)m.ival) && k < (int)c.size(); ++k) {
        f.pegs[c[k]].dead = true;
        fxBurst(w, f.pegs[c[k]].p, 0xa0ff40, 6, 90);
      }
      if (!resists(w, mi, false, false)) w.pl.corrode = std::max(w.pl.corrode, 2);
      logMsg(w, 0xa0ff40, "%s spits acid! Pins dissolve and your armor corrodes.", The(L).c_str());
      fxSound(w, S_POISON, 0.8f, 0.6f, m.p.x);
      break;
    }
    case IN_MUTATEPEGS: {
      if (resists(w, mi, true, false)) break;
      std::vector<int> c;
      for (int i = 0; i < (int)f.pegs.size(); ++i)
        if (!f.pegs[i].dead && !f.pegs[i].used && isEnchant(f.pegs[i].kind) && f.pegs[i].kind != PK_CURSE) c.push_back(i);
      f.rng.shuffle(c);
      int n = 0;
      for (int k = 0; k < std::max(1, (int)m.ival) && k < (int)c.size(); ++k, ++n) {
        f.pegs[c[k]].kind = PK_CURSE;
        f.pegs[c[k]].flash = 1.f;
      }
      if (n < m.ival) n += convertPins(w, PK_CURSE, m.ival - n);
      logMsg(w, 0xc080ff, "%s warps %d pegs into curses.", The(L).c_str(), n);
      fxSound(w, S_CAST, 0.6f, 0.4f, m.p.x);
      break;
    }
    case IN_SWAP: {
      std::vector<int> o;
      for (int i = 0; i < (int)f.mons.size(); ++i)
        if (i != mi && isHostile(w, i) && !f.mons[i].boss && !(MON[f.mons[i].def].traits & TR_STATIONARY)) o.push_back(i);
      if (o.empty() || m.boss || (d.traits & TR_STATIONARY)) break;
      int j = o[f.rng.range(0, (int)o.size() - 1)];
      Monster& a = f.mons[mi];
      Monster& b = f.mons[j];
      std::swap(a.clearing, b.clearing);
      a.moveFrom = a.p;
      b.moveFrom = b.p;
      std::swap(a.p, b.p);
      a.moveT = b.moveT = w.quiet ? 1.f : 0.f;
      if (a.clearing >= 0) f.clearings[a.clearing].mon = mi;
      if (b.clearing >= 0) f.clearings[b.clearing].mon = j;
      float cra = a.clearing >= 0 ? f.clearings[a.clearing].r - 3 : a.r, crb = b.clearing >= 0 ? f.clearings[b.clearing].r - 3 : b.r;
      a.r = std::min(a.r, cra);
      b.r = std::min(b.r, crb);
      logMsg(w, 0xff80ff, "%s swaps places with %s!", The(L).c_str(), TheM(b).c_str());
      fxSound(w, S_PORTAL, 0.7f, 1.2f, a.p.x);
      break;
    }
    case IN_DECOY: {
      int n = std::max(1, (int)m.ival);
      V2 mp = m.p;
      for (int k = 0; k < n; ++k) {
        if (summonedAlive(w) >= 5) break;
        int cl = freeClearing(w, mp, false);
        if (cl < 0) break;
        int ni = spawnMonster(w, M_DECOY, cl, true);
        if (ni < 0) break;
        Monster& src = f.mons[mi];
        Monster& dc = f.mons[ni];
        dc.look = src.look >= 0 ? src.look : src.def;
        dc.maxHp = src.maxHp;
        dc.hp = src.hp;
        dc.hpDisp = (float)src.hp;
        dc.r = std::min(src.r, f.clearings[cl].r - 3);
        dc.intent = IN_ATTACK;
        dc.ival = 4;
        dc.cd = f.rng.range(1, 3);
        dc.moveFrom = mp;
        dc.moveT = w.quiet ? 1.f : 0.f;
      }
      logMsg(w, 0xff90ff, "%s splits into mirror images!", The(L).c_str());
      fxSound(w, S_CAST, 0.7f, 1.6f, mp.x);
      break;
    }
    case IN_FREEZEPOCKET: {
      int frozen = 0;
      std::vector<int> c, pref;
      for (int i = 0; i < (int)f.pockets.size(); ++i) {
        int k = f.pockets[i].kind;
        if (k == PO_FROZEN) frozen++;
        else if (k != PO_CURSED && k != PO_VOID && k != PO_EMPTY) {
          c.push_back(i);
          if (k == PO_RECALL || k == PO_STRIKE) pref.push_back(i);
        }
      }
      if (frozen >= 2 || c.empty()) {
        fxText(w, m.p + V2(0, -m.r - 10), 0xa0a0a0, "the pockets resist", 13);
        break;
      }
      int i = (!pref.empty() && f.rng.chance(0.5f)) ? pref[f.rng.range(0, (int)pref.size() - 1)] : c[f.rng.range(0, (int)c.size() - 1)];
      f.pockets[i].orig = f.pockets[i].kind;
      f.pockets[i].kind = PO_FROZEN;
      f.pockets[i].val = 2;
      f.pockets[i].flash = 1.f;
      layoutPockets(w);
      logMsg(w, 0xa0e0ff, "%s freezes a pocket solid!", The(L).c_str());
      fxSound(w, S_FREEZE, 0.8f, 0.7f, m.p.x);
      break;
    }
    case IN_DEVOUR: {
      V2 c = m.p;
      int n = 0;
      for (auto& p : f.pegs) {
        if (p.dead || p.used || !isEnchant(p.kind) || p.kind == PK_CURSE || dist2(p.p, c) > 280 * 280) continue;
        fxZap(w, p.p, c, 0xe080ff);
        p.kind = PK_PIN;
        n++;
      }
      Monster& mm = f.mons[mi];
      if (n && mm.corruptT <= 0) mm.hp = std::min(mm.maxHp, mm.hp + 4 * n);
      logMsg(w, 0xe080ff, n ? "%s devours the magic of %d pegs!" : "%s finds nothing to devour.", The(L).c_str(), n);
      fxSound(w, S_GROWL, 0.7f, 0.6f, c.x);
      break;
    }
    case IN_GRAVITY: {
      V2 p(f.rng.rangef(PX0 + 120, PX1 - 120), f.rng.rangef(300, 680));
      int zi = addZone(w, ZK_WELL, p, V2(95, 0), true);
      if (zi >= 0) {
        f.zones[zi].str = 950;
        f.zones[zi].ttl = 2;
      }
      logMsg(w, 0xa080ff, "%s twists gravity into a well.", The(L).c_str());
      fxSound(w, S_PORTAL, 0.8f, 0.5f, m.p.x);
      break;
    }
    case IN_RANDOM:
      if (depthGuard < 2) doRandomIntent(w, mi, depthGuard);
      break;
    case IN_SLOW:
      if (resists(w, mi, false, true)) break;
      w.pl.slowed = std::max(w.pl.slowed, (int)m.ival);
      logMsg(w, 0x9090ff, "%s slows you. (No MP regeneration)", The(L).c_str());
      fxSound(w, S_CAST, 0.6f, 0.5f, m.p.x);
      break;
    case IN_SAP:
      if (resists(w, mi, false, true)) break;
      w.pl.sapped = std::max(w.pl.sapped, (int)m.ival);
      logMsg(w, 0xb0b0ff, "%s saps your power! (-2 base power)", The(L).c_str());
      fxSound(w, S_GROWL, 0.6f, 0.5f, m.p.x);
      break;
    // ---------------------------------------------------------- v3: boss moves & treasure imps
    case IN_QUAKE: {
      int dmg = intentDamage(w, m);
      V2 mp = m.p;
      fxShake(w, 20);
      fxSound(w, S_BOOM, 1.f, 0.45f, mp.x);
      fxRing(w, mp, 260, L.color);
      fxAttack(w, mp, L.color, dmg);
      damagePlayer(w, dmg, mi, true);
      int shaken = 0;
      for (auto& p : f.pegs)
        if (!p.dead && !p.used && isEnchant(p.kind) && p.kind != PK_CURSE && f.rng.chance(0.3f)) {
          p.kind = PK_PIN;
          p.flash = 1.f;
          shaken++;
        }
      std::vector<int> pins;
      for (int i = 0; i < (int)f.pegs.size(); ++i)
        if (!f.pegs[i].dead && f.pegs[i].kind == PK_PIN && !f.pegs[i].motion) pins.push_back(i);
      f.rng.shuffle(pins);
      for (int k = 0; k < 6 && k < (int)pins.size(); ++k) {
        f.pegs[pins[k]].dead = true;
        fxBurst(w, f.pegs[pins[k]].p, 0xa08060, 6, 90);
      }
      logMsg(w, 0xffa060, "%s slams the ground! The board shakes%s.", The(L).c_str(), shaken ? " and special pegs lose their magic" : "");
      break;
    }
    case IN_LIFEDRAIN: {
      int dmg = intentDamage(w, m);
      int before = w.pl.hp;
      fxZap(w, V2(200, 118), m.p, 0xd02040);
      damagePlayer(w, dmg, mi, false);
      int dealt = std::max(0, before - w.pl.hp);
      Monster& mm = f.mons[mi];
      if (!mm.dead && dealt > 0 && mm.corruptT <= 0) {
        int h = std::min(mm.maxHp - mm.hp, dealt * 2);
        mm.hp += h;
        if (h > 0) fxText(w, mm.p + V2(0, -mm.r - 8), 0xff6080, fmt("+%d", h), 14);
      }
      logMsg(w, 0xff6080, "%s drains your life!", The(L).c_str());
      fxSound(w, S_CAST, 0.8f, 0.5f, m.p.x);
      break;
    }
    case IN_DISPEL: {
      bool any = w.pl.block > 0 || w.pl.guardBlocks > 0 || w.pl.nextShotPower > 0 || w.pl.nextShotDouble || f.sanctuaryT > 0;
      w.pl.block = 0;
      w.pl.guardBlocks = 0;
      w.pl.nextShotPower = 0;
      w.pl.nextShotDouble = false;
      f.sanctuaryT = 0;
      f.blockKeep = 0;
      if (any) fxText(w, V2(200, 180), 0xd0a0ff, "Dispelled!", 18);
      int dmg = intentDamage(w, m);
      fxAttack(w, m.p, L.color, dmg);
      damagePlayer(w, dmg, mi, false);
      logMsg(w, 0xd0a0ff, "%s dispels your protections%s.", The(L).c_str(), any ? "" : " (you had none)");
      fxSound(w, S_SHATTER, 0.8f, 0.6f, m.p.x);
      break;
    }
    case IN_EXECUTE: {
      int dmg = intentDamage(w, m) + std::max(0, w.st.maxHp - w.pl.hp) / 4;
      fxAttack(w, m.p, L.color, dmg);
      damagePlayer(w, dmg, mi, false);
      logMsg(w, 0xff5050, "%s tries to finish you off!", The(L).c_str());
      fxSound(w, S_GROWL, 1.f, 0.6f, m.p.x);
      fxShake(w, 10);
      break;
    }
    case IN_SUNDER: {
      int dmg = intentDamage(w, m);
      fxAttack(w, m.p, L.color, dmg);
      damagePlayer(w, dmg, mi, false);
      w.pl.corrode = std::max(w.pl.corrode, 3);
      logMsg(w, 0xffa080, "%s sunders your armor!", The(L).c_str());
      fxSound(w, S_SHATTER, 0.7f, 0.7f, m.p.x);
      break;
    }
    case IN_FLEE: {
      m.escapeT--;
      if (m.escapeT <= 0) {
        V2 mp = m.p;
        m.dead = true;
        m.hp = 0;
        if (m.clearing >= 0 && m.clearing < (int)f.clearings.size() && f.clearings[m.clearing].mon == mi) f.clearings[m.clearing].mon = -1;
        fxBurst(w, mp, 0xffd040, 30, 220, 3);
        fxText(w, mp + V2(0, -30), 0xffd040, "escaped!", 16);
        fxSound(w, S_PORTAL, 0.8f, 1.6f, mp.x);
        logMsg(w, 0xffd040, "The treasure imp escapes with its loot!");
        break;
      }
      teleportMonster(w, mi);
      fxText(w, f.mons[mi].p + V2(0, -f.mons[mi].r - 12), 0xffd040, "hee hee!", 13);
      break;
    }
    case IN_METEOR: {
      V2 mp = m.p;
      int dmg = scaledMonsterValue(w, m.ival);
      int turns = m.iarg > 0 ? m.iarg : 2;
      for (int tries = 0; tries < 120; ++tries) {
        V2 p(f.rng.rangef(PX0 + 60, PX1 - 60), f.rng.rangef(FIELD_Y0 + 120, FIELD_Y1 - 80));
        if (!spotFree(w, p, 17, 10)) continue;
        int pi = addPeg(w, PK_MBOMB, p, 16);
        if (pi >= 0) {
          f.pegs[pi].hp = dmg;
          f.pegs[pi].val = turns;
          f.pegs[pi].aux = 3;
          f.pegs[pi].link = mi;
          logMsg(w, 0xff8040, "%s calls down a meteor! (%d damage in %d turns: hit the marker 3 times to shatter it)", The(L).c_str(), dmg, turns);
          fxBanner(w, "Meteor incoming!", 0xff8040);
          fxSound(w, S_FIRE, 1.f, 0.5f, p.x);
        }
        break;
      }
      (void)mp;
      break;
    }
    default: break;
  }
}

static bool monsterAct(World& w, int mi) {
  Floor& f = w.fl;
  Monster& m = f.mons[mi];
  if (m.dead || m.fresh) return false;
  const MonDef& d = MON[m.def];
  if (d.traits & TR_DECOY) {
    if (--m.cd <= 0) {
      fxText(w, m.p + V2(0, -m.r - 10), 0xff90ff, "the image flickers", 13);
      m.cd = f.rng.range(1, 3);
    }
    return false;
  }
  if (m.frozen > 0) {
    m.frozen--;
    m.freezeImmune = 1;
    fxText(w, m.p + V2(0, -m.r - 10), 0xc0f0ff, "frozen", 14);
    return true;
  }
  if (m.charmed) {
    if (--m.cd > 0) return false;
    int t = pickRandomHostile(w);
    if (t >= 0) {
      int dmg = std::max(3, intentDamage(w, m) > 0 ? intentDamage(w, m) : 4 + w.depth / 2);
      fxZap(w, m.p, f.mons[t].p, 0xff90ff);
      logMsg(w, 0xff90ff, "Your charmed %s attacks %s!", MON[m.def].name, TheM(f.mons[t]).c_str());
      damageMonster(w, t, dmg, DS_ALLY);
    }
    Monster& m2 = f.mons[mi];
    setIntent(w, m2, m2.spos + 1, 0);
    return true;
  }
  if (d.traits & TR_FLYING) teleportMonster(w, mi);
  Monster& mm = f.mons[mi];
  mm.cd--;
  if (mm.cd > 0) return false;
  // an intent with no delay chains straight into the next one: bosses act twice
  for (int chain = 0; chain < 3; ++chain) {
    Monster& cur = f.mons[mi];
    bool attackish = intentDamage(w, cur) > 0 || cur.intent == IN_BEAM;
    if (f.silenceT > 0 && !attackish) {
      fxText(w, cur.p + V2(0, -cur.r - 10), 0xa0a0b0, "silenced", 14);
    } else {
      execIntent(w, mi);
    }
    Monster& m2 = f.mons[mi];
    if (m2.dead || w.dead) break;
    int n = 0;
    const Intent* sc = monsterScript(m2, &n);
    bool chained = n > 1 && m2.spos < n && (sc[m2.spos].delay & INTENT_CHAIN) && m2.intent != IN_RANDOM;
    setIntent(w, m2, m2.spos + 1, 0);
    if (!chained) break;
  }
  return true;
}

static void alliesAct(World& w) {
  Floor& f = w.fl;
  float mul = allyDamageMul(w);
  for (int i = 0; i < (int)f.pegs.size(); ++i) {
    const Peg& p = f.pegs[i];
    if (p.dead) continue;
    int k = p.kind;
    bool fly = k == PK_FIREFLY && p.temp;
    if (!isAllyPeg(k) && !fly) continue;
    if (k == PK_TESLA) continue;  // acts after your shots
    if (aliveMonsterCount(w) == 0) break;
    V2 c = p.p;
    int t = -1, dmg = 0;
    uint32_t col = PEG_COLOR[k];
    int src = DS_ALLY;
    switch (k) {
      case PK_SKELETON: t = pickRandomHostile(w); dmg = 4 + w.depth / 2; break;
      case PK_IMP: t = pickRandomHostile(w); dmg = p.val; break;
      case PK_HOUND: t = nearestMonster(w, c); dmg = p.val; break;
      case PK_FAMILIAR: t = focusTarget(w); dmg = p.val; break;
      case PK_ANGEL: t = highestHpMonster(w); dmg = p.val; src = DS_HOLY; break;
      case PK_FIREFLY: t = pickRandomHostile(w); dmg = std::max(1, p.val); break;
    }
    if (t < 0 || dmg <= 0) continue;
    dmg = std::max(1, (int)std::lround(dmg * mul));
    fxZap(w, c, f.mons[t].p, col);
    damageMonster(w, t, dmg, src);
    if (k == PK_IMP) applyBurn(w, t, 1);
    if (k == PK_HOUND) applyBleed(w, t, 2);
  }
}

void enemyStep(World& w) {
  Floor& f = w.fl;
  switch (f.enemyStage) {
    case 0: {
      for (auto& m : f.mons) {
        if (m.dead) continue;
        m.shield = 0;
        m.fresh = false;
        if (m.freezeImmune > 0 && m.frozen == 0) m.freezeImmune--;
        m.turnDamage = 0;
      }
      for (int i = 0; i < (int)f.mons.size(); ++i) {
        if (f.mons[i].dead || f.mons[i].charmed) continue;
        if (f.mons[i].burn > 0) {
          int b = f.mons[i].burn;
          f.mons[i].burn = hasRelic(w, RL_U_INFERNO) ? b * 2 / 3 : b / 2;
          fxBurst(w, f.mons[i].p, 0xff7030, 10, 120);
          damageMonster(w, i, b, DS_BURN);
        }
        if (!f.mons[i].dead && f.mons[i].poison > 0) {
          int p = f.mons[i].poison;
          f.mons[i].poison = p - 1;
          damageMonster(w, i, p, DS_POISON);
        }
        if (!f.mons[i].dead && f.mons[i].bleed > 0) {
          int b = f.mons[i].bleed;
          f.mons[i].bleed = std::max(0, b - std::max(1, b / 3));
          fxBurst(w, f.mons[i].p, 0xe03848, 8, 100);
          damageMonster(w, i, b, DS_BLEED);
        }
        if (f.mons[i].dead) continue;
        const MonDef& d = MON[f.mons[i].def];
        Monster& m = f.mons[i];
        if (m.corruptT > 0 && --m.corruptT == 0) m.corruptAmt = 0;
        if ((d.traits & TR_REGEN) && m.hp < m.maxHp && m.corruptT <= 0) {
          int h = std::min(d.tval, m.maxHp - m.hp);
          m.hp += h;
          fxText(w, m.p + V2(0, -m.r - 8), 0x70ff90, fmt("+%d", h), 13);
        }
        if (d.traits & TR_AURA) {
          for (int j = 0; j < (int)f.mons.size(); ++j) {
            Monster& o = f.mons[j];
            if (j == i || o.dead || o.charmed || o.corruptT > 0 || o.hp >= o.maxHp) continue;
            int h = std::min(d.tval, o.maxHp - o.hp);
            o.hp += h;
            fxText(w, o.p + V2(0, -o.r - 8), 0x70ff90, fmt("+%d", h), 13);
          }
        }
        champTurn(w, i);
      }
      // totems shield their masters
      for (auto& p : f.pegs)
        if (!p.dead && p.kind == PK_TOTEM && p.link >= 0 && p.link < (int)f.mons.size() && !f.mons[p.link].dead)
          f.mons[p.link].shield += p.val;
      // hazards that hurt monsters standing in them
      for (int zi = 0; zi < (int)f.zones.size(); ++zi) {
        const Zone& z = f.zones[zi];
        if (z.dead || (z.kind != ZK_MIST && !(z.kind == ZK_WELL && z.link == -9))) continue;
        for (int i = 0; i < (int)f.mons.size(); ++i) {
          if (!isHostile(w, i)) continue;
          float rr = z.circle ? z.half.x : std::max(z.half.x, z.half.y);
          if (dist(f.mons[i].p, z.p) - f.mons[i].r > rr) continue;
          if (z.kind == ZK_MIST) applyPoison(w, i, 2);
          else damageMonster(w, i, std::max(1, z.dmg), DS_SPELL);
        }
      }
      // monster bombs and eggs tick
      for (int i = 0; i < (int)f.pegs.size(); ++i) {
        Peg& p = f.pegs[i];
        if (p.dead) continue;
        if (p.kind == PK_MBOMB) {
          if (--p.val <= 0) {
            p.dead = true;
            fxBurst(w, p.p, 0xff4020, 40, 300, 4);
            fxRing(w, p.p, 90, 0xff4020);
            fxSound(w, S_BOOM, 1.f, 0.9f, p.p.x);
            fxAttack(w, p.p, 0xff4020, p.hp);
            damagePlayer(w, p.hp, -1, false, "a bomb");
            logMsg(w, 0xff6040, "A bomb explodes!");
            if (w.dead) {
              f.phase = PH_DEAD;
              return;
            }
          }
        } else if (p.kind == PK_EGG) {
          if (--p.val <= 0) hatchEgg(w, i);
        }
      }
      if (aliveMonsterCount(w) == 0) {
        floorWon(w);
        return;
      }
      f.enemyStage = 1;
      f.enemyIdx = 0;
      f.enemyTimer = 0.15f;
      break;
    }
    case 1: {
      while (f.enemyIdx < (int)f.mons.size()) {
        int i = f.enemyIdx++;
        if (f.mons[i].dead || f.mons[i].fresh) continue;
        bool acted = monsterAct(w, i);
        if (w.dead) {
          f.phase = PH_DEAD;
          return;
        }
        if (acted) {
          f.enemyTimer = 0.42f;
          return;
        }
      }
      f.enemyStage = 2;
      f.enemyTimer = 0.1f;
      break;
    }
    case 2: {
      applyTurnModifiers(w);
      // allies strike
      if (f.raisedAllyT > 0) {
        f.raisedAllyT--;
        int t = lowestHpMonster(w);
        if (t >= 0) {
          fxZap(w, f.lastKillPos, f.mons[t].p, 0xc0a0ff);
          damageMonster(w, t, (int)std::lround(f.raisedAllyDmg * allyDamageMul(w)), DS_ALLY);
        }
      }
      alliesAct(w);
      if (aliveMonsterCount(w) == 0) {
        floorWon(w);
        return;
      }
      f.enemyStage = 3;
      f.enemyTimer = 0.1f;
      break;
    }
    case 3: {
      Player& pl = w.pl;
      if (pl.poison > 0) {
        int p = pl.poison;
        pl.poison /= 2;
        damagePlayer(w, p, -1, true, "poison");
        if (w.dead) {
          f.phase = PH_DEAD;
          return;
        }
      }
      if (pl.weak > 0) pl.weak--;
      if (pl.deathsDoor > 0) pl.deathsDoor--;
      if (pl.corrode > 0) pl.corrode--;
      if (pl.slowed > 0) pl.slowed--;
      if (pl.sapped > 0) pl.sapped--;
      if (f.silenceT > 0) f.silenceT--;
      if (f.sanctuaryT > 0) f.sanctuaryT--;
      for (auto& m : f.mons) {
        if (m.chilled > 0) m.chilled--;
        if (!m.dead && m.charmed && --m.charmT <= 0) {
          m.charmed = false;
          fxText(w, m.p + V2(0, -m.r - 10), 0xff90ff, "breaks free!", 14);
        }
      }
      for (auto& s : f.segs)
        if (!s.dead && s.ttl > 0 && --s.ttl == 0) s.dead = true;
      for (auto& p : f.pegs)
        if (!p.dead && p.ttl > 0 && --p.ttl == 0) {
          p.dead = true;
          fxBurst(w, p.p, PEG_COLOR[p.kind], 8, 100);
        }
      for (auto& z : f.zones)
        if (!z.dead && z.ttl > 0 && --z.ttl == 0) z.dead = true;
      FOR_EFF0(enemyPhaseEnd);
      if (pl.patron == PT_TOCK && !f.tookDamageThisTurn) gainPiety(w, 3);
      if (w.dead) {
        f.phase = PH_DEAD;
        return;
      }
      if (aliveMonsterCount(w) == 0) {
        floorWon(w);
        return;
      }
      startPlayerTurn(w, true);
      break;
    }
  }
}

void floorUpdate(World& w, float dt) {
  Floor& f = w.fl;
  if (f.phase == PH_REDIRECT || f.phase == PH_RELAUNCH || f.phase == PH_DEAD) return;
  ensureCapacity(w);
  f.time += dt;
  // presentation decay (cheap, deterministic)
  for (auto& m : f.mons) {
    m.flash = std::max(0.f, m.flash - dt * 4);
    m.act = std::max(0.f, m.act - dt * 3);
    if (m.moveT < 1) m.moveT = std::min(1.f, m.moveT + dt * 3.5f);
    m.hpDisp += (m.hp - m.hpDisp) * std::min(1.f, dt * 8);
  }
  for (auto& p : f.pegs) p.flash = std::max(0.f, p.flash - dt * 3);
  for (auto& s : f.segs) s.flash = std::max(0.f, s.flash - dt * 4);
  for (auto& p : f.pockets) p.flash = std::max(0.f, p.flash - dt * 2);
  animateBoard(w, dt);
  if (f.phase != PH_CLEARED) processSlots(w, dt);
  switch (f.phase) {
    case PH_FLIGHT: {
      physicsStep(w, dt);
      if (f.shot.slowT > 0) f.shot.slowT -= dt;
      if (f.phase == PH_FLIGHT) tumblerFlightAct(w);
      bool any = false;
      for (auto& b : f.balls) any |= b.alive;
      if (!any && f.newBalls.empty() && f.phase == PH_FLIGHT) endShot(w);
      break;
    }
    case PH_ENEMY: {
      f.enemyTimer -= dt;
      int guard = 0;
      while ((w.quiet || f.enemyTimer <= 0) && f.phase == PH_ENEMY && guard++ < 200) enemyStep(w);
      break;
    }
    case PH_CLEARED: f.clearT += dt; break;
    default: break;
  }
}

bool canLaunch(const World& w) { return w.fl.phase == PH_AIM && w.offers.empty() && w.relicOffers.empty() && !w.dead; }

void launch(World& w, float angle, float speed) {
  Floor& f = w.fl;
  if (!canLaunch(w)) return;
  ensureCapacity(w);
  f.phase = PH_FLIGHT;
  f.shotTime = 0;
  f.shotsFired++;
  w.rs.shots++;
  f.balls.clear();
  f.newBalls.clear();
  for (auto& m : f.mons) m.shotFlags = 0;
  if (w.pl.nextShotDouble) {
    f.shot.doubled = true;
    w.pl.nextShotDouble = false;
  }
  int pw = effPower(w) + w.pl.nextShotPower + f.shot.mightBonus + f.shot.spellweaveBonus;
  w.pl.nextShotPower = 0;
  if (w.pl.cursedBall) {
    w.pl.cursedBall = false;
    pw = std::max(1, pw / 2);
    fxText(w, launcherPos() + V2(0, 40), 0xb080ff, "drained!", 15);
  }
  float scale = f.shot.ballScale * (f.shot.heroism ? 1.2f : 1.f) * (f.shot.beast ? 1.25f : 1.f);
  V2 o = launcherPos();
  auto mk = [&](float a, int power, uint32_t flags, float r) {
    Ball b;
    b.id = f.nextId++;
    b.p = o + fromAng(a) * 26;
    b.v = fromAng(a) * speed;
    b.r = r;
    b.power = power;
    b.flags = flags;
    b.stuckRef = b.p;
    return b;
  };
  // the main ball
  {
    Ball b = mk(angle, pw, 0, w.st.ballR * scale);
    if (f.shot.boulder) {
      b.r = std::max(b.r, 15.f);
      b.flags |= BF_BOULDER;
      b.gravScale = 1.2f;
    }
    if (f.shot.beast) b.flags |= BF_BEAST;
    if (f.shot.elemental) b.flags |= BF_ELEMENTAL;
    if (f.shot.blessed) b.flags |= BF_HOLY;
    if (f.shot.golden) b.flags |= BF_GOLDEN;
    b.stormT = f.shot.stormBallT;
    b.flashHits = f.shot.flashHits;
    f.balls.push_back(b);
  }
  // twin launcher echoes
  for (int i = 1; i <= w.st.extraBalls; ++i) {
    float a = angle + ((i % 2) ? 1.f : -1.f) * 0.11f * ((i + 1) / 2);
    f.balls.push_back(mk(a, 1, BF_PHANTOM | BF_ECHO, w.st.ballR * scale * 0.85f));
  }
  // scatter shot: extra real balls in a fan
  if (f.shot.scatter > 0) {
    int sl = std::max(1, abLevel(w, AB_SCATTER));
    float frac = sl <= 1 ? 0.4f : sl == 2 ? 0.45f : 0.5f;
    for (int i = 1; i <= f.shot.scatter; ++i) {
      float a = angle + ((i % 2) ? 1.f : -1.f) * 0.14f * ((i + 1) / 2);
      Ball b = mk(a, std::max(1, (int)(pw * frac)), BF_SCATTER, w.st.ballR * scale);
      b.gen = 1;
      f.balls.push_back(b);
    }
  }
  // the ancestor's ball
  if (abLevel(w, AB_P_ANCESTOR)) {
    int ap = std::max(2, w.st.basePower / 2 + 2);
    if (abLevel(w, AB_P_ANCBLESS)) ap = ap * 3 / 2;
    if (f.shot.idealize) ap += 15;
    float a = clampv(angle + (angle < PI * 0.5f ? 0.2f : -0.2f), 0.15f, PI - 0.15f);
    f.balls.push_back(mk(a, ap, BF_PHANTOM | BF_ANCESTOR, w.st.ballR * 0.9f));
  }
  // echo shell: every Nth shot a full-power echo follows
  if (w.st.echoEvery > 0 && f.shotsFired % w.st.echoEvery == 0)
    f.balls.push_back(mk(angle + 0.05f, pw, BF_PHANTOM, w.st.ballR * scale * 0.9f));
  FOR_EFF0(shotStart);
  fxSound(w, S_LAUNCH, 0.8f);
}

void relaunch(World& w, float angle) {
  Floor& f = w.fl;
  if (f.phase != PH_RELAUNCH) return;
  V2 o = launcherPos();
  spawnBall(w, o + fromAng(angle) * 26, fromAng(angle) * f.launchSpeed, f.relaunchPower, 0);
  for (auto& nb : f.newBalls) f.balls.push_back(nb);
  f.newBalls.clear();
  f.phase = PH_FLIGHT;
  fxSound(w, S_LAUNCH, 0.8f, 1.2f);
}

void redirect(World& w, float angle) {
  Floor& f = w.fl;
  if (f.phase != PH_REDIRECT) return;
  for (auto& b : f.balls) {
    if (!b.alive) continue;
    float sp = std::max(len(b.v), 650.f);
    b.v = fromAng(angle) * sp;
    b.power += f.relaunchPower;
    fxBurst(w, b.p, 0xc080ff, 10, 160);
  }
  f.phase = PH_FLIGHT;
  fxSound(w, S_WHOOSH, 0.8f, 1.3f);
}

void flipperPress(World& w, int side, bool down) {
  Floor& f = w.fl;
  if (!f.hasFlippers || side < 0 || side > 1) return;
  if (!down) {
    f.flipKey[side] = false;
    return;
  }
  if (f.flipKey[side]) return;
  if (f.phase != PH_FLIGHT || f.shot.flipsLeft <= 0) return;
  f.shot.flipsLeft--;
  f.flipKey[side] = true;
  f.flipHeldT[side] = 0;
  fxSound(w, S_FLIP, 0.8f, 1.f, side == 0 ? 500.f : 1100.f);
}

// ================================================================ abilities / items
static bool findAbility(const World& w, int ab, int* lvl, int* slot) {
  if (ab >= AB_FIRST_DIVINE) {
    int l = abLevel(w, ab);
    if (lvl) *lvl = l;
    if (slot) *slot = -1;
    return l > 0;
  }
  for (int i = 0; i < (int)w.pl.abil.size(); ++i)
    if (w.pl.abil[i].id == ab) {
      if (lvl) *lvl = w.pl.abil[i].lvl;
      if (slot) *slot = i;
      return true;
    }
  return false;
}

bool abilityUsable(const World& w, int ab, std::string* why) {
  auto no = [&](const char* m) {
    if (why) *why = m;
    return false;
  };
  int lvl = 0, slot = -1;
  if (ab < 0 || ab >= AB_COUNT) return no("Unknown ability.");
  if (!findAbility(w, ab, &lvl, &slot)) return no("You don't have that ability.");
  const AbilityDef& d = ABIL[ab];
  if (d.timing == T_PASSIVE) return no("That ability is passive.");
  if (w.screen != RS_FLOOR) return no("Only usable on a floor.");
  const Floor& f = w.fl;
  if (d.timing == T_AIM && f.phase != PH_AIM) return no("Use this before you launch.");
  if (d.timing == T_FLIGHT && f.phase != PH_FLIGHT) return no("Use this while a ball is in flight.");
  if (d.timing == T_ANY && f.phase != PH_AIM && f.phase != PH_FLIGHT) return no("Not now.");
  if (slot >= 0 && w.pl.abil[slot].cd > 0) return no("Still recharging.");
  int cost = abilityCost(w, ab, lvl);
  if (d.school == SCH_DIVINE) {
    if (w.pl.patron != PT_AURUM && w.pl.piety < cost) return no("Not enough piety.");
  } else if (cost > w.pl.mp && !f.freeCasts && !(f.holsterFree && cost > 0)) return no("Not enough MP.");
  int hpc = abilityHpCost(w, ab, lvl);
  if (hpc > 0 && w.pl.hp <= hpc) return no("Not enough HP.");
  int gc = abilityGoldCost(w, ab, lvl);
  if (gc > w.pl.gold) return no("Not enough gold.");
  if (d.target == TG_MONSTER && aliveMonsterCount(w) == 0) return no("No target.");
  return true;
}

static void wildSurge(World& w) {
  Floor& f = w.fl;
  f.shot.wildSurges++;
  int r = f.rng.range(0, 5);
  switch (r) {
    case 0: gainMp(w, 2); fxText(w, V2(800, 330), 0xff60ff, "Wild surge: +2 MP", 15); break;
    case 1: allBallsPower(w, 6); fxText(w, V2(800, 330), 0xff60ff, "Wild surge: +6 power", 15); break;
    case 2: {
      static const int K[] = {PK_CRIT, PK_MULTI, PK_CHAOS, PK_CLOVER, PK_SPARK, PK_FIRE};
      for (int i = 0; i < 4; ++i) convertPins(w, K[f.rng.range(0, 5)], 1);
      fxText(w, V2(800, 330), 0xff60ff, "Wild surge: the pins shimmer", 15);
      break;
    }
    case 3: healPlayer(w, 4); break;
    case 4: {
      int t = pickRandomHostile(w);
      if (t >= 0) {
        fxZap(w, launcherPos(), f.mons[t].p, 0xff60ff);
        damageMonster(w, t, 6 + w.depth / 2, DS_SPELL);
      }
      break;
    }
    default: w.pl.nextShotPower += 5; fxText(w, V2(800, 330), 0xff60ff, "Wild surge: +5 next shot", 15); break;
  }
  fxSound(w, S_CAST, 0.6f, 1.9f);
}

bool castAbility(World& w, int ab, V2 pt, V2 pt2, int mon) {
  ensureCapacity(w);
  if (!abilityUsable(w, ab, nullptr)) return false;
  int lvl = 0, slot = -1;
  findAbility(w, ab, &lvl, &slot);
  const AbilityDef& d = ABIL[ab];
  if (d.target == TG_MONSTER) {
    if (mon < 0 || mon >= (int)w.fl.mons.size() || !isHostile(w, mon)) return false;
  }
  if (!d.cast || !d.cast(w, lvl, pt, pt2, mon)) {
    fxSound(w, S_DENY, 0.6f);
    return false;
  }
  int cost = abilityCost(w, ab, lvl);
  int hpc = abilityHpCost(w, ab, lvl);
  bool divine = d.school == SCH_DIVINE;
  int mpSpent = 0;
  if (divine) {
    if (cost > 0 && w.pl.patron != PT_AURUM) gainPiety(w, -cost);
  } else if (cost > 0) {
    if (w.fl.freeCasts) {
      fxText(w, V2(200, 150), 0x70a8ff, "free cast!", 14);
    } else if (w.fl.holsterFree) {
      w.fl.holsterFree = 0;
      fxText(w, V2(200, 150), 0xc080ff, "Holster: free!", 14);
    } else {
      w.pl.mp -= cost;
      mpSpent = cost;
    }
  }
  if (hpc > 0) selfDamage(w, hpc, nullptr);
  int gc = abilityGoldCost(w, ab, lvl);
  if (gc > 0) w.pl.gold -= gc;
  if (slot >= 0 && d.cooldown > 0) {
    int cd = d.cooldown;
    if (hasRelic(w, RL_CLOCKKEY)) cd = std::max(1, cd - 1);
    w.pl.abil[slot].cd = (uint8_t)cd;
  }
  w.rs.spellsCast++;
  logMsg(w, SCHOOL_COLOR[d.school], divine ? "You invoke %s." : "You use %s.", d.name);
  int sw = abLevel(w, AB_SPELLWEAVE);
  if (sw && cost > 0 && !divine) {
    int bonus = cost * (sw <= 1 ? 2 : sw == 2 ? 3 : 4);
    if (w.fl.phase == PH_FLIGHT) {
      for (auto& b : w.fl.balls)
        if (b.alive) b.power += bonus;
    } else w.fl.shot.spellweaveBonus += bonus;
  }
  conductSpell(w, ab, divine ? 0 : std::max(mpSpent, cost));
  if (!divine) {
    if (hasRelic(w, RL_CHALICE)) healPlayer(w, 1);
    if (hasRelic(w, RL_GRIMOIRE)) selfDamage(w, 1, nullptr);
    int ws = abLevel(w, AB_WILDSURGE);
    if (ws && ab != AB_WILDSURGE && w.fl.shot.wildSurges < 3 && w.fl.rng.chance(ws <= 1 ? 0.2f : ws == 2 ? 0.3f : 0.4f)) wildSurge(w);
    if (abLevel(w, AB_P_SPELLECHO) && !w.fl.shot.spellEchoUsed && !isInnate(ab)) {
      w.fl.shot.spellEchoUsed = true;
      int m2 = mon;
      if (d.target == TG_MONSTER && (m2 < 0 || m2 >= (int)w.fl.mons.size() || !isHostile(w, m2))) m2 = nearestMonster(w, pt);
      if (d.target != TG_MONSTER || m2 >= 0) {
        if (d.cast(w, lvl, pt, pt2, m2)) fxBanner(w, std::string("Spell Echo: ") + d.name, 0xa0c0ff);
      }
    }
  }
  return true;
}

bool itemUsable(const World& w, int slot, std::string* why) {
  auto no = [&](const char* m) {
    if (why) *why = m;
    return false;
  };
  if (slot < 0 || slot >= (int)w.pl.items.size() || w.pl.items[slot].id < 0) return no("Empty slot.");
  if (w.screen != RS_FLOOR) return no("Only usable on a floor.");
  if (w.fl.phase != PH_AIM) return no("Use items before you launch.");
  const ItemDef& d = ITEM[w.pl.items[slot].id];
  if (d.potion && w.st.noPotions) return no("You can't drink potions.");
  if (d.target == TG_MONSTER && aliveMonsterCount(w) == 0) return no("No target.");
  return true;
}

bool useItem(World& w, int slot, V2 pt, int mon) {
  ensureCapacity(w);
  if (!itemUsable(w, slot, nullptr)) return false;
  int it = w.pl.items[slot].id;
  const ItemDef& d = ITEM[it];
  if (d.target == TG_MONSTER && (mon < 0 || mon >= (int)w.fl.mons.size() || !isHostile(w, mon))) return false;
  if (!d.use || !d.use(w, pt, mon)) {
    fxSound(w, S_DENY, 0.6f);
    return false;
  }
  if (d.wand) {
    w.pl.items[slot].charges--;
    if (w.pl.items[slot].charges <= 0) {
      w.pl.items[slot] = InvItem();
      logMsg(w, d.color, "You zap the %s. It crumbles to dust.", d.name);
    } else {
      logMsg(w, d.color, "You zap the %s. (%d charge%s left)", d.name, w.pl.items[slot].charges, w.pl.items[slot].charges == 1 ? "" : "s");
    }
    w.rs.scrollsUsed++;
    return true;
  }
  w.pl.items[slot] = InvItem();
  if (d.potion) w.rs.potionsUsed++;
  else w.rs.scrollsUsed++;
  logMsg(w, d.color, d.potion ? "You drink the %s." : "You read the %s.", d.name);
  return true;
}

void learnAbility(World& w, int ab) {
  for (auto& a : w.pl.abil)
    if (a.id == ab) {
      if (a.lvl < ABIL[ab].maxLvl) a.lvl++;
      logMsg(w, SCHOOL_COLOR[ABIL[ab].school], "Your %s improves to level %d.", ABIL[ab].name, a.lvl);
      recalcStats(w);
      if (w.screen == RS_FLOOR) setupDevices(w);
      return;
    }
  OwnedAb o;
  o.id = (uint16_t)ab;
  o.lvl = 1;
  w.pl.abil.push_back(o);
  logMsg(w, SCHOOL_COLOR[ABIL[ab].school], "You learn %s!", ABIL[ab].name);
  recalcStats(w);
  if (w.screen == RS_FLOOR) setupDevices(w);
}

void gainRelic(World& w, int rl, uint32_t affixSeed) {
  if (rl < 0 || rl >= RL_COUNT || hasRelic(w, rl)) return;
  if (RELIC[rl].tier != 0) affixSeed = 0;
  w.pl.relicAffix.resize(w.pl.relics.size());
  w.pl.relics.push_back((uint16_t)rl);
  w.pl.relicAffix.push_back(makeAffixes(affixSeed, rl));
  recalcStats(w);
  int idx = (int)w.pl.relics.size() - 1;
  const char* kind = RELIC[rl].tier == 1 ? "the unique relic " : RELIC[rl].tier == 2 ? "the set relic " : "the ";
  logMsg(w, relicNameColor(w, idx), "You acquire %s%s.", kind, relicName(w, idx).c_str());
  if (RELIC[rl].tier == 1) fxBanner(w, std::string("Unique: ") + RELIC[rl].name, 0xffa838);
  if (RELIC[rl].tier == 2) {
    int n = relicSetCount(w, RELIC[rl].set);
    if (n >= 2) {
      logMsg(w, 0x5ee06a, "%s: %d of 3 pieces - set bonus active!", RELIC_SET_NAME[RELIC[rl].set], n);
      fxBanner(w, fmt("%s (%d/3)", RELIC_SET_NAME[RELIC[rl].set], n), 0x5ee06a);
    }
  }
  fxSound(w, S_CHEST, 0.9f, 1.1f);
}

bool gainItem(World& w, int it) {
  if (it < 0 || it >= IT_COUNT) return false;
  if (ITEM[it].wand) {
    for (auto& s : w.pl.items)
      if (s.id == it) {
        s.charges = (int16_t)std::min(9, s.charges + ITEM[it].charges);
        return true;
      }
  }
  for (auto& s : w.pl.items)
    if (s.id < 0) {
      s.id = (int16_t)it;
      s.charges = (int16_t)(ITEM[it].wand ? ITEM[it].charges : 0);
      return true;
    }
  return false;
}

int itemCount(const World& w) {
  int n = 0;
  for (auto& s : w.pl.items)
    if (s.id >= 0) n++;
  return n;
}

static int activeCount(const World& w) {
  int n = 0;
  for (auto& a : w.pl.abil)
    if (ABIL[a.id].timing != T_PASSIVE && !isInnate(a.id)) n++;
  return n;
}

static void statOffers(World& w) {
  w.offers.clear();
  for (int s = 0; s < STAT_COUNT; ++s) {
    Offer o;
    o.type = 4;
    o.id = s;
    w.offers.push_back(o);
  }
}

void generateOffers(World& w) {
  w.offers.clear();
  if (w.pendingLevels <= 0) {
    if (w.pl.statPoints > 0) statOffers(w);
    return;
  }
  const SpeciesDef& sp = SPECIES[w.pl.species];
  std::vector<int> ids;
  std::vector<float> wt;
  int actives = activeCount(w);
  for (int ab = 0; ab < AB_FIRST_INNATE; ++ab) {
    const AbilityDef& d = ABIL[ab];
    int lvl = abLevel(w, ab);
    if (lvl >= d.maxLvl) continue;
    if (!lvl && d.timing != T_PASSIVE && actives >= MAX_ACTIVES) continue;
    float x = d.rarity == R_COMMON ? 10.f : d.rarity == R_UNCOMMON ? 6.f : 2.5f;
    for (int k = 0; k < 3; ++k)
      if (sp.aff[k] == d.school) x *= 1.8f;
    if (lvl) x *= 1.3f;
    ids.push_back(ab);
    wt.push_back(x);
  }
  int n = w.st.offers;
  for (int k = 0; k < n && !ids.empty(); ++k) {
    int i = w.rng.weighted(wt);
    if (i < 0) break;
    Offer o;
    o.type = 0;
    o.id = ids[i];
    w.offers.push_back(o);
    ids.erase(ids.begin() + i);
    wt.erase(wt.begin() + i);
  }
  if (w.offers.empty()) {
    w.pendingLevels = 0;
    if (w.pl.statPoints > 0) statOffers(w);
  }
}

void chooseOffer(World& w, int idx) {
  if (w.offers.empty()) return;
  if (w.offers[0].type == 4) {
    int s = (idx >= 0 && idx < (int)w.offers.size()) ? w.offers[idx].id : w.rng.range(0, STAT_COUNT - 1);
    w.offers.clear();
    chooseStat(w, s);
    if (needsOffers(w)) generateOffers(w);
    return;
  }
  if (idx >= 0 && idx < (int)w.offers.size()) {
    learnAbility(w, w.offers[idx].id);
  } else {
    w.pl.bonusMaxHp += 4;
    recalcStats(w);
    w.pl.hp = std::min(w.st.maxHp, w.pl.hp + 4);
    logMsg(w, 0xd0d0d0, "You forgo new powers and toughen up instead (+4 max HP).");
  }
  w.offers.clear();
  w.pendingLevels = std::max(0, w.pendingLevels - 1);
  if (needsOffers(w)) generateOffers(w);
  fxSound(w, S_CLICK, 0.8f);
}

bool chooseRelicOffer(World& w, int idx) {
  if (w.relicOffers.empty()) return false;
  std::vector<Offer> offs = w.relicOffers;
  w.relicOffers.clear();
  if (idx >= 0 && idx < (int)offs.size()) {
    const Offer& o = offs[idx];
    switch (o.type) {
      case 1: gainRelic(w, o.id, o.seed); break;
      case 2: gainRandart(w, (uint32_t)o.id); break;
      case 3: chooseSacrifice(w, o.id); break;
      default: break;
    }
  }
  return true;
}

// ================================================================ floor setup
void floorBegin(World& w, const FloorSpec& spec) {
  w.fl = Floor();
  Floor& f = w.fl;
  f.spec = spec;
  f.rng.reseed(spec.seed);
  f.isVault = spec.kind == FK_VAULT;
  f.vaultShots = f.isVault ? 5 : 0;
  f.launchSpeed = BASE_LAUNCH;
  w.rewardItems.clear();
  w.rewardGold = w.pl.gold;
  speciesFloorStart(w);
  f.hpAtStart = w.pl.hp;
  generateBoard(w);
  ensureCapacity(w);
  setupDevices(w);
  FOR_EFF0(floorStart);
  refreshSpecials(w);
  if (hasMod(w, MOD_FORTIFIED))
    for (auto& m : f.mons) m.shield = m.hp / 4;
  if (w.descent >= 7)
    for (auto& m : f.mons) m.shield += m.hp / 10;
  if (w.descent >= 9)
    for (auto& m : f.mons)
      if (m.boss) m.cd = std::max(1, m.cd - 1);
  if (hasMod(w, MOD_BOUNTY) && !f.isVault) {
    std::vector<int> c;
    for (int i = 0; i < (int)f.mons.size(); ++i)
      if (!f.mons[i].dead && !f.mons[i].boss) c.push_back(i);
    if (!c.empty()) f.mons[c[f.rng.range(0, (int)c.size() - 1)]].bounty = true;
  }
  f.turn = 1;
  startPlayerTurn(w, false);
  const BiomeDef& b = BIOME[spec.biome];
  if (f.isVault) logMsg(w, 0xffd040, "You find a treasure vault! You have 5 shots to grab what you can.");
  else logMsg(w, b.accent, "You enter %s. (Depth %d)", b.name, w.depth);
  for (int i = 0; i < spec.nMods; ++i) logMsg(w, MODS[spec.mods[i]].color, "%s: %s", MODS[spec.mods[i]].name, MODS[spec.mods[i]].desc);
}
