// Dropcrawl - ability definitions (active spells, passive traits, patron gifts)
#include "game.h"
#include "audio.h"

AbilityDef ABIL[AB_COUNT];

#define L3(a, b, c) ((lvl) <= 1 ? (a) : (lvl) == 2 ? (b) : (c))

static AbilityDef& DEF(int id, const char* name, int school, int timing, int target, int rarity, int maxLvl,
                       std::initializer_list<int> cost, int cd, const char* desc) {
  AbilityDef& a = ABIL[id];
  a.id = (uint16_t)id;
  a.name = name;
  a.school = (uint8_t)school;
  a.timing = (uint8_t)timing;
  a.target = (uint8_t)target;
  a.rarity = (uint8_t)rarity;
  a.maxLvl = (uint8_t)maxLvl;
  int i = 0;
  for (int c : cost)
    if (i < 5) a.cost[i++] = (int8_t)c;
  for (; i < 5; ++i) a.cost[i] = i > 0 ? a.cost[i - 1] : 0;
  a.cooldown = (uint8_t)cd;
  a.goldCost = 0;
  a.desc = desc;
  a.cast = nullptr;
  a.h = Hooks();
  a.hpCost[0] = a.hpCost[1] = a.hpCost[2] = 0;
  a.innate = false;
  return a;
}

static float sqf(float x) { return x * x; }

static void zapNearest(World& w, V2 from, int dmg, uint32_t col) {
  int mi = nearestMonster(w, from);
  if (mi < 0) return;
  fxZap(w, from, w.fl.mons[mi].p, col);
  damageMonster(w, mi, dmg, DS_ZAP);
}

void initAbilities() {
  // =========================================================== FORCE
  {
    auto& a = DEF(AB_NUDGE, "Nudge", SCH_FORCE, T_FLIGHT, TG_NONE, R_COMMON, 3, {1, 1, 1}, 0,
                  "Push every ball toward the cursor (impulse [240|320|400]).");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      bool any = false;
      for (auto& b : w.fl.balls)
        if (b.alive) {
          b.v += norm(pt - b.p) * (float)L3(240, 320, 400);
          fxBurst(w, b.p, 0xa0c8ff, 6, 140);
          any = true;
        }
      if (any) fxSound(w, S_WHOOSH, 0.6f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_LEVITATE, "Levitate", SCH_FORCE, T_FLIGHT, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "Balls drift upward against gravity for [0.6|0.9|1.2] seconds.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.levitateT = std::max(w.fl.shot.levitateT, (float)L3(0.6f, 0.9f, 1.2f));
      fxSound(w, S_CAST, 0.5f, 1.3f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SLAM, "Slam", SCH_FORCE, T_FLIGHT, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "Balls gain +[3|5|7] power and plunge straight down. Each ball's next monster hit deals +[50|75|100]% damage.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      for (auto& b : w.fl.balls)
        if (b.alive) {
          b.v = V2(b.v.x * 0.15f, std::max(b.v.y, 950.f));
          b.flags |= BF_SLAM;
          b.power += L3(3, 5, 7);
        }
      fxSound(w, S_WHOOSH, 0.8f, 0.7f);
      return true;
    };
    a.h.monHit = [](World& w, HitCtx& c, int lvl) {
      Ball& b = w.fl.balls[c.ball];
      if (b.flags & BF_SLAM) {
        c.mult *= 1.f + L3(0.5f, 0.75f, 1.0f);
        b.flags &= ~BF_SLAM;
      }
    };
  }
  {
    auto& a = DEF(AB_HEAVY, "Heavy Ball", SCH_FORCE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "+[2|3|5] base power, but balls fall [10|15|20]% faster.");
    a.h.stats = [](World& w, int lvl) {
      w.st.basePower += L3(2, 3, 5);
      w.st.gravMul *= L3(1.1f, 1.15f, 1.2f);
    };
  }
  {
    auto& a = DEF(AB_FEATHER, "Featherweight", SCH_FORCE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Gravity is reduced by [15|25|35]%: more hang time, more bounces.");
    a.h.stats = [](World& w, int lvl) { w.st.gravMul *= L3(0.85f, 0.75f, 0.65f); };
  }
  {
    auto& a = DEF(AB_MOMENTUM, "Momentum", SCH_FORCE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "After hitting a monster, a ball keeps [35|55|75]% of its power instead of resetting.");
    a.h.monHit = [](World& w, HitCtx& c, int lvl) { c.keepPower = std::max(c.keepPower, L3(0.35f, 0.55f, 0.75f)); };
  }
  {
    auto& a = DEF(AB_RICOCHET, "Ricochet", SCH_FORCE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Bouncing off walls and ramps grants +[2|3|4] power.");
    a.h.wallHit = [](World& w, int bi, int lvl) { w.fl.balls[bi].power += L3(2, 3, 4); };
  }
  {
    auto& a = DEF(AB_REBOUND, "Rebound", SCH_FORCE, T_AIM, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "This shot, the first [1|2|3] time(s) a ball reaches the pockets it is bounced back up instead.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.rebounds += L3(1, 2, 3);
      fxSound(w, S_CAST, 0.5f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_KINETIC, "Kinetic Barrier", SCH_FORCE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Every ball hit dealing 10+ damage grants [1|2|3] Block. Block absorbs damage during the next enemy phase.");
    a.h.monDamaged = [](World& w, int, int, int dmg, int lvl) {
      if (dmg >= 10) addBlock(w, L3(1, 2, 3));
    };
  }
  {
    auto& a = DEF(AB_SECONDWIND, "Second Wind", SCH_FORCE, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 1,
                  "Pull your strongest ball back to the launcher, keeping its power (+[0|2|4]), and fire it again.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int best = -1;
      for (int i = 0; i < (int)w.fl.balls.size(); ++i) {
        auto& b = w.fl.balls[i];
        if (!b.alive || (b.flags & BF_PHANTOM)) continue;
        if (best < 0 || b.power > w.fl.balls[best].power) best = i;
      }
      if (best < 0) return false;
      w.fl.relaunchPower = w.fl.balls[best].power + L3(0, 2, 4);
      w.fl.balls[best].alive = false;
      fxBurst(w, w.fl.balls[best].p, 0xffffff, 14, 220);
      w.fl.phase = PH_RELAUNCH;
      fxSound(w, S_PORTAL, 0.7f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_PINBALL, "Pinball Wizard", SCH_FORCE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Flippers appear above the pockets. Press A / D (or Left / Right) to flip. [3|5|8] flips per shot; "
                  "flippers grow longer with level.");
    a.h.shotStart = [](World& w, int lvl) { w.fl.shot.flipsLeft = L3(3, 5, 8); };
  }
  {
    auto& a = DEF(AB_JUGGERNAUT, "Juggernaut", SCH_FORCE, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
                  "Balls with at least [20|15|10] power smash straight through monsters, keeping half their power.");
    a.h.monHit = [](World& w, HitCtx& c, int lvl) {
      if (c.base >= L3(20, 15, 10)) {
        c.pierce = true;
        c.keepPower = std::max(c.keepPower, 0.5f);
      }
    };
  }

  // =========================================================== FLAME
  {
    auto& a = DEF(AB_KINDLE, "Kindle", SCH_FLAME, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Ball hits apply Burn equal to [10|18|26]% of the damage (min 1). Burn deals its stacks as damage "
                  "each enemy phase, then halves.");
    a.h.monDamaged = [](World& w, int, int mi, int dmg, int lvl) {
      applyBurn(w, mi, std::max(1, (int)(dmg * L3(0.10f, 0.18f, 0.26f))));
    };
  }
  {
    auto& a = DEF(AB_FIREBALL, "Fireball", SCH_FLAME, T_AIM, TG_NONE, R_COMMON, 3, {3, 3, 3}, 0,
                  "Your next monster hit with 10+ power this shot explodes, dealing [70|90|110]% of its damage to every "
                  "other monster within 190 px. (If none qualifies, your final discharge explodes instead.)");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.fireball = true;
      w.fl.shot.fireballLvl = std::max(w.fl.shot.fireballLvl, lvl);
      fxSound(w, S_FIRE, 0.7f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_FLAMEPEGS, "Flame Pegs", SCH_FLAME, T_AIM, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "Ignite [4|6|8] random pins into Fire pegs (+2 power; the ball's next monster hit applies 4 Burn).");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int n = convertPins(w, PK_FIRE, L3(4, 6, 8));
      fxSound(w, S_FIRE, 0.7f);
      return n > 0;
    };
  }
  {
    auto& a = DEF(AB_EMBERTRAIL, "Ember Trail", SCH_FLAME, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Balls with 10+ power shed embers: passing within 40 px of a monster applies [2|3|4] Burn "
                  "(once per monster per shot).");
    a.h.tick = [](World& w, float, int lvl) {
      for (auto& b : w.fl.balls) {
        if (!b.alive || b.power < 10) continue;
        for (int mi = 0; mi < (int)w.fl.mons.size(); ++mi) {
          Monster& m = w.fl.mons[mi];
          if (m.dead || (m.shotFlags & 1) || isMonsterAlly(w, mi)) continue;
          if (dist2(b.p, m.p) < sqf(m.r + b.r + 40)) {
            m.shotFlags |= 1;
            applyBurn(w, mi, L3(2, 3, 4));
          }
        }
      }
    };
  }
  {
    auto& a = DEF(AB_COMBUSTION, "Combustion", SCH_FLAME, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Burning monsters explode when they die, dealing [3|4|5]x their Burn to monsters within 150 px.");
    a.h.kill = [](World& w, int mi, int lvl) {
      int burn = w.fl.mons[mi].burn;
      V2 p = w.fl.mons[mi].p;
      if (burn > 0) explodeAt(w, p, 150, burn * L3(3, 4, 5), -1);
    };
  }
  {
    auto& a = DEF(AB_INFERNO, "Inferno", SCH_FLAME, T_AIM, TG_NONE, R_UNCOMMON, 3, {4, 4, 4}, 2,
                  "Every burning monster immediately takes [2|3|4]x its Burn as damage.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      bool any = false;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (w.fl.mons[i].dead || w.fl.mons[i].burn <= 0 || isMonsterAlly(w, i)) continue;
        any = true;
        fxBurst(w, w.fl.mons[i].p, 0xff7020, 20, 260);
        damageMonster(w, i, w.fl.mons[i].burn * L3(2, 3, 4), DS_SPELL);
      }
      if (any) fxSound(w, S_FIRE, 1.f, 0.8f);
      return any;
    };
  }
  DEF(AB_PHOENIX, "Phoenix Feather", SCH_FLAME, T_PASSIVE, TG_NONE, R_RARE, 1, {0}, 0,
      "Once per run, when you would die you are reborn with 50% HP, and every monster gains 10 Burn.");
  {
    auto& a = DEF(AB_HEATSHIMMER, "Heat Shimmer", SCH_FLAME, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "+1 Fire peg appears each turn. Fire pegs grant +[5|7|9] extra power.");
    a.h.stats = [](World& w, int) { w.st.specials[PK_FIRE] += 1; };
    a.h.pegHit = [](World& w, int bi, int, int lvl) {
      if (w.fl.lastTrig == PK_FIRE) w.fl.balls[bi].power += L3(5, 7, 9);
    };
  }

  // =========================================================== FROST
  {
    auto& a = DEF(AB_FROSTBITE, "Frostbite", SCH_FROST, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "A ball hit dealing [25|20|15]+ damage Freezes the monster: it skips its next action. "
                  "(A monster can't be frozen two turns in a row.)");
    a.h.monDamaged = [](World& w, int, int mi, int dmg, int lvl) {
      if (dmg >= L3(25, 20, 15)) freezeMonster(w, mi);
    };
  }
  {
    auto& a = DEF(AB_ICEPEGS, "Ice Pegs", SCH_FROST, T_AIM, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "Freeze [4|6|8] random pins into Ice pegs (+3 power; the ball's next monster hit Chills it, "
                  "delaying its action by 1 turn).");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int n = convertPins(w, PK_ICE, L3(4, 6, 8));
      fxSound(w, S_FREEZE, 0.6f);
      return n > 0;
    };
  }
  {
    auto& a = DEF(AB_GLACIAL, "Glacial Armor", SCH_FROST, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "+[1|2|2] armor and +[0|0|10] max HP. Armor reduces the damage of every monster attack.");
    a.h.stats = [](World& w, int lvl) {
      w.st.armor += L3(1, 2, 2);
      w.st.maxHp += L3(0, 0, 10);
    };
  }
  {
    auto& a = DEF(AB_ICELANCE, "Ice Lance", SCH_FROST, T_AIM, TG_MONSTER, R_COMMON, 3, {2, 2, 2}, 2,
                  "Hurl an ice lance: [5|8|11] damage to a monster and Chill it (its countdown +1).");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      fxZap(w, launcherPos(), w.fl.mons[mon].p, 0x9fe8ff);
      fxSound(w, S_FREEZE, 0.8f);
      damageMonster(w, mon, L3(5, 8, 11), DS_SPELL);
      applyChill(w, mon, 1);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SHATTER, "Shatter", SCH_FROST, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Frozen or Chilled monsters take +[30|50|70]% damage from your balls.");
    a.h.monHit = [](World& w, HitCtx& c, int lvl) {
      Monster& m = w.fl.mons[c.mon];
      if (m.frozen > 0 || m.chilled > 0) c.mult *= 1.f + L3(0.3f, 0.5f, 0.7f);
    };
  }
  {
    auto& a = DEF(AB_COLDSNAP, "Cold Snap", SCH_FROST, T_AIM, TG_NONE, R_UNCOMMON, 3, {4, 4, 4}, 3,
                  "Chill every monster (countdown +1) and deal [4|8|12] damage to each.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      bool any = false;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (w.fl.mons[i].dead || isMonsterAlly(w, i)) continue;
        any = true;
        applyChill(w, i, 1);
        fxBurst(w, w.fl.mons[i].p, 0xbff0ff, 14, 200);
        damageMonster(w, i, L3(4, 8, 12), DS_SPELL);
      }
      fxSound(w, S_FREEZE, 1.f, 0.8f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_HAIL, "Hailstorm", SCH_FROST, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Call down [2|3|4] hailstones from the top of the board. They start with 3 power and never trigger "
                  "pockets.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int n = L3(2, 3, 4);
      for (int k = 0; k < n; ++k) {
        float x = PX0 + 40 + (PX1 - PX0 - 80) * (k + 0.5f) / n + w.fl.rng.rangef(-25, 25);
        spawnBall(w, V2(x, 24), V2(w.fl.rng.rangef(-60, 60), 120), 3, BF_PHANTOM | BF_FROST);
      }
      fxSound(w, S_FREEZE, 0.8f, 1.2f);
      return true;
    };
  }
  DEF(AB_PERMAFROST, "Permafrost", SCH_FROST, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
      "Special pegs have a [20|35|50]% chance not to be used up when triggered.");

  // =========================================================== STORM
  {
    auto& a = DEF(AB_STATIC, "Static", SCH_STORM, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Every [12|10|9] peg hits, a ball zaps the nearest monster for [3|5|7] damage.");
    a.h.pegHit = [](World& w, int bi, int, int lvl) {
      Ball& b = w.fl.balls[bi];
      if (++b.staticCount >= L3(12, 10, 9)) {
        b.staticCount = 0;
        V2 from = b.p;
        zapNearest(w, from, L3(3, 5, 7), 0xfff080);
        fxSound(w, S_ZAP, 0.5f, 1.2f, from.x);
      }
    };
  }
  {
    auto& a = DEF(AB_CHAIN, "Chain Lightning", SCH_STORM, T_AIM, TG_NONE, R_COMMON, 3, {3, 3, 3}, 0,
                  "Your next monster hit with 10+ power this shot arcs to [2|3|4] other monsters for 60% of its damage. (If "
                  "none qualifies, your final discharge arcs instead.)");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.chain = true;
      w.fl.shot.chainLvl = std::max(w.fl.shot.chainLvl, lvl);
      fxSound(w, S_ZAP, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SPARKPEGS, "Spark Pegs", SCH_STORM, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "[2|3|4] Spark pegs appear each turn. Hitting one zaps the nearest monster for half the ball's power.");
    a.h.stats = [](World& w, int lvl) { w.st.specials[PK_SPARK] += L3(2, 3, 4); };
  }
  {
    auto& a = DEF(AB_THUNDERCLAP, "Thunderclap", SCH_STORM, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {2, 2, 2}, 0,
                  "Each ball discharges: every monster within [140|170|200] px takes damage equal to the ball's "
                  "power. The ball's power resets.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      float rad = (float)L3(140, 170, 200);
      bool any = false;
      for (int bi = 0; bi < (int)w.fl.balls.size(); ++bi) {
        if (!w.fl.balls[bi].alive) continue;
        V2 bp = w.fl.balls[bi].p;
        int pw = w.fl.balls[bi].power;
        fxRing(w, bp, rad, 0xfff0a0);
        for (int mi = 0; mi < (int)w.fl.mons.size(); ++mi) {
          if (w.fl.mons[mi].dead || isMonsterAlly(w, mi)) continue;
          if (dist(bp, w.fl.mons[mi].p) - w.fl.mons[mi].r < rad) {
            fxZap(w, bp, w.fl.mons[mi].p, 0xfff080);
            damageMonster(w, mi, pw, DS_SPELL);
            any = true;
          }
        }
        w.fl.balls[bi].power = w.st.basePower;
      }
      fxSound(w, S_ZAP, 1.f, 0.8f);
      fxShake(w, 6);
      return any || true;
    };
  }
  {
    auto& a = DEF(AB_OVERCHARGE, "Overcharge", SCH_STORM, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "While a ball has [35|30|25]+ power, every peg it hits zaps the nearest monster for [1|2|2].");
    a.h.pegHit = [](World& w, int bi, int, int lvl) {
      Ball& b = w.fl.balls[bi];
      if (b.power >= L3(35, 30, 25)) zapNearest(w, b.p, L3(1, 2, 2), 0xd0f0ff);
    };
  }
  {
    auto& a = DEF(AB_CALLLIGHTNING, "Call Lightning", SCH_STORM, T_AIM, TG_NONE, R_UNCOMMON, 3, {4, 4, 4}, 1,
                  "Three bolts strike the monsters with the most HP for [6|9|12] damage each.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      std::vector<int> order = monstersSorted(w, true);
      if (order.empty()) return false;
      for (int k = 0; k < 3; ++k) {
        int mi = order[k % order.size()];
        if (w.fl.mons[mi].dead) continue;
        fxZap(w, V2(w.fl.mons[mi].p.x + w.fl.rng.rangef(-40, 40), 0), w.fl.mons[mi].p, 0xfff4a0);
        damageMonster(w, mi, L3(6, 9, 12), DS_SPELL);
      }
      fxSound(w, S_ZAP, 1.f, 0.7f);
      fxShake(w, 5);
      return true;
    };
  }
  {
    auto& a = DEF(AB_MAGNETISM, "Magnetism", SCH_STORM, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Balls with 10+ power are pulled toward the nearest monster (strength [120|200|280]).");
    a.h.tick = [](World& w, float dt, int lvl) {
      for (auto& b : w.fl.balls) {
        if (!b.alive || b.power < 10) continue;
        int mi = nearestMonster(w, b.p);
        if (mi < 0) continue;
        b.v += norm(w.fl.mons[mi].p - b.p) * (float)L3(120, 200, 280) * dt;
      }
    };
  }
  {
    auto& a = DEF(AB_CAPACITOR, "Capacitor", SCH_STORM, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Half the leftover power of balls leaving the board is stored for your next shot (up to [6|10|15]).");
    a.h.ballEnd = [](World& w, int bi, int, int lvl) {
      Ball& b = w.fl.balls[bi];
      if (b.flags & BF_PHANTOM) return;
      int cap = L3(6, 10, 15);
      int add = std::max(0, b.power - w.st.basePower) / 2;
      if (w.pl.nextShotPower < cap) w.pl.nextShotPower = std::min(cap, w.pl.nextShotPower + add);
    };
  }

  // =========================================================== EARTH
  {
    auto& a = DEF(AB_STONESKIN, "Stoneskin", SCH_EARTH, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "+[8|16|24] max HP.");
    a.h.stats = [](World& w, int lvl) { w.st.maxHp += L3(8, 16, 24); };
  }
  {
    auto& a = DEF(AB_BOULDER, "Boulder", SCH_EARTH, T_AIM, TG_NONE, R_COMMON, 3, {3, 3, 3}, 0,
                  "Your next ball is a boulder: much bigger, heavier and less bouncy, with +[5|8|12] power.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.boulder) return false;
      w.fl.shot.boulder = true;
      w.fl.shot.mightBonus += L3(5, 8, 12);
      fxSound(w, S_BLOCK, 0.6f, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_RAISEEARTH, "Raise Earth", SCH_EARTH, T_AIM, TG_POINT, R_COMMON, 3, {2, 2, 2}, 0,
                  "Raise [7|9|12] new pins around a chosen spot. They last for the rest of the floor.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int before = (int)w.fl.pegs.size();
      growPins(w, L3(7, 9, 12), pt, 80, true);
      fxSound(w, S_BLOCK, 0.7f, 0.5f, pt.x);
      fxRing(w, pt, 80, 0xc8a070);
      return (int)w.fl.pegs.size() > before;
    };
  }
  {
    auto& a = DEF(AB_QUAKE, "Quake", SCH_EARTH, T_AIM, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "The board shudders: pins shift slightly, every monster loses its Block and takes [3|5|7] damage.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      for (auto& p : w.fl.pegs) {
        if (p.dead || p.kind == PK_BUMPER || p.motion) continue;
        V2 np = p.p + V2(w.fl.rng.rangef(-8, 8), w.fl.rng.rangef(-8, 8));
        if (np.x > PX0 + 14 && np.x < PX1 - 14 && np.y > FIELD_Y0 - 10 && np.y < FIELD_Y1 + 10) {
          p.p = np;
          p.anchor = np;
        }
      }
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (w.fl.mons[i].dead || isMonsterAlly(w, i)) continue;
        w.fl.mons[i].shield = 0;
        damageMonster(w, i, L3(3, 5, 7), DS_SPELL);
      }
      fxShake(w, 14);
      fxSound(w, S_BOOM, 0.8f, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_CRYSTAL, "Crystal Growth", SCH_EARTH, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "[2|3|4] Crystal pegs (+4 power each) appear each turn.");
    a.h.stats = [](World& w, int lvl) { w.st.specials[PK_CRYSTAL] += L3(2, 3, 4); };
  }
  {
    auto& a = DEF(AB_AFTERSHOCK, "Aftershock", SCH_EARTH, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "When a single ball hit deals 30+ damage, every other monster takes [5|8|12] damage.");
    a.h.monDamaged = [](World& w, int, int mi, int dmg, int lvl) {
      if (dmg < 30) return;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (i == mi || w.fl.mons[i].dead || isMonsterAlly(w, i)) continue;
        fxBurst(w, w.fl.mons[i].p, 0xc8a070, 10, 160);
        damageMonster(w, i, L3(5, 8, 12), DS_SPELL);
      }
      fxShake(w, 8);
    };
  }
  {
    auto& a = DEF(AB_GOLEM, "Stone Golem", SCH_EARTH, T_PASSIVE, TG_NONE, R_RARE, 3, {0}, 0,
                  "A stone golem stands on every floor. Each ball hit on it grants +[5|7|9] power.");
    a.h.floorStart = [](World& w, int lvl) {
      for (int tries = 0; tries < 200; ++tries) {
        V2 p(w.fl.rng.rangef(PX0 + 80, PX1 - 80), w.fl.rng.rangef(FIELD_Y0 + 60, FIELD_Y0 + 300));
        if (spotFree(w, p, 18, 10)) {
          int pi = addPeg(w, PK_GOLEM, p, 18);
          if (pi >= 0) w.fl.pegs[pi].val = L3(5, 7, 9);
          return;
        }
      }
    };
  }
  {
    auto& a = DEF(AB_PILLAR, "Stone Pillar", SCH_EARTH, T_AIM, TG_POINT, R_COMMON, 3, {1, 1, 1}, 0,
                  "Raise a stone pillar at a chosen spot: +[2|3|4] power per hit, crumbles after [4|5|6] hits.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      if (!spotFree(w, pt, 13, 6)) return false;
      int pi = addPeg(w, PK_PILLAR, pt, 13);
      if (pi < 0) return false;
      w.fl.pegs[pi].val = L3(2, 3, 4);
      w.fl.pegs[pi].hp = L3(4, 5, 6);
      fxSound(w, S_BLOCK, 0.7f, 0.5f, pt.x);
      return true;
    };
  }

  // =========================================================== ARCANE
  {
    auto& a = DEF(AB_MISSILE, "Magic Missile", SCH_ARCANE, T_AIM, TG_MONSTER, R_COMMON, 3, {1, 1, 1}, 0,
                  "Deal [4|6|8] damage to a monster. Never misses.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      fxZap(w, launcherPos(), w.fl.mons[mon].p, 0xc080ff);
      fxSound(w, S_CAST, 0.6f, 1.4f);
      damageMonster(w, mon, L3(4, 6, 8), DS_SPELL);
      return true;
    };
  }
  {
    auto& a = DEF(AB_BLINK, "Blink", SCH_ARCANE, T_FLIGHT, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "Teleport your lowest ball toward the cursor (up to [200|260|320] px). It keeps its speed.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int best = -1;
      for (int i = 0; i < (int)w.fl.balls.size(); ++i)
        if (w.fl.balls[i].alive && (best < 0 || w.fl.balls[i].p.y > w.fl.balls[best].p.y)) best = i;
      if (best < 0) return false;
      Ball& b = w.fl.balls[best];
      V2 d = pt - b.p;
      float maxD = (float)L3(200, 260, 320);
      if (len(d) > maxD) d = norm(d) * maxD;
      V2 np = b.p + d;
      np.x = clampv(np.x, PX0 + b.r + 2, PX1 - b.r - 2);
      np.y = clampv(np.y, CEIL_Y + b.r + 2, POCKET_TOP - 30);
      // never into solid rock: come back toward the ball until clear of it
      for (int k = 0; k < 40 && inRock(w, np, b.r); ++k) np = np + norm(b.p - np) * std::min(12.f, dist(b.p, np));
      fxBurst(w, b.p, 0xc080ff, 12, 180);
      b.p = np;
      fxBurst(w, np, 0xc080ff, 12, 180);
      fxSound(w, S_PORTAL, 0.6f, 1.5f, np.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_WORMHOLE, "Wormhole", SCH_ARCANE, T_AIM, TG_TWO_POINTS, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Open a one-way portal: balls entering the first point exit at the second. Lasts [2|3|4] turns.");
    a.cast = [](World& w, int lvl, V2 a1, V2 a2, int) {
      if (dist(a1, a2) < 60) return false;
      placeWormhole(w, a1, a2, L3(2, 3, 4));
      fxSound(w, S_PORTAL, 0.8f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_ECHO, "Arcane Echo", SCH_ARCANE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "The first [1|2|3] special peg(s) you hit each shot trigger twice.");
    a.h.shotStart = [](World& w, int lvl) { w.fl.shot.echoLeft += L3(1, 2, 3); };
  }
  {
    auto& a = DEF(AB_MANAFONT, "Mana Font", SCH_ARCANE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "+[2|4|6] max MP and +1 MP regeneration per turn.");
    a.h.stats = [](World& w, int lvl) {
      w.st.maxMp += L3(2, 4, 6);
      w.st.mpRegen += 1;
    };
  }
  {
    auto& a = DEF(AB_STASIS, "Stasis", SCH_ARCANE, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {2, 2, 1}, 0,
                  "Freeze your balls in time, then choose a new direction to send them flying (+[0|2|4] power each).");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      bool any = false;
      for (auto& b : w.fl.balls) any |= b.alive;
      if (!any) return false;
      w.fl.relaunchPower = L3(0, 2, 4);
      w.fl.phase = PH_REDIRECT;
      fxSound(w, S_FREEZE, 0.6f, 1.5f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_DUPLICATE, "Duplicate", SCH_ARCANE, T_FLIGHT, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Every ball splits in two. Copies carry [50|75|100]% of the original's power.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      int n = (int)w.fl.balls.size();
      bool any = false;
      for (int i = 0; i < n; ++i)
        if (w.fl.balls[i].alive) {
          splitBall(w, i, L3(0.5f, 0.75f, 1.0f));
          any = true;
        }
      if (any) fxSound(w, S_CAST, 0.8f, 1.2f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_SCRYING, "Scrying", SCH_ARCANE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Your aiming guide shows [1|2|3] more bounce(s).");
    a.h.stats = [](World& w, int lvl) { w.st.preview += L3(1, 2, 3); };
  }
  DEF(AB_SPELLWEAVE, "Spellweave", SCH_ARCANE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
      "Casting a spell charges your balls with +[2|3|4] power per MP spent.");
  {
    auto& a = DEF(AB_DISPEL, "Dispel", SCH_ARCANE, T_AIM, TG_NONE, R_COMMON, 3, {2, 2, 2}, 0,
                  "Strip every monster's Block and buffs, and cleanse all Curse pegs. At level 3 also restores "
                  "cursed pockets.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      for (auto& m : w.fl.mons) {
        if (m.dead) continue;
        m.shield = 0;
        m.atkBonus = std::min(m.atkBonus, 0);
      }
      cleanseCurses(w, lvl >= 3);
      fxSound(w, S_CAST, 0.8f, 0.9f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_TIMEWARP, "Time Warp", SCH_ARCANE, T_FLIGHT, TG_NONE, R_COMMON, 3, {1, 1, 1}, 0,
                  "Time slows to a crawl for [3|4|5] seconds, giving you time to nudge, blink and flip.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      w.fl.shot.slowT = (float)L3(3, 4, 5);
      fxSound(w, S_PORTAL, 0.6f, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_HASTE, "Haste", SCH_ARCANE, T_AIM, TG_NONE, R_RARE, 3, {6, 5, 4}, 4,
                  "Your next shot is a free turn: monsters do not act after it.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.pendingFree) return false;
      w.fl.pendingFree = true;
      fxSound(w, S_CAST, 0.8f, 1.6f);
      return true;
    };
  }

  // =========================================================== LIFE
  {
    auto& a = DEF(AB_REGEN, "Regeneration", SCH_LIFE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Regenerate [1|2|3] HP at the start of each turn.");
    a.h.stats = [](World& w, int lvl) { w.st.hpRegen += L3(1, 2, 3); };
  }
  {
    auto& a = DEF(AB_HEALWOUNDS, "Heal Wounds", SCH_LIFE, T_AIM, TG_NONE, R_COMMON, 3, {3, 3, 3}, 2,
                  "Heal [7|11|15] HP.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.pl.hp >= w.st.maxHp) return false;
      healPlayer(w, L3(7, 11, 15));
      fxSound(w, S_HEAL, 0.8f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_VAMPIRIC, "Vampiric Ball", SCH_LIFE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Heal 1 HP for every [15|12|9] damage your balls deal.");
    a.h.monDamaged = [](World& w, int, int, int dmg, int lvl) {
      w.fl.vampAcc += dmg;
      int per = L3(15, 12, 9);
      int heal = 0;
      while (w.fl.vampAcc >= per) {
        w.fl.vampAcc -= per;
        heal++;
      }
      if (heal > 0) healPlayer(w, heal);
    };
  }
  {
    auto& a = DEF(AB_OVERGROWTH, "Overgrowth", SCH_LIFE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "[3|4|5] new pins sprout in open spaces at the start of each turn.");
    a.h.turnStart = [](World& w, int lvl) { growPins(w, L3(3, 4, 5), V2(-1, -1), 0, false); };
  }
  {
    auto& a = DEF(AB_HEALPEGS, "Healing Pegs", SCH_LIFE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "[1|2|3] extra Heal peg(s) appear each turn.");
    a.h.stats = [](World& w, int lvl) { w.st.specials[PK_HEAL] += L3(1, 2, 3); };
  }
  {
    auto& a = DEF(AB_BLOOM, "Bloom", SCH_LIFE, T_AIM, TG_POINT, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Every pin within [90|110|130] px of a chosen spot blossoms into a Life peg (+2 power, heal 1).");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int n = convertPins(w, PK_LIFE, 999, pt, (float)L3(90, 110, 130));
      fxRing(w, pt, (float)L3(90, 110, 130), 0x70ff90);
      fxSound(w, S_HEAL, 0.7f, 1.2f, pt.x);
      return n > 0;
    };
  }
  {
    auto& a = DEF(AB_THORNS, "Thornshield", SCH_LIFE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Monsters that attack you take [2|4|6] damage.");
    a.h.attacked = [](World& w, int mi, int&, int lvl) {
      if (mi >= 0 && !w.fl.mons[mi].dead) damageMonster(w, mi, L3(2, 4, 6), DS_THORNS);
    };
  }
  {
    auto& a = DEF(AB_VITALITY, "Vitality", SCH_LIFE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "All healing you receive is increased by [50|100|150]%.");
    a.h.stats = [](World& w, int lvl) { w.st.healMul += L3(0.5f, 1.0f, 1.5f); };
  }

  // =========================================================== FORTUNE
  {
    auto& a = DEF(AB_MIDAS, "Midas Touch", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "+1 Gold peg each turn. Gold pegs grant +[4|6|8] power.");
    a.h.stats = [](World& w, int) { w.st.specials[PK_GOLD] += 1; };
    a.h.pegHit = [](World& w, int bi, int, int lvl) {
      if (w.fl.lastTrig == PK_GOLD) w.fl.balls[bi].power += L3(4, 6, 8);
    };
  }
  {
    auto& a = DEF(AB_RHYTHM, "Rhythm", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "Every [4th|3rd|2nd] monster hit is a critical hit that deals double damage.");
    a.h.monHit = [](World& w, HitCtx& c, int lvl) {
      w.pl.rhythm++;
      if (w.pl.rhythm % L3(4, 3, 2) == 0) {
        c.mult *= 2.f;
        c.crit = true;
      }
    };
  }
  {
    auto& a = DEF(AB_CRITPEGS, "Crit Pegs", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "[1|2|3] extra Crit peg(s) appear each turn.");
    a.h.stats = [](World& w, int lvl) { w.st.specials[PK_CRIT] += L3(1, 2, 3); };
  }
  {
    auto& a = DEF(AB_JACKPOT, "Jackpot", SCH_FORTUNE, T_AIM, TG_NONE, R_UNCOMMON, 3, {4, 4, 4}, 0,
                  "This shot, pocket effects are multiplied x[2|3|4].");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.jackpotMul >= L3(2, 3, 4)) return false;
      w.fl.shot.jackpotMul = L3(2, 3, 4);
      fxSound(w, S_COIN, 0.8f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_INTEREST, "Interest", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "After each floor, gain [10|15|20]% of your gold as interest (max [25|40|60]).");
    a.h.floorEnd = [](World& w, int lvl) {
      int g = std::min((int)(w.pl.gold * L3(0.10f, 0.15f, 0.20f)), L3(25, 40, 60));
      if (g > 0) {
        w.pl.gold += g;
        logMsg(w, 0xffd860, "Your savings earn %d gold in interest.", g);
      }
    };
  }
  {
    auto& a = DEF(AB_BOUNTY, "Bounty Hunter", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Each kill grants +[3|5|7] gold.");
    a.h.stats = [](World& w, int lvl) { w.st.killGold += L3(3, 5, 7); };
  }
  {
    auto& a = DEF(AB_BRIBE, "Bribe", SCH_FORTUNE, T_AIM, TG_MONSTER, R_COMMON, 3, {0, 0, 0}, 0,
                  "Pay [12|10|8] gold (+1 per depth) to delay a monster's action by [1|1|2] turn(s).");
    a.goldCost = 12;
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0 || w.fl.mons[mon].boss) return false;
      w.fl.mons[mon].cd += L3(1, 1, 2);
      fxText(w, w.fl.mons[mon].p + V2(0, -30), 0xffd860, "Bribed!", 16);
      fxSound(w, S_COIN, 0.8f, 0.8f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_COINTOSS, "Coin Toss", SCH_FORTUNE, T_FLIGHT, TG_NONE, R_COMMON, 3, {0, 0, 0}, 0,
                  "Spend 5 gold (+1 per 2 depth): every ball gains +[8|12|16] power.");
    a.goldCost = 5;
    a.cast = [](World& w, int lvl, V2, V2, int) {
      bool any = false;
      for (auto& b : w.fl.balls)
        if (b.alive) {
          b.power += L3(8, 12, 16);
          fxBurst(w, b.p, 0xffd860, 10, 160);
          any = true;
        }
      if (any) fxSound(w, S_COIN, 0.9f, 1.2f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_DOUBLEDOWN, "Double Down", SCH_FORTUNE, T_AIM, TG_NONE, R_COMMON, 3, {1, 1, 1}, 0,
                  "This shot deals double damage, but if no monster is hit you take [4|3|2] damage.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.shot.doubleDown) return false;
      w.fl.shot.doubleDown = true;
      w.fl.shot.ddPenalty = L3(4, 3, 2);
      fxSound(w, S_COIN, 0.7f, 0.7f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_TREASURE, "Treasure Sense", SCH_FORTUNE, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "[1|2|3] treasure chest(s) appear on each floor. Break them open for gold and items.");
    a.h.floorStart = [](World& w, int lvl) {
      int n = L3(1, 2, 3);
      for (int k = 0; k < n; ++k) {
        for (int tries = 0; tries < 200; ++tries) {
          V2 p(w.fl.rng.rangef(PX0 + 60, PX1 - 60), w.fl.rng.rangef(FIELD_Y0 + 80, FIELD_Y1 - 40));
          if (spotFree(w, p, 15, 8)) {
            int pi = addPeg(w, PK_CHEST, p, 15);
            if (pi >= 0) w.fl.pegs[pi].hp = 3;
            break;
          }
        }
      }
    };
  }

  // =========================================================== SHADOW
  {
    auto& a = DEF(AB_VENOM, "Venom", SCH_SHADOW, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Ball hits apply Poison equal to [15|25|35]% of the damage (min 1). Poison deals its stacks each "
                  "enemy phase, then drops by 1.");
    a.h.monDamaged = [](World& w, int, int mi, int dmg, int lvl) {
      applyPoison(w, mi, std::max(1, (int)(dmg * L3(0.15f, 0.25f, 0.35f))));
    };
  }
  {
    auto& a = DEF(AB_PLAGUE, "Plague", SCH_SHADOW, T_AIM, TG_NONE, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Multiply every monster's Poison by [2|2.5|3]. Unpoisoned monsters gain [2|3|4] Poison.");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      bool any = false;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        Monster& m = w.fl.mons[i];
        if (m.dead || isMonsterAlly(w, i)) continue;
        any = true;
        if (m.poison > 0) m.poison = (int)std::ceil(m.poison * L3(2.f, 2.5f, 3.f));
        else m.poison = L3(2, 3, 4);
        fxBurst(w, m.p, 0x90ff50, 14, 150);
      }
      if (any) fxSound(w, S_POISON, 0.9f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_SIPHON, "Soul Siphon", SCH_SHADOW, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Each kill restores [1|2|3] MP.");
    a.h.stats = [](World& w, int lvl) { w.st.killMp += L3(1, 2, 3); };
  }
  {
    auto& a = DEF(AB_BONEHARVEST, "Bone Harvest", SCH_SHADOW, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Slain monsters leave bone bumpers behind that grant +[4|6|8] power per hit.");
    a.h.kill = [](World& w, int mi, int lvl) {
      Monster& m = w.fl.mons[mi];
      if (m.boss) return;
      float r = clampv(m.r * 0.55f, 10.f, 16.f);
      V2 p = m.p;
      int cl = m.clearing;
      int pi = addPeg(w, PK_BONE, p, r);
      if (pi >= 0) {
        w.fl.pegs[pi].val = L3(4, 6, 8);
        if (cl >= 0 && cl < (int)w.fl.clearings.size()) w.fl.clearings[cl].mon = -2;  // occupied by bones
      }
    };
  }
  {
    auto& a = DEF(AB_HEX, "Hex", SCH_SHADOW, T_AIM, TG_MONSTER, R_COMMON, 3, {2, 2, 2}, 0,
                  "Hex a monster: it takes +[40|60|80]% damage for 2 turns.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      Monster& m = w.fl.mons[mon];
      m.hexT = 2;
      m.hexPct = std::max(m.hexPct, L3(40, 60, 80));
      fxBurst(w, m.p, 0xb050ff, 18, 170);
      fxSound(w, S_CAST, 0.7f, 0.6f, m.p.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_DRAIN, "Drain Life", SCH_SHADOW, T_AIM, TG_MONSTER, R_COMMON, 3, {3, 3, 3}, 0,
                  "Deal [4|6|9] damage to a monster and heal that much.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      fxZap(w, w.fl.mons[mon].p, V2(190, 110), 0xff4060);
      int d = damageMonster(w, mon, L3(4, 6, 9), DS_SPELL);
      if (d > 0) healPlayer(w, d);
      fxSound(w, S_CAST, 0.7f, 0.5f);
      return true;
    };
  }
  DEF(AB_CURSEEATER, "Curse Eater", SCH_SHADOW, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
      "Curse pegs no longer halve your ball's power; they grant +[4|6|8] power instead.");
  {
    auto& a = DEF(AB_DEATHMARK, "Death Mark", SCH_SHADOW, T_AIM, TG_MONSTER, R_COMMON, 3, {1, 1, 1}, 2,
                  "Mark a monster. If it dies this turn, you gain 50% more XP and [10|20|30] gold.");
    a.cast = [](World& w, int lvl, V2, V2, int mon) {
      if (mon < 0) return false;
      w.fl.mons[mon].markT = 1;
      w.fl.mons[mon].markGold = L3(10, 20, 30);
      fxSound(w, S_CAST, 0.6f, 0.5f, w.fl.mons[mon].p.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_RAISEDEAD, "Raise Dead", SCH_SHADOW, T_AIM, TG_NONE, R_RARE, 3, {5, 5, 5}, 3,
                  "Raise the last monster slain on this floor as a wraith for [2|3|4] turns. At the end of each enemy "
                  "phase it strikes the weakest monster for [4|6|8] (+1 per 3 depth).");
    a.cast = [](World& w, int lvl, V2, V2, int) {
      if (w.fl.lastKillDef < 0) return false;
      w.fl.raisedAllyT = L3(2, 3, 4);
      w.fl.raisedAllyDmg = L3(4, 6, 8) + w.depth / 3;
      fxBurst(w, w.fl.lastKillPos, 0xc0a0ff, 24, 200);
      fxSound(w, S_SPAWN, 0.8f, 0.7f);
      logMsg(w, 0xc0a0ff, "The %s rises to serve you!", MON[w.fl.lastKillDef].name);
      return true;
    };
  }
  {
    auto& a = DEF(AB_NIGHTSHADE, "Nightshade", SCH_SHADOW, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "[1|2|3] Poison peg(s) appear each turn (+2 power; your next monster hit applies 5 Poison).");
    a.h.stats = [](World& w, int lvl) { w.st.specials[PK_POISON] += L3(1, 2, 3); };
  }

  // =========================================================== CLOCKWORK
  {
    auto& a = DEF(AB_BUMPERKIT, "Bumper Kit", SCH_CLOCKWORK, T_AIM, TG_POINT, R_COMMON, 3, {2, 2, 2}, 0,
                  "Place a bumper at a chosen spot for [3|4|5] turns. Bumpers kick balls hard and grant +2 power.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      if (!spotFree(w, pt, 16, 4)) return false;
      int pi = addPeg(w, PK_BUMPER, pt, 16);
      if (pi < 0) return false;
      w.fl.pegs[pi].ttl = L3(3, 4, 5);
      w.fl.pegs[pi].temp = true;
      fxSound(w, S_BUMP, 0.8f, 1.f, pt.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_SPINNER, "Spinner", SCH_CLOCKWORK, T_AIM, TG_POINT, R_COMMON, 3, {2, 2, 2}, 0,
                  "Install a spinning bar at a chosen spot for [3|4|5] turns. Spinners fling balls and grant +1 power.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      if (!spotFree(w, pt, 30, 0)) return false;
      int si = addSeg(w, SK_SPINNER, pt, pt, 5);
      if (si < 0) return false;
      Seg& s = w.fl.segs[si];
      s.c = pt;
      s.len = 46;
      s.angVel = 4.f;
      s.ttl = L3(3, 4, 5);
      s.rest = 0.8f;
      fxSound(w, S_FLIP, 0.8f, 0.8f, pt.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_TURRET, "Turret", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "After each shot your turret fires at the weakest monster, dealing 1 damage per [6|5|4] pegs hit "
                  "that shot.");
    a.h.shotEnd = [](World& w, int lvl) {
      int d = w.fl.shot.pegHits / L3(6, 5, 4);
      if (d <= 0) return;
      int mi = lowestHpMonster(w);
      if (mi < 0) return;
      fxZap(w, V2(PX0 + 14, POCKET_TOP - 10), w.fl.mons[mi].p, 0xffc860);
      fxSound(w, S_ZAP, 0.5f, 1.5f);
      damageMonster(w, mi, d, DS_ALLY);
    };
  }
  {
    auto& a = DEF(AB_TWIN, "Twin Launcher", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_RARE, 2, {0}, 0,
                  "Each shot launches [1|2] extra echo ball(s) alongside your own. Echo balls start with 1 power, deal half "
                  "damage, never trigger pockets and never discharge.");
    a.h.stats = [](World& w, int lvl) { w.st.extraBalls += lvl; };
  }
  {
    auto& a = DEF(AB_CATCHER, "Catcher", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_UNCOMMON, 3, {0}, 0,
                  "A catcher bucket patrols above the pockets. Caught balls return to the top with +[2|4|6] power "
                  "([1|2|3] catch(es) per shot).");
    a.h.shotStart = [](World& w, int lvl) { w.fl.shot.catchesLeft = L3(1, 2, 3); };
  }
  DEF(AB_OVERCLOCK, "Overclock", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
      "Bumpers, mushrooms and spinners grant +[2|3|4] extra power.");
  {
    auto& a = DEF(AB_GYRO, "Gyroscope", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Balls bounce [4|7|10]% livelier, hitting more pegs on the way down.");
    a.h.stats = [](World& w, int lvl) { w.st.restBonus += L3(0.04f, 0.07f, 0.10f); };
  }
  {
    auto& a = DEF(AB_DEMOLITION, "Demolition", SCH_CLOCKWORK, T_AIM, TG_POINT, R_UNCOMMON, 3, {3, 3, 3}, 0,
                  "Plant [2|3|4] bombs near a chosen spot. A ball hit detonates one for [10|14|18] damage (+1 per "
                  "depth) to nearby monsters.");
    a.cast = [](World& w, int lvl, V2 pt, V2, int) {
      int n = L3(2, 3, 4), placed = 0;
      for (int tries = 0; tries < 120 && placed < n; ++tries) {
        V2 p = pt + fromAng(w.fl.rng.rangef(0, TAU)) * w.fl.rng.rangef(0, 70);
        if (p.x < PX0 + 16 || p.x > PX1 - 16 || p.y < FIELD_Y0 || p.y > FIELD_Y1) continue;
        if (!spotFree(w, p, 9, 10)) continue;
        int pi = addPeg(w, PK_BOMB, p, 9);
        if (pi < 0) break;
        w.fl.pegs[pi].val = L3(10, 14, 18) + w.depth;
        w.fl.pegs[pi].temp = true;
        placed++;
      }
      if (placed) fxSound(w, S_TICK, 0.9f, 0.8f, pt.x);
      return placed > 0;
    };
  }
  {
    auto& a = DEF(AB_ROTOR, "Rotor", SCH_CLOCKWORK, T_AIM, TG_NONE, R_COMMON, 3, {1, 1, 0}, 0,
                  "Rotate the pockets one slot toward the side the cursor is on. Free at level 3.");
    a.cast = [](World& w, int, V2 pt, V2, int) {
      rotatePockets(w, pt.x < LAUNCH_X ? -1 : 1);
      fxSound(w, S_FLIP, 0.8f, 0.7f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_LAUNCHER, "Precision Launcher", SCH_CLOCKWORK, T_PASSIVE, TG_NONE, R_COMMON, 3, {0}, 0,
                  "Use the mouse wheel to set launch strength. +[1|2|3] base power.");
    a.h.stats = [](World& w, int lvl) {
      w.st.adjustLaunch = true;
      w.st.basePower += L3(1, 2, 3);
    };
  }

  // =========================================================== DIVINE (patron gifts)
  // Vrask the Unbroken
  {
    auto& a = DEF(AB_P_BERSERK, "Berserk", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {12}, 0,
                  "Fly into a rage: this shot deals double damage and starts with +3 power.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.berserk) return false;
      w.fl.shot.berserk = true;
      w.fl.shot.mightBonus += 3;
      fxSound(w, S_GROWL, 1.f, 1.3f);
      fxShake(w, 6);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_IRONHIDE, "Iron Hide", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0, "+2 armor.");
    a.h.stats = [](World& w, int) { w.st.armor += 2; };
  }
  {
    auto& a = DEF(AB_P_TROPHY, "Trophy Hunter", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0, "Kills heal 4 HP.");
    a.h.stats = [](World& w, int) { w.st.killHeal += 4; };
  }
  {
    auto& a = DEF(AB_P_WRATH, "Wrath of Vrask", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {50}, 0,
                  "Deal 30 damage (+2 per depth) to every monster.");
    a.cast = [](World& w, int, V2, V2, int) {
      int d = 30 + 2 * w.depth;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
        if (w.fl.mons[i].dead || isMonsterAlly(w, i)) continue;
        fxBurst(w, w.fl.mons[i].p, 0xff5030, 24, 260);
        damageMonster(w, i, d, DS_SPELL);
      }
      fxShake(w, 18);
      fxSound(w, S_BOOM, 1.f, 0.7f);
      return true;
    };
  }
  // Aurum the Gilded
  {
    auto& a = DEF(AB_P_TOLL, "Pay the Toll", SCH_DIVINE, T_AIM, TG_MONSTER, R_COMMON, 1, {0}, 0,
                  "Pay 15 gold (+1 per depth): the target takes 25 damage (+2 per depth).");
    a.goldCost = 15;
    a.cast = [](World& w, int, V2, V2, int mon) {
      if (mon < 0) return false;
      fxZap(w, V2(190, 60), w.fl.mons[mon].p, 0xffd860);
      damageMonster(w, mon, 25 + 2 * w.depth, DS_SPELL);
      fxSound(w, S_COIN, 1.f, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_GILDED, "Gilded Halls", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
                  "+2 Gold pegs each turn. Shops are 15% cheaper.");
    a.h.stats = [](World& w, int) {
      w.st.specials[PK_GOLD] += 2;
      w.st.shopMul *= 0.85f;
    };
  }
  {
    auto& a = DEF(AB_P_GOLDTOUCH, "Golden Touch", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {0}, 0,
                  "Pay 40 gold: this shot, every peg hit grants +1 gold and +1 extra power.");
    a.goldCost = 40;
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.goldTouch) return false;
      w.fl.shot.goldTouch = true;
      fxSound(w, S_COIN, 1.f, 1.3f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_BUYOUT, "Buyout", SCH_DIVINE, T_AIM, TG_MONSTER, R_COMMON, 1, {0}, 0,
                  "Pay 120 gold: a non-boss monster leaves the fight at once (you still gain its XP).");
    a.goldCost = 120;
    a.cast = [](World& w, int, V2, V2, int mon) {
      if (mon < 0 || w.fl.mons[mon].boss) return false;
      fxBurst(w, w.fl.mons[mon].p, 0xffd860, 30, 240);
      killMonster(w, mon, DS_SPELL);
      fxSound(w, S_BUY, 1.f);
      return true;
    };
  }
  // The Tumbler
  {
    auto& a = DEF(AB_P_LUCKY, "Tumbler's Luck", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
                  "Level-ups offer 1 more choice.");
    a.h.stats = [](World& w, int) { w.st.offers += 1; };
  }
  DEF(AB_P_GIFTS, "Tumbling Gifts", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
      "The Tumbler meddles more often (30% of turns), and its meddling is kinder.");
  {
    auto& a = DEF(AB_P_DICE, "Roll the Dice", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {30}, 0,
                  "Roll the Tumbler's dice: it meddles on your behalf, usually kindly. Anything can happen.");
    a.cast = [](World& w, int, V2, V2, int) {
      tumblerAct(w, true);
      return true;
    };
  }
  DEF(AB_P_FAVOR, "Fortune Favors", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
      "Once per floor, a blow that would kill you leaves you at 1 HP instead.");
  // Verdana, the Green Mother
  {
    auto& a = DEF(AB_P_SPROUT, "Sprout", SCH_DIVINE, T_AIM, TG_POINT, R_COMMON, 1, {10}, 0,
                  "Grow 12 pins around a chosen spot.");
    a.cast = [](World& w, int, V2 pt, V2, int) {
      growPins(w, 12, pt, 95, true);
      fxRing(w, pt, 95, 0x70ff90);
      fxSound(w, S_HEAL, 0.6f, 0.8f, pt.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_GREEN, "Green Blessing", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
                  "+2 Heal pegs each turn and +1 HP regeneration.");
    a.h.stats = [](World& w, int) {
      w.st.specials[PK_HEAL] += 2;
      w.st.hpRegen += 1;
    };
  }
  {
    auto& a = DEF(AB_P_BRAMBLE, "Bramble Cage", SCH_DIVINE, T_AIM, TG_MONSTER, R_COMMON, 1, {25}, 0,
                  "Entangle a monster: it skips its next action and is ringed by thorn bumpers (+3 power each).");
    a.cast = [](World& w, int, V2, V2, int mon) {
      if (mon < 0) return false;
      Monster& m = w.fl.mons[mon];
      m.frozen = std::max(m.frozen, 1);
      V2 c = m.p;
      float r = m.r;
      for (int k = 0; k < 7; ++k) {
        V2 p = c + fromAng(k * TAU / 7 + 0.3f) * (r + 22);
        if (p.x > PX0 + 10 && p.x < PX1 - 10 && spotFree(w, p, 7, 2)) {
          int pi = addPeg(w, PK_THORN, p, 7);
          (void)pi;
        }
      }
      fxSound(w, S_HEAL, 0.8f, 0.6f, c.x);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_WORLDTREE, "World Tree", SCH_DIVINE, T_AIM, TG_POINT, R_COMMON, 1, {60}, 0,
                  "Plant a great tree for the rest of the floor: each ball hit grants +8 power and heals 1 HP.");
    a.cast = [](World& w, int, V2 pt, V2, int) {
      if (!spotFree(w, pt, 24, 4)) return false;
      addPeg(w, PK_TREE, pt, 24);
      fxRing(w, pt, 60, 0x70ff90);
      fxSound(w, S_HEAL, 1.f, 0.5f, pt.x);
      return true;
    };
  }
  // Old Tock
  {
    auto& a = DEF(AB_P_STALL, "Stall", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {15}, 0,
                  "Every monster's countdown increases by 1.");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (!w.fl.mons[i].dead && !isMonsterAlly(w, i)) w.fl.mons[i].cd += 1;
      fxSound(w, S_TICK, 1.f, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_PATIENCE, "Patience", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
                  "+1 base power for every turn spent on the current floor (max +8).");
    a.h.stats = [](World& w, int) { w.st.basePower += std::min(8, std::max(0, w.fl.turn - 1)); };
  }
  {
    auto& a = DEF(AB_P_BORROWED, "Borrowed Time", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {35}, 0,
                  "Your next shot is a free turn: monsters do not act after it.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.pendingFree) return false;
      w.fl.pendingFree = true;
      fxSound(w, S_TICK, 1.f, 1.4f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_REWIND, "Rewind Wounds", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {70}, 0,
                  "Restore your HP to what it was when you arrived on this floor.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.pl.hp >= w.fl.hpAtStart) return false;
      healPlayer(w, w.fl.hpAtStart - w.pl.hp);
      fxSound(w, S_PORTAL, 1.f, 0.5f);
      return true;
    };
  }
  // Morgrave, the Pale Warden
  {
    auto& a = DEF(AB_P_SKELETON, "Raise Skeleton", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {20}, 0,
                  "A skeleton rises for the rest of the floor. Ball hits on it grant +4 power, and it strikes a "
                  "random monster for 4 (+1 per 2 depth) after every enemy phase.");
    a.cast = [](World& w, int, V2, V2, int) {
      V2 p = w.fl.lastKillPos;
      for (int tries = 0; tries < 200; ++tries) {
        if (spotFree(w, p, 14, 4)) {
          addPeg(w, PK_SKELETON, p, 14);
          fxBurst(w, p, 0xe8e8d8, 20, 180);
          fxSound(w, S_SPAWN, 0.8f, 0.6f, p.x);
          return true;
        }
        p = V2(w.fl.rng.rangef(PX0 + 50, PX1 - 50), w.fl.rng.rangef(FIELD_Y0 + 60, FIELD_Y1 - 60));
      }
      return false;
    };
  }
  {
    auto& a = DEF(AB_P_HARVEST, "Death's Harvest", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
                  "Kills restore 2 HP and 1 MP.");
    a.h.stats = [](World& w, int) {
      w.st.killHeal += 2;
      w.st.killMp += 1;
    };
  }
  {
    auto& a = DEF(AB_P_SOULREND, "Soul Rend", SCH_DIVINE, T_AIM, TG_MONSTER, R_COMMON, 1, {30}, 0,
                  "Rip away 30% of a monster's current HP (15% against bosses).");
    a.cast = [](World& w, int, V2, V2, int mon) {
      if (mon < 0) return false;
      Monster& m = w.fl.mons[mon];
      int d = std::max(1, (int)(m.hp * (m.boss ? 0.15f : 0.30f)));
      fxBurst(w, m.p, 0xc0a0ff, 26, 220);
      fxSound(w, S_CAST, 1.f, 0.4f, m.p.x);
      damageMonster(w, mon, d, DS_SPELL);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_DEATHSDOOR, "Death's Door", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {60}, 0,
                  "For the next 3 turns, you cannot drop below 1 HP.");
    a.cast = [](World& w, int, V2, V2, int) {
      w.pl.deathsDoor = 3;
      fxSound(w, S_CAST, 1.f, 0.3f);
      return true;
    };
  }
  // Ashka the Kindled
  {
    auto& a = DEF(AB_P_FIRESTORM, "Firestorm", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {15}, 0,
                  "Every monster gains 6 Burn (+1 per 2 depth).");
    a.cast = [](World& w, int, V2, V2, int) {
      for (int i = 0; i < (int)w.fl.mons.size(); ++i)
        if (!w.fl.mons[i].dead && !isMonsterAlly(w, i)) {
          applyBurn(w, i, 6 + w.depth / 2);
          fxBurst(w, w.fl.mons[i].p, 0xff7020, 16, 200);
        }
      fxSound(w, S_FIRE, 1.f, 0.7f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_KINDLING, "Kindling", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
                  "+2 Fire pegs each turn. Kills heal 2 HP.");
    a.h.stats = [](World& w, int) {
      w.st.specials[PK_FIRE] += 2;
      w.st.killHeal += 2;
    };
  }
  {
    auto& a = DEF(AB_P_IMMOLATE, "Immolate", SCH_DIVINE, T_AIM, TG_MONSTER, R_COMMON, 1, {25}, 0,
                  "A burning monster takes 3x its Burn as damage.");
    a.cast = [](World& w, int, V2, V2, int mon) {
      if (mon < 0 || w.fl.mons[mon].burn <= 0) return false;
      fxBurst(w, w.fl.mons[mon].p, 0xff5020, 30, 260);
      damageMonster(w, mon, w.fl.mons[mon].burn * 3, DS_SPELL);
      fxSound(w, S_FIRE, 1.f, 0.6f);
      return true;
    };
  }
  {
    auto& a = DEF(AB_P_APOCALYPSE, "Apocalypse", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {60}, 0,
                  "Ten random pins become bombs.");
    a.cast = [](World& w, int, V2, V2, int) {
      int n = convertPins(w, PK_BOMB, 10);
      fxSound(w, S_TICK, 1.f, 0.6f);
      return n > 0;
    };
  }
  // Mirra of the Glass
  {
    auto& a = DEF(AB_P_MIRRORBALL, "Mirror Ball", SCH_DIVINE, T_FLIGHT, TG_NONE, R_COMMON, 1, {12}, 0,
                  "Every ball in flight splits into two with full power.");
    a.cast = [](World& w, int, V2, V2, int) {
      int n = (int)w.fl.balls.size();
      bool any = false;
      for (int i = 0; i < n; ++i)
        if (w.fl.balls[i].alive) {
          splitBall(w, i, 1.f);
          any = true;
        }
      if (any) fxSound(w, S_SHATTER, 0.7f, 1.4f);
      return any;
    };
  }
  {
    auto& a = DEF(AB_P_REFLECTION, "Reflection", SCH_DIVINE, T_PASSIVE, TG_NONE, R_COMMON, 1, {0}, 0,
                  "Monsters that attack you take 30% of the damage back.");
    a.h.stats = [](World& w, int) { w.st.reflectPct = std::max(w.st.reflectPct, 0.3f); };
  }
  {
    auto& a = DEF(AB_P_SHATTERGLASS, "Shatterglass", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {25}, 0,
                  "Twelve random pins turn to glass (+3 power; they shatter when hit).");
    a.cast = [](World& w, int, V2, V2, int) {
      int n = convertPins(w, PK_GLASS, 12);
      fxSound(w, S_SHATTER, 0.8f, 0.8f);
      return n > 0;
    };
  }
  {
    auto& a = DEF(AB_P_KALEIDO, "Kaleidoscope", SCH_DIVINE, T_AIM, TG_NONE, R_COMMON, 1, {50}, 0,
                  "This shot, each ball splits into three on its first monster hit.");
    a.cast = [](World& w, int, V2, V2, int) {
      if (w.fl.shot.kaleido) return false;
      w.fl.shot.kaleido = true;
      fxSound(w, S_SHATTER, 1.f, 1.2f);
      return true;
    };
  }
}
