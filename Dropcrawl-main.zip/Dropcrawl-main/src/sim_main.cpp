// Dropcrawl - console balance simulator: dropcrawl_sim.exe [runs] [smart 0/1] [seed] [trace 0/1] [species] [bg]
#include "sim.h"
#include <cstdlib>
#include <map>
#include <chrono>

int main(int argc, char** argv) {
  initContent();
  std::string err;
  if (!validateContent(err)) {
    printf("CONTENT ERROR: %s\n", err.c_str());
    return 1;
  }
  int runs = argc > 1 ? atoi(argv[1]) : 4;
  bool smart = argc > 2 ? atoi(argv[2]) != 0 : true;
  uint64_t seed0 = argc > 3 ? (uint64_t)atoll(argv[3]) : 1000;
  bool trace = argc > 4 ? atoi(argv[4]) != 0 : false;
  int fixedSp = argc > 5 ? atoi(argv[5]) : -1;
  int fixedBg = argc > 6 ? atoi(argv[6]) : -1;
  BotStats bs;
  bs.smart = smart;
  if (argc > 7) bs.candidates = atoi(argv[7]);
  bs.trace = trace;
  int wins = 0;
  double depthSum = 0;
  std::map<std::string, int> killers, deaths;
  std::map<int, int> actReached;
  for (int i = 0; i < runs; ++i) {
    int sp = fixedSp >= 0 ? fixedSp : i % SP_COUNT;
    int bg = fixedBg >= 0 ? fixedBg : (i * 7 + i / SP_COUNT) % BG_COUNT;
    auto t0 = std::chrono::steady_clock::now();
    if (trace) printf("run %d: %s %s seed %llu\n", i, SPECIES[sp].name, BGS[bg].name, (unsigned long long)(seed0 + i));
    SimResult r = simRun(seed0 + i, sp, bg, bs);
    double secs = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    printf("%3d %-12s %-12s %s depth %2d (%-8s) xl %2d turns %4d %s%s  [%.1fs]\n", i, SPECIES[sp].name, BGS[bg].name,
           r.won ? "WON " : "died", r.depth, r.location.c_str(), r.xl, r.turns, r.won ? "" : r.killer.c_str(),
           r.hitGuard ? " (GUARD)" : "", secs);
    fflush(stdout);
    if (r.won) wins++;
    else {
      killers[r.killer]++;
      deaths[r.location]++;
    }
    depthSum += r.depth;
    actReached[r.act]++;
  }
  printf("\nWins %d/%d  avg depth %.1f\n", wins, runs, depthSum / std::max(1, runs));
  const char* KN[4] = {"normal", "elite", "boss", "vault"};
  printf("Per act/kind: floors, avg turns, avg HP lost (fraction of max)\n");
  for (int a = 0; a < 4; ++a)
    for (int k = 0; k < 3; ++k)
      if (bs.count[a][k] > 0)
        printf("  act %d %-6s n=%4.0f  turns %5.1f  hpLost %5.2f\n", a, KN[k], bs.count[a][k], bs.turns[a][k] / bs.count[a][k],
               bs.hpLost[a][k] / bs.count[a][k]);
  printf("Act reached:");
  for (auto& kv : actReached) printf("  act%d:%d", kv.first, kv.second);
  printf("\nKillers:\n");
  for (auto& kv : killers) printf("  %-30s %d\n", kv.first.c_str(), kv.second);
  printf("Death locations:\n");
  for (auto& kv : deaths) printf("  %-12s %d\n", kv.first.c_str(), kv.second);
  return 0;
}
