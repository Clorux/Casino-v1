// Dropcrawl - binary save / load of an in-progress run
#include "rules.h"
#include <cstdio>
#include <type_traits>

static const uint32_t SAVE_MAGIC = 0x43505244;  // "DRPC"
static const uint32_t SAVE_VERSION = 7;

struct Ar {
  FILE* fp = nullptr;
  bool writing = false;
  bool ok = true;
  void raw(void* p, size_t n) {
    if (!ok || n == 0) return;
    if (writing) ok = fwrite(p, 1, n, fp) == n;
    else ok = fread(p, 1, n, fp) == n;
  }
  template <class T> void pod(T& v) {
    static_assert(std::is_trivially_copyable<T>::value, "pod");
    raw(&v, sizeof(T));
  }
  template <class T> void vec(std::vector<T>& v) {
    static_assert(std::is_trivially_copyable<T>::value, "vec pod");
    uint32_t n = (uint32_t)v.size();
    pod(n);
    if (!ok) return;
    if (!writing) {
      if (n > 100000) { ok = false; return; }
      v.resize(n);
    }
    if (n) raw(v.data(), n * sizeof(T));
  }
  void str(std::string& s) {
    uint32_t n = (uint32_t)s.size();
    pod(n);
    if (!ok) return;
    if (!writing) {
      if (n > 1000000) { ok = false; return; }
      s.resize(n);
    }
    if (n) raw(&s[0], n);
  }
};

static void ioPlayer(Ar& a, Player& p) {
  a.pod(p.species); a.pod(p.bg); a.pod(p.hp); a.pod(p.mp); a.pod(p.gold); a.pod(p.xp); a.pod(p.xl);
  a.pod(p.baseHp); a.pod(p.baseMp); a.pod(p.basePower); a.pod(p.baseArmor);
  a.pod(p.bonusMaxHp); a.pod(p.bonusPower); a.pod(p.bonusMp); a.pod(p.bonusArmor);
  a.vec(p.abil); a.vec(p.relics); a.vec(p.items);
  a.pod(p.patron); a.pod(p.piety); a.pod(p.pietyMax);
  a.pod(p.poison); a.pod(p.weak); a.pod(p.block); a.pod(p.nextShotPower); a.pod(p.deathsDoor);
  a.pod(p.phoenixUsed); a.pod(p.rhythm); a.pod(p.charmHp);
  a.vec(p.randarts); a.pod(p.mut); a.pod(p.dsSchedMut); a.pod(p.dsSchedXL); a.pod(p.dsSchedN); a.pod(p.dsMonstrous);
  a.pod(p.lives); a.pod(p.draconic); a.pod(p.form); a.pod(p.sacrifices); a.pod(p.guardBlocks); a.pod(p.corrode);
  a.pod(p.slowed); a.pod(p.sapped); a.pod(p.cursedBall); a.pod(p.nextShotDouble); a.pod(p.pachinkoPegs);
  a.pod(p.medalPower); a.pod(p.tumbleCount);
  a.pod(p.stat); a.pod(p.statPoints); a.pod(p.shards); a.vec(p.relicAffix); a.pod(p.statGrowthLog);
}

static void ioFloor(Ar& a, Floor& f) {
  a.pod(f.spec);
  a.vec(f.pegs); a.vec(f.segs); a.vec(f.zones); a.vec(f.mons); a.vec(f.balls); a.vec(f.newBalls);
  a.vec(f.pockets); a.vec(f.clearings);
  a.pod(f.nextId); a.pod(f.turn); a.pod(f.time); a.pod(f.shotTime); a.pod(f.phase); a.pod(f.shot);
  a.pod(f.enemyIdx); a.pod(f.enemyTimer); a.pod(f.enemyStage);
  a.pod(f.pendingFree); a.pod(f.vulnTurn); a.pod(f.turnPegHits); a.pod(f.tookDamageThisTurn); a.pod(f.silenceT);
  a.pod(f.waterLevel); a.pod(f.lavaLevel); a.pod(f.windX); a.pod(f.gravNow); a.pod(f.dark);
  a.pod(f.hasCatcher); a.pod(f.catcherX); a.pod(f.catcherDir); a.pod(f.hasFlippers); a.pod(f.flipKey);
  a.pod(f.vaultShots); a.pod(f.isVault); a.pod(f.hpAtStart); a.pod(f.firstAttackBlocked); a.pod(f.holsterFree);
  a.pod(f.kills); a.pod(f.shotsFired); a.pod(f.raisedAllyT); a.pod(f.raisedAllyDmg); a.pod(f.favorUsed);
  a.pod(f.cleared); a.pod(f.revealBonus); a.pod(f.relaunchPower); a.pod(f.vampAcc); a.pod(f.lastTrig);
  a.pod(f.lastKillPos); a.pod(f.lastKillDef); a.pod(f.turretAcc); a.pod(f.launchSpeed); a.pod(f.baseSpecials);
  a.pod(f.bouncy); a.pod(f.dividerSeg); a.pod(f.flipSeg); a.pod(f.flipHeldT); a.pod(f.clearT);
  a.pod(f.swarmSpawned); a.pod(f.pietyAcc); a.pod(f.focus); a.pod(f.rng.s);
  a.vec(f.keepOut); a.pod(f.slotSpins); a.pod(f.slotT); a.pod(f.slotReel); a.pod(f.slotShow); a.pod(f.slotLast);
  a.pod(f.cursor); a.pod(f.blindTurns); a.pod(f.timeStop); a.pod(f.streak); a.pod(f.streakPower); a.pod(f.cardPower);
  a.pod(f.bountyGold); a.pod(f.tumblerFloor); a.pod(f.moodShown); a.pod(f.bankSerial); a.pod(f.ghostSolid);
  a.pod(f.onceFlags); a.pod(f.sanctuaryT); a.pod(f.blockKeep); a.pod(f.freeCasts); a.pod(f.cardsDrawn); a.pod(f.lastCard);
  a.pod(f.tempStat); a.pod(f.shrine); a.pod(f.trainingUsed); a.pod(f.bossTurns); a.pod(f.bossEnraged); a.pod(f.lootDropped);
}

static void ioWorld(Ar& a, World& w) {
  a.pod(w.seed);
  ioPlayer(a, w.pl);
  a.pod(w.act); a.pod(w.step); a.pod(w.depth); a.pod(w.branchA); a.pod(w.branchB); a.pod(w.runes); a.pod(w.descent);
  a.pod(w.won); a.pod(w.dead); a.pod(w.screen); a.pod(w.rng.s);
  a.vec(w.stairs); a.vec(w.shop); a.vec(w.offers); a.pod(w.pendingLevels); a.vec(w.relicOffers);
  a.pod(w.eventId); a.pod(w.eventStage); a.str(w.eventResult); a.vec(w.altarChoices); a.vec(w.rewardItems);
  a.pod(w.rewardGold); a.pod(w.restUsed);
  RunStats& r = w.rs;
  a.pod(r.kills); a.pod(r.damage); a.pod(r.shots); a.pod(r.turns); a.pod(r.floors); a.pod(r.goldEarned);
  a.pod(r.biggestHit); a.pod(r.bestShot); a.pod(r.pegHits); a.pod(r.potionsUsed); a.pod(r.scrollsUsed);
  a.pod(r.spellsCast); a.pod(r.eliteKills); a.pod(r.cards); a.pod(r.tumbles); a.pod(r.jackpots); a.str(r.killer);
  uint32_t nlog = (uint32_t)w.log.size();
  a.pod(nlog);
  if (!a.writing) {
    if (nlog > 10000) { a.ok = false; return; }
    w.log.resize(nlog);
  }
  for (uint32_t i = 0; i < nlog && a.ok; ++i) {
    a.str(w.log[i].text);
    a.pod(w.log[i].col);
    a.pod(w.log[i].turn);
  }
  a.pod(w.shopVisitedLast); a.pod(w.lastNonCombat); a.pod(w.tumblerMood);
  ioFloor(a, w.fl);
}

bool saveRun(const World& w, const std::wstring& path) {
  std::wstring tmp = path + L".tmp";
  FILE* fp = _wfopen(tmp.c_str(), L"wb");
  if (!fp) return false;
  Ar a;
  a.fp = fp;
  a.writing = true;
  uint32_t magic = SAVE_MAGIC, ver = SAVE_VERSION;
  a.pod(magic);
  a.pod(ver);
  World& ww = const_cast<World&>(w);
  ioWorld(a, ww);
  bool ok = a.ok;
  fclose(fp);
  if (!ok) {
    _wremove(tmp.c_str());
    return false;
  }
  _wremove(path.c_str());
  return _wrename(tmp.c_str(), path.c_str()) == 0;
}

bool loadRun(World& w, const std::wstring& path) {
  FILE* fp = _wfopen(path.c_str(), L"rb");
  if (!fp) return false;
  Ar a;
  a.fp = fp;
  a.writing = false;
  uint32_t magic = 0, ver = 0;
  a.pod(magic);
  a.pod(ver);
  if (magic != SAVE_MAGIC || ver != SAVE_VERSION) {
    fclose(fp);
    return false;
  }
  World tmp;
  ioWorld(a, tmp);
  fclose(fp);
  if (!a.ok) return false;
  w = tmp;
  ensureCapacity(w);
  w.st = Stats();
  w.st.maxHp = 0;
  w.effs.clear();
  int hp = w.pl.hp, mp = w.pl.mp;
  recalcStats(w);
  w.pl.hp = std::min(hp, w.st.maxHp);
  w.pl.mp = std::min(mp, w.st.maxMp);
  w.fx.clear();
  w.quiet = false;
  return true;
}
