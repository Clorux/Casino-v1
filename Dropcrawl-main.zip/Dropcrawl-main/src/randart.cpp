// Dropcrawl - randarts: randomly generated relics with 2-6 properties and a generated name.
// The same property engine powers the 1-2 random affixes of "magic" relics (loot.cpp).
#include "rules.h"

static const char* BASE_NAME[12] = {"Ring", "Amulet", "Orb", "Charm", "Crown", "Gauntlet", "Boots", "Cloak", "Talisman", "Idol", "Mask", "Bracers"};
static const int SPECIAL_KINDS[] = {PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_MULTI, PK_FIRE, PK_ICE, PK_SPARK, PK_CRYSTAL,
                                    PK_CLOVER, PK_CHAOS, PK_VAMPIRE, PK_FREEZE, PK_SHIELD, PK_RUNE, PK_FEATHER,
                                    PK_STAR, PK_MOON, PK_DICE, PK_PRISM, PK_BRAND, PK_COMBO, PK_ROD, PK_SNOWBALL};
static const int N_SPECIAL_KINDS = sizeof(SPECIAL_KINDS) / sizeof(SPECIAL_KINDS[0]);

const char* randartGlyph(const Randart& r) {
  static const char* G[12] = {"o", "\"", "*", "&", "^", "%", "[", "(", "+", "&", "0", "]"};
  return G[r.base % 12];
}

const char* randartPropName(int prop) {
  switch (prop) {
    case RP_POWER: return "power";
    case RP_ARMOR: return "armor";
    case RP_MAXHP: return "vitality";
    case RP_MAXMP: return "magic";
    case RP_DAMAGE: return "slaying";
    default: return "wonder";
  }
}

float randPropWeight(int p) {
  switch (p) {
    case RP_SLOT: case RP_OFFER: return 0.45f;
    case RP_CRIT: case RP_FIRSTFREE: case RP_CHAOS: case RP_VOID: case RP_TULIP: case RP_PORTAL: return 0.6f;
    case RP_ALLSTATS: case RP_MANASHIELD: case RP_SECONDCHANCE: case RP_PIERCE: case RP_OVERKILL: return 0.5f;
    case RP_RUNES: case RP_SHRINE: case RP_WELL: case RP_STARS: case RP_GEMS: case RP_TUMBLERKIND: return 0.5f;
    case RP_POWER: case RP_MAXHP: case RP_DAMAGE: case RP_ARMOR: return 1.3f;
    case RP_STR: case RP_DEX: case RP_INT: case RP_VIT: case RP_LCK: return 1.4f;
    default: return 1.f;
  }
}

int randPropAux(Rng& R, int p) {
  if (p == RP_SPECIAL) return SPECIAL_KINDS[R.range(0, N_SPECIAL_KINDS - 1)];
  if (p == RP_SCHOOLCOST) return R.range(0, SCH_DIVINE - 1);
  return 0;
}

int randPropRoll(Rng& R, int p, int depth) {
  int t = depth / 6;  // 0..4
  switch (p) {
    case RP_POWER: return R.range(1, 2) + (depth >= 12 ? 1 : 0);
    case RP_ARMOR: return R.range(1, 2);
    case RP_MAXHP: return R.range(5, 12) + depth / 2;
    case RP_MAXMP: return R.range(1, 3);
    case RP_MPREGEN: case RP_HPREGEN: case RP_SLOT: case RP_OFFER: case RP_CHILLFIRST: case RP_GOLDHIT: case RP_KILLMP:
    case RP_FIRSTBLOCK: case RP_POISONRES: case RP_FIRSTFREE: case RP_WALL: case RP_SCHOOLCOST: case RP_ALLYTURNS:
    case RP_HOMING: case RP_SECONDCHANCE: case RP_PIERCE: case RP_STRIKEWIDE: case RP_FREEWIDE: case RP_RUNES:
    case RP_SHRINE: case RP_GEMS: case RP_TUMBLERKIND: case RP_LOOT: return 1;
    case RP_LOWGRAV: return R.range(6, 15);
    case RP_BOUNCE: return R.range(3, 8);
    case RP_BIGBALL: return R.range(10, 20);
    case RP_PREVIEW: return R.range(1, 2);
    case RP_GOLD: return R.range(15, 40);
    case RP_XP: return R.range(10, 25);
    case RP_DAMAGE: return R.range(5, 12) + t * 2;
    case RP_ELITE: return R.range(15, 30);
    case RP_CRIT: return 5;
    case RP_HEALMUL: return R.range(25, 50);
    case RP_SHOP: return R.range(10, 20);
    case RP_SPECIAL: return R.range(1, 2);
    case RP_BURN: return R.range(1, 2) + (t >= 2 ? 1 : 0);
    case RP_POISON: return R.range(1, 3) + (t >= 2 ? 1 : 0);
    case RP_FLAT: return R.range(1, 3) + (t >= 3 ? 1 : 0);
    case RP_LIFESTEAL: return R.range(10, 20);
    case RP_ZAP: return R.range(10, 15);
    case RP_KILLHEAL: return R.range(1, 3);
    case RP_KILLGOLD: return R.range(2, 5);
    case RP_KILLBLAST: return R.range(3, 6) + depth / 3;
    case RP_TURNBLOCK: return R.range(1, 3);
    case RP_THORNS: return R.range(2, 4) + t;
    case RP_REFLECT: return R.range(10, 20);
    case RP_FULLHP: return R.range(10, 25);
    case RP_LOWHP: return R.range(15, 30);
    case RP_CHAOS: return R.range(5, 10);
    case RP_BLEED: return R.range(1, 2);
    case RP_EXPLOSION: return R.range(20, 40);
    case RP_ALLY: return R.range(20, 40);
    case RP_BUMPER: return R.range(2, 3);
    case RP_TULIP: return R.range(3, 5);
    case RP_VOID: return R.range(25, 50);
    case RP_PORTAL: return R.range(2, 4);
    // v3
    case RP_STR: case RP_DEX: case RP_INT: case RP_VIT: case RP_LCK: return R.range(1, 2) + (depth >= 9 ? 1 : 0) + (depth >= 18 ? 1 : 0);
    case RP_ALLSTATS: return 1 + (depth >= 14 ? 1 : 0);
    case RP_CRITCHANCE: return R.range(5, 10) + t;
    case RP_CRITDMG: return R.range(20, 40) + 5 * t;
    case RP_DODGE: return R.range(3, 6);
    case RP_SPELLDMG: return R.range(10, 20) + 3 * t;
    case RP_MAGICFIND: return R.range(10, 25);
    case RP_STARTBLOCK: return R.range(5, 10) + depth / 2;
    case RP_POTIONMUL: return R.range(25, 50);
    case RP_KILLPOWER: return R.range(2, 4);
    case RP_EXECUTE: return R.range(30, 60);
    case RP_FIRSTSTRIKE: return R.range(25, 50);
    case RP_OVERKILL: return R.range(50, 100);
    case RP_HOLY: return R.range(30, 60);
    case RP_MANASHIELD: return 3;
    case RP_DISCHARGE: return R.range(15, 30);
    case RP_WELL: return R.range(2, 4);
    case RP_STARS: return R.range(2, 3);
    case RP_BURNMUL: return R.range(25, 50);
    case RP_CHILLVULN: return R.range(15, 30);
    case RP_CRITBLEED: return R.range(2, 3);
    case RP_NEG_HP: return R.range(5, 10);
    case RP_NEG_GOLD: return R.range(15, 25);
    case RP_NEG_ARMOR: case RP_NEG_MONDMG: case RP_NEG_NOISY: case RP_NEG_CURSED: case RP_NEG_POWER: case RP_NEG_MPREGEN: return 1;
    case RP_NEG_HEAVY: return 10;
    case RP_NEG_HEAL: return 25;
    case RP_NEG_STR: case RP_NEG_DEX: case RP_NEG_INT: case RP_NEG_VIT: case RP_NEG_LCK: return 2;
    case RP_NEG_FRAGILE: return 10;
    case RP_NEG_BOSS: return 15;
  }
  return 1;
}

std::string randPropText(int p, int v, int aux) {
  switch (p) {
    case RP_POWER: return fmt("+%d base power", v);
    case RP_ARMOR: return fmt("+%d armor", v);
    case RP_MAXHP: return fmt("+%d max HP", v);
    case RP_MAXMP: return fmt("+%d max MP", v);
    case RP_MPREGEN: return "+1 MP regeneration";
    case RP_HPREGEN: return "+1 HP regeneration";
    case RP_LOWGRAV: return fmt("Gravity -%d%%", v);
    case RP_BOUNCE: return fmt("Balls bounce %d%% livelier", v);
    case RP_BIGBALL: return fmt("Balls are %d%% larger", v);
    case RP_PREVIEW: return fmt("Aiming guide +%d bounce%s", v, v > 1 ? "s" : "");
    case RP_GOLD: return fmt("+%d%% gold", v);
    case RP_XP: return fmt("+%d%% XP", v);
    case RP_DAMAGE: return fmt("+%d%% damage", v);
    case RP_ELITE: return fmt("+%d%% damage to elites and bosses", v);
    case RP_CRIT: return "Crit pegs multiply power by 0.5 more";
    case RP_HEALMUL: return fmt("+%d%% healing received", v);
    case RP_SHOP: return fmt("Shop prices -%d%%", v);
    case RP_SLOT: return "+1 consumable slot";
    case RP_OFFER: return "+1 choice at level-ups";
    case RP_SPECIAL: return fmt("+%d %s%s each turn", v, PEG_NAME[clampv(aux, 0, PK_COUNT - 1)], v > 1 ? "s" : "");
    case RP_BURN: return fmt("Ball hits apply %d Burn", v);
    case RP_POISON: return fmt("Ball hits apply %d Poison", v);
    case RP_CHILLFIRST: return "Your first monster hit each shot Chills";
    case RP_FLAT: return fmt("+%d damage on every ball hit", v);
    case RP_LIFESTEAL: return fmt("Heal 1 HP per %d damage your balls deal", v);
    case RP_GOLDHIT: return "+1 gold per monster hit";
    case RP_ZAP: return fmt("Every %d peg hits, zap the nearest monster", v);
    case RP_KILLHEAL: return fmt("Kills heal %d HP", v);
    case RP_KILLMP: return "Kills restore 1 MP";
    case RP_KILLGOLD: return fmt("Kills grant +%d gold", v);
    case RP_KILLBLAST: return fmt("Slain monsters burst for %d damage nearby", v);
    case RP_TURNBLOCK: return fmt("+%d Block at the start of each turn", v);
    case RP_THORNS: return fmt("Attackers take %d damage", v);
    case RP_REFLECT: return fmt("Reflect %d%% of attack damage", v);
    case RP_FIRSTBLOCK: return "The first attack each floor misses";
    case RP_POISONRES: return "Immune to poison";
    case RP_FIRSTFREE: return "Your first spell each floor is free";
    case RP_FULLHP: return fmt("+%d%% damage while at full HP", v);
    case RP_LOWHP: return fmt("+%d%% damage while below half HP", v);
    case RP_CHAOS: return fmt("Chaotic: the Tumbler watches you (%d%%/turn)", v);
    case RP_BLEED: return fmt("Ball hits apply %d Bleed", v);
    case RP_EXPLOSION: return fmt("Explosions deal +%d%% damage", v);
    case RP_ALLY: return fmt("Allies deal +%d%% damage", v);
    case RP_BUMPER: return fmt("Spinners, kickers and pendulums grant +%d power", v);
    case RP_TULIP: return fmt("Tulips and slot chuckers grant +%d power", v);
    case RP_VOID: return fmt("Void discharges +%d%% stronger", v);
    case RP_WALL: return "Wall bounces grant +1 power";
    case RP_PORTAL: return fmt("Portals and rifts grant +%d power", v);
    case RP_STR: return fmt("+%d Strength", v);
    case RP_DEX: return fmt("+%d Dexterity", v);
    case RP_INT: return fmt("+%d Intelligence", v);
    case RP_VIT: return fmt("+%d Vitality", v);
    case RP_LCK: return fmt("+%d Luck", v);
    case RP_ALLSTATS: return fmt("+%d to all stats", v);
    case RP_CRITCHANCE: return fmt("+%d%% critical hit chance", v);
    case RP_CRITDMG: return fmt("Critical hits deal +%d%% damage", v);
    case RP_DODGE: return fmt("+%d%% chance to dodge attacks", v);
    case RP_SPELLDMG: return fmt("+%d%% spell damage", v);
    case RP_MAGICFIND: return fmt("+%d%% better loot", v);
    case RP_SCHOOLCOST: return fmt("%s abilities cost 1 less MP", SCHOOL_NAME[clampv(aux, 0, SCH_COUNT - 1)]);
    case RP_STARTBLOCK: return fmt("+%d Block at the start of each floor", v);
    case RP_POTIONMUL: return fmt("Potions are %d%% stronger", v);
    case RP_KILLPOWER: return fmt("Kills give your balls +%d power", v);
    case RP_EXECUTE: return fmt("+%d%% damage to monsters below 25%% HP", v);
    case RP_FIRSTSTRIKE: return fmt("+%d%% damage on your first monster hit each shot", v);
    case RP_OVERKILL: return fmt("%d%% of overkill damage splashes to the nearest monster", v);
    case RP_HOLY: return fmt("+%d%% damage to undead and demons", v);
    case RP_ALLYTURNS: return "Your summons last 1 turn longer";
    case RP_HOMING: return "Balls curve gently toward monsters";
    case RP_MANASHIELD: return fmt("Mana shield: half of each hit is paid with MP (1 MP per %d damage)", v);
    case RP_SECONDCHANCE: return "A ball about to fall into a bad pocket is sent back up (once per shot)";
    case RP_PIERCE: return "Your first monster hit each shot pierces through";
    case RP_DISCHARGE: return fmt("Discharges deal +%d%% damage", v);
    case RP_STRIKEWIDE: return "Strike pockets are 30% wider";
    case RP_FREEWIDE: return "Free Turn pockets are 25% wider";
    case RP_RUNES: return "Rune circles grant two runes";
    case RP_SHRINE: return "Shrine blessings are twice as strong";
    case RP_WELL: return fmt("Healing wells heal +%d", v);
    case RP_STARS: return fmt("Star pegs grant +%d power", v);
    case RP_GEMS: return "Gems grant +1 more";
    case RP_BURNMUL: return fmt("Burn deals +%d%% damage", v);
    case RP_CHILLVULN: return fmt("Chilled monsters take +%d%% damage", v);
    case RP_CRITBLEED: return fmt("Critical hits apply %d Bleed", v);
    case RP_TUMBLERKIND: return "The Tumbler is kinder to you";
    case RP_LOOT: return "Monsters drop loot twice as often";
    case RP_NEG_HP: return fmt("-%d max HP", v);
    case RP_NEG_ARMOR: return "-1 armor";
    case RP_NEG_MONDMG: return "Monsters deal +1 damage";
    case RP_NEG_GOLD: return fmt("-%d%% gold", v);
    case RP_NEG_NOISY: return "Noisy: monsters act 1 turn sooner on each floor";
    case RP_NEG_CURSED: return "Cursed: 1 Curse peg appears each turn";
    case RP_NEG_HEAVY: return "Heavy: gravity +10%";
    case RP_NEG_POWER: return "-1 base power";
    case RP_NEG_HEAL: return "-25% healing received";
    case RP_NEG_STR: return fmt("-%d Strength", v);
    case RP_NEG_DEX: return fmt("-%d Dexterity", v);
    case RP_NEG_INT: return fmt("-%d Intelligence", v);
    case RP_NEG_VIT: return fmt("-%d Vitality", v);
    case RP_NEG_LCK: return fmt("-%d Luck", v);
    case RP_NEG_FRAGILE: return fmt("Fragile: you take %d%% more damage", v);
    case RP_NEG_MPREGEN: return "-1 MP regeneration";
    case RP_NEG_BOSS: return fmt("Bosses deal +%d%% damage to you", v);
  }
  return "?";
}

static std::string syllableName(Rng& R) {
  static const char* A[] = {"Ar", "Bel", "Cor", "Dra", "El", "Fen", "Gor", "Hal", "Ith", "Jor", "Kal", "Lun", "Mor",
                            "Nar", "Oth", "Pel", "Quin", "Ral", "Syl", "Thar", "Ul", "Vex", "Wyn", "Xan", "Yor", "Zel"};
  static const char* B[] = {"a", "e", "i", "o", "u", "ae", "ia", "ou", "", ""};
  static const char* C[] = {"dor", "mir", "wen", "thas", "gar", "lith", "rin", "vash", "zul", "nor", "sha", "rok", "dil", "vin", "mora", "tek"};
  std::string s = A[R.range(0, 25)];
  s += B[R.range(0, 9)];
  s += C[R.range(0, 15)];
  return s;
}

Randart makeRandart(uint32_t seed) {
  Randart r;
  r.seed = seed;
  int depth = (int)(seed & 31);
  bool bonus = (seed >> 5) & 1;
  Rng R((uint64_t)seed * 2654435761ull + 17);
  r.base = (uint8_t)R.range(0, 11);
  int good = 2 + (R.chance(0.5f) ? 1 : 0) + (depth >= 10 && R.chance(0.4f) ? 1 : 0) + (bonus ? 1 : 0);
  bool bad = R.chance(0.35f);
  if (bad) good++;
  good = std::min(good, bad ? 5 : 6);
  std::vector<float> wt(RP_GOOD_COUNT);
  for (int p = 0; p < RP_GOOD_COUNT; ++p) wt[p] = randPropWeight(p);
  r.n = 0;
  for (int k = 0; k < good; ++k) {
    int p = R.weighted(wt);
    if (p < 0) break;
    wt[p] = 0;
    // mutually redundant pairs
    if (p == RP_FULLHP) wt[RP_LOWHP] = 0;
    if (p == RP_LOWHP) wt[RP_FULLHP] = 0;
    if (p == RP_ALLSTATS)
      for (int q = RP_STR; q <= RP_LCK; ++q) wt[q] *= 0.3f;
    r.prop[r.n] = (uint8_t)p;
    r.val[r.n] = (int8_t)randPropRoll(R, p, depth);
    r.aux[r.n] = (uint8_t)randPropAux(R, p);
    r.n++;
  }
  if (bad && r.n < 6) {
    int p = R.range(RP_NEG_HP, RP_NEG_END - 1);
    r.prop[r.n] = (uint8_t)p;
    r.val[r.n] = (int8_t)randPropRoll(R, p, depth);
    r.aux[r.n] = 0;
    r.n++;
  }
  static const uint32_t COLS[] = {0xff7080, 0x80c0ff, 0xffd060, 0xa0ff90, 0xe090ff, 0xff9f40, 0x70f0e0, 0xf0f0a0, 0xff80d0, 0xb0b0ff};
  r.color = COLS[R.range(0, 9)];
  static const char* ADJ[] = {"Glimmering", "Whispering", "Shattered", "Gilded", "Hollow", "Burning", "Frozen", "Weeping",
                              "Laughing", "Crooked", "Eternal", "Humming", "Bouncing", "Wandering", "Lucky", "Restless"};
  std::string name;
  std::string nm = syllableName(R);
  switch (R.range(0, 3)) {
    case 0: name = std::string("the ") + BASE_NAME[r.base] + " of " + nm; break;
    case 1: name = std::string("the ") + ADJ[R.range(0, 15)] + " " + BASE_NAME[r.base]; break;
    case 2: name = nm + "'s " + BASE_NAME[r.base]; break;
    default: name = std::string("the ") + BASE_NAME[r.base] + " \"" + nm + "\""; break;
  }
  snprintf(r.name, sizeof(r.name), "%s", name.c_str());
  return r;
}

std::string randartDesc(const Randart& r) {
  std::string s;
  for (int i = 0; i < r.n; ++i) {
    if (i) s += "\n";
    s += randPropText(r.prop[i], r.val[i], r.aux[i]);
  }
  return s;
}

uint32_t newRandartSeed(World& w) {
  uint32_t x = w.rng.next();
  uint32_t seed = (x & ~63u) | (uint32_t)std::min(31, std::max(1, w.depth));
  if (hasRelic(w, RL_MONOCLE)) seed |= 32u;
  return seed;
}

void gainRandart(World& w, uint32_t seed) {
  if (w.pl.randarts.size() >= 24) return;
  Randart r = makeRandart(seed);
  w.pl.randarts.push_back(r);
  recalcStats(w);
  logMsg(w, r.color, "You find %s! (%d properties)", r.name, (int)r.n);
  fxSound(w, S_CHEST, 0.9f, 1.3f);
}

// ---------------------------------------------------------------- the shared hook table
// Every property of every randart and every magic relic's affixes flows through these hooks.
template <class F> static void eachProp(const World& w, F fn) {
  for (auto& r : w.pl.randarts)
    for (int i = 0; i < r.n; ++i) fn((int)r.prop[i], (int)r.val[i], (int)r.aux[i]);
  for (auto& r : w.pl.relicAffix)
    for (int i = 0; i < r.n; ++i) fn((int)r.prop[i], (int)r.val[i], (int)r.aux[i]);
}

bool anyAffixes(const World& w) {
  if (!w.pl.randarts.empty()) return true;
  for (auto& r : w.pl.relicAffix)
    if (r.n > 0) return true;
  return false;
}

int propTotal(const World& w, int prop) {
  int t = 0;
  eachProp(w, [&](int p, int v, int) {
    if (p == prop) t += v;
  });
  return t;
}

bool randartHasProp(const World& w, int prop, int* total) {
  int t = 0;
  bool any = false;
  eachProp(w, [&](int p, int v, int) {
    if (p == prop) {
      any = true;
      t += v;
    }
  });
  if (total) *total = t;
  return any;
}

static void rStats(World& w, int) {
  Stats& s = w.st;
  eachProp(w, [&](int p, int v, int aux) {
    switch (p) {
      case RP_POWER: s.basePower += v; break;
      case RP_ARMOR: s.armor += v; break;
      case RP_MAXHP: s.maxHp += v; break;
      case RP_MAXMP: s.maxMp += v; break;
      case RP_MPREGEN: s.mpRegen += 1; break;
      case RP_HPREGEN: s.hpRegen += 1; break;
      case RP_LOWGRAV: s.gravMul *= 1.f - v / 100.f; break;
      case RP_BOUNCE: s.restBonus += v / 100.f; break;
      case RP_BIGBALL: s.ballR *= 1.f + v / 100.f; break;
      case RP_PREVIEW: s.preview += v; break;
      case RP_GOLD: s.goldMul *= 1.f + v / 100.f; break;
      case RP_XP: s.xpMul *= 1.f + v / 100.f; break;
      case RP_DAMAGE: s.dmgMul *= 1.f + v / 100.f; break;
      case RP_ELITE: s.eliteDmgMul *= 1.f + v / 100.f; break;
      case RP_CRIT: s.critMul += 0.5f; break;
      case RP_HEALMUL: s.healMul += v / 100.f; break;
      case RP_SHOP: s.shopMul *= 1.f - v / 100.f; break;
      case RP_SLOT: s.slots += 1; break;
      case RP_OFFER: s.offers += 1; break;
      case RP_SPECIAL: if (aux > 0 && aux < PK_COUNT) s.specials[aux] += v; break;
      case RP_FLAT: s.flatHit += v; break;
      case RP_KILLHEAL: s.killHeal += v; break;
      case RP_KILLMP: s.killMp += 1; break;
      case RP_KILLGOLD: s.killGold += v; break;
      case RP_THORNS: s.thornsDmg += v; break;
      case RP_REFLECT: s.reflectPct += v / 100.f; break;
      case RP_POISONRES: s.poisonRes = true; break;
      case RP_FULLHP: s.fullHpDmg += v / 100.f; break;
      case RP_LOWHP: s.lowHpDmg += v / 100.f; break;
      case RP_CHAOS: s.tumblerWatch += v / 100.f; break;
      case RP_EXPLOSION: s.explosionMul *= 1.f + v / 100.f; break;
      case RP_ALLY: s.allyDmgMul *= 1.f + v / 100.f; s.allyTurns = std::max(s.allyTurns, 1); break;
      case RP_BUMPER: s.kickerBonus += v; break;
      case RP_TULIP: s.tulipBonus += v; break;
      case RP_VOID: s.voidMul += v / 100.f; break;
      case RP_WALL: s.wallPower = true; break;
      case RP_PORTAL: s.portalBonus += v; break;
      case RP_STR: case RP_DEX: case RP_INT: case RP_VIT: case RP_LCK: s.statBonus[p - RP_STR] += v; break;
      case RP_ALLSTATS:
        for (int k = 0; k < STAT_COUNT; ++k) s.statBonus[k] += v;
        break;
      case RP_CRITCHANCE: s.critChance += v / 100.f; break;
      case RP_CRITDMG: s.critDmg += v / 100.f; break;
      case RP_DODGE: s.dodge += v / 100.f; break;
      case RP_SPELLDMG: s.spellDmgMul *= 1.f + v / 100.f; break;
      case RP_MAGICFIND: s.magicFind += v / 100.f; break;
      case RP_SCHOOLCOST: s.cheapSchool |= 1u << clampv(aux, 0, 31); break;
      case RP_STARTBLOCK: s.startBlock += v; break;
      case RP_POTIONMUL: s.potionMul *= 1.f + v / 100.f; break;
      case RP_KILLPOWER: s.killPower += v; break;
      case RP_EXECUTE: s.executeBelow += v / 100.f; break;
      case RP_FIRSTSTRIKE: s.firstStrike += v / 100.f; break;
      case RP_OVERKILL: s.overkill += v / 100.f; break;
      case RP_HOLY: s.holyPct += v; break;
      case RP_ALLYTURNS: s.allyTurns += 1; break;
      case RP_HOMING: s.homing = std::max(s.homing, 120); break;
      case RP_MANASHIELD: s.mpShield = std::max(s.mpShield, v); break;
      case RP_SECONDCHANCE: s.secondChance = true; break;
      case RP_PIERCE: s.pierceFirst = true; break;
      case RP_DISCHARGE: s.discharge += v; break;
      case RP_STRIKEWIDE: s.strikeWidth *= 1.3f; break;
      case RP_FREEWIDE: s.recallWidth *= 1.25f; break;
      case RP_RUNES: s.runeDouble = true; break;
      case RP_SHRINE: s.shrineBonus += 1; break;
      case RP_WELL: s.wellBonus += v; break;
      case RP_STARS: s.starBonus += v; break;
      case RP_GEMS: s.gemBonus += 1; break;
      case RP_BURNMUL: s.burnMul *= 1.f + v / 100.f; break;
      case RP_CHILLVULN: s.chillVuln += v / 100.f; break;
      case RP_CRITBLEED: s.critBleed += v; break;
      case RP_TUMBLERKIND: s.tumblerKind = true; break;
      case RP_LOOT: s.lootMul *= 2.f; break;
      case RP_NEG_HP: s.maxHp -= v; break;
      case RP_NEG_ARMOR: s.armor -= 1; break;
      case RP_NEG_MONDMG: s.monsterAtkBonus += 1; break;
      case RP_NEG_GOLD: s.goldMul *= 1.f - v / 100.f; break;
      case RP_NEG_CURSED: s.specials[PK_CURSE] += 1; break;
      case RP_NEG_HEAVY: s.gravMul *= 1.1f; break;
      case RP_NEG_POWER: s.basePower -= 1; break;
      case RP_NEG_HEAL: s.healMul *= 0.75f; break;
      case RP_NEG_STR: case RP_NEG_DEX: case RP_NEG_INT: case RP_NEG_VIT: case RP_NEG_LCK: s.statBonus[p - RP_NEG_STR] -= v; break;
      case RP_NEG_FRAGILE: s.dmgTaken *= 1.f + v / 100.f; break;
      case RP_NEG_MPREGEN: s.mpRegen -= 1; break;
      case RP_NEG_BOSS: s.bossDmgTaken *= 1.f + v / 100.f; break;
    }
  });
}

static void rFloorStart(World& w, int) {
  int blk = 0;
  eachProp(w, [&](int p, int v, int) {
    switch (p) {
      case RP_FIRSTBLOCK: w.fl.firstAttackBlocked = 1; break;
      case RP_FIRSTFREE: w.fl.holsterFree = 1; break;
      case RP_STARTBLOCK: blk += v; break;
      case RP_NEG_NOISY:
        for (auto& m : w.fl.mons)
          if (!m.dead) m.cd = std::max(1, m.cd - 1);
        break;
    }
  });
  if (blk > 0 && !w.fl.isVault) {
    w.pl.block += blk;
    w.fl.blockKeep = std::max(w.fl.blockKeep, 1);
  }
}

static void rTurnStart(World& w, int) {
  int blk = 0;
  eachProp(w, [&](int p, int v, int) {
    if (p == RP_TURNBLOCK) blk += v;
  });
  if (blk > 0) w.pl.block += blk;
}

static void rPegHit(World& w, int bi, int, int) {
  eachProp(w, [&](int p, int v, int) {
    if (p != RP_ZAP || v <= 0) return;
    if (w.fl.shot.pegHits % v != 0) return;
    Ball& b = w.fl.balls[bi];
    int t = nearestMonster(w, b.p);
    if (t < 0) return;
    fxZap(w, b.p, w.fl.mons[t].p, 0xfff080);
    damageMonster(w, t, 3 + w.depth / 4, DS_ZAP);
  });
}

static void rMonHit(World& w, HitCtx& c, int) {
  const Monster& m = w.fl.mons[c.mon];
  eachProp(w, [&](int p, int v, int) {
    switch (p) {
      case RP_CHILLFIRST: if (c.first) applyChill(w, c.mon, 1); break;
      case RP_EXECUTE: if (m.hp * 4 < m.maxHp) c.mult *= 1.f + v / 100.f; break;
      case RP_FIRSTSTRIKE: if (c.first) c.mult *= 1.f + v / 100.f; break;
      case RP_HOLY: if (isUndeadOrDemon(m)) c.mult *= 1.f + v / 100.f; break;
      case RP_PIERCE:
        if (c.first && !w.fl.shot.pierceUsed) {
          w.fl.shot.pierceUsed = true;
          c.pierce = true;
          c.keepPower = std::max(c.keepPower, 0.6f);
        }
        break;
    }
  });
}

static void rMonDamaged(World& w, int, int mi, int dmg, int) {
  if (dmg <= 0) return;
  eachProp(w, [&](int p, int v, int) {
    if (w.fl.mons[mi].dead && p != RP_LIFESTEAL && p != RP_GOLDHIT) return;
    switch (p) {
      case RP_BURN: applyBurn(w, mi, v); break;
      case RP_POISON: applyPoison(w, mi, v); break;
      case RP_BLEED: applyBleed(w, mi, v); break;
      case RP_LIFESTEAL: {
        int h = dmg / std::max(1, v);
        if (w.fl.rng.range(0, std::max(1, v) - 1) < dmg % std::max(1, v)) h++;
        if (h > 0) healPlayer(w, h);
        break;
      }
      case RP_GOLDHIT: gainGold(w, 1, w.fl.mons[mi].p); break;
    }
  });
}

static void rKill(World& w, int mi, int) {
  V2 pos = w.fl.mons[mi].p;
  int blast = 0;
  eachProp(w, [&](int p, int v, int) {
    if (p == RP_KILLBLAST) blast += v;
  });
  if (blast > 0) {
    fxRing(w, pos, 90, 0xffa040);
    hitMonstersInRadius(w, pos, 90, blast, DS_EXPLOSION, mi);
  }
}

Hooks RANDART_HOOKS = [] {
  Hooks h;
  h.stats = rStats;
  h.floorStart = rFloorStart;
  h.turnStart = rTurnStart;
  h.pegHit = rPegHit;
  h.monHit = rMonHit;
  h.monDamaged = rMonDamaged;
  h.kill = rKill;
  return h;
}();
