// Dropcrawl - headless bot
#pragma once
#include "game.h"

struct BotStats {
  bool smart = true;
  int candidates = 16;
  int samples = 2;
  bool trace = false;
  // accumulators per act x floor kind (normal, elite, boss)
  double turns[4][4] = {}, hpLost[4][4] = {}, count[4][4] = {}, dmgPerShot[4][4] = {};
};

struct SimResult {
  bool won = false;
  int depth = 0, act = 0, xl = 0, turns = 0;
  bool hitGuard = false;
  std::string killer, location;
};

float botPickAngle(const World& w, int candidates, int samples, float noise, uint64_t salt);
void botScreenStep(World& w, Rng& r, BotStats* bs);
SimResult simRun(uint64_t seed, int species, int bg, BotStats& bs);
