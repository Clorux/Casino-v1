// Dropcrawl - software mixer with synthesized sound effects and generative music.
// Everything is synthesized at startup; no asset files are needed.
//
//  * Sound effects: one-shot samples on a small voice pool (unchanged from the original mixer).
//  * Music: ~40 synthesized instruments (multi-sampled; sustained ones have seamless loops) and a
//    generative composer. Whenever a mood starts, and again every ~1.5-3 minutes, it writes a new
//    "song": one of the mood's style variants, key, mode, tempo, chord progressions (A, A' with a
//    cadence, B, and a tense one for fights), instrumentation, drum groove, bass pattern, arpeggio
//    or ostinato and a melodic motif. The song is arranged in sections (intro, A, A', B, breakdown,
//    climax, outro) whose texture changes every 4-16 bars; the motif is varied per phrase (answer,
//    inversion, retrograde, displacement, ornaments, cadences, call-and-response between
//    instruments). Notes are scheduled bar by bar with sample accuracy on the mixer thread. The
//    music bus has its own reverb, tempo-synced ping-pong delay and a peak limiter, and is then
//    mixed under the SFX exactly as before.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <mmsystem.h>
#include <xmmintrin.h>
#include <cctype>
#include <climits>
#include <cstdlib>
#include "audio.h"
#include "common.h"

namespace audio {

static const int RATE = 44100;
struct Sample {
  std::vector<float> d;
};
static Sample g_sfx[S_COUNT];

struct Voice {
  const Sample* s = nullptr;
  double pos = 0;
  float rate = 1, vl = 0, vr = 0;
  int id = -1;
  uint32_t age = 0;
};
static const int MAXV = 64;  // SFX voices (music has its own pool, see MusicEngine)
static Voice g_v[MAXV];
struct Req {
  int sfx;
  float vol, pitch, pan;
};
static const int MAXREQ = 64;
static CRITICAL_SECTION g_cs;
static Req g_reqs[MAXREQ];
static int g_nreq = 0;
static volatile float g_master = 0.8f, g_sfxVol = 0.8f, g_musVol = 0.45f;
static volatile int g_mood = -1;
static volatile float g_intensity = 0.f;
static HWAVEOUT g_hwo = nullptr;
static HANDLE g_ev = nullptr, g_thread = nullptr;
static volatile bool g_run = false;
static const int NBUF = 5, FRAMES = 512;
static WAVEHDR g_hdr[NBUF];
static short g_buf[NBUF][FRAMES * 2];
static uint32_t g_age = 0;
static bool g_ok = false;

float semis(float s) { return std::pow(2.f, s / 12.f); }

// ---------------------------------------------------------------- synthesis
static uint32_t g_ns = 0x1234567;
static float noise() {
  g_ns = g_ns * 1664525u + 1013904223u;
  return ((g_ns >> 8) & 0xFFFF) / 32768.f - 1.f;
}
static float sq(float x) { return std::tanh(4.f * std::sin(x)); }

template <class F> static void gen(Sample& out, float dur, F fn) {
  int n = (int)(dur * RATE);
  out.d.assign(n, 0.f);
  for (int i = 0; i < n; ++i) out.d[i] = fn(i / (float)RATE);
  float pk = 0;
  for (float v : out.d) pk = std::max(pk, std::fabs(v));
  if (pk > 0) {
    float g = 0.9f / pk;
    for (float& v : out.d) v *= g;
  }
  // tiny fade out to avoid clicks
  int fo = std::min(n, 200);
  for (int i = 0; i < fo; ++i) out.d[n - 1 - i] *= i / (float)fo;
}

static float bell(float t, float f, float dec) {
  if (t < 0) return 0;
  return (std::sin(TAU * f * t) + 0.5f * std::sin(TAU * f * 2.76f * t) * std::exp(-t * dec * 1.5f) +
          0.25f * std::sin(TAU * f * 5.4f * t) * std::exp(-t * dec * 3.f)) *
         std::exp(-t * dec) * std::min(1.f, t * 400.f);
}

static void buildSfx() {
  // Peg ping (pitched per combo in game)
  gen(g_sfx[S_PEG], 0.22f, [](float t) {
    float f = 1046.5f;
    return (std::sin(TAU * f * t) + 0.25f * std::sin(TAU * 2 * f * t) + 0.08f * std::sin(TAU * 3 * f * t)) *
           std::exp(-t * 26.f) * std::min(1.f, t * 600.f);
  });
  gen(g_sfx[S_PEG_SPECIAL], 0.55f, [](float t) { return bell(t, 1318.5f, 8.f); });
  {
    double ph = 0;
    gen(g_sfx[S_BUMP], 0.32f, [&](float t) {
      float f = 200.f + 320.f * (1.f - std::exp(-t * 28.f));
      ph += TAU * f / RATE;
      return (float)(std::sin(ph) * std::exp(-t * 11.f) + 0.2f * noise() * std::exp(-t * 90.f));
    });
  }
  {
    float lp = 0;
    double ph = 0;
    gen(g_sfx[S_HIT], 0.38f, [&](float t) {
      float f = 50.f + 100.f * std::exp(-t * 22.f);
      ph += TAU * f / RATE;
      lp += 0.25f * (noise() - lp);
      return (float)(std::sin(ph) * std::exp(-t * 12.f) + 0.7f * lp * std::exp(-t * 40.f));
    });
  }
  {
    float lp = 0;
    double ph = 0;
    gen(g_sfx[S_CRIT], 0.6f, [&](float t) {
      float f = 50.f + 110.f * std::exp(-t * 22.f);
      ph += TAU * f / RATE;
      lp += 0.3f * (noise() - lp);
      float metal = (std::sin(TAU * 1250 * t) + 0.7f * std::sin(TAU * 1873 * t) + 0.5f * std::sin(TAU * 2637 * t)) *
                    std::exp(-t * 9.f) * 0.35f;
      return (float)(std::sin(ph) * std::exp(-t * 11.f) + 0.6f * lp * std::exp(-t * 35.f) + metal);
    });
  }
  {
    float lp = 0;
    double ph = 0;
    gen(g_sfx[S_KILL], 0.75f, [&](float t) {
      float a = 0.35f * std::exp(-t * 3.f) + 0.02f;
      lp += a * (noise() - lp);
      float f = 620.f * std::exp(-t * 2.8f) + 90.f;
      ph += TAU * f / RATE;
      return (float)(lp * std::exp(-t * 4.5f) * 1.2f + 0.35f * sq((float)ph) * std::exp(-t * 6.f));
    });
  }
  gen(g_sfx[S_COIN], 0.42f, [](float t) {
    float f = t < 0.07f ? 987.8f : 1318.5f;
    float tt = t < 0.07f ? t : t - 0.07f;
    float dec = t < 0.07f ? 18.f : 8.f;
    return (std::sin(TAU * f * t) + 0.3f * std::sin(TAU * 3 * f * t)) * std::exp(-tt * dec) * std::min(1.f, tt * 800.f);
  });
  {
    double ph = 0;
    gen(g_sfx[S_HEAL], 0.6f, [&](float t) {
      float f = 420.f + 700.f * t + 12.f * std::sin(TAU * 7 * t);
      ph += TAU * f / RATE;
      return (float)(std::sin(ph) * std::sin(PI * std::min(1.f, t / 0.6f)) + 0.3f * bell(t - 0.15f, 1760.f, 7.f));
    });
  }
  gen(g_sfx[S_MANA], 0.55f, [](float t) {
    float idx = 4.f * std::exp(-t * 6.f);
    return std::sin(TAU * 880 * t + idx * std::sin(TAU * 1760 * t)) * std::exp(-t * 5.f) * std::min(1.f, t * 300.f);
  });
  {
    float lp1 = 0, lp2 = 0;
    gen(g_sfx[S_LAUNCH], 0.32f, [&](float t) {
      float c = 0.05f + 0.4f * std::min(1.f, t / 0.25f);
      lp1 += c * (noise() - lp1);
      lp2 += c * 0.5f * (lp1 - lp2);
      float band = lp1 - lp2;
      return band * std::min(1.f, t * 50.f) * std::exp(-t * 7.f) * 2.f +
             std::sin(TAU * 120 * t) * std::exp(-t * 30.f) * 0.6f;
    });
  }
  gen(g_sfx[S_POCKET], 0.9f, [](float t) {
    return bell(t, 1046.5f, 6.f) + bell(t - 0.06f, 1318.5f, 6.f) + bell(t - 0.12f, 1568.f, 5.f);
  });
  {
    float ph[5] = {0.1f, 1.3f, 2.2f, 0.7f, 2.9f};
    float fr[5] = {660, 990, 1320, 1760, 2200};
    gen(g_sfx[S_CAST], 0.65f, [&](float t) {
      float v = 0;
      for (int k = 0; k < 5; ++k) v += std::sin(TAU * fr[k] * t + ph[k]) * (0.6f + 0.4f * std::sin(TAU * (9 + k * 3) * t));
      return v * std::min(1.f, t * 20.f) * std::exp(-t * 4.f);
    });
  }
  {
    float lp = 0;
    gen(g_sfx[S_ZAP], 0.38f, [&](float t) {
      float n = noise();
      lp += 0.1f * (n - lp);
      float hp = n - lp;
      float gate = std::sin(TAU * 55 * t) > 0.2f ? 1.f : 0.3f;
      return hp * gate * std::exp(-t * 8.f) + 0.3f * sq(TAU * 110 * t) * std::exp(-t * 14.f);
    });
  }
  {
    float lp = 0;
    gen(g_sfx[S_BOOM], 0.95f, [&](float t) {
      lp += 0.07f * (noise() - lp);
      return lp * 3.f * std::exp(-t * 4.f) + std::sin(TAU * (40 + 30 * std::exp(-t * 8)) * t) * std::exp(-t * 5.f);
    });
  }
  gen(g_sfx[S_HURT], 0.42f, [](float t) {
    return (sq(TAU * 98 * t) + sq(TAU * 104 * t)) * std::exp(-t * 7.f) * std::min(1.f, t * 200.f);
  });
  gen(g_sfx[S_LEVEL], 1.1f, [](float t) {
    float n[5] = {523.25f, 659.25f, 783.99f, 1046.5f, 1318.5f};
    float v = 0;
    for (int k = 0; k < 5; ++k) v += bell(t - k * 0.075f, n[k], 4.5f);
    return v;
  });
  gen(g_sfx[S_CLICK], 0.045f, [](float t) { return std::sin(TAU * 1800 * t) * std::exp(-t * 120.f); });
  gen(g_sfx[S_HOVER], 0.025f, [](float t) { return std::sin(TAU * 2600 * t) * std::exp(-t * 220.f); });
  gen(g_sfx[S_GROWL], 0.48f, [](float t) {
    float idx = 3.f;
    return std::sin(TAU * 105 * t + idx * std::sin(TAU * 52 * t)) * (0.7f + 0.3f * std::sin(TAU * 18 * t)) *
           std::min(1.f, t * 30.f) * std::exp(-t * 4.5f);
  });
  {
    float lp = 0;
    gen(g_sfx[S_FREEZE], 0.55f, [&](float t) {
      float n = noise();
      lp += 0.2f * (n - lp);
      float hiss = (n - lp) * 0.3f;
      float v = (std::sin(TAU * 2093 * t) + std::sin(TAU * 2637 * t) + std::sin(TAU * 3136 * t)) *
                (0.6f + 0.4f * std::sin(TAU * 25 * t));
      return (v * 0.4f + hiss) * std::exp(-t * 5.5f) * std::min(1.f, t * 100.f);
    });
  }
  {
    float lp = 0;
    uint32_t cs = 99;
    gen(g_sfx[S_FIRE], 0.55f, [&](float t) {
      lp += 0.18f * (noise() - lp);
      cs = cs * 1664525u + 1013904223u;
      float crack = ((cs >> 20) % 900 == 0) ? 1.f : 0.f;
      return (lp * 2.f + crack) * std::exp(-t * 4.f) * std::min(1.f, t * 60.f);
    });
  }
  gen(g_sfx[S_POISON], 0.42f, [](float t) {
    float st[4] = {0.f, 0.08f, 0.16f, 0.26f};
    float v = 0;
    for (int k = 0; k < 4; ++k) {
      float tt = t - st[k];
      if (tt < 0 || tt > 0.07f) continue;
      float f = 300 + k * 60 + tt * 4000;
      v += std::sin(TAU * f * tt) * std::sin(PI * tt / 0.07f);
    }
    return v;
  });
  {
    double ph = 0;
    gen(g_sfx[S_PORTAL], 0.55f, [&](float t) {
      float f = 300.f + 600.f * std::sin(PI * t / 0.55f) + 20 * std::sin(TAU * 11 * t);
      ph += TAU * f / RATE;
      return (float)(std::sin(ph) * std::sin(PI * t / 0.55f));
    });
  }
  gen(g_sfx[S_BLOCK], 0.32f, [](float t) {
    return (std::sin(TAU * 400 * t) + 0.8f * std::sin(TAU * 1083 * t) + 0.6f * std::sin(TAU * 1751 * t) +
            0.4f * std::sin(TAU * 2610 * t)) * std::exp(-t * 16.f) + noise() * std::exp(-t * 120.f) * 0.5f;
  });
  gen(g_sfx[S_WIN], 1.7f, [](float t) {
    float v = bell(t, 523.25f, 3.f) + bell(t - 0.12f, 659.25f, 3.f) + bell(t - 0.24f, 783.99f, 3.f);
    v += 0.8f * (bell(t - 0.42f, 1046.5f, 1.8f) + bell(t - 0.42f, 1318.5f, 1.8f) + bell(t - 0.42f, 1568.f, 1.8f));
    return v;
  });
  gen(g_sfx[S_LOSE], 1.9f, [](float t) {
    float n[4] = {392.f, 311.13f, 261.63f, 130.81f};
    float v = 0;
    for (int k = 0; k < 4; ++k) {
      float tt = t - k * 0.3f;
      if (tt < 0) continue;
      v += std::sin(TAU * n[k] * tt) * (0.8f + 0.2f * std::sin(TAU * 6 * tt)) * std::exp(-tt * (k == 3 ? 1.5f : 4.f)) *
           std::min(1.f, tt * 100.f);
    }
    return v;
  });
  gen(g_sfx[S_BUY], 0.5f, [](float t) {
    return bell(t, 1318.5f, 9.f) * 0.8f + bell(t - 0.08f, 1975.5f, 8.f) * 0.6f;
  });
  gen(g_sfx[S_STAIRS], 0.75f, [](float t) {
    float v = 0;
    for (int k = 0; k < 4; ++k) {
      float tt = t - k * 0.15f;
      if (tt < 0) continue;
      v += std::sin(TAU * (160 - k * 18) * tt) * std::exp(-tt * 30.f) * (1.f - k * 0.15f);
    }
    return v;
  });
  {
    float lp = 0;
    double ph = 0;
    gen(g_sfx[S_SPAWN], 0.5f, [&](float t) {
      lp += (0.02f + 0.3f * t) * (noise() - lp);
      ph += TAU * (200 + 800 * t) / RATE;
      return (float)((lp * 1.5f + 0.4f * std::sin(ph)) * std::sin(PI * t / 0.5f));
    });
  }
  gen(g_sfx[S_TICK], 0.06f, [](float t) { return std::sin(TAU * 1200 * t) * std::exp(-t * 80.f) + noise() * std::exp(-t * 400.f) * 0.3f; });
  gen(g_sfx[S_WALL], 0.09f, [](float t) { return std::sin(TAU * 180 * t) * std::exp(-t * 40.f); });
  {
    float lp = 0;
    gen(g_sfx[S_SHATTER], 0.45f, [&](float t) {
      float n = noise();
      lp += 0.3f * (n - lp);
      return (n - lp) * std::exp(-t * 9.f) + 0.3f * (std::sin(TAU * 3520 * t) + std::sin(TAU * 4186 * t)) * std::exp(-t * 14.f);
    });
  }
  gen(g_sfx[S_FLIP], 0.09f, [](float t) { return noise() * std::exp(-t * 200.f) + std::sin(TAU * 300 * t) * std::exp(-t * 50.f); });
  {
    float lp1 = 0, lp2 = 0;
    gen(g_sfx[S_WHOOSH], 0.36f, [&](float t) {
      float c = 0.45f - 0.4f * std::min(1.f, t / 0.3f);
      lp1 += c * (noise() - lp1);
      lp2 += c * 0.5f * (lp1 - lp2);
      return (lp1 - lp2) * std::sin(PI * t / 0.36f) * 2.f;
    });
  }
  gen(g_sfx[S_CHEST], 0.65f, [](float t) {
    return std::sin(TAU * 90 * t) * std::exp(-t * 20.f) + 0.6f * bell(t - 0.1f, 1568.f, 7.f) + 0.5f * bell(t - 0.18f, 2093.f, 7.f);
  });
  gen(g_sfx[S_DENY], 0.16f, [](float t) { return sq(TAU * 150 * t) * std::exp(-t * 18.f); });
}

// ================================================================ music: synthesis helpers
static float midiHz(float m) { return 440.f * std::pow(2.f, (m - 69.f) / 12.f); }
static float hzMidi(float f) { return 69.f + 12.f * std::log2(f / 440.f); }
static inline int modp(int a, int b) {
  int r = a % b;
  return r < 0 ? r + b : r;
}
static inline int floorDiv(int a, int b) { return a >= 0 ? a / b : -((-a + b - 1) / b); }

static float g_sinT[4098];
static void initSinTable() {
  for (int i = 0; i < 4098; ++i) g_sinT[i] = (float)std::sin(i * (6.283185307179586 / 4096.0));
}
// sine of a phase given in cycles: tsinw needs 0 <= ph < 1, tsin accepts any phase
static inline float tsinw(double ph) {
  double x = ph * 4096.0;
  int i = (int)x;
  float f = (float)(x - i);
  return g_sinT[i] + (g_sinT[i + 1] - g_sinT[i]) * f;
}
static inline float tsin(double ph) { return tsinw(ph - std::floor(ph)); }

struct Rnd {  // fast noise for instrument synthesis (independent of the SFX noise sequence)
  uint32_t s;
  explicit Rnd(uint32_t seed) : s(seed * 2654435761u + 0x6D2B79F5u) {
    if (!s) s = 1;
  }
  inline float operator()() {  // uniform in [-1, 1)
    s ^= s << 13;
    s ^= s >> 17;
    s ^= s << 5;
    return (float)(int32_t)s * (1.f / 2147483648.f);
  }
};

// TPT state-variable filter. bpn() is a band-pass normalised to unity gain at the centre.
struct SVF {
  float ic1 = 0, ic2 = 0, a1 = 1, a2 = 0, a3 = 0, k = 1.4f;
  void set(float fc, float q) {
    fc = clampv(fc, 5.f, RATE * 0.49f);
    float g = std::tan(PI * fc / RATE);
    k = 1.f / q;
    a1 = 1.f / (1.f + g * (g + k));
    a2 = g * a1;
    a3 = g * a2;
  }
  inline void tick(float v0, float& lp, float& bp) {
    float v3 = v0 - ic2;
    float v1 = a1 * ic1 + a2 * v3;
    float v2 = ic2 + a2 * ic1 + a3 * v3;
    ic1 = 2.f * v1 - ic1;
    ic2 = 2.f * v2 - ic2;
    lp = v2;
    bp = v1;
  }
  inline float lp(float v0) {
    float l, b;
    tick(v0, l, b);
    return l;
  }
  inline float bpn(float v0) {
    float l, b;
    tick(v0, l, b);
    return b * k;
  }
  inline float hp(float v0) {
    float l, b;
    tick(v0, l, b);
    return v0 - k * b - l;
  }
};
static inline float blep(float t, float dt) {  // PolyBLEP residual (band-limited saw / pulse)
  if (t < dt) {
    t /= dt;
    return t + t - t * t - 1.f;
  }
  if (t > 1.f - dt) {
    t = (t - 1.f) / dt;
    return t * t + t + t + 1.f;
  }
  return 0.f;
}

// ================================================================ music: instruments
// Each instrument is rendered once into a few zones (pitches) so no note is resampled by more
// than about half an octave. Sustained instruments loop seamlessly: every oscillator and LFO is
// tuned to a whole number of cycles per loop, so the loop region is exactly periodic, and a short
// crossfade hides the non-periodic breath noise. Zones are normalised to equal loudness.
enum {
  IN_HARP, IN_NYLON, IN_EPIANO, IN_MARIMBA, IN_KALIMBA, IN_MUSICBOX, IN_BELL, IN_GLOCK,
  IN_STRINGS, IN_WARMPAD, IN_CHOIR, IN_ORGAN, IN_FLUTE, IN_PULSE, IN_BRASS, IN_CALLIOPE, IN_REED,
  IN_SUBBASS, IN_PBASS, IN_SYNBASS, IN_TUBA, IN_TIMPANI, IN_BUBBLE,
  IN_KICK, IN_SNARE, IN_CLAP, IN_RIM, IN_HATC, IN_HATO, IN_SHAKER, IN_TOM, IN_CRASH, IN_WOOD,
  IN_TICK, IN_ANVIL, IN_TAIKO, IN_TRI, IN_RATCHET, IN_SWELL,
  IN_COUNT,
  IN_NONE = 255
};
struct Zone {
  std::vector<float> d;  // len + 1 samples (the last one is an interpolation guard)
  float base = 60.f;     // MIDI pitch the zone was rendered at
  int len = 0;
  int loopStart = -1;    // >= 0: sustain loop is [loopStart, len)
};
struct Instr {
  const char* name = "";
  Zone z[6];
  int nz = 0;
  float gain = 1.f;  // mix trim on top of the loudness normalisation
  float rel = 0.2f;  // default release (seconds to -60 dB)
  int lo = 0, hi = 127, center = 60;
  bool loop = false, drum = false;
};
static Instr g_ins[IN_COUNT];
struct InsMeta {
  const char* name;
  float gain, rel;
  int lo, hi, center;
};
static const InsMeta INS_META[IN_COUNT] = {
    {"harp", 1.0f, 0.3f, 40, 96, 67},     {"nylon", 1.0f, 0.22f, 40, 84, 62},   {"e.piano", 0.9f, 0.35f, 36, 91, 67},
    {"marimba", 0.95f, 0.2f, 45, 96, 72}, {"kalimba", 0.9f, 0.3f, 55, 93, 74},  {"musicbox", 0.7f, 0.5f, 67, 103, 84},
    {"bell", 0.6f, 0.9f, 45, 100, 79},    {"glock", 0.55f, 0.5f, 72, 108, 88},  {"strings", 0.9f, 0.45f, 36, 91, 67},
    {"warmpad", 0.9f, 0.9f, 36, 84, 60},  {"choir", 0.85f, 0.6f, 43, 84, 64},   {"organ", 0.7f, 0.1f, 31, 91, 60},
    {"flute", 0.85f, 0.12f, 60, 96, 76},  {"pulse", 0.6f, 0.08f, 45, 91, 72},   {"brass", 0.8f, 0.18f, 41, 84, 64},
    {"calliope", 0.7f, 0.1f, 60, 96, 76}, {"reed", 0.7f, 0.12f, 48, 88, 69},    {"subbass", 1.0f, 0.12f, 24, 55, 36},
    {"p.bass", 1.0f, 0.1f, 24, 60, 38},   {"synbass", 1.0f, 0.12f, 24, 60, 38}, {"tuba", 0.9f, 0.1f, 24, 55, 36},
    {"timpani", 0.9f, 0.8f, 36, 55, 43},  {"bubble", 0.6f, 0.1f, 60, 100, 79},  {"kick", 1.f, 0.1f, 0, 127, 60},
    {"snare", 1.f, 0.1f, 0, 127, 60},     {"clap", 1.f, 0.1f, 0, 127, 60},      {"rim", 1.f, 0.1f, 0, 127, 60},
    {"hat", 1.f, 0.05f, 0, 127, 60},      {"openhat", 1.f, 0.05f, 0, 127, 60},  {"shaker", 1.f, 0.05f, 0, 127, 60},
    {"tom", 1.f, 0.1f, 0, 127, 60},       {"crash", 1.f, 0.3f, 0, 127, 60},     {"woodblock", 1.f, 0.05f, 0, 127, 60},
    {"tick", 1.f, 0.05f, 0, 127, 60},     {"anvil", 1.f, 0.3f, 0, 127, 74},     {"taiko", 1.f, 0.2f, 0, 127, 60},
    {"triangle", 1.f, 0.3f, 0, 127, 60},  {"ratchet", 1.f, 0.05f, 0, 127, 60},  {"swell", 1.f, 0.2f, 0, 127, 60},
};

static void zAlloc(Zone& z, int n) {
  z.d.assign((size_t)n + 1, 0.f);
  z.len = n;
  z.loopStart = -1;
}
static float zRms(const Zone& z, int a, int b) {
  a = std::max(0, a);
  b = std::min(z.len, b);
  if (b <= a) return 0.f;
  double s = 0;
  for (int i = a; i < b; ++i) s += (double)z.d[i] * z.d[i];
  return (float)std::sqrt(s / (b - a));
}
static void zScale(Zone& z, float g) {
  for (float& v : z.d) v *= g;
}
static void zNormRms(Zone& z, int a, int b, float target) {
  float r = zRms(z, a, b);
  if (r > 1e-7f) zScale(z, target / r);
}
static void zNormPeak(Zone& z, float target) {
  float pk = 0;
  for (float v : z.d) pk = std::max(pk, std::fabs(v));
  if (pk > 1e-7f) zScale(z, target / pk);
}
static void zFades(Zone& z, int in, int out) {  // declick one-shots
  in = std::min(in, z.len);
  out = std::min(out, z.len);
  for (int i = 0; i < in; ++i) z.d[i] *= (float)i / in;
  for (int i = 0; i < out; ++i) z.d[z.len - 1 - i] *= (float)i / out;
  z.d[z.len] = 0.f;
}
// make [ls, le) a sustain loop: the xf samples before le are crossfaded with the ones before ls
static void zLoop(Zone& z, int ls, int le, int xf) {
  xf = std::min(xf, ls);
  for (int i = 0; i < xf; ++i) {
    float a = (i + 0.5f) / xf;
    z.d[le - xf + i] = z.d[le - xf + i] * (1.f - a) + z.d[ls - xf + i] * a;
  }
  z.d.resize((size_t)le + 1);
  z.d[le] = z.d[ls];
  z.len = le;
  z.loopStart = ls;
}
// loop geometry: the loop lasts exactly loopN samples and holds a whole (even) number of periods
struct LoopGeo {
  int pre, loopN, total, xf;
  double f, L;
};
static LoopGeo loopGeo(float midi, float preSec, float loopSec) {
  LoopGeo g;
  g.pre = (int)(preSec * RATE);
  g.loopN = (int)std::lround(loopSec * RATE);
  g.L = g.loopN / (double)RATE;
  long periods = std::max(1L, std::lround(midiHz(midi) * g.L / 2.0)) * 2;
  g.f = periods / g.L;
  g.total = g.pre + g.loopN;
  g.xf = std::min(g.pre / 2, (int)(0.2f * RATE));
  return g;
}
static double loopSnap(double hz, double L) { return std::round(hz * L) / L; }

// --- Karplus-Strong plucked strings (harp, nylon guitar, plucked bass)
struct KSP {
  float t60, exLP, pick, outLP, body, dur;
};
static void ksZone(Zone& z, float midi, const KSP& p, uint32_t seed) {
  float f0 = midiHz(midi);
  // loop filter y[n+N] = (1-S) y[n] + S y[n+1]: period N - S samples. A small S for high notes keeps
  // them from dying out (plain KS with S = 0.5 loses a lot per period up there).
  float S = clampv(0.5f * 160.f / f0, 0.06f, 0.5f);
  int N = std::max(4, (int)std::lround(RATE / f0 + S));
  float f = RATE / (N - S);
  z.base = hzMidi(f);
  float t60 = p.t60 * std::pow(220.f / f, 0.35f);
  int n = (int)(p.dur * RATE);
  zAlloc(z, n);
  Rnd r(seed);
  std::vector<float> ex(N), buf(N);
  float lp = 0;
  for (int k = 0; k < 2; ++k)
    for (int i = 0; i < N; ++i) {
      lp += p.exLP * (r() - lp);
      ex[i] = lp;
    }
  int M = std::max(1, (int)(p.pick * N));  // pick position: comb-filtered excitation
  float mean = 0;
  for (int i = 0; i < N; ++i) {
    buf[i] = ex[i] - ex[(i - M + N) % N];
    mean += buf[i];
  }
  mean /= N;
  for (float& v : buf) v -= mean;
  float g = std::pow(10.f, -3.f / (t60 * f));
  SVF b1, b2;
  b1.set(105.f, 2.f);
  b2.set(215.f, 2.5f);
  float o = 0;
  int idx = 0;
  for (int i = 0; i < n; ++i) {
    int nx = idx + 1 == N ? 0 : idx + 1;
    float y = buf[idx];
    buf[idx] = ((1.f - S) * buf[idx] + S * buf[nx]) * g;
    idx = nx;
    o += p.outLP * (y - o);
    float v = o;
    if (p.body > 0) v += p.body * (b1.bpn(o) + b2.bpn(o));
    z.d[i] = v;
  }
  zFades(z, 44, n / 5);
  zNormRms(z, 0, RATE / 4, 0.2f);
}

// --- modal synthesis (mallets, bells, music box, timpani, anvil)
struct Partial {
  float ratio, amp, dec;
};
struct ModalP {
  float dur, baseDec, decExp, atkMs, click, clickLP, clickDec, bend, bendRate;
};
static void modalZone(Zone& z, float midi, const Partial* P, int np, const ModalP& m, uint32_t seed) {
  float f = midiHz(midi);
  z.base = midi;
  int n = (int)(m.dur * RATE);
  zAlloc(z, n);
  float sc = std::pow(f / 440.f, m.decExp);
  double ph[8], inc[8];
  float e[8], em[8];
  int use = 0;
  for (int k = 0; k < np && use < 8; ++k) {
    float fk = f * P[k].ratio;
    if (fk > 16000.f) continue;
    ph[use] = 0;
    inc[use] = fk / RATE;
    e[use] = P[k].amp;
    em[use] = std::exp(-P[k].dec * m.baseDec * sc / RATE);
    ++use;
  }
  Rnd r(seed);
  float lp = 0, ce = m.click, cem = std::exp(-m.clickDec / RATE);
  float be = m.bend, bem = std::exp(-m.bendRate / RATE);
  float atk = std::max(1.f, m.atkMs * 0.001f * RATE);
  for (int i = 0; i < n; ++i) {
    float bm = 1.f + be;
    be *= bem;
    float v = 0;
    for (int k = 0; k < use; ++k) {
      v += tsinw(ph[k]) * e[k];
      e[k] *= em[k];
      ph[k] += inc[k] * bm;
      if (ph[k] >= 1.0) ph[k] -= 1.0;
    }
    if (ce > 1e-5f) {
      lp += m.clickLP * (r() - lp);
      v += lp * ce;
      ce *= cem;
    }
    if (i < atk) v *= i / atk;
    z.d[i] = v;
  }
  zFades(z, 4, n / 6);
  zNormRms(z, 0, RATE / 4, 0.2f);
}

// --- FM electric piano (1:1 bark + a fast-decaying high "tine" modulator + a detuned pair)
static void epZone(Zone& z, float midi, float dur) {
  float f = midiHz(midi);
  z.base = midi;
  int n = (int)(dur * RATE);
  zAlloc(z, n);
  double pc = 0, pm = 0, pt = 0, pc2 = 0, pm2 = 0;
  double ic = f / RATE, ic2 = f * 1.0011 / RATE;
  double it = (f * 14.f < 9000.f ? 14.0 : 7.0) * f / RATE;
  float env = 1, em = std::exp(-(0.8f + f / 520.f) / RATE);
  float x1 = 1, xm1 = std::exp(-3.2f / RATE), xt = 1, xmt = std::exp(-32.f / RATE);
  const float inv = 1.f / TAU;
  int atk = (int)(0.0015f * RATE);
  for (int i = 0; i < n; ++i) {
    float mod = tsinw(pm) * (0.3f + 1.5f * x1) * inv + tsinw(pt) * (0.8f * xt * inv);
    float c = tsin(pc + mod);
    float c2 = tsin(pc2 + tsinw(pm2) * (0.25f + 0.8f * x1) * inv);
    float v = (c + 0.45f * c2) * env;
    if (i < atk) v *= (float)i / atk;
    z.d[i] = v;
    env *= em;
    x1 *= xm1;
    xt *= xmt;
    pc += ic;
    if (pc >= 1) pc -= 1;
    pm += ic;
    if (pm >= 1) pm -= 1;
    pt += it;
    if (pt >= 1) pt -= 1;
    pc2 += ic2;
    if (pc2 >= 1) pc2 -= 1;
    pm2 += ic2;
    if (pm2 >= 1) pm2 -= 1;
  }
  zFades(z, 4, n / 6);
  zNormRms(z, 0, RATE / 4, 0.2f);
}

// --- detuned oscillator ensembles (strings, warm pad, brass, pulse lead, reed), looped
struct EnsP {
  int n = 1;
  float cents[8] = {0}, amp[8] = {1, 1, 1, 1, 1, 1, 1, 1}, ratio[8] = {1, 1, 1, 1, 1, 1, 1, 1};
  bool pulse = false;
  float duty = 0.5f;
  float cutAdd = 1000, cutMul = 2, cutMax = 9000, q = 0.7f;
  float envAmt = 0, envDec = 12;    // filter envelope (in multiples of f) and its decay rate
  float scoop = 0, scoopRate = 25;  // initial pitch offset in cents
  float vibRate = 0, vibDepth = 0, vibDelay = 0.2f;
  float atk = 0.05f, loopSec = 1.6f, preSec = 0.6f, hp = 60;
};
static void ensZone(Zone& z, float midi, const EnsP& P, uint32_t seed) {
  LoopGeo g = loopGeo(midi, P.preSec, P.loopSec);
  z.base = hzMidi((float)g.f);
  zAlloc(z, g.total);
  Rnd r(seed);
  double inc[8], ph[8];
  float vph[8], norm = 0;
  long used[8];
  for (int k = 0; k < P.n; ++k) {
    // detune in whole beats per loop (keeps the loop periodic); oscillators of equal ratio get
    // distinct offsets so none collapse onto the same frequency in the low zones
    double fk = g.f * P.ratio[k];
    long mb = std::lround(fk * (std::pow(2.0, P.cents[k] / 1200.0) - 1.0) * g.L);
    int sgn = P.cents[k] < 0 ? -1 : 1;
    if (P.cents[k] != 0 && mb == 0) mb = sgn;
    for (bool clash = true; clash;) {
      clash = false;
      for (int j = 0; j < k; ++j)
        if (P.ratio[j] == P.ratio[k] && used[j] == mb) {
          clash = true;
          mb += sgn;
          break;
        }
    }
    used[k] = mb;
    fk += mb / g.L;
    inc[k] = fk / RATE;
    ph[k] = 0.5 + 0.5 * r();
    vph[k] = 0.5f + 0.5f * r();
    norm += P.amp[k] * P.amp[k];
  }
  norm = 1.f / std::sqrt(norm);
  double vr = P.vibRate > 0 ? loopSnap(P.vibRate, g.L) : 0.0;
  SVF flt;
  float hpS = 0, hpA = 1.f - std::exp(-TAU * P.hp / RATE), cutF = -1;
  for (int i = 0; i < g.total; ++i) {
    float t = (float)i / RATE;
    float vd = P.vibDepth * clampv((t - P.vibDelay) / 0.25f, 0.f, 1.f);
    float scoopM = (P.scoop != 0 && t < 0.5f) ? std::pow(2.f, P.scoop * std::exp(-t * P.scoopRate) / 1200.f) : 1.f;
    double vt = vr * i / RATE;
    float v = 0;
    for (int k = 0; k < P.n; ++k) {
      float vib = vd > 0 ? 1.f + vd * tsin(vt + vph[k]) : 1.f;
      double di = inc[k] * vib * scoopM;
      float t0 = (float)ph[k], dt = (float)di;
      float s = 2.f * t0 - 1.f - blep(t0, dt);
      if (P.pulse) {
        float t1 = t0 + (1.f - P.duty);
        if (t1 >= 1.f) t1 -= 1.f;
        s -= 2.f * t1 - 1.f - blep(t1, dt);
      }
      v += s * P.amp[k];
      ph[k] += di;
      if (ph[k] >= 1.0) ph[k] -= 1.0;
    }
    v *= norm;
    hpS += hpA * (v - hpS);
    v -= hpS;
    if ((i & 31) == 0) {
      float fc = std::min(P.cutMax, P.cutAdd + (float)g.f * (P.cutMul + P.envAmt * std::exp(-t * P.envDec)));
      if (std::fabs(fc - cutF) > 0.5f) {
        flt.set(fc, P.q);
        cutF = fc;
      }
    }
    v = flt.lp(v);
    if (t < P.atk) v *= t / P.atk;
    z.d[i] = v;
  }
  zLoop(z, g.pre, g.total, g.xf);
  zNormRms(z, g.pre, g.total, 0.2f);
}

// --- additive, looped (organ, flute, calliope, sub bass)
struct AddP {
  int n = 1;
  float ratio[10] = {1}, amp[10] = {1};
  float rank2 = 0;  // second rank ~3 cents sharp (each partial beats a whole number of times per loop)
  float breath = 0, breathAt = 2.f, breathQ = 1.5f, hiss = 0;
  float vibRate = 0, vibDepth = 0, vibDelay = 0.2f, trem = 0;
  float atk = 0.03f, chiff = 0, loopSec = 1.5f, preSec = 0.5f;
};
static void addZone(Zone& z, float midi, const AddP& P, uint32_t seed) {
  LoopGeo g = loopGeo(midi, P.preSec, P.loopSec);
  z.base = hzMidi((float)g.f);
  zAlloc(z, g.total);
  Rnd r(seed);
  double inc[20], ph[20];
  float amp[20];
  int m = 0;
  for (int k = 0; k < P.n && m < 18; ++k) {
    double fk = g.f * P.ratio[k];
    if (fk > 15000) continue;
    inc[m] = fk / RATE;
    ph[m] = 0;
    amp[m] = P.amp[k];
    ++m;
    if (P.rank2 > 0) {
      double beats = std::max(1.0, std::round(fk * 0.0017 * g.L));  // ~3 cents, proportional per partial
      inc[m] = (fk + beats / g.L) / RATE;
      ph[m] = 0.5 + 0.5 * r();
      amp[m] = P.amp[k] * P.rank2;
      ++m;
    }
  }
  double vr = P.vibRate > 0 ? loopSnap(P.vibRate, g.L) : 0.0;
  SVF bb, ch;
  bb.set(std::min(12000.f, (float)g.f * P.breathAt), P.breathQ);
  ch.set(std::min(12000.f, (float)g.f * 3.f), 1.f);
  float hs = 0;
  for (int i = 0; i < g.total; ++i) {
    float t = (float)i / RATE;
    float ramp = clampv((t - P.vibDelay) / 0.25f, 0.f, 1.f);
    float lfo = vr > 0 ? tsin(vr * i / RATE) : 0.f;
    float vib = 1.f + P.vibDepth * ramp * lfo;
    float v = 0;
    for (int k = 0; k < m; ++k) {
      v += tsinw(ph[k]) * amp[k];
      ph[k] += inc[k] * vib;
      if (ph[k] >= 1.0) ph[k] -= 1.0;
    }
    v *= 1.f + P.trem * ramp * lfo;
    float nz = r();
    if (P.breath > 0) v += bb.bpn(nz) * P.breath * 6.f;
    if (P.hiss > 0) {
      hs += 0.5f * (nz - hs);
      v += (nz - hs) * P.hiss;
    }
    if (P.chiff > 0 && t < 0.15f) v += ch.bpn(nz) * P.chiff * std::exp(-t * 40.f) * 6.f;
    float a = t < P.atk ? 0.5f - 0.5f * std::cos(PI * t / P.atk) : 1.f;
    z.d[i] = v * a;
  }
  zLoop(z, g.pre, g.total, g.xf);
  zNormRms(z, g.pre, g.total, 0.2f);
}

// --- choir "aah": five detuned glottal saws with their own vibrato, through vowel formants
static void choirZone(Zone& z, float midi, uint32_t seed) {
  LoopGeo g = loopGeo(midi, 0.8f, 2.4f);
  z.base = hzMidi((float)g.f);
  zAlloc(z, g.total);
  Rnd r(seed);
  const int NV = 5;
  const float DET[NV] = {-2, -1, 0, 1, 2}, VRT[NV] = {4.6f, 5.1f, 5.5f, 4.9f, 5.8f}, AMP[NV] = {0.5f, 0.55f, 1.f, 0.55f, 0.5f};
  double inc[NV], ph[NV], vr[NV];
  float vph[NV];
  for (int k = 0; k < NV; ++k) {
    inc[k] = (g.f + DET[k] / g.L) / RATE;
    ph[k] = 0.5 + 0.5 * r();
    vr[k] = loopSnap(VRT[k], g.L);
    vph[k] = 0.5f + 0.5f * r();
  }
  static const float FLO[4] = {570, 840, 2410, 3300}, GLO[4] = {1, 0.45f, 0.12f, 0.06f}, BLO[4] = {70, 80, 120, 150};
  static const float FMI[4] = {730, 1090, 2440, 3400}, GMI[4] = {1, 0.5f, 0.18f, 0.08f}, BMI[4] = {80, 90, 120, 150};
  static const float FHI[4] = {850, 1220, 2810, 3600}, GHI[4] = {1, 0.42f, 0.18f, 0.08f}, BHI[4] = {90, 100, 130, 160};
  const float *F = FMI, *G = GMI, *B = BMI;
  if (midi < 54) F = FLO, G = GLO, B = BLO;
  else if (midi >= 66) F = FHI, G = GHI, B = BHI;
  SVF fm[4], body;
  for (int j = 0; j < 4; ++j) fm[j].set(F[j], F[j] / B[j]);
  body.set(std::min(900.f, (float)g.f * 2.5f), 0.7f);
  for (int i = 0; i < g.total; ++i) {
    float t = (float)i / RATE;
    float vd = 0.0035f * clampv((t - 0.15f) / 0.3f, 0.f, 1.f);
    float src = 0;
    for (int k = 0; k < NV; ++k) {
      float vib = 1.f + vd * tsin(vr[k] * i / RATE + vph[k]);
      double di = inc[k] * vib;
      float t0 = (float)ph[k];
      src += (2.f * t0 - 1.f - blep(t0, (float)di)) * AMP[k];
      ph[k] += di;
      if (ph[k] >= 1.0) ph[k] -= 1.0;
    }
    src = src * 0.6f + r() * 0.03f;
    float v = 0;
    for (int j = 0; j < 4; ++j) v += fm[j].bpn(src) * G[j];
    v += body.lp(src) * 0.25f;
    float a = t < 0.18f ? 0.5f - 0.5f * std::cos(PI * t / 0.18f) : 1.f;
    z.d[i] = v * a;
  }
  zLoop(z, g.pre, g.total, g.xf);
  zNormRms(z, g.pre, g.total, 0.2f);
}

static void tubaZone(Zone& z, float midi) {  // round brass bass for oom-pah
  float f = midiHz(midi);
  z.base = midi;
  int n = (int)(1.3f * RATE);
  zAlloc(z, n);
  double ph = 0, inc = f / RATE;
  SVF flt;
  float cutF = -1;
  for (int i = 0; i < n; ++i) {
    float t = (float)i / RATE;
    float t0 = (float)ph;
    float s = (2.f * t0 - 1.f - blep(t0, (float)inc)) * 0.7f + tsinw(ph) * 0.6f;
    ph += inc;
    if (ph >= 1) ph -= 1;
    if ((i & 31) == 0) {
      float fc = 80.f + f * (1.6f + 4.f * std::exp(-t * 9.f));
      if (std::fabs(fc - cutF) > 0.5f) {
        flt.set(fc, 0.8f);
        cutF = fc;
      }
    }
    z.d[i] = flt.lp(s) * std::min(1.f, t / 0.018f) * std::exp(-t * 2.4f);
  }
  zFades(z, 4, n / 6);
  zNormRms(z, 0, RATE / 4, 0.2f);
}
static void synBassZone(Zone& z, float midi) {  // the original I_BASS timbre
  float f = midiHz(midi);
  z.base = midi;
  int n = (int)(1.6f * RATE);
  zAlloc(z, n);
  double p1 = 0, p2 = 0, p3 = 0;
  for (int i = 0; i < n; ++i) {
    float t = (float)i / RATE;
    z.d[i] = (tsinw(p1) + 0.25f * tsinw(p2) + 0.1f * tsinw(p3)) * std::exp(-t * 1.6f) * std::min(1.f, t * 150.f);
    p1 += f / RATE;
    if (p1 >= 1) p1 -= 1;
    p2 += 2 * f / RATE;
    if (p2 >= 1) p2 -= 1;
    p3 += 3 * f / RATE;
    if (p3 >= 1) p3 -= 1;
  }
  zFades(z, 4, n / 6);
  zNormRms(z, 0, RATE / 4, 0.2f);
}
static void bubbleZone(Zone& z) {  // water drop / slime bubble: sine sweeping upward
  z.base = 72;
  float f0 = midiHz(72);
  int n = (int)(0.2f * RATE);
  zAlloc(z, n);
  double ph = 0;
  for (int i = 0; i < n; ++i) {
    float t = (float)i / RATE;
    ph += f0 * (1.f + 1.2f * (1.f - std::exp(-t * 35.f))) / RATE;
    if (ph >= 1) ph -= 1;
    z.d[i] = tsinw(ph) * std::min(1.f, t / 0.002f) * std::exp(-t * 26.f);
  }
  zFades(z, 2, n / 5);
  zNormRms(z, 0, n / 2, 0.2f);
}
template <class F> static void drumZone(Zone& z, float dur, F fn) {
  int n = (int)(dur * RATE);
  zAlloc(z, n);
  z.base = 60.f;
  for (int i = 0; i < n; ++i) z.d[i] = fn((float)i / RATE);
  zFades(z, 2, std::min(n / 4, RATE / 20));
  zNormPeak(z, 0.9f);
}

static void buildInstruments() {
  for (int i = 0; i < IN_COUNT; ++i) {
    Instr& I = g_ins[i];
    const InsMeta& m = INS_META[i];
    I.name = m.name;
    I.gain = m.gain;
    I.rel = m.rel;
    I.lo = m.lo;
    I.hi = m.hi;
    I.center = m.center;
    I.drum = i >= IN_KICK;
    I.nz = 1;
  }
  // plucked strings
  {
    const float m[] = {43, 55, 67, 79, 91};
    for (int k = 0; k < 5; ++k) ksZone(g_ins[IN_HARP].z[k], m[k], KSP{3.4f, 0.55f - 0.05f * k, 0.13f, 0.62f - 0.04f * k, 0.f, 2.6f - 0.3f * k}, 100 + k);
    g_ins[IN_HARP].nz = 5;
  }
  {
    const float m[] = {40, 52, 64, 76};
    for (int k = 0; k < 4; ++k) ksZone(g_ins[IN_NYLON].z[k], m[k], KSP{2.4f, 0.32f, 0.21f, 0.5f, 0.35f, 2.2f - 0.25f * k}, 110 + k);
    g_ins[IN_NYLON].nz = 4;
  }
  {
    const float m[] = {28, 40, 52};
    for (int k = 0; k < 3; ++k) ksZone(g_ins[IN_PBASS].z[k], m[k], KSP{3.0f, 0.12f, 0.3f, 0.22f, 0.f, 2.2f}, 120 + k);
    g_ins[IN_PBASS].nz = 3;
  }
  // mallets and bells
  {
    const Partial P[] = {{1.f, 1.f, 1.f}, {3.93f, 0.28f, 3.5f}, {9.8f, 0.09f, 8.f}};
    const float m[] = {48, 60, 72, 84}, dur[] = {1.5f, 1.2f, 0.95f, 0.75f};
    for (int k = 0; k < 4; ++k) modalZone(g_ins[IN_MARIMBA].z[k], m[k], P, 3, ModalP{dur[k], 3.2f, 0.4f, 1.2f, 0.25f, 0.3f, 250.f, 0.f, 0.f}, 130 + k);
    g_ins[IN_MARIMBA].nz = 4;
  }
  {
    const Partial P[] = {{1.f, 1.f, 1.f}, {5.4f, 0.24f, 5.f}, {11.8f, 0.07f, 9.f}};
    const float m[] = {60, 72, 84}, dur[] = {1.9f, 1.6f, 1.3f};
    for (int k = 0; k < 3; ++k) modalZone(g_ins[IN_KALIMBA].z[k], m[k], P, 3, ModalP{dur[k], 1.5f, 0.3f, 0.6f, 0.35f, 0.5f, 400.f, 0.012f, 40.f}, 140 + k);
    g_ins[IN_KALIMBA].nz = 3;
  }
  {
    const Partial P[] = {{1.f, 1.f, 1.f}, {2.f, 0.1f, 1.6f}, {6.27f, 0.26f, 3.5f}, {17.55f, 0.07f, 7.f}};
    const float m[] = {72, 84, 96}, dur[] = {2.2f, 1.8f, 1.4f};
    for (int k = 0; k < 3; ++k) modalZone(g_ins[IN_MUSICBOX].z[k], m[k], P, 4, ModalP{dur[k], 1.4f, 0.35f, 0.4f, 0.3f, 0.85f, 900.f, 0.f, 0.f}, 150 + k);
    g_ins[IN_MUSICBOX].nz = 3;
  }
  {
    const Partial P[] = {{1.f, 1.f, 1.f}, {2.76f, 0.5f, 2.5f}, {5.4f, 0.25f, 4.f}};
    const float m[] = {57, 69, 81, 93}, dur[] = {3.6f, 3.2f, 2.4f, 1.8f};
    for (int k = 0; k < 4; ++k) modalZone(g_ins[IN_BELL].z[k], m[k], P, 3, ModalP{dur[k], 1.556f, 0.5f, 2.5f, 0.f, 0.f, 0.f, 0.f, 0.f}, 160 + k);
    g_ins[IN_BELL].nz = 4;
  }
  {
    const Partial P[] = {{1.f, 1.f, 1.f}, {2.76f, 0.35f, 2.2f}, {5.4f, 0.18f, 3.5f}, {8.93f, 0.08f, 5.f}};
    const float m[] = {84, 96}, dur[] = {1.6f, 1.3f};
    for (int k = 0; k < 2; ++k) modalZone(g_ins[IN_GLOCK].z[k], m[k], P, 4, ModalP{dur[k], 1.6f, 0.3f, 0.3f, 0.15f, 0.9f, 1200.f, 0.f, 0.f}, 170 + k);
    g_ins[IN_GLOCK].nz = 2;
  }
  {
    const Partial P[] = {{1.f, 1.f, 1.f}, {1.5f, 0.45f, 1.3f}, {1.98f, 0.3f, 1.6f}, {2.44f, 0.15f, 2.f}};
    const float m[] = {41, 50};
    for (int k = 0; k < 2; ++k) modalZone(g_ins[IN_TIMPANI].z[k], m[k], P, 4, ModalP{2.2f, 2.4f, 0.3f, 2.f, 0.6f, 0.06f, 30.f, 0.03f, 18.f}, 180 + k);
    g_ins[IN_TIMPANI].nz = 2;
  }
  {
    const float m[] = {48, 60, 72, 84}, dur[] = {2.8f, 2.4f, 1.9f, 1.5f};
    for (int k = 0; k < 4; ++k) epZone(g_ins[IN_EPIANO].z[k], m[k], dur[k]);
    g_ins[IN_EPIANO].nz = 4;
  }
  // sustained ensembles
  {
    EnsP p;
    p.n = 7;
    const float c[7] = {-12, -7, -3, 0, 3, 7, 12}, a[7] = {0.35f, 0.42f, 0.5f, 1.f, 0.5f, 0.42f, 0.35f};
    for (int k = 0; k < 7; ++k) p.cents[k] = c[k], p.amp[k] = a[k];
    p.cutAdd = 1300;
    p.cutMul = 2.6f;
    p.q = 0.65f;
    p.vibRate = 5.2f;
    p.vibDepth = 0.0022f;
    p.vibDelay = 0.15f;
    p.atk = 0.08f;
    p.loopSec = 3.0f;
    p.preSec = 0.7f;
    p.hp = 90;
    const float m[] = {48, 60, 72};
    for (int k = 0; k < 3; ++k) ensZone(g_ins[IN_STRINGS].z[k], m[k], p, 200 + k);
    g_ins[IN_STRINGS].nz = 3;
  }
  {
    EnsP p;
    p.n = 6;
    const float c[6] = {-9, -4, 0, 4, 9, 0}, a[6] = {0.45f, 0.55f, 1.f, 0.55f, 0.45f, 0.3f};
    for (int k = 0; k < 6; ++k) p.cents[k] = c[k], p.amp[k] = a[k];
    p.ratio[5] = 2.f;
    p.cutAdd = 350;
    p.cutMul = 1.3f;
    p.q = 0.55f;
    p.atk = 0.2f;
    p.loopSec = 3.0f;
    p.preSec = 0.6f;
    const float m[] = {48, 60};
    for (int k = 0; k < 2; ++k) ensZone(g_ins[IN_WARMPAD].z[k], m[k], p, 210 + k);
    g_ins[IN_WARMPAD].nz = 2;
  }
  {
    EnsP p;
    p.n = 3;
    p.cents[0] = -5;
    p.cents[2] = 5;
    p.amp[0] = p.amp[2] = 0.55f;
    p.cutAdd = 250;
    p.cutMul = 2.4f;
    p.envAmt = 5.f;
    p.envDec = 14.f;
    p.q = 0.9f;
    p.scoop = -35;
    p.scoopRate = 30;
    p.vibRate = 5.f;
    p.vibDepth = 0.003f;
    p.vibDelay = 0.35f;
    p.atk = 0.03f;
    p.loopSec = 1.6f;
    p.preSec = 0.9f;
    const float m[] = {48, 60, 72};
    for (int k = 0; k < 3; ++k) ensZone(g_ins[IN_BRASS].z[k], m[k], p, 220 + k);
    g_ins[IN_BRASS].nz = 3;
  }
  {
    EnsP p;
    p.n = 2;
    p.cents[1] = 6;
    p.amp[1] = 0.6f;
    p.pulse = true;
    p.duty = 0.3f;
    p.cutAdd = 900;
    p.cutMul = 4;
    p.cutMax = 7000;
    p.q = 0.7f;
    p.vibRate = 5.5f;
    p.vibDepth = 0.0035f;
    p.vibDelay = 0.25f;
    p.atk = 0.01f;
    p.loopSec = 1.4f;
    p.preSec = 0.8f;
    const float m[] = {48, 60, 72};
    for (int k = 0; k < 3; ++k) ensZone(g_ins[IN_PULSE].z[k], m[k], p, 230 + k);
    g_ins[IN_PULSE].nz = 3;
  }
  {
    EnsP p;
    p.n = 4;
    const float c[4] = {-9, 0, 9, 0}, a[4] = {0.65f, 1.f, 0.65f, 0.35f};
    for (int k = 0; k < 4; ++k) p.cents[k] = c[k], p.amp[k] = a[k];
    p.ratio[3] = 0.5f;
    p.pulse = true;
    p.duty = 0.4f;
    p.cutAdd = 1100;
    p.cutMul = 3;
    p.q = 0.8f;
    p.atk = 0.035f;
    p.loopSec = 1.6f;
    p.preSec = 0.5f;
    const float m[] = {48, 60, 72};
    for (int k = 0; k < 3; ++k) ensZone(g_ins[IN_REED].z[k], m[k], p, 240 + k);
    g_ins[IN_REED].nz = 3;
  }
  // additive
  {
    AddP p;
    p.n = 7;
    const float r[7] = {0.5f, 1, 2, 3, 4, 6, 8}, a[7] = {0.3f, 1, 0.55f, 0.2f, 0.28f, 0.08f, 0.1f};
    for (int k = 0; k < 7; ++k) p.ratio[k] = r[k], p.amp[k] = a[k];
    p.rank2 = 0.3f;
    p.chiff = 0.12f;
    p.atk = 0.025f;
    p.loopSec = 3.0f;
    p.preSec = 0.4f;
    const float m[] = {36, 48, 60, 72};
    for (int k = 0; k < 4; ++k) addZone(g_ins[IN_ORGAN].z[k], m[k], p, 250 + k);
    g_ins[IN_ORGAN].nz = 4;
  }
  {
    AddP p;
    p.n = 3;
    const float r[3] = {1, 2, 3}, a[3] = {1, 0.09f, 0.035f};
    for (int k = 0; k < 3; ++k) p.ratio[k] = r[k], p.amp[k] = a[k];
    p.breath = 0.07f;
    p.hiss = 0.012f;
    p.vibRate = 5.f;
    p.vibDepth = 0.005f;
    p.vibDelay = 0.25f;
    p.trem = 0.03f;
    p.atk = 0.07f;
    p.chiff = 0.25f;
    p.loopSec = 1.5f;
    p.preSec = 0.8f;
    const float m[] = {60, 72, 84};
    for (int k = 0; k < 3; ++k) addZone(g_ins[IN_FLUTE].z[k], m[k], p, 260 + k);
    g_ins[IN_FLUTE].nz = 3;
  }
  {
    AddP p;
    p.n = 4;
    const float r[4] = {1, 2, 3, 4}, a[4] = {1, 0.4f, 0.22f, 0.08f};
    for (int k = 0; k < 4; ++k) p.ratio[k] = r[k], p.amp[k] = a[k];
    p.breath = 0.12f;
    p.hiss = 0.02f;
    p.vibRate = 6.4f;
    p.vibDepth = 0.009f;
    p.vibDelay = 0.f;
    p.trem = 0.05f;
    p.atk = 0.03f;
    p.chiff = 0.2f;
    p.loopSec = 1.2f;
    p.preSec = 0.5f;
    const float m[] = {60, 72, 84};
    for (int k = 0; k < 3; ++k) addZone(g_ins[IN_CALLIOPE].z[k], m[k], p, 270 + k);
    g_ins[IN_CALLIOPE].nz = 3;
  }
  {
    AddP p;
    p.n = 3;
    const float r[3] = {1, 2, 3}, a[3] = {1, 0.18f, 0.05f};
    for (int k = 0; k < 3; ++k) p.ratio[k] = r[k], p.amp[k] = a[k];
    p.atk = 0.012f;
    p.loopSec = 1.0f;
    p.preSec = 0.3f;
    const float m[] = {28, 40};
    for (int k = 0; k < 2; ++k) addZone(g_ins[IN_SUBBASS].z[k], m[k], p, 280 + k);
    g_ins[IN_SUBBASS].nz = 2;
  }
  {
    const float m[] = {48, 60, 72};
    for (int k = 0; k < 3; ++k) choirZone(g_ins[IN_CHOIR].z[k], m[k], 290 + k);
    g_ins[IN_CHOIR].nz = 3;
  }
  {
    const float m[] = {29, 41, 53};
    for (int k = 0; k < 3; ++k) tubaZone(g_ins[IN_TUBA].z[k], m[k]);
    g_ins[IN_TUBA].nz = 3;
  }
  synBassZone(g_ins[IN_SYNBASS].z[0], 33);
  synBassZone(g_ins[IN_SYNBASS].z[1], 45);
  g_ins[IN_SYNBASS].nz = 2;
  bubbleZone(g_ins[IN_BUBBLE].z[0]);
  // drum kit and percussion (all rendered at "MIDI 60"; pitch by playing other notes)
  {
    double ph = 0;
    Rnd r(11);
    float lp = 0;
    drumZone(g_ins[IN_KICK].z[0], 0.45f, [&](float t) {
      ph += (46.f + 95.f * std::exp(-t * 38.f)) / RATE;
      if (ph >= 1) ph -= 1;
      lp += 0.5f * (r() - lp);
      return tsinw(ph) * std::exp(-t * 7.5f) * std::min(1.f, t * 2000.f) + lp * 0.25f * std::exp(-t * 350.f);
    });
  }
  {
    Rnd r(12);
    SVF bp, hp;
    bp.set(2600.f, 0.8f);
    hp.set(5000.f, 0.7f);
    double p1 = 0, p2 = 0;
    drumZone(g_ins[IN_SNARE].z[0], 0.32f, [&](float t) {
      p1 += 188.0 / RATE;
      if (p1 >= 1) p1 -= 1;
      p2 += 335.0 / RATE;
      if (p2 >= 1) p2 -= 1;
      float tone = (tsinw(p1) + 0.5f * tsinw(p2)) * std::exp(-t * 20.f) * 0.55f;
      float n = r();
      float nz = (bp.bpn(n) + 0.35f * hp.hp(n)) * std::exp(-t * 15.f);
      return (tone + nz) * std::min(1.f, t * 3000.f);
    });
  }
  {
    Rnd r(13);
    SVF bp;
    bp.set(1250.f, 1.4f);
    drumZone(g_ins[IN_CLAP].z[0], 0.3f, [&](float t) {
      static const float TK[4] = {0.f, 0.010f, 0.021f, 0.033f};
      float e = 0;
      for (float x : TK)
        if (t >= x) e += std::exp(-(t - x) * 220.f);
      if (t >= 0.033f) e += 0.5f * std::exp(-(t - 0.033f) * 18.f);
      return bp.bpn(r()) * e;
    });
  }
  {
    Rnd r(14);
    SVF bp;
    bp.set(3200.f, 2.f);
    double p = 0;
    drumZone(g_ins[IN_RIM].z[0], 0.08f, [&](float t) {
      p += 1700.0 / RATE;
      if (p >= 1) p -= 1;
      return (tsinw(p) * 0.5f + bp.bpn(r()) * 0.8f) * std::exp(-t * 75.f);
    });
  }
  auto hat = [](Zone& z, float dur, float dec, uint32_t seed) {
    Rnd r(seed);
    SVF hp, lp;
    hp.set(7000.f, 0.7f);
    lp.set(12000.f, 0.7f);
    const double fr[6] = {3140, 4270, 5510, 6620, 7890, 9370};
    double ph[6] = {0, 0, 0, 0, 0, 0};
    drumZone(z, dur, [&](float t) {
      float m = 0;
      for (int k = 0; k < 6; ++k) {
        ph[k] += fr[k] / RATE;
        if (ph[k] >= 1) ph[k] -= 1;
        m += ph[k] < 0.5 ? 1.f : -1.f;
      }
      float v = hp.hp(r() * 0.8f + m * 0.12f);
      return lp.lp(v) * std::exp(-t * dec) * std::min(1.f, t * 4000.f);
    });
  };
  hat(g_ins[IN_HATC].z[0], 0.09f, 55.f, 15);
  hat(g_ins[IN_HATO].z[0], 0.7f, 6.f, 16);
  {
    Rnd r(17);
    SVF bp;
    bp.set(6200.f, 1.2f);
    drumZone(g_ins[IN_SHAKER].z[0], 0.14f, [&](float t) { return bp.bpn(r()) * std::min(1.f, t / 0.012f) * std::exp(-t * 28.f); });
  }
  {
    Rnd r(18);
    double ph = 0;
    float lp = 0;
    drumZone(g_ins[IN_TOM].z[0], 0.6f, [&](float t) {
      ph += 128.f * (1.f + 0.3f * std::exp(-t * 20.f)) / RATE;
      if (ph >= 1) ph -= 1;
      lp += 0.2f * (r() - lp);
      return tsinw(ph) * std::exp(-t * 6.5f) + lp * 0.25f * std::exp(-t * 35.f);
    });
  }
  {
    Rnd r(19);
    SVF hp, lp;
    hp.set(3500.f, 0.7f);
    lp.set(10000.f, 0.7f);
    const double fr[6] = {2350, 3670, 4910, 6230, 7580, 8810};
    double ph[6] = {0, 0, 0, 0, 0, 0};
    drumZone(g_ins[IN_CRASH].z[0], 2.2f, [&](float t) {
      float m = 0;
      for (int k = 0; k < 6; ++k) {
        ph[k] += fr[k] / RATE;
        if (ph[k] >= 1) ph[k] -= 1;
        m += tsinw(ph[k]);
      }
      return lp.lp(hp.hp(r() * 0.7f + m * 0.08f)) * std::exp(-t * 2.3f) * std::min(1.f, t * 1000.f);
    });
  }
  {
    Rnd r(20);
    double p1 = 0, p2 = 0;
    drumZone(g_ins[IN_WOOD].z[0], 0.12f, [&](float t) {
      p1 += 920.0 / RATE;
      if (p1 >= 1) p1 -= 1;
      p2 += 2230.0 / RATE;
      if (p2 >= 1) p2 -= 1;
      return (tsinw(p1) + 0.35f * tsinw(p2)) * std::exp(-t * 48.f) + r() * 0.3f * std::exp(-t * 900.f);
    });
  }
  {
    Rnd r(21);
    SVF bp;
    bp.set(4500.f, 3.f);
    double p = 0;
    drumZone(g_ins[IN_TICK].z[0], 0.05f, [&](float t) {
      p += 2750.0 / RATE;
      if (p >= 1) p -= 1;
      return bp.bpn(r()) * 0.8f * std::exp(-t * 320.f) + tsinw(p) * 0.5f * std::exp(-t * 140.f);
    });
  }
  {
    const Partial P[] = {{1.f, 1.f, 1.f}, {2.41f, 0.65f, 1.3f}, {3.87f, 0.45f, 1.6f}, {5.36f, 0.3f, 2.f}, {7.12f, 0.18f, 2.4f}};
    modalZone(g_ins[IN_ANVIL].z[0], 74.f, P, 5, ModalP{1.4f, 2.5f, 0.f, 0.3f, 0.6f, 0.9f, 120.f, 0.f, 0.f}, 22);
    zNormPeak(g_ins[IN_ANVIL].z[0], 0.9f);
  }
  {
    Rnd r(23);
    double ph = 0;
    float lp = 0;
    SVF bp;
    bp.set(1200.f, 1.f);
    drumZone(g_ins[IN_TAIKO].z[0], 1.0f, [&](float t) {
      ph += 58.f * (1.f + 0.45f * std::exp(-t * 18.f)) / RATE;
      if (ph >= 1) ph -= 1;
      float n = r();
      lp += 0.08f * (n - lp);
      return tsinw(ph) * std::exp(-t * 4.5f) + lp * 0.6f * std::exp(-t * 22.f) + bp.bpn(n) * 0.15f * std::exp(-t * 80.f);
    });
  }
  {
    double p1 = 0, p2 = 0, p3 = 0;
    drumZone(g_ins[IN_TRI].z[0], 1.5f, [&](float t) {
      p1 += 3400.0 / RATE;
      if (p1 >= 1) p1 -= 1;
      p2 += 5780.0 / RATE;
      if (p2 >= 1) p2 -= 1;
      p3 += 8130.0 / RATE;
      if (p3 >= 1) p3 -= 1;
      return (tsinw(p1) + 0.45f * tsinw(p2) + 0.25f * tsinw(p3)) * std::exp(-t * 3.f) * std::min(1.f, t * 2000.f);
    });
  }
  {
    Rnd r(24);
    SVF bp;
    bp.set(2800.f, 1.5f);
    drumZone(g_ins[IN_RATCHET].z[0], 0.34f, [&](float t) {
      float e = 0;
      for (int k = 0; k < 11; ++k) {
        float x = t - k * 0.028f;
        if (x >= 0) e += std::exp(-x * 260.f) * (1.f - k * 0.05f);
      }
      return bp.bpn(r()) * e;
    });
  }
  {  // reverse cymbal swell that lands on a downbeat
    const Zone& c = g_ins[IN_CRASH].z[0];
    Zone& z = g_ins[IN_SWELL].z[0];
    int n = (int)(1.5f * RATE);
    zAlloc(z, n);
    z.base = 60;
    for (int i = 0; i < n; ++i) {
      float a = (float)i / n;
      z.d[i] = c.d[n - 1 - i] * a * a;
    }
    for (int i = 0; i < 200; ++i) z.d[n - 1 - i] *= i / 200.f;
    zNormPeak(z, 0.9f);
  }
  for (int i = 0; i < IN_COUNT; ++i) g_ins[i].loop = g_ins[i].z[0].loopStart >= 0;
}

// ================================================================ music: theory
enum { MD_ION, MD_DOR, MD_PHR, MD_LYD, MD_MIX, MD_AEO, MD_HARM, MD_PHRDOM, MD_WHOLE, MD_HUNG, MD_COUNT };
static const int8_t MODES[MD_COUNT][8] = {
    {7, 0, 2, 4, 5, 7, 9, 11}, {7, 0, 2, 3, 5, 7, 9, 10}, {7, 0, 1, 3, 5, 7, 8, 10}, {7, 0, 2, 4, 6, 7, 9, 11},
    {7, 0, 2, 4, 5, 7, 9, 10}, {7, 0, 2, 3, 5, 7, 8, 10}, {7, 0, 2, 3, 5, 7, 8, 11}, {7, 0, 1, 4, 5, 7, 8, 10},
    {6, 0, 2, 4, 6, 8, 10, 0}, {7, 0, 2, 3, 6, 7, 8, 11}};
static const char* const MODE_NAME[MD_COUNT] = {"ionian", "dorian", "phrygian", "lydian", "mixolydian",
                                                "aeolian", "harmonic-minor", "phrygian-dom", "whole-tone", "hungarian-minor"};
static const char* const NOTE_NAME[12] = {"C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B"};
enum { Q_MAJ, Q_MIN, Q_DIM, Q_AUG, Q_SUS2, Q_SUS4, Q_MAJ7, Q_MIN7, Q_DOM7, Q_HDIM, Q_DIM7, Q_ADD9, Q_MADD9, Q_MIN9, Q_DOM9, Q_POW, Q_MAJ6, Q_MIN6, Q_COUNT };
static const int8_t QUAL[Q_COUNT][6] = {{3, 0, 4, 7},     {3, 0, 3, 7},      {3, 0, 3, 6},        {3, 0, 4, 8},        {3, 0, 2, 7},
                                        {3, 0, 5, 7},     {4, 0, 4, 7, 11},  {4, 0, 3, 7, 10},    {4, 0, 4, 7, 10},    {4, 0, 3, 6, 10},
                                        {4, 0, 3, 6, 9},  {4, 0, 4, 7, 14},  {4, 0, 3, 7, 14},    {5, 0, 3, 7, 10, 14}, {5, 0, 4, 7, 10, 14},
                                        {2, 0, 7},        {4, 0, 4, 7, 9},   {4, 0, 3, 7, 9}};
static const char* const QSUF[Q_COUNT] = {"", "", "o", "+", "sus2", "sus4", "M7", "7", "7", "h7", "o7", "add9", "add9", "9", "9", "5", "6", "6"};
static bool qMinor(int q) {
  return q == Q_MIN || q == Q_DIM || q == Q_MIN7 || q == Q_HDIM || q == Q_DIM7 || q == Q_MADD9 || q == Q_MIN9 || q == Q_MIN6;
}
struct Chord {
  int8_t root;  // semitones above the key
  uint8_t q;
  uint8_t beats;
};
struct Prog {
  Chord c[16] = {};
  int n = 0, beats = 0;
};
// "i bVI bIII bVII", "IM7 vi7 ii7 V7*2 I+*2" ... numerals are relative to the MAJOR scale of the
// key (so minor keys write bIII, bVI, bVII); case gives major/minor, suffixes set the quality,
// "*N" sets the length in beats (default: one bar).
static Prog parseProg(const char* s, int bpb) {
  static const char* const RN[7] = {"I", "II", "III", "IV", "V", "VI", "VII"};
  static const int RS[7] = {0, 2, 4, 5, 7, 9, 11};
  Prog p;
  const char* c = s;
  while (*c && p.n < 16) {
    while (*c == ' ') ++c;
    if (!*c) break;
    int acc = 0;
    if (*c == 'b') acc = -1, ++c;
    else if (*c == '#') acc = 1, ++c;
    bool upper = *c == 'I' || *c == 'V';
    char num[8];
    int nl = 0;
    while ((*c == 'I' || *c == 'V' || *c == 'i' || *c == 'v') && nl < 7) num[nl++] = (char)std::toupper((unsigned char)*c++);
    num[nl] = 0;
    int deg = -1;
    for (int k = 0; k < 7; ++k)
      if (!strcmp(num, RN[k])) deg = k;
    const char* sf = c;
    while (*c && *c != ' ' && *c != '*') ++c;
    std::string suf(sf, c);
    int beats = bpb;
    if (*c == '*') {
      ++c;
      beats = std::max(1, atoi(c));
      while (std::isdigit((unsigned char)*c)) ++c;
    }
    if (deg < 0) continue;
    int q = upper ? Q_MAJ : Q_MIN;
    if (suf == "7") q = upper ? Q_DOM7 : Q_MIN7;
    else if (suf == "M7") q = upper ? Q_MAJ7 : Q_MIN7;
    else if (suf == "o") q = Q_DIM;
    else if (suf == "o7") q = Q_DIM7;
    else if (suf == "h7") q = Q_HDIM;
    else if (suf == "+") q = Q_AUG;
    else if (suf == "sus2") q = Q_SUS2;
    else if (suf == "sus4") q = Q_SUS4;
    else if (suf == "add9") q = upper ? Q_ADD9 : Q_MADD9;
    else if (suf == "9") q = upper ? Q_DOM9 : Q_MIN9;
    else if (suf == "5") q = Q_POW;
    else if (suf == "6") q = upper ? Q_MAJ6 : Q_MIN6;
    p.c[p.n++] = Chord{(int8_t)modp(RS[deg] + acc, 12), (uint8_t)q, (uint8_t)beats};
    p.beats += beats;
  }
  if (p.n == 0) p.c[p.n++] = Chord{0, Q_MIN, (uint8_t)bpb}, p.beats = bpb;
  int rem = p.beats % bpb;
  if (rem) p.c[p.n - 1].beats = (uint8_t)(p.c[p.n - 1].beats + bpb - rem), p.beats += bpb - rem;
  return p;
}
static void progText(const Prog& p, char* out, int cap) {
  static const char* const UP[12] = {"I", "bII", "II", "bIII", "III", "IV", "bV", "V", "bVI", "VI", "bVII", "VII"};
  int w = 0;
  out[0] = 0;
  for (int i = 0; i < p.n && w < cap - 12; ++i) {
    const Chord& c = p.c[i];
    char num[8];
    snprintf(num, sizeof num, "%s", UP[modp(c.root, 12)]);
    if (qMinor(c.q))
      for (char* x = num; *x; ++x)
        if (*x != 'b') *x = (char)std::tolower((unsigned char)*x);
    w += snprintf(out + w, cap - w, "%s%s%s", i ? " " : "", num, QSUF[c.q]);
  }
}
static int chordPcs(const Chord& c, int key, int* out) {
  const int8_t* q = QUAL[c.q];
  for (int i = 0; i < q[0]; ++i) out[i] = modp(key + c.root + q[1 + i], 12);
  return q[0];
}
static uint16_t chordMask(const Chord& c, int key) {
  int p[6];
  int n = chordPcs(c, key, p);
  uint16_t m = 0;
  for (int i = 0; i < n; ++i) m |= (uint16_t)(1 << p[i]);
  return m;
}
// pitch set for melodies over a chord: the scale, with chromatic chord tones replacing their
// clashing scale neighbours (so a borrowed V in minor gives harmonic minor, etc.)
static uint16_t chordScale(uint16_t sm, uint16_t cm) {
  uint16_t r = sm | cm;
  for (int pc = 0; pc < 12; ++pc)
    if ((cm & (1 << pc)) && !(sm & (1 << pc)))
      for (int d = -1; d <= 1; d += 2) {
        int q = modp(pc + d, 12);
        if (!(cm & (1 << q))) r &= (uint16_t)~(1 << q);
      }
  return r;
}
static int snapTo(int midi, uint16_t mask, int dir) {
  if (!mask) return midi;
  int s = dir >= 0 ? 1 : -1;
  for (int d = 0; d < 12; ++d) {
    int a = midi + d * s, b = midi - d * s;
    if (mask & (1 << modp(a, 12))) return a;
    if (mask & (1 << modp(b, 12))) return b;
  }
  return midi;
}
static int nearestPc(int pc, int target) { return target + modp(pc - modp(target, 12) + 6, 12) - 6; }
// close-position voicing in [lo, hi] with the least movement from the previous voicing
static int voiceChord(const Chord& c, int key, int lo, int hi, int nv, const int* prev, int prevN, int* out, Rng& r) {
  int pcs[6];
  int n = chordPcs(c, key, pcs), use[6], nu = 0;
  if (n <= nv) {
    for (int i = 0; i < n; ++i) use[nu++] = pcs[i];
  } else {
    static const int PRI[5] = {0, 1, 3, 4, 2};  // root, third, seventh, ninth, fifth
    for (int i = 0; i < 5 && nu < nv; ++i)
      if (PRI[i] < n) use[nu++] = pcs[PRI[i]];
  }
  int best[6], bn = 0;
  float bc = 1e9f;
  for (int ir = 0; ir < nu; ++ir)
    for (int oct = 0; oct <= 12; oct += 12) {
      int v[6], cnt = nu;
      v[0] = lo + oct + modp(use[ir] - (lo + oct), 12);
      for (int k = 1; k < nu; ++k) {
        int m = v[k - 1] + 1;
        v[k] = m + modp(use[(ir + k) % nu] - m, 12);
      }
      if (v[nu - 1] > hi) continue;
      if (cnt < nv && v[0] + 12 <= hi && v[0] + 12 > v[cnt - 1]) v[cnt++] = v[0] + 12;
      float cost = 0;
      if (prevN > 0) {
        for (int i = 0; i < cnt; ++i) {
          int dmin = 99;
          for (int j = 0; j < prevN; ++j) dmin = std::min(dmin, std::abs(v[i] - prev[j]));
          cost += dmin;
        }
      } else {
        cost = std::fabs((v[0] + v[cnt - 1]) * 0.5f - (lo + hi) * 0.5f);
      }
      cost += r.f() * 1.5f;
      if (cost < bc) {
        bc = cost;
        bn = cnt;
        for (int i = 0; i < cnt; ++i) best[i] = v[i];
      }
    }
  if (!bn) {
    for (int i = 0; i < nu; ++i) best[i] = lo + modp(use[i] - lo, 12);
    bn = nu;
    std::sort(best, best + bn);
  }
  for (int i = 0; i < bn; ++i) out[i] = best[i];
  return bn;
}
static int chordNotes(const Chord& c, int key, int lo, int hi, int* out, int maxn) {
  uint16_t m = chordMask(c, key);
  int k = 0;
  for (int x = lo; x <= hi && k < maxn; ++x)
    if (m & (1 << modp(x, 12))) out[k++] = x;
  return k;
}
enum { A_UP, A_DOWN, A_UPDOWN, A_BROKEN, A_PEDAL, A_RANDOM, A_ALBERTI };
static const char* const ARP_NAME[7] = {"up", "down", "updown", "broken", "pedal", "random", "alberti"};
static int arpOrder(int style, int k, int n) {
  if (n <= 1) return 0;
  switch (style) {
    case A_DOWN: return n - 1 - k % n;
    case A_UPDOWN: {
      int p = 2 * n - 2, x = k % p;
      return x < n ? x : p - x;
    }
    case A_BROKEN: return ((k % 2 == 0) ? k / 2 : k / 2 + 2) % n;
    case A_PEDAL: return (k % 2 == 0) ? 0 : 1 + (k / 2) % (n - 1);
    case A_ALBERTI: {
      static const int P[4] = {0, 2, 1, 2};
      return std::min(n - 1, P[k % 4]);
    }
    case A_RANDOM: return (int)(((uint32_t)k * 2654435761u >> 7) % (uint32_t)n);
    default: return k % n;
  }
}

// ================================================================ music: rhythm tables
enum { DK, DS, DC, DR, DH, DO, DP, DT, DX, DW, DI, DA, DB, DG, DQ, DV, D_COUNT };
enum { TR_PAD, TR_BASS, TR_ARP, TR_LEAD, TR_LEAD2, TR_COMP, TR_DRUM, TR_HAT, TR_FX, TR_DRONE, TR_COUNT };
static const int TRACK_CAP[TR_COUNT] = {12, 2, 10, 4, 4, 12, 18, 2, 10, 4};
struct DrumDef {
  uint8_t ins;
  float gain, pan, send;
  uint8_t track;
};
static const DrumDef DRUM[D_COUNT] = {
    {IN_KICK, 0.62f, 0.f, 0.02f, TR_DRUM},     {IN_SNARE, 0.4f, 0.06f, 0.18f, TR_DRUM}, {IN_CLAP, 0.36f, -0.08f, 0.2f, TR_DRUM},
    {IN_RIM, 0.3f, 0.18f, 0.14f, TR_DRUM},     {IN_HATC, 0.2f, 0.3f, 0.05f, TR_HAT},    {IN_HATO, 0.17f, 0.3f, 0.08f, TR_HAT},
    {IN_SHAKER, 0.2f, -0.35f, 0.08f, TR_DRUM}, {IN_TOM, 0.42f, 0.f, 0.15f, TR_DRUM},    {IN_CRASH, 0.24f, -0.25f, 0.2f, TR_DRUM},
    {IN_WOOD, 0.28f, 0.28f, 0.12f, TR_DRUM},   {IN_TICK, 0.24f, 0.4f, 0.06f, TR_DRUM},  {IN_ANVIL, 0.26f, -0.2f, 0.25f, TR_DRUM},
    {IN_TAIKO, 0.62f, 0.f, 0.18f, TR_DRUM},    {IN_TRI, 0.15f, 0.42f, 0.25f, TR_DRUM},  {IN_RATCHET, 0.22f, -0.3f, 0.12f, TR_DRUM},
    {IN_SWELL, 0.26f, 0.f, 0.35f, TR_FX},
};
enum {
  G_NONE, G_SHAKER, G_SOFTKICK, G_LOFI, G_BACKBEAT, G_DRIVE, G_BREAK, G_TRIBAL, G_CLOCK, G_CLOCK2, G_CLOCK3,
  G_ANVIL, G_FORGE, G_EPIC, G_HEART, G_TOMS, G_WALTZ, G_CIRCUS, G_CIRCUS2, G_SWING, G_BRUSH, G_SPARKLE,
  G_SPARKLE2, G_MARCH, G_MARCH2, G_SLIME, G_SLIMELO, G_FUNGAL, G_FUNGAL2, G_T128, G_T128B, G_T128C,
  G_TIPTOE, G_TEMPLE, G_BOSSA, G_ICE, G_COUNT
};
struct Lane {
  uint8_t drum;
  const char* p;  // 'X' accent, 'x' normal, 'o' soft, 'g' ghost; any length (mapped onto the bar grid)
};
struct GrooveDef {
  const char* name;
  Lane l[6];
};
static const GrooveDef GROOVE[G_COUNT] = {
    {"none", {}},
    {"shaker", {{DP, "x.o.x.o.x.o.x.o."}}},
    {"softkick", {{DK, "x.......x......."}, {DP, "..o...o...o...o."}}},
    {"lofi", {{DK, "x......x..x....."}, {DS, "....x.......x..."}, {DH, "x.o.x.o.x.o.x.o."}}},
    {"backbeat", {{DK, "x.......x.x....."}, {DS, "....x.......x..."}, {DH, "x.x.x.x.x.x.x.x."}}},
    {"drive", {{DK, "x...x...x...x..."}, {DS, "....x.......x..."}, {DH, "xoxoxoxoxoxoxoxo"}, {DO, "..............x."}}},
    {"break", {{DK, "x.....x...x.x..."}, {DS, "....x..g.g..x..g"}, {DH, "x.xox.xox.xox.xo"}}},
    {"tribal", {{DT, "x..x..x...x.x..."}, {DK, "x.....x.x......."}, {DB, "x.......x......."}, {DS, "............x..."}}},
    {"clock", {{DI, "XoxoXoxoXoxoXoxo"}, {DW, "x......x..x....."}}},
    {"clock2", {{DI, "XoxoXoxoXoxoXoxo"}, {DW, "x......x..x....."}, {DK, "x.......x......."}, {DR, "....x.......x..."}}},
    {"clock3", {{DI, "XxxxXxxxXxxxXxxx"}, {DK, "x...x...x...x..."}, {DS, "....x.......x..."}, {DW, "x..x..x...x..x.."}, {DQ, "..............x."}}},
    {"anvil", {{DA, "....x.......x..."}, {DB, "x.......x......."}}},
    {"forge", {{DK, "x..x..x.x..x..x."}, {DA, "....X.......X..."}, {DH, "x.x.x.x.x.x.x.x."}, {DT, "..........x.x.x."}}},
    {"epic", {{DK, "x..x..x.x..x..x."}, {DS, "....X.......X..."}, {DB, "x.......x......."}, {DH, "x.x.x.x.x.x.x.x."}}},
    {"heart", {{DB, "x..o............"}, {DP, "........o......."}}},
    {"toms", {{DT, "x.......x..x...."}, {DB, "x...........x..."}, {DK, "x..............."}}},
    {"waltz", {{DK, "x..........."}, {DR, "....x...x..."}, {DP, "..o...o...o."}}},
    {"circus", {{DK, "x..........."}, {DS, "....o...o..."}, {DW, "x.......x..."}, {DG, "x..........."}}},
    {"circus2", {{DK, "x.......x..."}, {DS, "....x...x.x."}, {DW, "x.x.x.x.x.x."}, {DH, "..x...x...x."}, {DX, "x..........."}}},
    {"swing", {{DK, "x.......x......."}, {DR, "....x.......x..."}, {DH, "x.x.x.x.x.x.x.x."}}},
    {"brush", {{DP, "x.o.x.o.x.o.x.o."}, {DR, "....x.......x..."}}},
    {"sparkle", {{DP, "xoxoxoxoxoxoxoxo"}, {DC, "....x.......x..."}, {DK, "x.......x......."}, {DG, "x..............."}}},
    {"sparkle2", {{DP, "xoxoxoxoxoxoxoxo"}, {DC, "....x.......x..."}, {DK, "x...x...x...x..."}, {DO, "..x...x...x...x."}}},
    {"march", {{DS, "x..o..o.x.o.x..o"}, {DK, "x.......x......."}}},
    {"march2", {{DS, "x.oox.o.x.oox.xo"}, {DK, "x...x...x...x..."}, {DH, "..x...x...x...x."}}},
    {"slime", {{DK, "x..x....x.x....."}, {DC, "....x.......x..."}, {DP, "..x...x...x...x."}}},
    {"slimelo", {{DC, "....x.......x..."}, {DP, "x.o.x.o.x.o.x.o."}}},
    {"fungal", {{DW, "x..x..x...x.x..."}, {DP, "x.o.x.o.x.o.x.o."}}},
    {"fungal2", {{DW, "x..x..x...x.x..."}, {DP, "x.o.x.o.x.o.x.o."}, {DK, "x.......x.x....."}, {DR, "....x.......x..."}}},
    {"triplet", {{DP, "x.ox.ox.ox.o"}, {DK, "x.....x....."}}},
    {"triplet2", {{DK, "x.....x.x..."}, {DR, "...x.....x.."}, {DP, "x.ox.ox.ox.o"}}},
    {"triplet3", {{DK, "x..x..x.xx.."}, {DS, "...x.....x.."}, {DH, "xoxxoxxoxxox"}, {DT, "..........xx"}}},
    {"tiptoe", {{DW, "x.....x.....x..."}, {DR, "....x.......x..."}, {DI, "..x...x...x...x."}}},
    {"temple", {{DB, "x..............."}, {DG, "........x......."}}},
    {"bossa", {{DR, "x..x..x...x..x.."}, {DP, "xoxoxoxoxoxoxoxo"}, {DK, "x..x....x..x...."}}},
    {"ice", {{DB, "x.......x......."}, {DP, "..o...o...o...o."}, {DG, "x..............."}}},
};
// bass rhythm: R root, F fifth, O octave, T third, A approach to the next chord, X root/fifth
// alternating per bar (oom-pah), lower case = softer, '-' = note off
enum { B_WHOLE, B_HALF, B_ROOT4, B_PULSE8, B_OCT8, B_SYNC, B_WALK, B_GALLOP, B_ARP, B_BOUNCE, B_CLOCK, B_HEART, B_TIPTOE, B_OOM, B_WALTZ, B_BOSSA, B_LOFI, B_COUNT };
static const char* const BASSPAT[B_COUNT] = {
    "R...............", "R.......F.......", "R...R...R...R...", "R.R.R.R.R.R.R.R.", "R.O.R.O.R.O.R.O.", "R..R..R.....F...",
    "R...T...F...A...", "R.RRR.RRR.RRR.RR", "R...F...O...F...", "R.-O.-R.-O.-R.F.", "R.R.-.RR.R-.R.F.", "R..r............",
    "R.-.F.-.R.-.F.-.", "X...........",     "R...F...F...",     "R..F..R...R..F..", "R......R..R....."};
static const char* const BASSNAME[B_COUNT] = {"whole", "half", "quarters", "eighths", "octaves", "sync", "walk", "gallop", "arp",
                                              "bounce", "clock", "heart", "tiptoe", "oom", "waltz", "bossa", "lofi"};
enum { C_OFFBEAT, C_CHARL, C_STRUM, C_PULSE8, C_HALF, C_STAB, C_LOFI, C_BOSSA, C_TIPTOE, C_PAH, C_SUST, C_COUNT };
static const char* const COMPPAT[C_COUNT] = {"..x...x...x...x.", "x.....x.........", "x.....x...x.x...", "x.x.x.x.x.x.x.x.",
                                             "x.......x.......", "x..x..x...x.x...", "x......x..x.....", "x..x..x...x..x..",
                                             "x...x...x...x...", "....x...x...",     "x..............."};
static const char* const COMPNAME[C_COUNT] = {"offbeat", "charleston", "strum", "pulse", "half", "stab", "lofi", "bossa", "tiptoe", "pah", "sustain"};
static const bool COMP_SHORT[C_COUNT] = {true, false, false, true, false, true, false, false, true, true, false};
static int patStrength(char c) {
  switch (c) {
    case 'X': return 5;
    case '.': return 0;
    case '-': return 1;
    case 'g': return 2;
    case 'o': case 'r': case 'f': return 3;
    default: return 4;
  }
}
static void mapPat(const char* p, int steps, char* out) {  // any-length pattern -> bar grid
  for (int i = 0; i < steps; ++i) out[i] = '.';
  out[steps] = 0;
  if (!p) return;
  int L = (int)strlen(p);
  for (int i = 0; i < L; ++i) {
    if (p[i] == '.') continue;
    int g = (int)std::floor((double)i * steps / L + 0.5);
    if (g >= steps) continue;
    if (patStrength(p[i]) > patStrength(out[g])) out[g] = p[i];
  }
}

// ================================================================ music: styles ("tracks")
enum : uint32_t {
  F_STRICT = 1u << 0,     // mechanical timing (no humanising)
  F_OSTINATO = 1u << 1,   // arpeggios become a fixed repeating cell (often cross-rhythmic)
  F_ANVIL = 1u << 2,      // tuned anvil strikes
  F_BUBBLES = 1u << 3,    // bubbling blips
  F_SPARKLE = 1u << 4,    // high glock / music-box glints with echoes
  F_TOLL = 1u << 5,       // low bell toll every other bar
  F_DRONE = 1u << 6,      // choir drone on the tonic in quiet parts, drone bass
  F_TRITONE = 1u << 7,    // the drone adds the tritone
  F_WONKY = 1u << 8,      // detuned notes + a slow global pitch wobble (warped tape / carousel)
  F_CHROMATIC = 1u << 9,  // chromatic approach notes in melodies
  F_LURCH = 1u << 10,     // tempo lurches between sections, ritardando at section ends
  F_MODUP = 1u << 11,     // key change up for the last big section
  F_HARM3 = 1u << 12,     // melodies harmonised in thirds
  F_TIMP = 1u << 13,      // timpani on section downbeats and in fights
  F_SWELL = 1u << 14,     // reverse-cymbal swells into bigger sections
  F_DRIPS = 1u << 15,     // water drips with echoes
  F_GRACE = 1u << 16,     // grace notes on sustained leads
  F_SHORT = 1u << 17,     // short songs (~30-40 s), then a new variation
  F_STACCATO = 1u << 18,  // short, detached melody notes
  F_JAZZY = 1u << 19,     // random 7ths on chords
  F_PADPULSE = 1u << 20,  // pads pulse in eighths in fights
  F_FANFARE = 1u << 21,   // brass stabs on big section downbeats
  F_NODRUMS = 1u << 22,   // never any drum kit
};
struct Style {
  const char* name = "";
  std::vector<int> keys, modes;
  float bpmLo = 80, bpmHi = 90;
  int beats = 4, sub = 4;
  float swLo = 0, swHi = 0;
  bool sw16 = false;
  std::vector<const char*> sA, sB, sX;
  std::vector<Prog> A, B, X;
  std::vector<uint8_t> pad, bass, arp, lead, lead2, comp;
  std::vector<uint8_t> gLo, gMid, gHi, bLo, bMid, bHi, arpSt, compPat;
  float density = 0.5f, space = 0.2f, verb = 0.3f, dly = 0.12f, ebias = 0.f, drumAt = 0.5f;
  float arpProb = 0.65f, compProb = 0.6f, leadProb = 0.9f;
  int motifBars = 1;
  uint32_t flags = 0;
  float gain = 1.f;  // loudness trim (set from the table at the end of buildStyles)
};
static const int NMOODS = 20;
static std::vector<Style> g_styles[NMOODS];
static Style& defStyle(int mood, const char* name) {
  g_styles[mood].emplace_back();
  Style& s = g_styles[mood].back();
  s.name = name;
  return s;
}
static void buildStyles() {
  for (auto& v : g_styles) v.clear();
  // ------------------------------------------------ 0: title
  {
    Style& s = defStyle(0, "harp overture");
    s.keys = {57, 55, 62, 60};
    s.modes = {MD_AEO, MD_AEO, MD_DOR};
    s.bpmLo = 70, s.bpmHi = 82;
    s.sA = {"i bVI bIII bVII", "i bVII bVI bVII", "i iv bVI bVII", "i bIII bVII iv", "i bVI iv bVII", "i v bVI bIII"};
    s.sB = {"bVI bVII i i", "iv bVI bVII i", "bIII bVII bVI V", "bVI bIII bVII bVII", "iv i bVI V"};
    s.sX = {"i bVI bVII i", "i iv V i"};
    s.pad = {IN_STRINGS, IN_WARMPAD, IN_CHOIR};
    s.bass = {IN_PBASS, IN_SUBBASS};
    s.arp = {IN_HARP, IN_NYLON, IN_HARP};
    s.lead = {IN_FLUTE, IN_EPIANO, IN_STRINGS};
    s.lead2 = {IN_MUSICBOX, IN_BELL, IN_GLOCK};
    s.gLo = {G_NONE, G_SOFTKICK}, s.gMid = {G_SOFTKICK, G_LOFI}, s.gHi = {G_BACKBEAT};
    s.bLo = {B_WHOLE, B_HALF}, s.bMid = {B_HALF, B_SYNC}, s.bHi = {B_PULSE8};
    s.arpSt = {A_UP, A_UPDOWN, A_BROKEN};
    s.density = 0.45f, s.space = 0.25f, s.verb = 0.4f, s.dly = 0.18f, s.drumAt = 0.6f, s.arpProb = 0.75f;
  }
  {
    Style& s = defStyle(0, "lofi dungeon");
    s.keys = {62, 60, 57};
    s.modes = {MD_DOR, MD_AEO};
    s.bpmLo = 74, s.bpmHi = 86;
    s.swLo = 0.3f, s.swHi = 0.45f, s.sw16 = true;
    s.sA = {"i7 IV7 i7 IV7", "iv7 bVII7 bIIIM7 bVIM7", "i7 bVIIM7 bVIM7 V7", "i9 iv7 i9 iv7"};
    s.sB = {"bVIM7 bVII i7 i7", "iv7 v7 i7 i7", "bIIIM7 bVIM7 iv7 V7"};
    s.sX = {"i7 bVI7 bVII7 i7"};
    s.pad = {IN_WARMPAD};
    s.bass = {IN_SUBBASS, IN_PBASS};
    s.arp = {IN_KALIMBA, IN_MARIMBA};
    s.lead = {IN_EPIANO, IN_FLUTE, IN_KALIMBA};
    s.lead2 = {IN_BELL, IN_GLOCK, IN_MARIMBA};
    s.comp = {IN_EPIANO};
    s.compPat = {C_LOFI, C_HALF, C_CHARL};
    s.gLo = {G_SHAKER}, s.gMid = {G_LOFI}, s.gHi = {G_LOFI, G_BACKBEAT};
    s.bLo = {B_WHOLE, B_LOFI}, s.bMid = {B_LOFI, B_SYNC}, s.bHi = {B_LOFI};
    s.flags = F_JAZZY;
    s.density = 0.5f, s.verb = 0.3f, s.dly = 0.25f, s.arpProb = 0.45f, s.drumAt = 0.45f, s.compProb = 0.8f;
  }
  {
    Style& s = defStyle(0, "music box waltz");
    s.keys = {64, 59, 57};
    s.modes = {MD_AEO, MD_HARM};
    s.beats = 3, s.sub = 2;
    s.bpmLo = 92, s.bpmHi = 108;
    s.sA = {"i i iv iv bVII bVII bIII V", "i iv V i", "i bVI bIII V", "i iv bVII bIII"};
    s.sB = {"bVI bVI iv iv V V i i", "iv i V i", "bIII bVII iv V"};
    s.sX = {"i iv V i"};
    s.pad = {IN_STRINGS, IN_CHOIR};
    s.bass = {IN_PBASS};
    s.arp = {IN_HARP, IN_MUSICBOX};
    s.lead = {IN_MUSICBOX, IN_GLOCK, IN_FLUTE};
    s.lead2 = {IN_STRINGS, IN_FLUTE, IN_BELL};
    s.comp = {IN_HARP};
    s.compPat = {C_PAH};
    s.gLo = {G_NONE}, s.gMid = {G_WALTZ}, s.gHi = {G_WALTZ};
    s.bLo = {B_OOM}, s.bMid = {B_OOM, B_WALTZ}, s.bHi = {B_WALTZ};
    s.arpSt = {A_UP, A_UPDOWN};
    s.motifBars = 2;
    s.verb = 0.45f, s.dly = 0.2f, s.drumAt = 0.7f;
  }
  // ------------------------------------------------ 1: the Upper Halls
  {
    Style& s = defStyle(1, "stone halls");
    s.keys = {64, 62, 57};
    s.modes = {MD_AEO, MD_DOR};
    s.bpmLo = 88, s.bpmHi = 100;
    s.sA = {"i bVII bVI bVII", "i iv bVI v", "i bIII bVII iv", "i bVI bIII bVII", "i v iv i"};
    s.sB = {"bVI bVII i i", "iv v bVI bVII", "bIII bVII iv V", "bVI iv bVII V"};
    s.sX = {"i bVI bVII i", "i bII bVII i", "i iv V i"};
    s.pad = {IN_STRINGS, IN_WARMPAD};
    s.bass = {IN_PBASS, IN_SYNBASS};
    s.arp = {IN_NYLON, IN_HARP, IN_PULSE};
    s.lead = {IN_FLUTE, IN_PULSE, IN_STRINGS, IN_BRASS};
    s.lead2 = {IN_BELL, IN_STRINGS, IN_MARIMBA};
    s.gLo = {G_SOFTKICK, G_SHAKER}, s.gMid = {G_BACKBEAT}, s.gHi = {G_DRIVE, G_BREAK};
    s.bLo = {B_HALF, B_WHOLE}, s.bMid = {B_SYNC, B_PULSE8}, s.bHi = {B_PULSE8, B_GALLOP};
    s.verb = 0.3f, s.dly = 0.12f, s.drumAt = 0.5f;
  }
  {
    Style& s = defStyle(1, "torchlit dorian");
    s.keys = {62, 64, 67};
    s.modes = {MD_DOR};
    s.bpmLo = 80, s.bpmHi = 92;
    s.swLo = 0.1f, s.swHi = 0.25f;
    s.sA = {"i IV i IV", "i bVII IV i", "i ii bIII IV", "i IV bVII i"};
    s.sB = {"bIII IV i i", "bVII IV i v", "bIII bVII IV IV"};
    s.sX = {"i bVII bVI bVII", "i iv V i"};
    s.pad = {IN_ORGAN, IN_STRINGS};
    s.bass = {IN_PBASS};
    s.arp = {IN_HARP, IN_MARIMBA};
    s.lead = {IN_FLUTE, IN_EPIANO, IN_REED};
    s.lead2 = {IN_KALIMBA, IN_BELL};
    s.comp = {IN_NYLON};
    s.compPat = {C_STRUM, C_OFFBEAT};
    s.gLo = {G_SHAKER}, s.gMid = {G_LOFI, G_BACKBEAT}, s.gHi = {G_DRIVE};
    s.bLo = {B_HALF}, s.bMid = {B_SYNC, B_WALK}, s.bHi = {B_PULSE8};
    s.verb = 0.32f, s.dly = 0.15f;
  }
  // ------------------------------------------------ 2: the Fungal Lair
  {
    Style& s = defStyle(2, "mushroom groove");
    s.keys = {62, 64, 67};
    s.modes = {MD_DOR};
    s.bpmLo = 92, s.bpmHi = 106;
    s.swLo = 0.2f, s.swHi = 0.4f;
    s.sA = {"i IV i IV", "i7 IV7 i7 IV7", "i ii i IV", "i bIII IV i"};
    s.sB = {"bVII IV i i", "iv7 bVII7 i7 i7", "bIII IV bVII IV"};
    s.sX = {"i iv bVII i", "i bVI bVII i"};
    s.pad = {IN_WARMPAD, IN_CHOIR};
    s.bass = {IN_PBASS};
    s.arp = {IN_MARIMBA, IN_KALIMBA};
    s.lead = {IN_MARIMBA, IN_FLUTE, IN_KALIMBA};
    s.lead2 = {IN_KALIMBA, IN_NYLON, IN_MARIMBA};
    s.comp = {IN_MARIMBA, IN_NYLON};
    s.compPat = {C_OFFBEAT, C_CHARL};
    s.gLo = {G_FUNGAL}, s.gMid = {G_FUNGAL2}, s.gHi = {G_BREAK, G_FUNGAL2};
    s.bLo = {B_HALF, B_SYNC}, s.bMid = {B_SYNC, B_BOUNCE}, s.bHi = {B_OCT8};
    s.verb = 0.25f, s.dly = 0.1f, s.drumAt = 0.5f, s.density = 0.55f;
  }
  {
    Style& s = defStyle(2, "spore drift");
    s.keys = {62, 57};
    s.modes = {MD_DOR, MD_AEO};
    s.sub = 3;
    s.bpmLo = 70, s.bpmHi = 80;
    s.sA = {"i IV i IV", "i v IV i", "i bVII IV IV"};
    s.sB = {"bVII IV i i", "bIII IV i i"};
    s.sX = {"i iv bVII i"};
    s.pad = {IN_CHOIR, IN_WARMPAD};
    s.bass = {IN_SUBBASS, IN_PBASS};
    s.arp = {IN_MARIMBA, IN_KALIMBA};
    s.lead = {IN_FLUTE, IN_KALIMBA};
    s.lead2 = {IN_MARIMBA, IN_BELL};
    s.gLo = {G_T128}, s.gMid = {G_T128B}, s.gHi = {G_T128C};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF}, s.bHi = {B_PULSE8};
    s.verb = 0.35f, s.dly = 0.2f;
  }
  // ------------------------------------------------ 3: the Drowned Halls
  {
    Style& s = defStyle(3, "sunken echoes");
    s.keys = {64, 66, 61};
    s.modes = {MD_AEO, MD_DOR};
    s.sub = 3;
    s.bpmLo = 60, s.bpmHi = 70;
    s.sA = {"i bVI bIII bVII", "i7 bVIM7 iv7 v7", "i9 bVIM7 bIIIM7 bVII", "i v bVI bIII"};
    s.sB = {"bVIM7 bVII i i", "iv7 bVIM7 i i", "bIIIM7 bVIM7 iv7 V"};
    s.sX = {"i bVI iv V", "i bII i bVII"};
    s.pad = {IN_CHOIR, IN_WARMPAD, IN_STRINGS};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_EPIANO, IN_HARP};
    s.lead = {IN_EPIANO, IN_FLUTE, IN_BELL};
    s.lead2 = {IN_BELL, IN_GLOCK, IN_HARP};
    s.gLo = {G_NONE}, s.gMid = {G_HEART, G_T128}, s.gHi = {G_T128C};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF, B_HEART}, s.bHi = {B_PULSE8};
    s.flags = F_DRIPS | F_SWELL;
    s.verb = 0.55f, s.dly = 0.4f, s.space = 0.3f, s.drumAt = 0.65f, s.arpProb = 0.8f;
  }
  {
    Style& s = defStyle(3, "tidal lydian");
    s.keys = {60, 62};
    s.modes = {MD_LYD};
    s.bpmLo = 64, s.bpmHi = 74;
    s.sA = {"IM7 II IM7 II", "IM7 vi7 II IV", "IM7 II iii7 II"};
    s.sB = {"iii7 II IM7 IM7", "vi7 V IV IV"};
    s.sX = {"vi IV II V"};
    s.pad = {IN_WARMPAD, IN_CHOIR};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_HARP, IN_EPIANO};
    s.lead = {IN_FLUTE, IN_MUSICBOX};
    s.lead2 = {IN_BELL, IN_GLOCK};
    s.gLo = {G_NONE}, s.gMid = {G_SHAKER}, s.gHi = {G_SOFTKICK, G_LOFI};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF}, s.bHi = {B_SYNC};
    s.flags = F_DRIPS;
    s.verb = 0.55f, s.dly = 0.35f, s.space = 0.3f, s.drumAt = 0.65f;
  }
  // ------------------------------------------------ 4: the Clockwork Mines
  {
    Style& s = defStyle(4, "gearworks");
    s.keys = {60, 62, 57};
    s.modes = {MD_AEO, MD_HARM};
    s.bpmLo = 104, s.bpmHi = 118;
    s.sA = {"i i bVI bVII", "i bVII bVI V", "i iv bVII bIII", "i bVI bIII bVII"};
    s.sB = {"iv iv i i", "bVI bVI V V", "iv bVII bIII bVI"};
    s.sX = {"i bII i bII", "i bVI V V", "i iv V i"};
    s.pad = {IN_WARMPAD, IN_ORGAN, IN_STRINGS};
    s.bass = {IN_PBASS, IN_SYNBASS};
    s.arp = {IN_MUSICBOX, IN_MARIMBA, IN_PULSE, IN_GLOCK};
    s.lead = {IN_PULSE, IN_MARIMBA, IN_MUSICBOX};
    s.lead2 = {IN_GLOCK, IN_BELL};
    s.gLo = {G_CLOCK}, s.gMid = {G_CLOCK2}, s.gHi = {G_CLOCK3};
    s.bLo = {B_HALF, B_CLOCK}, s.bMid = {B_CLOCK}, s.bHi = {B_CLOCK, B_PULSE8};
    s.flags = F_STRICT | F_OSTINATO;
    s.verb = 0.18f, s.dly = 0.1f, s.drumAt = 0.3f, s.arpProb = 0.9f;
  }
  {
    Style& s = defStyle(4, "mechanism");
    s.keys = {62, 60};
    s.modes = {MD_MIX};
    s.bpmLo = 96, s.bpmHi = 110;
    s.sA = {"I bVII IV I", "I bVII I bVII", "I IV bVII I"};
    s.sB = {"IV IV I I", "bVI bVII I I"};
    s.sX = {"i bVII bVI bVII", "i bII i bII"};
    s.pad = {IN_ORGAN, IN_STRINGS};
    s.bass = {IN_PBASS};
    s.arp = {IN_MARIMBA, IN_MUSICBOX};
    s.lead = {IN_PULSE, IN_EPIANO};
    s.lead2 = {IN_GLOCK};
    s.gLo = {G_CLOCK}, s.gMid = {G_CLOCK2}, s.gHi = {G_CLOCK3};
    s.bLo = {B_CLOCK}, s.bMid = {B_CLOCK}, s.bHi = {B_PULSE8};
    s.flags = F_STRICT | F_OSTINATO;
    s.verb = 0.2f, s.dly = 0.1f, s.drumAt = 0.3f, s.arpProb = 0.9f;
  }
  // ------------------------------------------------ 5: the Crypt
  {
    Style& s = defStyle(5, "funeral organ");
    s.keys = {61, 60, 62};
    s.modes = {MD_HARM, MD_AEO};
    s.bpmLo = 56, s.bpmHi = 66;
    s.sA = {"i iv i V", "i bVI iv V", "i iv bVI V", "i bII i V"};
    s.sB = {"iv i V i", "bVI iv bII V", "iv bVI V V"};
    s.sX = {"i bII i V", "i bVI bII V"};
    s.pad = {IN_ORGAN, IN_CHOIR};
    s.bass = {IN_SUBBASS, IN_SYNBASS};
    s.arp = {IN_HARP, IN_EPIANO};
    s.lead = {IN_EPIANO, IN_MUSICBOX, IN_CHOIR, IN_STRINGS};
    s.lead2 = {IN_BELL, IN_CHOIR};
    s.gLo = {G_NONE}, s.gMid = {G_HEART}, s.gHi = {G_TOMS};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF, B_HEART}, s.bHi = {B_PULSE8};
    s.flags = F_TOLL | F_DRONE;
    s.verb = 0.55f, s.dly = 0.15f, s.space = 0.3f, s.drumAt = 0.7f, s.arpProb = 0.5f;
  }
  {
    Style& s = defStyle(5, "candle procession");
    s.keys = {62, 60};
    s.modes = {MD_HARM};
    s.beats = 3, s.sub = 2;
    s.bpmLo = 72, s.bpmHi = 84;
    s.sA = {"i iv V i", "i bVI iv V"};
    s.sB = {"iv i V i", "bVI iv V V"};
    s.sX = {"i bII V i"};
    s.pad = {IN_CHOIR, IN_ORGAN};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_HARP};
    s.lead = {IN_MUSICBOX, IN_STRINGS};
    s.lead2 = {IN_BELL};
    s.gLo = {G_NONE}, s.gMid = {G_WALTZ}, s.gHi = {G_WALTZ};
    s.bLo = {B_OOM}, s.bMid = {B_OOM}, s.bHi = {B_WALTZ};
    s.flags = F_TOLL;
    s.motifBars = 2;
    s.verb = 0.55f, s.dly = 0.15f, s.drumAt = 0.75f;
  }
  // ------------------------------------------------ 6: the Ember Forge
  {
    Style& s = defStyle(6, "anvil march");
    s.keys = {64, 66, 62};
    s.modes = {MD_PHR, MD_PHRDOM};
    s.bpmLo = 104, s.bpmHi = 120;
    s.sA = {"i bII i bII", "i bII bIII bII", "i bVII bVI bII", "i bII bVII i"};
    s.sB = {"bVI bVII i i", "bII bII i i", "iv bII i i"};
    s.sX = {"i bII i bII", "I bII I bII"};
    s.pad = {IN_STRINGS, IN_BRASS, IN_WARMPAD};
    s.bass = {IN_SYNBASS, IN_PBASS};
    s.arp = {IN_PULSE, IN_NYLON};
    s.lead = {IN_BRASS, IN_PULSE, IN_STRINGS};
    s.lead2 = {IN_STRINGS, IN_CHOIR};
    s.comp = {IN_BRASS};
    s.compPat = {C_STAB};
    s.gLo = {G_ANVIL}, s.gMid = {G_FORGE}, s.gHi = {G_TRIBAL, G_EPIC};
    s.bLo = {B_HALF, B_PULSE8}, s.bMid = {B_PULSE8}, s.bHi = {B_GALLOP, B_PULSE8};
    s.flags = F_ANVIL | F_OSTINATO;
    s.verb = 0.25f, s.dly = 0.08f, s.drumAt = 0.35f, s.compProb = 0.5f;
  }
  {
    Style& s = defStyle(6, "magma gallop");
    s.keys = {64, 57};
    s.modes = {MD_HARM, MD_PHRDOM};
    s.sub = 3;
    s.bpmLo = 96, s.bpmHi = 110;
    s.sA = {"i bVI V i", "i iv V i", "i bVI bVII V"};
    s.sB = {"iv bVI V V", "bVI bII V V"};
    s.sX = {"i bII V i"};
    s.pad = {IN_CHOIR, IN_STRINGS};
    s.bass = {IN_SYNBASS};
    s.arp = {IN_PULSE, IN_HARP};
    s.lead = {IN_BRASS, IN_STRINGS};
    s.lead2 = {IN_CHOIR};
    s.comp = {IN_BRASS};
    s.compPat = {C_STAB};
    s.gLo = {G_ANVIL}, s.gMid = {G_T128B}, s.gHi = {G_T128C};
    s.bLo = {B_HALF}, s.bMid = {B_GALLOP}, s.bHi = {B_GALLOP};
    s.flags = F_ANVIL;
    s.verb = 0.28f, s.dly = 0.08f, s.drumAt = 0.35f, s.compProb = 0.4f;
  }
  // ------------------------------------------------ 7: the Frozen Vaults
  {
    Style& s = defStyle(7, "glass silence");
    s.keys = {59, 66, 64};
    s.modes = {MD_AEO, MD_DOR};
    s.bpmLo = 60, s.bpmHi = 72;
    s.sA = {"i9 bVIM7 bIIIM7 bVII", "i bVI bIII bVII", "i7 iv7 i7 bVIIM7", "i bIIIM7 bVIM7 bVII"};
    s.sB = {"bVIM7 bVIIsus4 i i", "iv7 bVIM7 bVII i", "bIIIM7 bVIIsus4 bVIM7 bVIM7"};
    s.sX = {"i bVI iv V", "i bII i V"};
    s.pad = {IN_STRINGS, IN_CHOIR, IN_WARMPAD};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_MUSICBOX, IN_GLOCK, IN_HARP};
    s.lead = {IN_MUSICBOX, IN_BELL, IN_FLUTE};
    s.lead2 = {IN_GLOCK, IN_BELL, IN_HARP};
    s.gLo = {G_NONE}, s.gMid = {G_NONE, G_SHAKER}, s.gHi = {G_ICE};
    s.bLo = {B_WHOLE}, s.bMid = {B_WHOLE, B_HALF}, s.bHi = {B_HALF};
    s.flags = F_SPARKLE | F_DRONE | F_SWELL;
    s.verb = 0.6f, s.dly = 0.45f, s.space = 0.5f, s.drumAt = 0.8f, s.arpProb = 0.55f, s.density = 0.35f;
  }
  {
    Style& s = defStyle(7, "aurora");
    s.keys = {64, 62};
    s.modes = {MD_LYD};
    s.bpmLo = 64, s.bpmHi = 76;
    s.sA = {"I II I II", "IM7 II vi7 IV", "IM7 IM7 II II"};
    s.sB = {"vi7 II IM7 IM7", "iii7 IV II II"};
    s.sX = {"vi IV V V"};
    s.pad = {IN_CHOIR, IN_STRINGS};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_GLOCK, IN_MUSICBOX, IN_HARP};
    s.lead = {IN_FLUTE, IN_BELL, IN_MUSICBOX};
    s.lead2 = {IN_GLOCK};
    s.gLo = {G_NONE}, s.gMid = {G_NONE}, s.gHi = {G_ICE};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF}, s.bHi = {B_HALF};
    s.flags = F_SPARKLE;
    s.verb = 0.6f, s.dly = 0.4f, s.space = 0.45f, s.drumAt = 0.8f, s.density = 0.4f;
  }
  // ------------------------------------------------ 8: the Core
  {
    Style& s = defStyle(8, "heart of the world");
    s.keys = {65, 64, 67};
    s.modes = {MD_AEO, MD_HARM};
    s.bpmLo = 88, s.bpmHi = 100;
    s.sA = {"i bVI bIII bVII", "i bVI bVII i", "i iv bVI V", "i bVII bVI V"};
    s.sB = {"bVI bVII i i", "iv bVI V V", "bVI bIII bVII i", "bII bVI bVII i"};
    s.sX = {"i bVI bVII i", "i bII i V", "i iv V i"};
    s.pad = {IN_STRINGS, IN_CHOIR, IN_BRASS};
    s.bass = {IN_PBASS, IN_SYNBASS, IN_SUBBASS};
    s.arp = {IN_HARP, IN_PULSE};
    s.lead = {IN_BRASS, IN_STRINGS, IN_CHOIR};
    s.lead2 = {IN_CHOIR, IN_STRINGS, IN_BELL};
    s.comp = {IN_STRINGS, IN_BRASS};
    s.compPat = {C_PULSE8, C_STAB};
    s.gLo = {G_SOFTKICK, G_HEART}, s.gMid = {G_TRIBAL}, s.gHi = {G_EPIC};
    s.bLo = {B_WHOLE, B_HALF}, s.bMid = {B_PULSE8}, s.bHi = {B_GALLOP, B_PULSE8};
    s.flags = F_TIMP | F_OSTINATO | F_SWELL | F_PADPULSE;
    s.verb = 0.42f, s.dly = 0.1f, s.drumAt = 0.45f;
  }
  {
    Style& s = defStyle(8, "final descent");
    s.keys = {65, 62};
    s.modes = {MD_HARM, MD_AEO};
    s.sub = 3;
    s.bpmLo = 70, s.bpmHi = 80;
    s.sA = {"i bVI bIII bVII", "i v bVI bVII"};
    s.sB = {"bVI bVII i i", "iv V i i"};
    s.sX = {"i bII i V"};
    s.pad = {IN_CHOIR, IN_STRINGS};
    s.bass = {IN_SYNBASS, IN_PBASS};
    s.arp = {IN_HARP, IN_PULSE};
    s.lead = {IN_BRASS, IN_STRINGS};
    s.lead2 = {IN_CHOIR};
    s.comp = {IN_STRINGS};
    s.compPat = {C_PULSE8};
    s.gLo = {G_T128}, s.gMid = {G_T128B}, s.gHi = {G_T128C};
    s.bLo = {B_WHOLE}, s.bMid = {B_GALLOP}, s.bHi = {B_GALLOP};
    s.flags = F_TIMP | F_SWELL;
    s.verb = 0.45f, s.dly = 0.1f, s.drumAt = 0.45f;
  }
  // ------------------------------------------------ 9: shop / calm
  {
    Style& s = defStyle(9, "jaunty shop");
    s.keys = {60, 65, 67, 58};
    s.modes = {MD_ION};
    s.bpmLo = 100, s.bpmHi = 116;
    s.swLo = 0.4f, s.swHi = 0.6f;
    s.sA = {"I vi ii V", "IM7 vi7 ii7 V7", "I IV V IV", "I iii IV V", "I V IV I"};
    s.sB = {"IV iv I vi", "ii7 V7 IM7 VI7", "IV V iii vi", "IV I ii V"};
    s.sX = {"vi IV ii V", "vi ii V I"};
    s.pad = {IN_WARMPAD};
    s.bass = {IN_PBASS};
    s.arp = {IN_MARIMBA, IN_NYLON, IN_KALIMBA};
    s.lead = {IN_MARIMBA, IN_FLUTE, IN_REED, IN_EPIANO, IN_PULSE};
    s.lead2 = {IN_GLOCK, IN_KALIMBA, IN_BELL};
    s.comp = {IN_EPIANO, IN_NYLON};
    s.compPat = {C_OFFBEAT, C_CHARL};
    s.gLo = {G_BRUSH}, s.gMid = {G_SWING}, s.gHi = {G_SWING, G_BACKBEAT};
    s.bLo = {B_HALF}, s.bMid = {B_WALK}, s.bHi = {B_WALK, B_OCT8};
    s.flags = F_JAZZY | F_GRACE;
    s.verb = 0.22f, s.dly = 0.08f, s.drumAt = 0.4f, s.density = 0.6f, s.compProb = 0.75f;
  }
  {
    Style& s = defStyle(9, "lazy bossa");
    s.keys = {60, 65};
    s.modes = {MD_ION, MD_LYD};
    s.bpmLo = 88, s.bpmHi = 100;
    s.sA = {"IM7 ii7 iii7 ii7", "IM7 IVM7 iii7 vi7", "ii7 V7 IM7 IM7"};
    s.sB = {"IVM7 iv6 IM7 VI7", "iii7 VI7 ii7 V7"};
    s.sX = {"vi7 ii7 V7 IM7"};
    s.pad = {IN_WARMPAD};
    s.bass = {IN_PBASS};
    s.arp = {IN_NYLON};
    s.lead = {IN_FLUTE, IN_EPIANO};
    s.lead2 = {IN_MARIMBA, IN_BELL};
    s.comp = {IN_NYLON, IN_EPIANO};
    s.compPat = {C_BOSSA};
    s.gLo = {G_BOSSA}, s.gMid = {G_BOSSA}, s.gHi = {G_BOSSA};
    s.bLo = {B_BOSSA}, s.bMid = {B_BOSSA}, s.bHi = {B_BOSSA};
    s.flags = F_JAZZY;
    s.verb = 0.25f, s.dly = 0.1f, s.drumAt = 0.3f, s.compProb = 0.85f, s.arpProb = 0.3f;
  }
  // ------------------------------------------------ 10: the Slime Pits
  {
    Style& s = defStyle(10, "bubble bounce");
    s.keys = {55, 57, 53};
    s.modes = {MD_AEO, MD_DOR, MD_HARM};
    s.bpmLo = 96, s.bpmHi = 110;
    s.swLo = 0.1f, s.swHi = 0.25f;
    s.sA = {"i iv i V", "i bVI bVII i", "i bIII iv bVI", "i iv bVII bIII"};
    s.sB = {"bVI bVII i i", "iv V i i", "iv iv i V"};
    s.sX = {"i iv V i", "i bVI V i"};
    s.pad = {IN_WARMPAD};
    s.bass = {IN_PBASS, IN_SYNBASS};
    s.arp = {IN_MARIMBA, IN_KALIMBA, IN_PULSE};
    s.lead = {IN_PULSE, IN_MARIMBA, IN_KALIMBA, IN_FLUTE};
    s.lead2 = {IN_GLOCK, IN_KALIMBA};
    s.comp = {IN_MARIMBA};
    s.compPat = {C_OFFBEAT};
    s.gLo = {G_SLIMELO}, s.gMid = {G_SLIME}, s.gHi = {G_BREAK, G_SLIME};
    s.bLo = {B_HALF, B_BOUNCE}, s.bMid = {B_BOUNCE, B_OCT8}, s.bHi = {B_OCT8};
    s.flags = F_BUBBLES | F_STACCATO;
    s.verb = 0.25f, s.dly = 0.15f, s.density = 0.55f, s.drumAt = 0.45f;
  }
  {
    Style& s = defStyle(10, "ooze waltz");
    s.keys = {55, 57};
    s.modes = {MD_HARM, MD_AEO};
    s.beats = 3, s.sub = 2;
    s.bpmLo = 126, s.bpmHi = 144;
    s.sA = {"i i iv iv V V i i", "i iv V i", "i bVI V i"};
    s.sB = {"iv iv i i V V i i", "bVI bVI V V"};
    s.sX = {"i iv V i"};
    s.pad = {IN_WARMPAD};
    s.bass = {IN_TUBA, IN_PBASS};
    s.arp = {IN_MARIMBA};
    s.lead = {IN_PULSE, IN_MARIMBA, IN_CALLIOPE};
    s.lead2 = {IN_GLOCK};
    s.comp = {IN_MARIMBA, IN_REED};
    s.compPat = {C_PAH};
    s.gLo = {G_NONE}, s.gMid = {G_WALTZ}, s.gHi = {G_CIRCUS};
    s.bLo = {B_OOM}, s.bMid = {B_OOM}, s.bHi = {B_WALTZ};
    s.flags = F_BUBBLES;
    s.verb = 0.25f, s.dly = 0.12f, s.drumAt = 0.45f, s.compProb = 0.8f;
  }
  // ------------------------------------------------ 11: the Abyss
  {
    Style& s = defStyle(11, "void drone");
    s.keys = {62, 60, 63};
    s.modes = {MD_HUNG, MD_PHR};
    s.bpmLo = 50, s.bpmHi = 60;
    s.sA = {"i bv i bv", "i bII i bv", "i bvi i bII", "i bVI+ i bII"};
    s.sB = {"bv bvi i i", "bII bv i i", "bvi bII i i"};
    s.sX = {"i bII i bv", "i bv bII i"};
    s.pad = {IN_CHOIR, IN_WARMPAD, IN_STRINGS};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_BELL, IN_EPIANO};
    s.lead = {IN_BELL, IN_MUSICBOX, IN_CHOIR, IN_FLUTE};
    s.lead2 = {IN_GLOCK, IN_BELL};
    s.gLo = {G_NONE}, s.gMid = {G_HEART}, s.gHi = {G_TOMS};
    s.bLo = {B_WHOLE}, s.bMid = {B_WHOLE, B_HEART}, s.bHi = {B_PULSE8};
    s.flags = F_DRONE | F_TRITONE | F_SWELL;
    s.verb = 0.65f, s.dly = 0.35f, s.space = 0.5f, s.drumAt = 0.7f, s.arpProb = 0.4f, s.density = 0.35f;
  }
  {
    Style& s = defStyle(11, "deep pressure");
    s.keys = {60, 61};
    s.modes = {MD_PHR};
    s.sub = 3;
    s.bpmLo = 54, s.bpmHi = 62;
    s.sA = {"i bII i bII", "i bii i bv"};
    s.sB = {"bII bII i i", "bv bv i i"};
    s.sX = {"i bII i bv"};
    s.pad = {IN_ORGAN, IN_CHOIR};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_EPIANO, IN_HARP};
    s.lead = {IN_CHOIR, IN_BELL};
    s.lead2 = {IN_BELL};
    s.gLo = {G_NONE}, s.gMid = {G_HEART}, s.gHi = {G_T128C};
    s.bLo = {B_WHOLE}, s.bMid = {B_WHOLE}, s.bHi = {B_PULSE8};
    s.flags = F_DRONE | F_TRITONE | F_SWELL;
    s.verb = 0.6f, s.dly = 0.3f, s.space = 0.45f, s.drumAt = 0.7f, s.density = 0.35f;
  }
  // ------------------------------------------------ 12: rest site
  {
    Style& s = defStyle(12, "campfire");
    s.keys = {55, 62, 60, 57};
    s.modes = {MD_ION, MD_MIX};
    s.bpmLo = 72, s.bpmHi = 86;
    s.swLo = 0.f, s.swHi = 0.2f;
    s.sA = {"I V vi IV", "I IV I V", "I iii IV I", "I IM7 IV iv", "I vi IV V"};
    s.sB = {"IV I V vi", "vi IV I V", "IV iv I I", "ii IV I V"};
    s.sX = {"vi IV V I"};
    s.pad = {IN_WARMPAD, IN_REED, IN_STRINGS};
    s.bass = {IN_PBASS};
    s.arp = {IN_NYLON, IN_HARP};
    s.lead = {IN_FLUTE, IN_NYLON, IN_REED, IN_KALIMBA};
    s.lead2 = {IN_NYLON, IN_FLUTE, IN_MUSICBOX};
    s.comp = {IN_NYLON};
    s.compPat = {C_STRUM};
    s.gLo = {G_NONE, G_SHAKER}, s.gMid = {G_SHAKER}, s.gHi = {G_BRUSH};
    s.bLo = {B_WHOLE, B_HALF}, s.bMid = {B_ARP, B_HALF}, s.bHi = {B_ARP};
    s.arpSt = {A_PEDAL, A_UP, A_BROKEN};
    s.flags = F_GRACE;
    s.verb = 0.3f, s.dly = 0.1f, s.drumAt = 0.6f, s.compProb = 0.7f;
  }
  {
    Style& s = defStyle(12, "starry camp");
    s.keys = {55, 53};
    s.modes = {MD_ION};
    s.beats = 3, s.sub = 2;
    s.bpmLo = 84, s.bpmHi = 96;
    s.sA = {"I IV I V", "I vi IV V", "I I IV IV V V I I"};
    s.sB = {"IV I V I", "vi IV I V"};
    s.sX = {"vi IV V I"};
    s.pad = {IN_WARMPAD, IN_STRINGS};
    s.bass = {IN_PBASS};
    s.arp = {IN_NYLON, IN_HARP};
    s.lead = {IN_FLUTE, IN_MUSICBOX};
    s.lead2 = {IN_NYLON};
    s.comp = {IN_NYLON};
    s.compPat = {C_PAH};
    s.gLo = {G_NONE}, s.gMid = {G_NONE}, s.gHi = {G_WALTZ};
    s.bLo = {B_OOM}, s.bMid = {B_OOM}, s.bHi = {B_WALTZ};
    s.motifBars = 2;
    s.verb = 0.32f, s.dly = 0.12f, s.drumAt = 0.7f;
  }
  // ------------------------------------------------ 13: altar / temple
  {
    Style& s = defStyle(13, "sanctum");
    s.keys = {65, 63, 67};
    s.modes = {MD_ION, MD_MIX};
    s.bpmLo = 60, s.bpmHi = 72;
    s.sA = {"I IV I V", "I vi IV V", "I IV vi IV", "I bVII IV I", "IV I V vi"};
    s.sB = {"IV V vi IV", "ii IV I I", "vi IV I V", "IV iv I I"};
    s.sX = {"vi IV V V"};
    s.pad = {IN_ORGAN, IN_CHOIR, IN_STRINGS};
    s.bass = {IN_SUBBASS, IN_SYNBASS};
    s.arp = {IN_HARP};
    s.lead = {IN_CHOIR, IN_FLUTE, IN_STRINGS};
    s.lead2 = {IN_BELL, IN_HARP, IN_GLOCK};
    s.gLo = {G_NONE}, s.gMid = {G_NONE, G_TEMPLE}, s.gHi = {G_TEMPLE};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF}, s.bHi = {B_HALF};
    s.flags = F_TOLL | F_SWELL;
    s.verb = 0.6f, s.dly = 0.15f, s.drumAt = 0.7f, s.arpProb = 0.5f;
  }
  {
    Style& s = defStyle(13, "chant");
    s.keys = {62, 64};
    s.modes = {MD_DOR};
    s.bpmLo = 62, s.bpmHi = 70;
    s.sA = {"i IV i IV", "i bVII i bVII", "i bIII IV i"};
    s.sB = {"bIII IV i i", "bVII IV i i"};
    s.sX = {"i bVII bVI bVII"};
    s.pad = {IN_CHOIR, IN_ORGAN};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_HARP, IN_BELL};
    s.lead = {IN_CHOIR, IN_FLUTE};
    s.lead2 = {IN_BELL};
    s.gLo = {G_NONE}, s.gMid = {G_NONE}, s.gHi = {G_TEMPLE};
    s.bLo = {B_WHOLE}, s.bMid = {B_WHOLE}, s.bHi = {B_HALF};
    s.flags = F_TOLL | F_DRONE;
    s.verb = 0.6f, s.dly = 0.15f, s.drumAt = 0.75f, s.arpProb = 0.45f;
  }
  // ------------------------------------------------ 14: strange passage / event
  {
    Style& s = defStyle(14, "curious");
    s.keys = {62, 60, 65};
    s.modes = {MD_LYD, MD_DOR};
    s.bpmLo = 80, s.bpmHi = 94;
    s.swLo = 0.f, s.swHi = 0.15f;
    s.sA = {"I II I II", "IM7 bIIM7 IM7 bIIM7", "i IV i bII", "I II iii II"};
    s.sB = {"bVI bVII I I", "bII bIII I I", "IV II I I"};
    s.sX = {"i bII i bII"};
    s.pad = {IN_CHOIR, IN_WARMPAD};
    s.bass = {IN_PBASS};
    s.arp = {IN_MUSICBOX, IN_KALIMBA, IN_HARP, IN_GLOCK};
    s.lead = {IN_KALIMBA, IN_MUSICBOX, IN_FLUTE, IN_EPIANO};
    s.lead2 = {IN_BELL, IN_GLOCK, IN_NYLON};
    s.comp = {IN_NYLON};
    s.compPat = {C_TIPTOE};
    s.gLo = {G_TIPTOE}, s.gMid = {G_TIPTOE}, s.gHi = {G_TIPTOE, G_LOFI};
    s.bLo = {B_TIPTOE}, s.bMid = {B_TIPTOE}, s.bHi = {B_TIPTOE, B_PULSE8};
    s.flags = F_STACCATO | F_SPARKLE | F_CHROMATIC;
    s.verb = 0.4f, s.dly = 0.3f, s.drumAt = 0.4f;
  }
  {
    Style& s = defStyle(14, "whole-tone dream");
    s.keys = {60, 62};
    s.modes = {MD_WHOLE};
    s.bpmLo = 76, s.bpmHi = 88;
    s.sA = {"I+ II+ I+ II+", "I+ bVII+ I+ bVII+", "I+ I+ II+ bVII+"};
    s.sB = {"II+ II+ I+ I+", "bVII+ II+ I+ I+"};
    s.pad = {IN_CHOIR, IN_WARMPAD};
    s.bass = {IN_SUBBASS, IN_PBASS};
    s.arp = {IN_MUSICBOX, IN_HARP, IN_GLOCK};
    s.lead = {IN_MUSICBOX, IN_FLUTE, IN_KALIMBA};
    s.lead2 = {IN_BELL};
    s.gLo = {G_NONE, G_TIPTOE}, s.gMid = {G_TIPTOE}, s.gHi = {G_TIPTOE};
    s.bLo = {B_WHOLE}, s.bMid = {B_TIPTOE}, s.bHi = {B_TIPTOE};
    s.flags = F_SPARKLE | F_STACCATO;
    s.verb = 0.5f, s.dly = 0.35f, s.drumAt = 0.5f;
  }
  // ------------------------------------------------ 15: treasure vault
  {
    Style& s = defStyle(15, "glitter");
    s.keys = {63, 60, 62, 65};
    s.modes = {MD_LYD, MD_ION};
    s.bpmLo = 100, s.bpmHi = 120;
    s.sA = {"I II IV I", "I V vi IV", "I IV V I", "IM7 IVM7 IM7 IVM7", "I iii IV V"};
    s.sB = {"IV V iii vi", "IV iv I I", "bVI bVII I I", "ii V I I"};
    s.sX = {"vi IV V I"};
    s.pad = {IN_WARMPAD, IN_STRINGS, IN_CHOIR};
    s.bass = {IN_PBASS};
    s.arp = {IN_GLOCK, IN_MUSICBOX, IN_HARP, IN_MARIMBA};
    s.lead = {IN_MUSICBOX, IN_BELL, IN_MARIMBA, IN_PULSE, IN_FLUTE};
    s.lead2 = {IN_GLOCK, IN_KALIMBA, IN_BELL};
    s.comp = {IN_MARIMBA, IN_EPIANO};
    s.compPat = {C_OFFBEAT};
    s.gLo = {G_SHAKER}, s.gMid = {G_SPARKLE}, s.gHi = {G_SPARKLE2};
    s.bLo = {B_HALF}, s.bMid = {B_OCT8, B_HALF}, s.bHi = {B_OCT8};
    s.flags = F_SPARKLE | F_HARM3 | F_MODUP;
    s.verb = 0.35f, s.dly = 0.25f, s.drumAt = 0.45f, s.arpProb = 0.85f;
  }
  // ------------------------------------------------ 16: victory
  {
    Style& s = defStyle(16, "triumph");
    s.keys = {60, 62, 63, 58};
    s.modes = {MD_ION};
    s.bpmLo = 104, s.bpmHi = 118;
    s.sA = {"I IV V I", "I bVI bVII I", "I V vi IV", "I iii IV V", "I IV I V"};
    s.sB = {"IV V iii vi", "bVI bVII I I", "ii V I I", "IV I V V"};
    s.sX = {"vi IV V I"};
    s.pad = {IN_STRINGS, IN_BRASS, IN_CHOIR};
    s.bass = {IN_PBASS, IN_SYNBASS};
    s.arp = {IN_HARP, IN_GLOCK};
    s.lead = {IN_BRASS, IN_STRINGS, IN_FLUTE, IN_PULSE};
    s.lead2 = {IN_BRASS, IN_BELL, IN_GLOCK};
    s.comp = {IN_BRASS, IN_STRINGS};
    s.compPat = {C_STAB, C_PULSE8};
    s.gLo = {G_MARCH}, s.gMid = {G_MARCH2}, s.gHi = {G_EPIC};
    s.bLo = {B_HALF}, s.bMid = {B_ROOT4, B_OCT8}, s.bHi = {B_OCT8, B_PULSE8};
    s.flags = F_TIMP | F_HARM3 | F_MODUP | F_FANFARE | F_SWELL;
    s.verb = 0.35f, s.dly = 0.12f, s.drumAt = 0.3f;
  }
  {
    Style& s = defStyle(16, "hero's rest");
    s.keys = {65, 60};
    s.modes = {MD_ION};
    s.bpmLo = 84, s.bpmHi = 96;
    s.sA = {"I V vi iii IV I IV V", "I IV vi V"};
    s.sB = {"IV V iii vi", "ii V I I"};
    s.pad = {IN_STRINGS, IN_CHOIR};
    s.bass = {IN_PBASS};
    s.arp = {IN_HARP};
    s.lead = {IN_FLUTE, IN_STRINGS, IN_BRASS};
    s.lead2 = {IN_BELL, IN_GLOCK};
    s.gLo = {G_NONE}, s.gMid = {G_SOFTKICK}, s.gHi = {G_MARCH};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF}, s.bHi = {B_ROOT4};
    s.flags = F_TIMP | F_HARM3;
    s.verb = 0.38f, s.dly = 0.12f, s.drumAt = 0.55f;
  }
  // ------------------------------------------------ 17: death / game over
  {
    Style& s = defStyle(17, "requiem");
    s.keys = {60, 62, 57};
    s.modes = {MD_AEO, MD_HARM};
    s.bpmLo = 56, s.bpmHi = 66;
    s.sA = {"i iv i V", "i bVI iv V", "i bVII bVI V", "i iv bVII bIII"};
    s.sB = {"bVI iv i V", "iv i bVI V"};
    s.pad = {IN_STRINGS, IN_CHOIR, IN_ORGAN};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_HARP, IN_EPIANO};
    s.lead = {IN_EPIANO, IN_MUSICBOX, IN_FLUTE, IN_STRINGS};
    s.lead2 = {IN_BELL, IN_CHOIR};
    s.gLo = {G_NONE}, s.gMid = {G_NONE}, s.gHi = {G_NONE};
    s.bLo = {B_WHOLE}, s.bMid = {B_WHOLE, B_HALF}, s.bHi = {B_HALF};
    s.flags = F_TOLL | F_SHORT | F_NODRUMS;
    s.verb = 0.55f, s.dly = 0.25f, s.space = 0.35f, s.arpProb = 0.5f;
  }
  {
    Style& s = defStyle(17, "fading light");
    s.keys = {57, 64};
    s.modes = {MD_AEO, MD_HARM};
    s.beats = 3, s.sub = 2;
    s.bpmLo = 60, s.bpmHi = 72;
    s.sA = {"i iv V i", "i bVI iv V", "i i iv iv bVI bVI V V"};
    s.sB = {"iv i V i"};
    s.pad = {IN_STRINGS, IN_CHOIR};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_HARP, IN_MUSICBOX};
    s.lead = {IN_MUSICBOX, IN_EPIANO};
    s.lead2 = {IN_BELL};
    s.gLo = {G_NONE}, s.gMid = {G_NONE}, s.gHi = {G_NONE};
    s.bLo = {B_OOM}, s.bMid = {B_OOM}, s.bHi = {B_WALTZ};
    s.flags = F_SHORT | F_NODRUMS;
    s.motifBars = 2;
    s.verb = 0.5f, s.dly = 0.25f, s.space = 0.3f;
  }
  // ------------------------------------------------ 18: carnival (the Tumbler's Playground)
  {
    Style& s = defStyle(18, "tumbler's waltz");
    s.keys = {60, 65, 67, 58};
    s.modes = {MD_ION};
    s.beats = 3, s.sub = 2;
    s.bpmLo = 150, s.bpmHi = 176;
    s.sA = {"I I V7 V7 V7 V7 I I", "I IV I V7", "I I IV iv I V7 I I", "I vi ii V7"};
    s.sB = {"IV IV I I V7 V7 I I", "vi vi II7 II7 V7 V7 I I", "i i iv iv V7 V7 i i"};
    s.sX = {"i iv V7 i", "i bVI V7 i"};
    s.pad = {IN_ORGAN};
    s.bass = {IN_TUBA};
    s.arp = {IN_GLOCK, IN_MUSICBOX};
    s.lead = {IN_CALLIOPE, IN_REED, IN_PULSE, IN_GLOCK};
    s.lead2 = {IN_GLOCK, IN_REED, IN_CALLIOPE};
    s.comp = {IN_ORGAN, IN_REED};
    s.compPat = {C_PAH};
    s.gLo = {G_CIRCUS}, s.gMid = {G_CIRCUS}, s.gHi = {G_CIRCUS2};
    s.bLo = {B_OOM}, s.bMid = {B_OOM}, s.bHi = {B_OOM, B_WALTZ};
    s.flags = F_WONKY | F_CHROMATIC | F_LURCH | F_MODUP | F_HARM3;
    s.verb = 0.25f, s.dly = 0.05f, s.drumAt = 0.25f, s.density = 0.6f, s.arpProb = 0.4f, s.compProb = 0.95f;
  }
  {
    Style& s = defStyle(18, "mad carousel");
    s.keys = {57, 62};
    s.modes = {MD_HARM};
    s.beats = 3, s.sub = 2;
    s.bpmLo = 160, s.bpmHi = 184;
    s.sA = {"i i V7 V7 V7 V7 i i", "i iv V7 i", "i i iv iv V7 V7 i i"};
    s.sB = {"bVI bVI V7 V7 i i V7 V7", "iv iv i i V7 V7 i i"};
    s.sX = {"i bII V7 i"};
    s.pad = {IN_ORGAN};
    s.bass = {IN_TUBA};
    s.arp = {IN_GLOCK, IN_MUSICBOX};
    s.lead = {IN_CALLIOPE, IN_REED, IN_PULSE};
    s.lead2 = {IN_GLOCK, IN_REED};
    s.comp = {IN_ORGAN, IN_REED};
    s.compPat = {C_PAH};
    s.gLo = {G_CIRCUS}, s.gMid = {G_CIRCUS}, s.gHi = {G_CIRCUS2};
    s.bLo = {B_OOM}, s.bMid = {B_OOM}, s.bHi = {B_WALTZ};
    s.flags = F_WONKY | F_CHROMATIC | F_LURCH | F_HARM3;
    s.verb = 0.25f, s.dly = 0.05f, s.drumAt = 0.25f, s.density = 0.65f, s.arpProb = 0.4f, s.compProb = 0.95f;
  }
  // ------------------------------------------------ 19: title theme B
  {
    Style& s = defStyle(19, "heroic dawn");
    s.keys = {62, 60, 63};
    s.modes = {MD_ION, MD_MIX, MD_ION};
    s.bpmLo = 92, s.bpmHi = 106;
    s.sA = {"I V vi IV", "I IV vi V", "I bVII IV I", "vi IV I V", "I iii IV V"};
    s.sB = {"IV V iii vi", "ii IV V V", "bVI bVII I I", "IV I V vi"};
    s.sX = {"vi IV V V"};
    s.pad = {IN_STRINGS, IN_CHOIR};
    s.bass = {IN_PBASS, IN_SUBBASS};
    s.arp = {IN_HARP, IN_GLOCK};
    s.lead = {IN_BRASS, IN_FLUTE, IN_STRINGS};
    s.lead2 = {IN_BELL, IN_GLOCK, IN_STRINGS};
    s.comp = {IN_STRINGS};
    s.compPat = {C_PULSE8};
    s.gLo = {G_NONE, G_SOFTKICK}, s.gMid = {G_MARCH}, s.gHi = {G_EPIC, G_MARCH2};
    s.bLo = {B_WHOLE, B_HALF}, s.bMid = {B_ROOT4, B_HALF}, s.bHi = {B_PULSE8, B_OCT8};
    s.flags = F_TIMP | F_MODUP | F_FANFARE | F_SWELL;
    s.verb = 0.38f, s.dly = 0.12f, s.drumAt = 0.5f;
  }
  {
    Style& s = defStyle(19, "starlit");
    s.keys = {65, 63, 62};
    s.modes = {MD_LYD, MD_ION};
    s.bpmLo = 64, s.bpmHi = 76;
    s.sA = {"IM7 II IM7 II", "IM7 iii7 IVM7 IV", "IVM7 V iii7 vi7", "IM7 IVM7 IM7 IVM7"};
    s.sB = {"vi7 IVM7 IM7 V", "ii7 iii7 IVM7 V", "IVM7 IVM7 iii7 vi7"};
    s.pad = {IN_CHOIR, IN_WARMPAD, IN_STRINGS};
    s.bass = {IN_SUBBASS};
    s.arp = {IN_EPIANO, IN_HARP, IN_MUSICBOX};
    s.lead = {IN_MUSICBOX, IN_EPIANO, IN_FLUTE};
    s.lead2 = {IN_BELL, IN_GLOCK};
    s.gLo = {G_NONE}, s.gMid = {G_NONE, G_SOFTKICK}, s.gHi = {G_SOFTKICK};
    s.bLo = {B_WHOLE}, s.bMid = {B_HALF}, s.bHi = {B_HALF};
    s.flags = F_SPARKLE;
    s.verb = 0.5f, s.dly = 0.32f, s.space = 0.35f, s.drumAt = 0.75f;
  }
  // loudness trims (dB), measured offline so all styles sit at a similar level under the SFX, with a
  // little character on top (the Core / victory a touch bigger, the Abyss / Frozen / death quieter)
  static const struct {
    const char* name;
    float db;
  } TRIM[] = {
      {"harp overture", -0.5f},  {"lofi dungeon", +0.9f},  {"music box waltz", +0.2f}, {"stone halls", +1.2f},
      {"torchlit dorian", +0.9f}, {"mushroom groove", +1.2f}, {"spore drift", +0.4f},  {"sunken echoes", -1.6f},
      {"tidal lydian", -1.3f},   {"gearworks", +2.0f},     {"mechanism", +1.8f},      {"funeral organ", -1.7f},
      {"candle procession", -0.8f}, {"anvil march", -0.1f}, {"magma gallop", +0.2f},  {"glass silence", -2.1f},
      {"aurora", -1.9f},         {"heart of the world", -0.7f}, {"final descent", -0.3f}, {"jaunty shop", +1.1f},
      {"lazy bossa", +0.9f},     {"bubble bounce", +0.2f}, {"ooze waltz", +1.9f},     {"void drone", -3.1f},
      {"deep pressure", -2.0f},  {"campfire", +1.0f},      {"starry camp", +1.4f},    {"sanctum", -1.7f},
      {"chant", -1.0f},          {"curious", +0.5f},       {"whole-tone dream", +0.f}, {"glitter", +0.f},
      {"triumph", +0.5f},        {"hero's rest", +0.4f},   {"requiem", -1.3f},        {"fading light", -0.5f},
      {"tumbler's waltz", +1.3f}, {"mad carousel", +1.3f}, {"heroic dawn", -0.1f},    {"starlit", -1.0f},
  };
  for (auto& v : g_styles)
    for (Style& s : v) {
      for (const auto& t : TRIM)
        if (!strcmp(t.name, s.name)) s.gain = std::pow(10.f, t.db / 20.f);
      if (s.arpSt.empty()) s.arpSt = {A_UP, A_UPDOWN, A_BROKEN};
      for (const char* p : s.sA) s.A.push_back(parseProg(p, s.beats));
      for (const char* p : s.sB) s.B.push_back(parseProg(p, s.beats));
      for (const char* p : s.sX) s.X.push_back(parseProg(p, s.beats));
      if (s.B.empty()) s.B = s.A;
      if (s.X.empty()) s.X = s.A;
    }
}

// ================================================================ music: motifs
struct MNote {
  int16_t step, len;  // grid steps from the motif start
  int8_t deg;         // scale degrees relative to the anchor chord tone
  uint8_t vel;
};
struct Motif {
  MNote n[32];
  int cnt = 0, steps = 16;
};
static void motifLens(Motif& m) {
  std::sort(m.n, m.n + m.cnt, [](const MNote& a, const MNote& b) { return a.step < b.step; });
  int w = 0;
  for (int i = 0; i < m.cnt; ++i)
    if (m.n[i].step >= 0 && m.n[i].step < m.steps && (w == 0 || m.n[i].step != m.n[w - 1].step)) m.n[w++] = m.n[i];
  m.cnt = w;
  for (int i = 0; i < m.cnt; ++i) {
    int nx = i + 1 < m.cnt ? m.n[i + 1].step : m.steps;
    m.n[i].len = (int16_t)std::max(1, nx - m.n[i].step);
  }
}
struct Cell {
  const char* p;
  float w0, wd;  // weight = w0 + wd * density
};
static const Cell CELL4[9] = {{"x...", 1.0f, 0.f}, {"x.x.", 0.3f, 1.0f}, {"x.xx", 0.f, 0.5f}, {"xx.x", 0.f, 0.3f}, {"..x.", 0.3f, 0.f},
                              {"....", 0.55f, -0.5f}, {"x..x", 0.05f, 0.3f}, {"xxxx", 0.f, 0.12f}, {".xx.", 0.f, 0.1f}};
static const Cell CELL3[5] = {{"x..", 1.0f, 0.f}, {"x.x", 0.2f, 0.7f}, {"xxx", 0.f, 0.35f}, {"..x", 0.25f, 0.f}, {"...", 0.5f, -0.45f}};
static const Cell CELL2[4] = {{"x.", 1.0f, 0.f}, {"xx", 0.2f, 0.8f}, {".x", 0.25f, 0.f}, {"..", 0.45f, -0.4f}};
static Motif genMotif(Rng& r, int beats, int sub, int bars, float dens) {
  Motif m;
  m.steps = beats * sub * bars;
  const Cell* C = sub == 4 ? CELL4 : sub == 3 ? CELL3 : CELL2;
  int nc = sub == 4 ? 9 : sub == 3 ? 5 : 4;
  int tb = beats * bars;
  for (int b = 0; b < tb; ++b) {
    float w[9], tot = 0;
    for (int k = 0; k < nc; ++k) {
      int ons = 0;
      for (const char* q = C[k].p; *q; ++q) ons += *q == 'x';
      float x = std::max(0.f, C[k].w0 + C[k].wd * dens);
      if (b == 0 && C[k].p[0] != 'x') x = 0;
      if (b == tb - 1 && ons > 1) x *= 0.2f;
      w[k] = x;
      tot += x;
    }
    float pick = r.f() * tot;
    int k = 0;
    for (; k < nc - 1; ++k) {
      pick -= w[k];
      if (pick <= 0) break;
    }
    for (int j = 0; j < sub; ++j)
      if (C[k].p[j] == 'x' && m.cnt < 30)
        m.n[m.cnt++] = MNote{(int16_t)(b * sub + j), 1, 0, (uint8_t)(j == 0 ? (b % beats == 0 ? 255 : 225) : 190)};
  }
  if (m.cnt < 2) m.n[m.cnt++] = MNote{(int16_t)(sub * std::min(2, tb - 1)), 1, 0, 225};
  motifLens(m);
  int d = 0, leap = 0;
  for (int i = 0; i < m.cnt; ++i) {
    if (i == 0) {
      d = r.chance(0.65f) ? 0 : (r.chance(0.5f) ? 2 : -3);
    } else {
      int sv;
      if (leap) {
        sv = leap > 0 ? -1 : 1;  // fill the gap after a leap
      } else {
        float x = r.f();
        sv = x < 0.12f ? 0 : x < 0.6f ? 1 : x < 0.8f ? 2 : x < 0.92f ? 3 : 4;
        int dir = r.chance(0.5f) ? 1 : -1;
        if (d >= 4) dir = -1;
        else if (d <= -4) dir = 1;
        sv *= dir;
      }
      leap = std::abs(sv) >= 3 ? sv : 0;
      d += sv;
    }
    m.n[i].deg = (int8_t)d;
  }
  return m;
}
static Motif mvTranspose(Motif m, int d) {
  for (int i = 0; i < m.cnt; ++i) m.n[i].deg = (int8_t)(m.n[i].deg + d);
  return m;
}
static Motif mvInvert(Motif m) {
  int d0 = m.cnt ? m.n[0].deg : 0;
  for (int i = 0; i < m.cnt; ++i) m.n[i].deg = (int8_t)(2 * d0 - m.n[i].deg);
  return m;
}
static Motif mvRetro(Motif m) {
  for (int i = 0; i < m.cnt / 2; ++i) std::swap(m.n[i].deg, m.n[m.cnt - 1 - i].deg);
  return m;
}
static Motif mvDisplace(Motif m, int k) {
  for (int i = 0; i < m.cnt; ++i) m.n[i].step = (int16_t)((m.n[i].step + k) % m.steps);
  motifLens(m);
  return m;
}
static Motif mvOrnament(const Motif& m, Rng& r) {
  Motif o = m;
  for (int i = 0; i + 1 < m.cnt && o.cnt < 30; ++i) {
    const MNote &a = m.n[i], &b = m.n[i + 1];
    int gap = b.step - a.step;
    if (gap >= 2 && std::abs(b.deg - a.deg) == 2 && r.chance(0.6f))
      o.n[o.cnt++] = MNote{(int16_t)(a.step + gap / 2), 1, (int8_t)((a.deg + b.deg) / 2), (uint8_t)(a.vel * 0.8f)};
    else if (gap >= 4 && a.deg == b.deg && r.chance(0.35f))
      o.n[o.cnt++] = MNote{(int16_t)(a.step + gap / 2), 1, (int8_t)(a.deg + 1), (uint8_t)(a.vel * 0.75f)};
  }
  motifLens(o);
  return o;
}
static Motif mvSparse(const Motif& m, int sub) {  // keep only notes on beats
  Motif o;
  o.steps = m.steps;
  for (int i = 0; i < m.cnt; ++i)
    if (m.n[i].step % sub == 0) o.n[o.cnt++] = m.n[i];
  if (!o.cnt && m.cnt) o.n[o.cnt++] = m.n[0];
  motifLens(o);
  return o;
}
static Motif mvDiminish(const Motif& m, Rng& r) {  // double-time statement + a sequenced repeat
  Motif o;
  o.steps = m.steps;
  int half = m.steps / 2, seq = r.chance(0.5f) ? 1 : -1;
  for (int rep = 0; rep < 2; ++rep)
    for (int i = 0; i < m.cnt && o.cnt < 30; ++i) {
      MNote x = m.n[i];
      x.step = (int16_t)(m.n[i].step / 2 + rep * half);
      x.deg = (int8_t)(x.deg + rep * seq);
      o.n[o.cnt++] = x;
    }
  motifLens(o);
  return o;
}
static Motif mvResponse(const Motif& m, int type, Rng& r) {
  Motif o = m;
  switch (type) {
    case 0:  // same rhythm, open ending on the third or fifth above the anchor
      if (o.cnt) o.n[o.cnt - 1].deg = (int8_t)(r.chance(0.5f) ? 4 : 2);
      break;
    case 1: o = mvInvert(m); break;
    case 2: o = mvRetro(m); break;
    default: o = mvTranspose(m, -1); break;
  }
  return o;
}
static Motif mvCadence(const Motif& m, Rng& r, int sub) {  // first half of the idea, then a long resolution
  Motif o;
  o.steps = m.steps;
  int half = m.steps / 2;
  for (int i = 0; i < m.cnt && o.cnt < 30; ++i)
    if (m.n[i].step < half) o.n[o.cnt++] = m.n[i];
  int last = o.cnt ? o.n[o.cnt - 1].step : -1;
  int fin = (last / sub + 1) * sub;
  if (last < 0) fin = 0;
  if (fin >= m.steps) fin = std::max(0, m.steps - sub);
  if (fin > last) o.n[o.cnt++] = MNote{(int16_t)fin, 1, 0, 230};
  else o.n[o.cnt - 1].deg = 0;
  if (o.cnt >= 2 && r.chance(0.35f)) o.n[o.cnt - 2].deg = (int8_t)(r.chance(0.5f) ? 1 : -1);
  motifLens(o);
  return o;
}

// ================================================================ music: songs
enum { SK_INTRO, SK_A, SK_A2, SK_B, SK_BREAK, SK_CLIMAX, SK_OUTRO };
static const char* const SK_NAME[7] = {"I", "A", "A'", "B", "D", "C", "O"};
enum { MM_COUNTER, MM_CALLRESP, MM_HARM, MM_OCT };
enum { R_PAD = 1, R_BASS = 2, R_ARP = 4, R_LEAD = 8, R_LEAD2 = 16, R_COMP = 32, R_DRUMS = 64, R_PERC = 128, R_FX = 256 };
struct Section {
  uint8_t kind = SK_A, bars = 8, prog = 0, motif = 0, lead = 0, lead2 = 0, arpIns = 0, melMode = 0, fill = 0;
  int8_t transpose = 0;
  uint16_t roles = 0;
  float energy = 0.5f, tempoMul = 1.f;
};
struct MGroove {
  int n = 0;
  uint8_t drum[6] = {0, 0, 0, 0, 0, 0};
  char pat[6][49];
};
struct Song {
  int mood = -1, styleIdx = 0, serial = 0;
  const Style* st = nullptr;
  uint32_t seed = 0;
  int key = 60, mode = 0, scaleN = 7;
  int8_t scale[7] = {0, 2, 4, 5, 7, 9, 11};
  bool major = true;
  float bpm = 90, swing = 0, human = 1;
  bool swing16 = false;
  int beats = 4, sub = 4, steps = 16;
  Prog pA, pA2, pB, pX, pT;
  uint8_t insPad = 0, insBass = 0, insArp = 0, insArp2 = 0, insLeadA = 0, insLeadB = 0, insLead2 = 0, insComp = IN_NONE;
  uint8_t gId[3] = {0, 0, 0}, bId[3] = {0, 0, 0}, compId = 0;
  MGroove g[3];
  char bpat[3][49];
  char cpat[49];
  uint8_t arpStyle = 0, arpRate = 2, arpOct = 1, ostRate = 1;
  float arpSkip = 0;
  int arpLo = 60;
  bool useOstin = false;
  int8_t ostin[48];
  int padLo = 52, padVoices = 4, leadOff = 0;
  float padAtk = 0.2f, padRel = 0.8f;
  uint8_t padStyle = 0;  // 0 sustained chords, 1 pulsing eighths
  float leadPan = 0, lead2Pan = 0, arpPan = 0, compPan = 0;
  uint8_t respType = 0;
  bool displace = false;
  float delayBeats = 0.75f;
  Motif mA, mB, mA2, mX;
  Section sec[24];
  int nsec = 0, totalBars = 0;
};

// ================================================================ music: voices and bus effects
static const int MAXMV = 128, MAXEV = 2048;
struct MVoice {
  const float* d = nullptr;  // null = free
  double pos = 0;
  float rate = 1, glide = 1;
  int len = 0, loopStart = -1, glideN = 0;
  float gl = 0, gr = 0, gs = 0, gd = 0;  // left, right, reverb send, delay send
  float env = 1, envMul = 1, envAdd = 0, relMul = 0.999f;
  float lp = 0, lpA = 1;
  int64_t relAt = INT64_MAX;
  float midi = 60;
  uint32_t age = 0;
  uint8_t track = 0, ins = 0;
  bool releasing = false, wob = false;
};
enum { EV_EXTEND = 1 };
struct NoteEv {
  double t;
  float midi, vel, dur, pan, send, dsend, atk, rel, bright, glide;
  uint8_t ins, track, flags;
};
// Freeverb-style stereo reverb (8 damped combs + 4 allpasses per side), mono in
struct Reverb {
  std::vector<float> buf;
  float* cb[16];
  float* ab[8];
  int cn[16], ci[16], an[8], ai[8];
  float cs[16];
  float fb = 0.84f, damp = 0.3f, ig = 0.2f;
  void init() {
    static const int CL[8] = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617}, AL[4] = {556, 441, 341, 225};
    int tot = 0;
    for (int k = 0; k < 16; ++k) tot += CL[k & 7] + (k >= 8 ? 23 : 0);
    for (int k = 0; k < 8; ++k) tot += AL[k & 3] + (k >= 4 ? 23 : 0);
    buf.assign(tot, 0.f);
    float* p = buf.data();
    for (int k = 0; k < 16; ++k) {
      cn[k] = CL[k & 7] + (k >= 8 ? 23 : 0);
      cb[k] = p;
      p += cn[k];
      ci[k] = 0;
      cs[k] = 0;
    }
    for (int k = 0; k < 8; ++k) {
      an[k] = AL[k & 3] + (k >= 4 ? 23 : 0);
      ab[k] = p;
      p += an[k];
      ai[k] = 0;
    }
    ig = std::sqrt(1.f - fb * fb) / std::sqrt(8.f);  // roughly unity RMS gain for noise
  }
  inline void proc(float in, float& ol, float& orr) {
    in *= ig;
    float l = 0, r = 0, d1 = damp, d2 = 1.f - damp;
    for (int k = 0; k < 8; ++k) {
      float y = cb[k][ci[k]];
      cs[k] = y * d2 + cs[k] * d1;
      cb[k][ci[k]] = in + cs[k] * fb;
      if (++ci[k] >= cn[k]) ci[k] = 0;
      l += y;
    }
    for (int k = 8; k < 16; ++k) {
      float y = cb[k][ci[k]];
      cs[k] = y * d2 + cs[k] * d1;
      cb[k][ci[k]] = in + cs[k] * fb;
      if (++ci[k] >= cn[k]) ci[k] = 0;
      r += y;
    }
    for (int k = 0; k < 4; ++k) {
      float y = ab[k][ai[k]];
      float o = y - l;
      ab[k][ai[k]] = l + y * 0.5f;
      if (++ai[k] >= an[k]) ai[k] = 0;
      l = o;
    }
    for (int k = 4; k < 8; ++k) {
      float y = ab[k][ai[k]];
      float o = y - r;
      ab[k][ai[k]] = r + y * 0.5f;
      if (++ai[k] >= an[k]) ai[k] = 0;
      r = o;
    }
    ol = l;
    orr = r;
  }
};
// tempo-synced ping-pong delay with darkening repeats; delay changes glide instead of jumping
struct PingPong {
  std::vector<float> l, r;
  int n = 0, w = 0;
  float cur = 16000, target = 16000, fb = 0.38f, lpl = 0, lpr = 0;
  void init(int maxSamples) {
    n = maxSamples;
    l.assign(n, 0.f);
    r.assign(n, 0.f);
  }
  inline void proc(float in, float& ol, float& orr) {
    cur += (target - cur) * 0.00005f;
    float rp = (float)w - cur;
    if (rp < 0) rp += n;
    int i0 = (int)rp;
    float fr = rp - i0;
    int i1 = i0 + 1 >= n ? 0 : i0 + 1;
    float yl = l[i0] + (l[i1] - l[i0]) * fr, yr = r[i0] + (r[i1] - r[i0]) * fr;
    lpl += 0.45f * (yl - lpl);
    lpr += 0.45f * (yr - lpr);
    l[w] = in + lpr * fb;
    r[w] = lpl * fb;
    if (++w >= n) w = 0;
    ol = yl;
    orr = yr;
  }
};

static const float MUS_GAIN = 0.22f;  // music bus trim (calibrated so music sits under the SFX)
// white-box test hooks (tests compile this file directly; the game never changes these)
static uint32_t g_dbgTrackMask = 0xFFFFFFFFu;
static int g_dbgStyle = -1;
static const float MUS_LIMIT = 0.9f; // music bus peak limit (before the music volume)

// ================================================================ music: the engine
struct MusicEngine {
  MVoice v[MAXMV];
  uint32_t age = 0;
  NoteEv q[MAXEV];
  int qh = 0, qn = 0;
  int64_t clock = 0;
  double nextBeatT = 0, barStartT = 0, beatLen = 22050, stepLen = 5512.5;
  int beatInBar = 0;
  Song song;
  bool haveSong = false, switchPending = false, fillDone = false;
  int curMood = -1, lastReq = -1;
  int64_t reqSince = 0;
  float reqInt = 0, barInt = 0, bpmCur = 90;
  int secIdx = 0, barInSec = 0, barNo = 0, songSerial = 0;
  int padV[6], padN = 0, compV[6], compN = 0;
  int leadPrev = -1, lead2Prev = -1, ctrPrev = -1, leadAnchor = 0, lead2Anchor = 0;
  struct BarChord {
    Chord c;
    int s0, s1;  // step range relative to the bar start (may extend beyond the bar)
  };
  BarChord bc[8];
  int nbc = 0, barKey = 60;
  Chord nextCh{0, Q_MAJ, 4};
  Reverb rev;
  PingPong dly;
  float wet = 0.3f, wetT = 0.3f, lev = 0;
  float dcx[2] = {0, 0}, dcy[2] = {0, 0}, tl[2] = {0, 0};
  bool wonky = false;
  double wobT = 0;
  float wob = 1.f;
  float bl[FRAMES], br[FRAMES], bs[FRAMES], bd[FRAMES];
  Rng rng;
  MusicStats* st = nullptr;
  double songE = 0;  // (stats only) energy of the current song on the music bus
  int64_t songN = 0;

  explicit MusicEngine(uint64_t seed) : rng(seed) {
    rev.init();
    dly.init((int)(1.6 * RATE));
  }

  // ---------------------------------------------------------------- theory helpers
  int degToMidi(int key, int deg) const {
    int o = floorDiv(deg, song.scaleN);
    return key + 12 * o + song.scale[deg - o * song.scaleN];
  }
  int midiToDeg(int key, int m) const {
    int rel = m - key, o = floorDiv(rel, 12), pc = rel - o * 12, idx = 0;
    for (int k = 0; k < song.scaleN; ++k)
      if (song.scale[k] <= pc) idx = k;
    return o * song.scaleN + idx;
  }
  uint16_t scaleMask(int key) const {
    uint16_t m = 0;
    for (int k = 0; k < song.scaleN; ++k) m |= (uint16_t)(1 << modp(key + song.scale[k], 12));
    return m;
  }
  int chordIndexAt(int step) const {
    for (int k = nbc - 1; k >= 0; --k)
      if (step >= bc[k].s0) return k;
    return 0;
  }
  const Chord& chordAt(int step) const { return bc[chordIndexAt(step)].c; }
  int chooseAnchor(const Chord& c, int key, int target) {
    int pcs[6];
    int n = std::min(chordPcs(c, key, pcs), 3), best = target, bdist = 99;
    for (int i = 0; i < n; ++i) {
      int m = nearestPc(pcs[i], target);
      int d = std::abs(m - target) + (rng.chance(0.3f) ? 1 : 0);
      if (d < bdist) bdist = d, best = m;
    }
    return midiToDeg(key, best);
  }

  // ---------------------------------------------------------------- timing
  double stepT(int s) const {  // with swing
    double pos = s;
    if (song.swing > 0.f && song.sub % 2 == 0 && s >= 0) {
      int unit = song.swing16 ? song.sub / 2 : song.sub;
      if (unit >= 2) {
        int k = s % unit;
        double half = unit * 0.5, d = song.swing * unit / 6.0;
        double p = k <= half ? k * (half + d) / half : (half + d) + (k - half) * (half - d) / half;
        pos = (s - k) + p;
      }
    }
    return barStartT + pos * stepLen;
  }
  double jit(float amt) { return song.human > 0 ? (double)(rng.f() - 0.5f) * 0.012 * RATE * song.human * amt : 0.0; }
  float hv() { return song.human > 0 ? 1.f + (rng.f() - 0.5f) * 0.14f : 1.f; }

  // ---------------------------------------------------------------- events
  void emit(double t, int ins, float midi, float vel, double dur, int track, float pan, float send, float dsend,
            float atk = 0.f, float rel = 0.f, float bright = 1.f, uint8_t flags = 0, float glide = 0.f) {
    if (qn >= MAXEV || ins < 0 || ins >= IN_COUNT) return;
    if (wonky && !g_ins[ins].drum) midi += rng.rangef(-0.16f, 0.16f);
    if (song.st) vel *= song.st->gain;
    NoteEv& e = q[qn++];
    e.t = t;
    e.midi = midi;
    e.vel = vel;
    e.dur = (float)dur;
    e.pan = pan;
    e.send = send;
    e.dsend = dsend;
    e.atk = atk;
    e.rel = rel;
    e.bright = bright;
    e.glide = glide;
    e.ins = (uint8_t)ins;
    e.track = (uint8_t)track;
    e.flags = flags;
  }
  void sortQueue() {
    if (qh > 0) {
      memmove(q, q + qh, (size_t)(qn - qh) * sizeof(NoteEv));
      qn -= qh;
      qh = 0;
    }
    std::sort(q, q + qn, [](const NoteEv& a, const NoteEv& b) { return a.t < b.t; });
  }
  static void releaseVoice(MVoice& x, float sec) {
    float m = std::exp(-6.9f / (sec * RATE));
    x.envMul = x.releasing ? std::min(x.envMul, m) : m;
    x.envAdd = 0;
    x.releasing = true;
  }
  void fadeAll(float sec) {
    for (MVoice& x : v)
      if (x.d) releaseVoice(x, sec);
  }
  int alloc(int track, bool mono) {
    int freeI = -1, cnt = 0, oldest = -1;
    uint32_t oa = UINT32_MAX;
    for (int i = 0; i < MAXMV; ++i) {
      MVoice& x = v[i];
      if (!x.d) {
        if (freeI < 0) freeI = i;
        continue;
      }
      if (x.track != track || x.releasing) continue;
      if (mono) {
        releaseVoice(x, track == TR_HAT ? 0.03f : 0.05f);
        continue;
      }
      ++cnt;
      if (x.age < oa) oa = x.age, oldest = i;
    }
    if (!mono && cnt >= TRACK_CAP[track] && oldest >= 0) releaseVoice(v[oldest], 0.06f);
    if (freeI >= 0) return freeI;
    int best = -1, oldestAll = 0;
    float be = 1e9f;
    uint32_t ba = UINT32_MAX;
    for (int i = 0; i < MAXMV; ++i) {
      if (v[i].releasing && v[i].env < be) be = v[i].env, best = i;
      if (v[i].age < ba) ba = v[i].age, oldestAll = i;
    }
    if (st) st->steals++;
    return best >= 0 ? best : oldestAll;
  }
  void fire(const NoteEv& e) {
    if (e.ins >= IN_COUNT || !((g_dbgTrackMask >> e.track) & 1u)) return;  // cancelled / muted by a test
    const Instr& I = g_ins[e.ins];
    if (e.flags & EV_EXTEND)
      for (MVoice& x : v)
        if (x.d && !x.releasing && x.track == e.track && x.ins == e.ins && std::fabs(x.midi - e.midi) < 0.01f) {
          x.relAt = clock + (int64_t)e.dur;
          return;
        }
    const Zone* z = &I.z[0];
    float bdist = 1e9f;
    for (int k = 0; k < I.nz; ++k) {
      float d = std::fabs(e.midi - I.z[k].base);
      if (d < bdist) bdist = d, z = &I.z[k];
    }
    if (z->len <= 1) return;
    bool mono = e.track == TR_BASS || e.track == TR_HAT || ((e.track == TR_LEAD || e.track == TR_LEAD2) && I.loop);
    MVoice& x = v[alloc(e.track, mono)];
    x.d = z->d.data();
    x.len = z->len;
    x.loopStart = z->loopStart;
    x.pos = 0;
    x.rate = std::pow(2.f, (e.midi - z->base) / 12.f);
    x.glide = 1.f;
    x.glideN = 0;
    if (e.glide != 0.f) {
      x.glide = std::pow(2.f, e.glide / 12.f / RATE);
      x.glideN = (int)std::max(0.f, e.dur);
    }
    float g = e.vel * I.gain, p = clampv(e.pan, -1.f, 1.f);
    x.gl = g * std::sqrt(0.5f * (1 - p));
    x.gr = g * std::sqrt(0.5f * (1 + p));
    x.gs = g * e.send;
    x.gd = g * e.dsend;
    if (e.atk > 0.001f) x.env = 0, x.envAdd = 1.f / (e.atk * RATE);
    else x.env = 1, x.envAdd = 0;
    x.envMul = 1;
    x.releasing = false;
    x.relMul = std::exp(-6.9f / ((e.rel > 0 ? e.rel : I.rel) * RATE));
    x.relAt = e.dur > 0 ? clock + (int64_t)e.dur : (I.loop ? clock + 2 * RATE : INT64_MAX);
    if (e.bright >= 0.999f) x.lpA = 1.f;
    else x.lpA = 1.f - std::exp(-TAU * 250.f * std::pow(2.f, e.bright * 6.5f) / RATE);
    x.lp = 0;
    x.midi = e.midi;
    x.track = e.track;
    x.ins = e.ins;
    x.age = ++age;
    x.wob = wonky && !I.drum;
    if (st) st->notes++;
  }

  // ---------------------------------------------------------------- voice rendering (hot path)
  template <bool GLIDE> static void runVoice(MVoice& x, float* L, float* R, float* S, float* D, int a, int b, float wobv) {
    const float* d = x.d;
    double pos = x.pos;
    const float wm = x.wob ? wobv : 1.f;
    float rate = x.rate * wm;
    const double len = x.len, loopLen = x.loopStart >= 0 ? (double)(x.len - x.loopStart) : 0.0;
    float env = x.env, lp = x.lp;
    const float em = x.envMul, ea = x.envAdd, la = x.lpA, gl = x.gl, gr = x.gr, gs = x.gs, gd = x.gd;
    int gn = x.glideN;
    for (int i = a; i < b; ++i) {
      int ip = (int)pos;
      float fr = (float)(pos - ip);
      float s = d[ip] + (d[ip + 1] - d[ip]) * fr;
      lp += la * (s - lp);
      env = env * em + ea;
      if (env > 1.f) env = 1.f;
      float o = lp * env;
      L[i] += o * gl;
      R[i] += o * gr;
      S[i] += o * gs;
      D[i] += o * gd;
      pos += rate;
      if (GLIDE && gn > 0) rate *= x.glide, --gn;
      if (pos >= len) {
        if (loopLen > 0) pos -= loopLen;
        else {
          x.d = nullptr;
          return;
        }
      }
    }
    x.pos = pos;
    x.env = env;
    x.lp = lp;
    if (GLIDE) x.rate = rate / wm, x.glideN = gn;
    if (x.releasing && env < 1e-4f) x.d = nullptr;
  }
  void runRange(MVoice& x, int a, int b, float* L, float* R, float* S, float* D) {
    if (x.glideN > 0) runVoice<true>(x, L, R, S, D, a, b, wob);
    else runVoice<false>(x, L, R, S, D, a, b, wob);
  }
  void renderVoices(float* L, float* R, float* S, float* D, int n) {
    for (MVoice& x : v) {
      if (!x.d) continue;
      int a = 0;
      if (!x.releasing && x.relAt < clock + n) {
        int k = (int)std::max<int64_t>(0, x.relAt - clock);
        if (k > 0) runRange(x, 0, k, L, R, S, D);
        if (!x.d) continue;
        releaseVoice(x, 1.f);
        x.envMul = x.relMul;
        a = k;
      }
      if (a < n) runRange(x, a, n, L, R, S, D);
    }
  }

  // ---------------------------------------------------------------- composing a song
  void genForm(Song& s) {
    const Style& sty = *s.st;
    float barSec = s.beats * 60.f / s.bpm;
    bool shortForm = (sty.flags & F_SHORT) != 0;
    float target = shortForm ? rng.rangef(26.f, 40.f) : rng.rangef(85.f, 160.f);
    int unit = clampv((int)std::lround(18.f / barSec / 4.f) * 4, 4, 16);
    if (shortForm) unit = clampv(unit, 4, 8);
    int total = std::max(unit * 2 + 4, (int)(target / barSec));
    s.nsec = 0;
    auto add = [&](int kind, int bars) {
      if (s.nsec >= 24) return;
      Section& x = s.sec[s.nsec++];
      x = Section();
      x.kind = (uint8_t)kind;
      x.bars = (uint8_t)bars;
    };
    int intro = (barSec > 2.6f || shortForm) ? 2 : 4;
    add(SK_INTRO, intro);
    int used = intro, prev = SK_INTRO;
    bool hadB = false;
    while (used + unit + 2 <= total && s.nsec < 21) {
      float x = rng.f();
      int k;
      switch (prev) {
        case SK_INTRO: k = SK_A; break;
        case SK_A: k = x < 0.35f ? SK_A2 : x < 0.8f ? SK_B : SK_BREAK; break;
        case SK_A2: k = x < 0.55f ? SK_B : x < 0.75f ? SK_BREAK : SK_CLIMAX; break;
        case SK_B: k = x < 0.45f ? SK_A2 : x < 0.75f ? SK_CLIMAX : SK_BREAK; break;
        case SK_BREAK: k = x < 0.35f ? SK_B : x < 0.65f ? SK_A : SK_CLIMAX; break;
        default: k = x < 0.4f ? SK_A2 : x < 0.75f ? SK_BREAK : SK_B; break;
      }
      if (shortForm && k == SK_CLIMAX) k = SK_A2;
      int bars = k == SK_BREAK ? std::max(2, unit / 2) : unit;
      add(k, bars);
      used += bars;
      prev = k;
      hadB |= k == SK_B;
    }
    if (!hadB && !shortForm && s.nsec >= 3) s.sec[s.nsec - 1].kind = SK_B;
    add(SK_OUTRO, barSec > 2.6f ? 2 : 4);
    int modAt = -1;
    if ((sty.flags & F_MODUP) && s.nsec >= 5 && rng.chance(0.6f))
      for (int i = s.nsec - 2; i >= 3; --i)
        if (s.sec[i].kind == SK_A2 || s.sec[i].kind == SK_CLIMAX || s.sec[i].kind == SK_B) {
          modAt = i;
          break;
        }
    int8_t tr = 0;
    uint16_t prevRoles = 0;
    s.totalBars = 0;
    for (int i = 0; i < s.nsec; ++i) {
      Section& x = s.sec[i];
      static const float EN[7] = {0.18f, 0.42f, 0.52f, 0.62f, 0.18f, 0.84f, 0.15f};
      x.energy = clampv(EN[x.kind] + rng.rangef(-0.05f, 0.05f), 0.f, 1.f);
      switch (x.kind) {
        case SK_B: x.prog = 1, x.motif = 1; break;
        case SK_A2: x.prog = 2, x.motif = 2; break;
        case SK_CLIMAX: x.prog = rng.chance(0.5f) ? 1 : 0, x.motif = rng.chance(0.5f) ? 0 : 2; break;
        case SK_BREAK: x.prog = (uint8_t)rng.range(0, 1), x.motif = 0; break;
        case SK_OUTRO: x.prog = 3, x.motif = 0; break;
        default: x.prog = 0, x.motif = 0; break;
      }
      bool altLead = (x.kind == SK_B || (x.kind == SK_CLIMAX && rng.chance(0.5f))) && rng.chance(0.65f);
      x.lead = altLead ? s.insLeadB : s.insLeadA;
      x.lead2 = s.insLead2;
      x.arpIns = ((x.kind == SK_B || x.kind == SK_BREAK) && rng.chance(0.4f)) ? s.insArp2 : s.insArp;
      float y = rng.f();
      x.melMode = MM_COUNTER;
      if ((sty.flags & F_HARM3) && y < 0.45f) x.melMode = MM_HARM;
      else if (y < 0.4f) x.melMode = MM_CALLRESP;
      else if (y < 0.52f) x.melMode = MM_OCT;
      if (i == modAt) tr = (int8_t)(tr + (rng.chance(0.7f) ? 2 : 1));
      x.transpose = tr;
      x.tempoMul = (sty.flags & F_LURCH) ? rng.rangef(0.93f, 1.07f) : 1.f;
      x.roles = pickRoles(s, x, prevRoles);
      prevRoles = x.roles;
      s.totalBars += x.bars;
    }
    for (int i = 0; i + 1 < s.nsec; ++i) {
      float up = s.sec[i + 1].energy - s.sec[i].energy;
      s.sec[i].fill = up > 0.15f ? (rng.chance(0.55f) ? 2 : 1) : (rng.chance(0.45f) ? 1 : 0);
    }
  }
  uint16_t pickRoles(const Song& s, const Section& x, uint16_t prevRoles) {
    const Style& sty = *s.st;
    float E = clampv(x.energy + sty.ebias, 0.f, 1.f);
    bool hasComp = s.insComp != IN_NONE;
    uint16_t r = R_PAD;
    switch (x.kind) {
      case SK_INTRO:
        if (rng.chance(0.55f) || (sty.flags & F_OSTINATO)) r |= R_ARP;
        if (rng.chance(0.3f)) r |= R_BASS;
        if (rng.chance(0.2f)) r |= R_LEAD;
        break;
      case SK_BREAK:
        if (sty.space < 0.3f && rng.chance(0.45f)) r &= ~R_PAD;  // sparse styles keep their pad
        r |= R_ARP;
        if (rng.chance(0.5f)) r |= R_LEAD;
        break;
      case SK_OUTRO:
        if (rng.chance(0.4f)) r |= R_ARP;
        if (rng.chance(0.5f)) r |= R_BASS;
        break;
      default:
        if (rng.chance(sty.leadProb)) r |= R_LEAD;
        if (E >= 0.3f || rng.chance(0.5f)) r |= R_BASS;
        if (rng.chance(clampv(sty.arpProb + (E - 0.5f) * 0.4f, 0.1f, 0.97f))) r |= R_ARP;
        if (E >= 0.5f && rng.chance(0.55f)) r |= R_LEAD2;
        if (hasComp && E >= 0.35f && rng.chance(sty.compProb)) r |= R_COMP;
        if (x.kind == SK_A && rng.chance(0.2f)) r &= ~R_PAD;
        break;
    }
    if (!(sty.flags & F_NODRUMS)) {
      if (x.kind != SK_BREAK && x.kind != SK_OUTRO && E >= sty.drumAt) r |= R_DRUMS;
      else if (x.kind != SK_OUTRO && E >= 0.22f && rng.chance(0.7f)) r |= R_PERC;
    }
    if ((sty.flags & (F_BUBBLES | F_SPARKLE | F_DRIPS | F_TOLL | F_DRONE | F_ANVIL | F_TIMP | F_FANFARE | F_WONKY)) && rng.chance(0.75f)) r |= R_FX;
    if (x.kind == SK_CLIMAX) r |= R_BASS | R_LEAD | (hasComp ? R_COMP : 0);
    if (r == prevRoles && x.kind != SK_OUTRO) r ^= rng.chance(0.5f) ? R_ARP : (hasComp ? R_COMP : R_LEAD2);
    if (!(r & (R_PAD | R_ARP | R_LEAD))) r |= R_ARP;
    return r;
  }
  static int differences(const Song& a, const Song& b) {
    int d = 0;
    d += a.styleIdx != b.styleIdx ? 2 : 0;
    d += a.key != b.key;
    d += std::fabs(a.bpm - b.bpm) >= 4.f;
    d += memcmp(a.pA.c, b.pA.c, sizeof(Chord) * (size_t)std::max(a.pA.n, b.pA.n)) != 0 || a.pA.n != b.pA.n;
    d += a.insLeadA != b.insLeadA;
    d += a.insArp != b.insArp;
    d += a.gId[1] != b.gId[1];
    return d;
  }
  void logSongEnd() {
    if (!st || !song.st || songN <= 0) return;
    char buf[160];
    snprintf(buf, sizeof buf, "   end #%d '%s' %.0f s, bus rms %.1f dB\n", song.serial, song.st->name, songN / 2.0 / RATE,
             10.0 * std::log10(songE / songN + 1e-20));
    st->log += buf;
    songE = 0;
    songN = 0;
  }
  void newSong(int mood, bool continuing) {
    logSongEnd();
    const std::vector<Style>& V = g_styles[mood];
    bool same = continuing && song.mood == mood;
    Song s;
    for (int attempt = 0; attempt < 10; ++attempt) {
      s = Song();
      s.mood = mood;
      int si = rng.range(0, (int)V.size() - 1);
      if (same && V.size() > 1 && si == song.styleIdx && rng.chance(0.6f)) si = (si + 1 + rng.range(0, (int)V.size() - 2)) % (int)V.size();
      if (g_dbgStyle >= 0 && g_dbgStyle < (int)V.size()) si = g_dbgStyle;
      s.styleIdx = si;
      s.st = &V[si];
      const Style& sty = *s.st;
      s.key = pickv(sty.keys, 60);
      if (same && song.styleIdx == si && rng.chance(0.35f)) s.key = song.key;
      s.mode = pickv(sty.modes, (int)MD_AEO);
      s.scaleN = MODES[s.mode][0];
      s.major = false;
      for (int k = 0; k < s.scaleN; ++k) {
        s.scale[k] = MODES[s.mode][1 + k];
        if (s.scale[k] == 4) s.major = true;
      }
      s.beats = sty.beats;
      s.sub = sty.sub;
      s.steps = s.beats * s.sub;
      s.bpm = std::round(rng.rangef(sty.bpmLo, sty.bpmHi));
      s.swing = rng.rangef(sty.swLo, sty.swHi);
      s.swing16 = sty.sw16;
      s.human = (sty.flags & F_STRICT) ? 0.f : rng.rangef(0.6f, 1.2f);
      s.pA = sty.A[rng.range(0, (int)sty.A.size() - 1)];
      s.pB = sty.B[rng.range(0, (int)sty.B.size() - 1)];
      s.pX = sty.X[rng.range(0, (int)sty.X.size() - 1)];
      s.insPad = (uint8_t)pickv(sty.pad, IN_WARMPAD);
      s.insBass = (uint8_t)pickv(sty.bass, IN_PBASS);
      s.insArp = (uint8_t)pickv(sty.arp, IN_HARP);
      s.insArp2 = (uint8_t)pickv(sty.arp, IN_HARP);
      s.insLeadA = (uint8_t)pickv(sty.lead, IN_FLUTE);
      s.insLeadB = (uint8_t)pickv(sty.lead, IN_FLUTE);
      if (s.insLeadB == s.insLeadA) s.insLeadB = (uint8_t)pickv(sty.lead, IN_FLUTE);
      s.insLead2 = (uint8_t)pickv(sty.lead2, IN_BELL);
      if (s.insLead2 == s.insLeadA) s.insLead2 = (uint8_t)pickv(sty.lead2, IN_BELL);
      s.insComp = sty.comp.empty() ? (uint8_t)IN_NONE : (uint8_t)pickv(sty.comp, IN_EPIANO);
      s.gId[0] = (uint8_t)pickv(sty.gLo, G_NONE);
      s.gId[1] = (uint8_t)pickv(sty.gMid, s.gId[0]);
      s.gId[2] = (uint8_t)pickv(sty.gHi, s.gId[1]);
      if (!continuing || !same || differences(song, s) >= 3) break;
    }
    const Style& sty = *s.st;
    s.serial = ++songSerial;
    s.seed = rng.next();
    // harmony variants
    if (sty.flags & F_JAZZY)
      for (Prog* p : {&s.pA, &s.pB})
        for (int i = 0; i < p->n; ++i) {
          Chord& c = p->c[i];
          if (c.q == Q_MIN && rng.chance(0.6f)) c.q = Q_MIN7;
          else if (c.q == Q_MAJ && rng.chance(0.5f)) c.q = c.root == 7 ? Q_DOM7 : Q_MAJ7;
        }
    s.pA2 = s.pA;
    if (s.pA2.n >= 2) {
      Chord& last = s.pA2.c[s.pA2.n - 1];
      float x = rng.f();
      if (x < 0.4f) {  // dominant cadence
        if (!(last.root == 7 && (last.q == Q_MAJ || last.q == Q_DOM7))) last.root = 7, last.q = rng.chance(0.5f) ? Q_MAJ : Q_DOM7;
      } else if (x < 0.6f) {  // plagal / borrowed subdominant
        last.root = 5;
        last.q = s.major ? (rng.chance(0.5f) ? Q_MIN : Q_MAJ) : Q_MIN;
      } else if (x < 0.75f) {  // relative substitution
        Chord& c = s.pA2.c[1];
        if (c.q == Q_MAJ) c.root = (int8_t)modp(c.root + 9, 12), c.q = Q_MIN;
        else if (c.q == Q_MIN) c.root = (int8_t)modp(c.root + 3, 12), c.q = Q_MAJ;
      } else if (x < 0.85f && !s.major) {
        last.root = 10, last.q = Q_MAJ;  // bVII
      }
    }
    s.pT = Prog();
    s.pT.c[0] = Chord{0, (uint8_t)(s.mode == MD_WHOLE ? Q_AUG : s.major ? Q_MAJ : Q_MIN), (uint8_t)s.beats};
    s.pT.n = 1;
    s.pT.beats = s.beats;
    // patterns
    for (int i = 0; i < 3; ++i) {
      const GrooveDef& G = GROOVE[s.gId[i]];
      MGroove& m = s.g[i];
      m.n = 0;
      for (int l = 0; l < 6 && G.l[l].p; ++l) {
        m.drum[m.n] = G.l[l].drum;
        mapPat(G.l[l].p, s.steps, m.pat[m.n]);
        ++m.n;
      }
    }
    s.bId[0] = (uint8_t)pickv(sty.bLo, B_WHOLE);
    s.bId[1] = (uint8_t)pickv(sty.bMid, s.bId[0]);
    s.bId[2] = (uint8_t)pickv(sty.bHi, s.bId[1]);
    for (int i = 0; i < 3; ++i) mapPat(BASSPAT[s.bId[i]], s.steps, s.bpat[i]);
    s.compId = (uint8_t)pickv(sty.compPat, C_HALF);
    mapPat(COMPPAT[s.compId], s.steps, s.cpat);
    s.arpStyle = (uint8_t)pickv(sty.arpSt, A_UP);
    if (s.sub == 4) s.arpRate = rng.chance(s.bpm < 90 ? 0.55f : 0.3f) ? 1 : 2;
    else if (s.sub == 3) s.arpRate = 1;
    else s.arpRate = rng.chance(0.7f) ? 1 : 2;
    s.arpOct = (uint8_t)(rng.chance(0.5f) ? 1 : 2);
    s.arpSkip = (sty.flags & F_SPARKLE) ? sty.space * 0.6f : rng.rangef(0.f, 0.15f);
    s.arpLo = g_ins[s.insArp].center - rng.range(3, 8);
    s.useOstin = (sty.flags & F_OSTINATO) && rng.chance(0.75f);
    s.ostRate = (uint8_t)((s.sub == 4 && s.bpm > 112) ? 2 : 1);
    {
      int cl = rng.range(3, 6), cell[6];
      for (int k = 0; k < cl; ++k) cell[k] = (k > 0 && rng.chance(0.12f)) ? -1 : rng.range(0, 3);
      for (int k = 0; k < 48; ++k) s.ostin[k] = (int8_t)cell[k % cl];
    }
    s.padLo = (s.insPad == IN_ORGAN ? 48 : 51) + rng.range(0, 4);
    s.padVoices = rng.chance(0.6f) ? 4 : 3;
    s.padAtk = rng.rangef(0.05f, 0.6f);
    s.padRel = rng.rangef(0.5f, 1.2f);
    s.padStyle = (uint8_t)(((sty.flags & F_PADPULSE) && rng.chance(0.3f)) ? 1 : 0);
    s.leadOff = rng.range(-3, 3);
    s.leadPan = rng.rangef(-0.25f, 0.25f);
    s.lead2Pan = clampv(-s.leadPan * 1.5f + rng.rangef(-0.2f, 0.2f), -0.6f, 0.6f);
    s.arpPan = rng.rangef(-0.45f, 0.45f);
    s.compPan = clampv(-s.arpPan * 0.8f, -0.5f, 0.5f);
    s.respType = (uint8_t)rng.range(0, 3);
    s.displace = rng.chance(0.35f);
    s.delayBeats = s.sub == 3 ? 1.f : (rng.chance(0.5f) ? 0.75f : (rng.chance(0.5f) ? 0.5f : 1.f));
    // motifs
    float dens = clampv(sty.density + rng.rangef(-0.12f, 0.12f), 0.1f, 0.95f);
    s.mA = genMotif(rng, s.beats, s.sub, sty.motifBars, dens);
    s.mB = rng.chance(0.4f) ? mvRetro(mvInvert(s.mA)) : genMotif(rng, s.beats, s.sub, sty.motifBars, clampv(dens + rng.rangef(-0.25f, 0.25f), 0.1f, 0.95f));
    float y = rng.f();
    s.mA2 = y < 0.5f ? mvOrnament(s.mA, rng) : y < 0.75f ? mvDisplace(s.mA, std::max(1, s.sub / 2)) : mvTranspose(s.mA, rng.chance(0.5f) ? 2 : -2);
    s.mX = mvDiminish(s.mA, rng);
    genForm(s);
    song = s;
    wonky = (sty.flags & F_WONKY) != 0;
    wetT = sty.verb;
    dly.fb = clampv(0.3f + sty.dly * 0.4f, 0.3f, 0.5f);
    rev.damp = sty.verb > 0.5f ? 0.25f : 0.35f;
    secIdx = barInSec = 0;
    padN = compN = 0;
    leadPrev = lead2Prev = ctrPrev = -1;
    if (st) {
      st->songs++;
      char pa[96], pb[96], px[96], form[160], buf[1024];
      progText(s.pA, pa, sizeof pa);
      progText(s.pB, pb, sizeof pb);
      progText(s.pX, px, sizeof px);
      int w = 0;
      form[0] = 0;
      for (int i = 0; i < s.nsec && w < (int)sizeof form - 8; ++i) w += snprintf(form + w, sizeof form - w, "%s%s%d", i ? " " : "", SK_NAME[s.sec[i].kind], s.sec[i].bars);
      snprintf(buf, sizeof buf,
               "#%d mood %d '%s' %s %s %.0fbpm %d/%d sw%.2f | A[%s] B[%s] X[%s] | pad %s bass %s arp %s/%s(%s%s) lead %s/%s lead2 %s comp %s(%s) | "
               "drums %s/%s/%s bass %s/%s/%s | %d bars: %s\n",
               s.serial, mood, sty.name, NOTE_NAME[modp(s.key, 12)], MODE_NAME[s.mode], s.bpm, s.sub == 3 ? s.beats * 3 : s.beats, s.sub == 3 ? 8 : 4, s.swing, pa, pb, px,
               g_ins[s.insPad].name, g_ins[s.insBass].name, g_ins[s.insArp].name, g_ins[s.insArp2].name, ARP_NAME[s.arpStyle],
               s.useOstin ? ",ostinato" : "", g_ins[s.insLeadA].name, g_ins[s.insLeadB].name, g_ins[s.insLead2].name,
               s.insComp == IN_NONE ? "-" : g_ins[s.insComp].name, COMPNAME[s.compId], GROOVE[s.gId[0]].name, GROOVE[s.gId[1]].name, GROOVE[s.gId[2]].name,
               BASSNAME[s.bId[0]], BASSNAME[s.bId[1]], BASSNAME[s.bId[2]], s.totalBars, form);
      st->log += buf;
    }
  }
  template <class T> int pickv(const std::vector<T>& vv, int def) { return vv.empty() ? def : (int)vv[rng.range(0, (int)vv.size() - 1)]; }

  // ---------------------------------------------------------------- one bar at a time
  void setupChords(const Section& S, bool combat) {
    const Prog* P = &song.pA;
    if (combat) P = &song.pX;
    else if (S.prog == 1) P = &song.pB;
    else if (S.prog == 2) P = &song.pA2;
    else if (S.prog == 3) P = &song.pT;
    int pbars = std::max(1, P->beats / song.beats);
    if (!combat && S.prog == 0 && pbars * 2 <= S.bars && (barInSec / pbars) % 2 == 1) P = &song.pA2;  // answer phrase cadences
    int beat0 = (barInSec % pbars) * song.beats, acc = 0;
    nbc = 0;
    for (int k = 0; k < P->n && nbc < 8; ++k) {
      int c0 = acc, c1 = acc + P->c[k].beats;
      acc = c1;
      if (c1 <= beat0 || c0 >= beat0 + song.beats) continue;
      bc[nbc++] = BarChord{P->c[k], (c0 - beat0) * song.sub, (c1 - beat0) * song.sub};
    }
    if (!nbc) bc[nbc++] = BarChord{Chord{0, (uint8_t)(song.major ? Q_MAJ : Q_MIN), (uint8_t)song.beats}, 0, song.steps};
    int nb = (beat0 + song.beats) % std::max(1, P->beats);
    acc = 0;
    nextCh = P->c[0];
    for (int k = 0; k < P->n; ++k) {
      if (nb >= acc && nb < acc + P->c[k].beats) {
        nextCh = P->c[k];
        break;
      }
      acc += P->c[k].beats;
    }
  }
  void genBar() {
    if (secIdx >= song.nsec) {
      newSong(curMood, true);
      bpmCur = song.bpm * (1.f + 0.08f * barInt);
    }
    const Section& S = song.sec[secIdx];
    const Style& sty = *song.st;
    float inten = barInt;
    bool combat = inten >= 0.6f;
    float target = song.bpm * S.tempoMul * (1.f + 0.08f * inten);
    if (sty.flags & F_LURCH) bpmCur = target;
    else {
      float mx = bpmCur * 0.035f;
      bpmCur += clampv(target - bpmCur, -mx, mx);
    }
    float bpmBar = bpmCur;
    bool lastBar = barInSec == S.bars - 1;
    if ((sty.flags & F_LURCH) && lastBar && rng.chance(0.5f)) bpmBar *= 0.9f;  // lurching ritardando
    beatLen = RATE * 60.0 / bpmBar;
    stepLen = beatLen / song.sub;
    barStartT = nextBeatT;
    dly.target = (float)clampv(song.delayBeats * beatLen, 2000.0, (double)dly.n - 4.0);
    setupChords(S, combat);
    int key = song.key + S.transpose;
    barKey = key;
    float E = clampv(S.energy + sty.ebias + inten * 0.55f, 0.f, 1.f);
    uint16_t roles = S.roles;
    if (inten >= 0.45f && !(sty.flags & F_NODRUMS)) roles |= R_DRUMS | R_BASS;
    if (inten >= 0.8f) {
      roles |= R_ARP | R_LEAD;
      if (song.insComp != IN_NONE) roles |= R_COMP;
    }
    if (roles & R_PAD) genPad(key, E, combat);
    if (roles & R_BASS) genBass(key, E, combat);
    if (roles & R_ARP) genArp(key, E, combat);
    if (roles & R_LEAD) genLead(key, E, combat, roles);
    else leadPrev = -1;
    bool lead2Busy = (roles & R_LEAD) && (S.melMode == MM_CALLRESP || S.melMode == MM_HARM || S.melMode == MM_OCT);
    if ((roles & R_LEAD2) && !lead2Busy) genCounter(key, E);
    if (roles & R_COMP) genComp(key, E);
    genDrums(key, E, combat, roles, lastBar);
    genColor(key, E, combat, roles, lastBar);
    ++barNo;
    if (st) st->bars++;
    if (++barInSec >= S.bars) {
      barInSec = 0;
      ++secIdx;
      if (st) st->sections++;
    }
    sortQueue();
  }
  void genPad(int key, float E, bool combat) {
    int ins = song.insPad, tmp[6];
    bool pulse = song.padStyle == 1 || (combat && (song.st->flags & F_PADPULSE));
    float vel = 0.15f * (0.7f + 0.4f * E);
    for (int k = 0; k < nbc; ++k) {
      const BarChord& b = bc[k];
      if (b.s0 < 0 && barInSec != 0) continue;  // still ringing from the previous bar
      int s0 = std::max(0, b.s0);
      int nv = voiceChord(b.c, key, song.padLo, song.padLo + 19, song.padVoices, padV, padN, tmp, rng);
      for (int i = 0; i < nv; ++i) padV[i] = tmp[i];
      padN = nv;
      if (!pulse) {
        double dur = (b.s1 - s0) * stepLen + 0.06 * RATE, t = stepT(s0);
        for (int i = 0; i < nv; ++i)
          emit(t + i * 0.004 * RATE * song.human, ins, (float)padV[i], vel * (i == 0 ? 1.f : 0.88f), dur, TR_PAD,
               -0.5f + (float)i / std::max(1, nv - 1), 0.75f, 0.f, song.padAtk, song.padRel);
      } else {
        int s1 = std::min(b.s1, song.steps), stp = std::max(1, song.sub / 2);
        for (int s = s0; s < s1; s += stp)
          for (int i = 0; i < nv; ++i)
            emit(stepT(s), ins, (float)padV[i], vel * (s % song.sub == 0 ? 1.f : 0.72f), stp * stepLen * 0.85, TR_PAD,
                 -0.5f + (float)i / std::max(1, nv - 1), 0.45f, 0.f, 0.004f, 0.07f);
      }
    }
  }
  void genBass(int key, float E, bool combat) {
    const Style& sty = *song.st;
    int ins = song.insBass;
    const Instr& I = g_ins[ins];
    int reg = I.center - 6;
    if ((sty.flags & F_DRONE) && E < 0.5f) {
      int r = reg + modp(key + bc[0].c.root - reg, 12);
      emit(stepT(0), ins, (float)r, 0.47f, song.steps * stepLen + 0.3 * RATE, TR_BASS, 0.f, 0.1f, 0.f, 0.4f, 0.8f, 1.f, EV_EXTEND);
      return;
    }
    int gi = (combat || E >= 0.72f) ? 2 : E >= 0.45f ? 1 : 0;
    const char* pat = song.bpat[gi];
    for (int s = 0; s < song.steps; ++s) {
      char c = pat[s];
      if (c == '.' || c == '-') continue;
      int e = song.steps;
      for (int j = s + 1; j < song.steps; ++j)
        if (pat[j] != '.') {
          e = j;
          break;
        }
      const Chord& ch = chordAt(s);
      int root = reg + modp(key + ch.root - reg, 12), pitch = root;
      switch (c) {
        case 'F': case 'f': pitch = root + 7 > reg + 14 ? root - 5 : root + 7; break;
        case 'O': case 'o': pitch = root + 12; break;
        case 'T': case 't': pitch = root + QUAL[ch.q][2]; break;
        case 'X': pitch = (barNo & 1) ? (root + 7 > reg + 14 ? root - 5 : root + 7) : root; break;
        case 'A': case 'a': {
          int nr = reg + modp(key + nextCh.root - reg, 12);
          pitch = rng.chance(0.5f) ? nr - 1 : snapTo(nr + 2, scaleMask(key), 1);
          break;
        }
        default: break;
      }
      float vel = 0.56f * (0.8f + 0.3f * E) * (std::islower((unsigned char)c) ? 0.75f : 1.f) * (s % song.sub == 0 ? 1.f : 0.86f);
      double dur = (e - s) * stepLen * (I.loop ? 0.92 : 0.97);
      emit(stepT(s) + jit(0.5f), ins, (float)pitch, vel * hv(), dur, TR_BASS, 0.f, 0.05f, 0.f, I.loop ? 0.008f : 0.f, 0.f);
    }
  }
  void genArp(int key, float E, bool combat) {
    const Section& S = song.sec[secIdx];
    int ins = S.arpIns;
    const Instr& I = g_ins[ins];
    int rate = song.useOstin ? song.ostRate : song.arpRate;
    if (!song.useOstin && (combat || E > 0.8f) && rate == 2 && song.sub != 3) rate = 1;
    int lo = song.arpLo, hi = lo + 12 * song.arpOct + 4, L[24], nL = 0, last = -1, idx = 0;
    float base = 0.24f * (0.75f + 0.35f * E) * (song.useOstin ? 1.35f : 1.f);  // an ostinato is a lead voice
    for (int s = 0; s < song.steps; s += rate) {
      int ci = chordIndexAt(s);
      if (ci != last) nL = chordNotes(bc[ci].c, key, lo, hi, L, 24), last = ci;
      if (!nL) continue;
      int note;
      if (song.useOstin) {
        int o = song.ostin[s % 48];
        if (o < 0) continue;
        note = L[o % nL];
      } else {
        if (s % song.sub != 0 && rng.chance(song.arpSkip)) {
          ++idx;
          continue;
        }
        note = L[arpOrder(song.arpStyle, idx++, nL)];
      }
      float vel = base * (s % song.sub == 0 ? 1.f : 0.8f) * hv();
      double dur = I.loop ? rate * stepLen * 0.9 : std::max(rate * stepLen * 3.0, 0.3 * RATE);
      emit(stepT(s) + jit(0.7f), ins, (float)note, vel, dur, TR_ARP, song.arpPan + ((s / rate) & 1 ? 0.12f : -0.12f), 0.6f,
           song.st->dly * 1.2f, I.loop ? 0.006f : 0.f, 0.f);
    }
  }
  void playMotifBar(const Motif& m, int part, int ins, int track, float vel, bool cadence, int key, int hmode, int hins) {
    const Instr& I = g_ins[ins];
    const Style& sty = *song.st;
    int s0 = part * song.steps, s1 = s0 + song.steps;
    int& prev = track == TR_LEAD ? leadPrev : lead2Prev;
    int& anchor = track == TR_LEAD ? leadAnchor : lead2Anchor;
    int center = I.center + song.leadOff;
    if (part == 0) {
      int target = (prev >= 0 && std::abs(prev - center) <= 9) ? prev : center;
      const Chord& c0 = chordAt(0);
      anchor = cadence ? midiToDeg(key, nearestPc(modp(key + c0.root, 12), target)) : chooseAnchor(c0, key, target);
    }
    int idx[32], pit[32], cnt = 0;
    for (int i = 0; i < m.cnt && cnt < 32; ++i)
      if (m.n[i].step >= s0 && m.n[i].step < s1) idx[cnt++] = i;
    if (!cnt) return;
    uint16_t smask = scaleMask(key);
    for (int j = 0; j < cnt; ++j) {
      const MNote& n = m.n[idx[j]];
      int s = n.step - s0;
      int midi = degToMidi(key, anchor + n.deg);
      const Chord& c = chordAt(s);
      uint16_t cm = chordMask(c, key);
      bool strong = (s % song.sub == 0 && ((s / song.sub) % 2 == 0 || song.beats == 3)) || n.len >= 2 * song.sub;
      int dir = j > 0 ? (n.deg >= m.n[idx[j - 1]].deg ? 1 : -1) : 1;
      midi = snapTo(midi, strong ? cm : chordScale(smask, cm), dir);
      if (cadence && idx[j] == m.cnt - 1) midi = nearestPc(modp(key + c.root, 12), midi);
      pit[j] = midi;
    }
    if (sty.flags & F_CHROMATIC)
      for (int j = 0; j + 1 < cnt; ++j) {
        const MNote& n = m.n[idx[j]];
        if (n.len <= 2 && (n.step - s0) % song.sub != 0 && std::abs(pit[j + 1] - pit[j]) >= 2 && rng.chance(0.4f))
          pit[j] = pit[j + 1] + (pit[j + 1] > pit[j] ? -1 : 1);
      }
    int mx = pit[0], mn = pit[0];
    for (int j = 1; j < cnt; ++j) mx = std::max(mx, pit[j]), mn = std::min(mn, pit[j]);
    int shift = 0;
    while (mx + shift > I.hi) shift -= 12;
    while (mn + shift < I.lo && mx + shift + 12 <= I.hi) shift += 12;
    float pan = track == TR_LEAD ? song.leadPan : song.lead2Pan;
    float dsend = sty.dly * (track == TR_LEAD ? 1.f : 0.8f);
    for (int j = 0; j < cnt; ++j) {
      const MNote& n = m.n[idx[j]];
      int s = n.step - s0, midi = pit[j] + shift;
      double dur = n.len * stepLen;
      if (I.loop) dur *= 0.93;
      else dur = std::max(dur, 0.25 * RATE) * 1.6;
      if (sty.flags & F_STACCATO) dur = std::min(dur, stepLen * 1.3);
      float v = vel * (n.vel / 255.f) * hv() * ((sty.flags & F_STACCATO) ? 1.3f : 1.f);  // short notes need a bit more level
      double t = stepT(s) + jit(0.8f);
      if ((sty.flags & F_GRACE) && I.loop && n.len >= song.sub && rng.chance(0.18f))
        emit(t - 0.05 * RATE, ins, (float)snapTo(midi + 2, smask, 1), v * 0.6f, 0.05 * RATE, track, pan, 0.4f, dsend, 0.f, 0.03f);
      emit(t, ins, (float)midi, v, dur, track, pan, 0.5f, dsend, I.loop ? 0.012f : 0.f, 0.f);
      if (hmode == MM_HARM || hmode == MM_OCT) {
        const Instr& H = g_ins[hins];
        int hm;
        if (hmode == MM_HARM) hm = snapTo(degToMidi(key, midiToDeg(key, midi) - 2), chordScale(smask, chordMask(chordAt(s), key)), -1);
        else hm = midi + 12;
        while (hm > H.hi) hm -= 12;
        while (hm < H.lo) hm += 12;
        emit(t + 0.002 * RATE, hins, (float)hm, v * (hmode == MM_HARM ? 0.62f : 0.42f), H.loop ? dur : std::max(dur, 0.3 * RATE), TR_LEAD2, -pan,
             0.5f, dsend, H.loop ? 0.012f : 0.f, 0.f);
      }
      prev = midi;
    }
  }
  void genLead(int key, float E, bool combat, uint16_t roles) {
    const Section& S = song.sec[secIdx];
    const Style& sty = *song.st;
    int mb = std::max(1, std::min(sty.motifBars, (int)S.bars));
    int units = std::max(1, S.bars / mb), unit = barInSec / mb, part = barInSec % mb, pos = unit % 4;
    const Motif* base = combat ? &song.mX : S.motif == 1 ? &song.mB : S.motif == 2 ? &song.mA2 : &song.mA;
    Rng vr(song.seed ^ ((uint64_t)S.kind * 7919u + (uint64_t)unit * 104729u + 17u));
    Motif m = *base;
    bool cadence = false, resp = S.melMode == MM_CALLRESP && (roles & R_LEAD2), useLead2 = false;
    switch (pos) {
      case 1:
        m = mvResponse(m, song.respType, vr);
        useLead2 = resp;
        break;
      case 2: m = song.displace ? mvDisplace(m, std::max(1, song.sub / 2)) : mvOrnament(m, vr); break;
      case 3:
        m = mvCadence(m, vr, song.sub);
        cadence = true;
        useLead2 = resp;
        break;
      default: break;
    }
    if (unit == units - 1 && !cadence && pos != 0) m = mvCadence(m, vr, song.sub), cadence = true;
    if (S.kind == SK_BREAK || S.kind == SK_INTRO || S.kind == SK_OUTRO) {
      if (pos % 2 == 1 && !vr.chance(0.3f)) return;
      m = mvSparse(m, song.sub);
    } else if (!resp && (pos == 1 || pos == 3) && !combat && vr.chance(sty.space)) {
      return;  // leave some air
    }
    int ins = useLead2 ? S.lead2 : S.lead, track = useLead2 ? TR_LEAD2 : TR_LEAD;
    float vel = (useLead2 ? 0.4f : 0.5f) * (0.75f + 0.35f * E);
    int hmode = (!useLead2 && (roles & R_LEAD2) && (S.melMode == MM_HARM || S.melMode == MM_OCT)) ? S.melMode : -1;
    playMotifBar(m, part, ins, track, vel, cadence, key, hmode, S.lead2);
  }
  void genCounter(int key, float E) {
    const Section& S = song.sec[secIdx];
    int ins = S.lead2;
    const Instr& I = g_ins[ins];
    int center = I.center - 5;
    float vel = 0.3f * (0.75f + 0.35f * E);
    for (int k = 0; k < nbc; ++k) {
      const BarChord& b = bc[k];
      if (b.s0 < 0 && barInSec != 0) continue;
      int s0 = std::max(0, b.s0), s1 = std::min(song.steps, b.s1);
      int parts = (s1 - s0 >= song.steps && E > 0.5f && song.beats == 4) ? 2 : 1;
      for (int p = 0; p < parts; ++p) {
        int s = s0 + p * (s1 - s0) / parts, target = ctrPrev >= 0 ? ctrPrev : center, pcs[6];
        int n = std::min(chordPcs(b.c, key, pcs), 4), best = target, bdist = 99;
        for (int i = 0; i < n; ++i) {
          int m = nearestPc(pcs[i], target), d = std::abs(m - target);
          if (d == 0 && rng.chance(0.5f)) d = 3;
          if (d < bdist) bdist = d, best = m;
        }
        while (best > I.hi) best -= 12;
        while (best < I.lo) best += 12;
        double dur = (double)(s1 - s0) / parts * stepLen * (I.loop ? 0.96 : 1.4);
        emit(stepT(s) + jit(0.5f), ins, (float)best, vel * hv(), dur, TR_LEAD2, song.lead2Pan, 0.55f, song.st->dly * 0.6f,
             I.loop ? 0.06f : 0.f, 0.f);
        ctrPrev = best;
      }
    }
  }
  void genComp(int key, float E) {
    int ins = song.insComp;
    if (ins == IN_NONE) return;
    const Instr& I = g_ins[ins];
    const char* pat = song.cpat;
    bool strum = ins == IN_NYLON || ins == IN_HARP, shortHit = COMP_SHORT[song.compId];
    int last = -1, cv[6], nv = 0, lo = I.center - 10;
    float vel = 0.24f * (0.75f + 0.35f * E);
    for (int s = 0; s < song.steps; ++s) {
      char c = pat[s];
      if (c == '.' || c == '-') continue;
      int ci = chordIndexAt(s);
      if (ci != last) {
        nv = voiceChord(bc[ci].c, key, lo, lo + 16, 4, compV, compN, cv, rng);
        for (int i = 0; i < nv; ++i) compV[i] = cv[i];
        compN = nv;
        last = ci;
      }
      int e = song.steps;
      for (int j = s + 1; j < song.steps; ++j)
        if (pat[j] != '.') {
          e = j;
          break;
        }
      double dur = shortHit ? std::min((e - s) * stepLen * 0.6, 0.3 * RATE) : (e - s) * stepLen * 0.95;
      bool up = strum && (s % song.sub != 0);
      float v = vel * (s % song.sub == 0 ? 1.f : 0.8f) * hv();
      double t = stepT(s) + jit(0.6f);
      for (int i = 0; i < nv; ++i) {
        int j = up ? nv - 1 - i : i;
        double tt = t + (strum ? i * (0.012 + 0.004 * rng.f()) * RATE : 0.0);
        emit(tt, ins, (float)cv[j], v * (up ? 0.75f : 1.f) * (strum ? 0.8f + 0.2f * i / nv : 1.f), dur, TR_COMP,
             song.compPan + (j - nv / 2) * 0.12f, 0.45f, 0.f, I.loop ? 0.01f : 0.f, 0.f);
      }
    }
  }
  void hit(int drum, int s, float vel, int key, float pitch = 0.f) {
    const DrumDef& D = DRUM[drum];
    float midi = 60.f + pitch;
    if (drum == DA) midi = (float)(69 + modp(key + chordAt(s).root - 69, 12));  // the anvil rings on the chord root
    emit(stepT(s) + jit(0.4f), D.ins, midi, vel * D.gain * hv(), -1.0, D.track, D.pan, D.send, 0.f);
  }
  void genFill(int from, int to, int key) {
    const Style& sty = *song.st;
    int stp = (stepLen > 0.16 * RATE && song.sub != 3) ? 2 : 1;
    int n = std::max(1, (to - from) / stp), type = rng.range(0, 2);
    if (sty.flags & F_ANVIL) type = 3;
    if (sty.flags & F_STRICT) type = 4;
    hit(DK, from, 0.8f, key);
    int k = 0;
    for (int s = from; s < to; s += stp, ++k) {
      float a = (float)k / n, vel = 0.4f + 0.55f * a;
      switch (type) {
        case 0: hit(DT, s, vel, key, 7.f - 12.f * a); break;  // tom run
        case 1: hit(DS, s, vel * 0.85f, key); break;          // snare roll
        case 2: hit((k & 1) ? DT : DS, s, vel, key, (k & 1) ? 3.f - 8.f * a : 0.f); break;
        case 3: hit((k & 1) ? DA : DB, s, vel, key); break;   // anvil + taiko
        default: hit((k & 1) ? DW : DI, s, vel, key); break;  // clockwork: ticks and blocks
      }
    }
    if (type == 4) hit(DQ, from, 0.8f, key);
  }
  void melodicFill(int key) {  // sections without drums end with a scale run instead
    const Section& S = song.sec[secIdx];
    int ins = S.arpIns, from = song.steps - song.sub * (S.fill == 2 ? 2 : 1);
    const Instr& I = g_ins[ins];
    int deg = midiToDeg(key, snapTo(I.center - 5, chordMask(chordAt(from), key), 1)), k = 0;
    for (int s = from; s < song.steps; ++s, ++k)
      emit(stepT(s), ins, (float)degToMidi(key, deg + k), 0.2f * (0.7f + 0.3f * k / std::max(1, song.steps - from)),
           I.loop ? stepLen * 0.9 : 0.4 * RATE, TR_ARP, song.arpPan, 0.6f, song.st->dly * 1.5f, I.loop ? 0.006f : 0.f, 0.f);
  }
  void genDrums(int key, float E, bool combat, uint16_t roles, bool lastBar) {
    const Section& S = song.sec[secIdx];
    int gi = -1;
    if (roles & R_DRUMS) gi = (combat || E >= 0.75f) ? 2 : (E >= 0.5f ? 1 : 0);
    else if (roles & R_PERC) gi = 0;
    if ((roles & R_DRUMS) && barInt >= 0.45f) {  // fights always get a real groove, even in quiet sections
      gi = std::max(gi, 1);
      if (song.g[gi].n == 0) gi = 2;
    }
    bool nextExists = secIdx + 1 < song.nsec;
    if (gi >= 1 && barInSec == 0 && S.kind != SK_INTRO && secIdx > 0) hit(DX, 0, 0.55f, key);
    if (gi < 0 || song.g[gi].n == 0) {
      if (lastBar && S.fill && nextExists && (roles & (R_ARP | R_LEAD)) && rng.chance(0.6f)) melodicFill(key);
      return;
    }
    const MGroove& G = song.g[gi];
    int fillFrom = song.steps;
    if (lastBar && S.fill && nextExists && gi >= 1) fillFrom = song.steps - (S.fill == 2 ? 2 : 1) * song.sub;
    for (int l = 0; l < G.n; ++l) {
      int drum = G.drum[l];
      for (int s = 0; s < fillFrom; ++s) {
        char c = G.pat[l][s];
        if (c == '.') continue;
        float vel = c == 'X' ? 1.f : c == 'x' ? 0.8f : c == 'o' ? 0.5f : 0.28f;
        if (s != 0 && rng.chance(0.04f)) continue;
        if ((drum == DH || drum == DP) && rng.chance(0.08f)) vel *= 0.55f;
        hit(drum, s, vel, key);
      }
    }
    if (gi >= 1 && rng.chance(0.18f)) {
      int s = rng.range(0, song.steps - 1) | 1;
      if (s < fillFrom) hit(rng.chance(0.5f) ? DS : DR, s, 0.25f, key);
    }
    if (fillFrom < song.steps) genFill(fillFrom, song.steps, key);
  }
  void genColor(int key, float E, bool combat, uint16_t roles, bool lastBar) {
    const Section& S = song.sec[secIdx];
    uint32_t f = song.st->flags;
    if ((f & F_SWELL) && lastBar && secIdx + 1 < song.nsec && song.sec[secIdx + 1].energy > S.energy + 0.2f) {
      double t = std::max(barStartT, barStartT + song.steps * stepLen - g_ins[IN_SWELL].z[0].len);
      emit(t, IN_SWELL, 60.f, DRUM[DV].gain, -1.0, TR_FX, 0.f, 0.35f, 0.f);
    }
    if (!(roles & R_FX)) return;
    if ((f & F_TOLL) && barInSec % 2 == 0 && E < 0.75f)
      emit(stepT(0), IN_BELL, (float)(45 + modp(key - 45, 12)), 0.3f, -1.0, TR_FX, -0.15f, 0.7f, 0.1f);
    if (f & F_BUBBLES) {
      int n = rng.range(0, 2) + (E > 0.5f ? 1 : 0);
      for (int i = 0; i < n; ++i)
        emit(stepT(rng.range(0, song.steps - 1)), IN_BUBBLE, (float)snapTo(rng.range(74, 91), scaleMask(key), 1), 0.2f * hv(), -1.0, TR_FX,
             rng.rangef(-0.7f, 0.7f), 0.35f, 0.25f);
    }
    if ((f & F_SPARKLE) && rng.chance(0.6f)) {
      int n = rng.range(1, 2);
      for (int i = 0; i < n; ++i) {
        int s = rng.range(0, song.steps - 1);
        emit(stepT(s), rng.chance(0.5f) ? IN_GLOCK : IN_MUSICBOX, (float)snapTo(rng.range(84, 98), chordMask(chordAt(s), key), 1), 0.12f * hv(),
             -1.0, TR_FX, rng.rangef(-0.8f, 0.8f), 0.6f, 0.5f);
      }
    }
    if ((f & F_DRIPS) && rng.chance(0.45f))
      emit(stepT(rng.range(0, song.steps - 1)), rng.chance(0.5f) ? IN_BUBBLE : IN_HARP, (float)snapTo(rng.range(79, 93), scaleMask(key), -1), 0.14f,
           -1.0, TR_FX, rng.rangef(-0.8f, 0.8f), 0.5f, 0.55f);
    if (f & F_TIMP) {
      int r = 38 + modp(key + bc[0].c.root - 38, 12);
      if (barInSec == 0 && S.kind != SK_INTRO && E >= 0.45f) emit(stepT(0), IN_TIMPANI, (float)r, 0.45f, -1.0, TR_FX, 0.1f, 0.3f, 0.f);
      else if (combat || E >= 0.8f) {
        emit(stepT(0), IN_TIMPANI, (float)r, 0.32f, -1.0, TR_FX, 0.1f, 0.3f, 0.f);
        emit(stepT(song.steps / 2), IN_TIMPANI, (float)(r + 7 > 50 ? r - 5 : r + 7), 0.26f, -1.0, TR_FX, 0.1f, 0.3f, 0.f);
      }
      if (lastBar && S.fill == 2)
        for (int s = song.steps - song.sub; s < song.steps; ++s)
          emit(stepT(s), IN_TIMPANI, (float)r, 0.12f + 0.25f * (s - (song.steps - song.sub)) / song.sub, -1.0, TR_FX, 0.1f, 0.3f, 0.f);
    }
    if ((f & F_DRONE) && E < 0.6f) {
      int m = 48 + modp(key - 48, 12);
      double dur = song.steps * stepLen + 0.4 * RATE;
      emit(stepT(0), IN_CHOIR, (float)m, 0.08f, dur, TR_DRONE, -0.3f, 0.8f, 0.f, 1.2f, 1.2f, 1.f, EV_EXTEND);
      if (f & F_TRITONE) emit(stepT(0), IN_CHOIR, (float)(m + 6), 0.045f, dur, TR_DRONE, 0.3f, 0.8f, 0.f, 1.5f, 1.2f, 1.f, EV_EXTEND);
    }
    if ((f & F_ANVIL) && !(roles & R_DRUMS) && barInSec % 2 == 1) hit(DA, song.steps / 2, 0.5f, key);
    if ((f & F_WONKY) && lastBar && S.fill && rng.chance(0.6f)) {  // circus slide whistle into the next section
      bool up = rng.chance(0.6f);
      double len = std::max(0.25 * RATE, song.sub * stepLen * 1.5);
      emit(stepT(song.steps - song.sub), IN_CALLIOPE, up ? 72.f : 84.f, 0.2f, len, TR_FX, rng.rangef(-0.4f, 0.4f), 0.3f, 0.f, 0.02f, 0.06f,
           1.f, 0, (up ? 12.f : -12.f) * RATE / (float)len);
    }
    if ((f & F_FANFARE) && barInSec == 0 && S.kind != SK_INTRO && S.kind != SK_OUTRO && E >= 0.5f) {
      int cv[6], nv = voiceChord(bc[0].c, key, 55, 72, 3, nullptr, 0, cv, rng);
      for (int i = 0; i < nv; ++i) emit(stepT(0), IN_BRASS, (float)cv[i], 0.22f, beatLen * 1.5, TR_COMP, -0.3f + 0.3f * i, 0.4f, 0.f, 0.01f, 0.25f);
    }
  }
  // a big jump in intensity mid-bar: replace the rest of this bar's drums with a fill
  void intensityCheck() {
    if (fillDone || (song.st->flags & F_NODRUMS)) return;
    int beatsLeft = song.beats - beatInBar;
    if (beatsLeft > 2 || beatsLeft < 1 || reqInt - barInt < 0.3f) return;
    double barEnd = barStartT + song.steps * stepLen;
    for (int i = qh; i < qn; ++i)
      if ((q[i].track == TR_DRUM || q[i].track == TR_HAT) && q[i].t >= (double)clock && q[i].t < barEnd) q[i].ins = IN_NONE;
    genFill(beatInBar * song.sub, song.steps, barKey);
    fillDone = true;
    sortQueue();
  }

  // ---------------------------------------------------------------- transport
  void switchTo(int mood) {
    fadeAll(mood < 0 ? 1.6f : 0.9f);
    qh = qn = 0;
    if (mood < 0) {
      curMood = -1;
      haveSong = false;
      return;
    }
    curMood = mood;
    newSong(mood, false);
    haveSong = true;
    beatInBar = 0;
    barInt = reqInt;
    bpmCur = song.bpm * (1.f + 0.08f * reqInt);
    nextBeatT = (double)clock + 0.03 * RATE;
  }
  void control(int req, float inten) {
    reqInt = clampv(inten, 0.f, 1.f);
    if (req < 0 || req >= NMOODS) req = -1;
    if (req != lastReq) lastReq = req, reqSince = clock;
    if (req == curMood) {
      switchPending = false;
      return;
    }
    if (clock - reqSince < (int64_t)(0.12 * RATE)) return;  // ignore flicker
    if (!haveSong) switchTo(req);
    else switchPending = true;  // handled on the next beat
  }
  void onBeat() {
    if (switchPending) {
      switchPending = false;
      if (lastReq != curMood) {
        switchTo(lastReq);
        return;
      }
    }
    if (beatInBar == 0) {
      barInt = reqInt;
      fillDone = false;
      genBar();
    } else {
      intensityCheck();
    }
    if (++beatInBar >= song.beats) beatInBar = 0;
    nextBeatT = barStartT + (beatInBar == 0 ? song.steps * stepLen : beatInBar * beatLen);
  }
  void render(float* outL, float* outR, int n, int req, float inten) {
    std::fill(bl, bl + n, 0.f);
    std::fill(br, br + n, 0.f);
    std::fill(bs, bs + n, 0.f);
    std::fill(bd, bd + n, 0.f);
    int done = 0;
    while (done < n) {
      control(req, inten);
      while (haveSong && (double)clock >= nextBeatT) onBeat();
      while (qh < qn && q[qh].t <= (double)clock) fire(q[qh++]);
      int chunk = n - done;
      if (haveSong) chunk = std::min(chunk, std::max(1, (int)std::ceil(nextBeatT - (double)clock)));
      if (qh < qn) chunk = std::min(chunk, std::max(1, (int)std::ceil(q[qh].t - (double)clock)));
      if (wonky) {
        wobT += chunk / (double)RATE;
        wob = 1.f + 0.006f * (float)std::sin(TAU * 0.37 * wobT) + 0.003f * (float)std::sin(TAU * 1.3 * wobT);
      } else {
        wob = 1.f;
      }
      renderVoices(bl + done, br + done, bs + done, bd + done, chunk);
      clock += chunk;
      done += chunk;
    }
    if (st) {
      int act = 0;
      for (const MVoice& x : v) act += x.d != nullptr;
      st->peakVoices = std::max(st->peakVoices, act);
    }
    const float toneA = 0.8f;  // ~11 kHz one-pole: takes the edge off the top
    for (int i = 0; i < n; ++i) {
      wet += (wetT - wet) * 0.0002f;
      float dl, dr, rl, rr;
      dly.proc(bd[i], dl, dr);
      rev.proc(bs[i] + (dl + dr) * 0.25f, rl, rr);
      float x[2] = {bl[i] + dl + rl * wet * 1.4f, br[i] + dr + rr * wet * 1.4f};
      for (int c = 0; c < 2; ++c) {
        float y = x[c] - dcx[c] + 0.9995f * dcy[c];  // DC blocker
        dcx[c] = x[c];
        dcy[c] = y;
        tl[c] += toneA * (y - tl[c]);
        x[c] = tl[c] * MUS_GAIN;
        if (!std::isfinite(x[c])) {
          x[c] = 0.f;
          dcx[c] = dcy[c] = tl[c] = 0.f;
          if (st) st->nonFinite++;
        }
      }
      float pk = std::max(std::fabs(x[0]), std::fabs(x[1]));
      if (st) {
        if (pk > st->peakBus) st->peakBus = pk;
        if (haveSong) songE += (double)x[0] * x[0] + (double)x[1] * x[1], songN += 2;
      }
      lev = pk > lev ? pk : lev * 0.99985f + pk * 0.00015f;
      float g = 1.f;
      if (lev > MUS_LIMIT) {
        g = MUS_LIMIT / lev;
        if (st) st->limited++;
      }
      outL[i] = x[0] * g;
      outR[i] = x[1] * g;
    }
  }
};

static MusicEngine* g_music = nullptr;
static bool g_built = false;
static double g_synthMs = 0;

static void buildAll() {
  if (g_built) return;
  LARGE_INTEGER f, a, b;
  QueryPerformanceFrequency(&f);
  QueryPerformanceCounter(&a);
  initSinTable();
  buildSfx();
  buildInstruments();
  buildStyles();
  QueryPerformanceCounter(&b);
  g_synthMs = (b.QuadPart - a.QuadPart) * 1000.0 / f.QuadPart;
  g_built = true;
}

// ---------------------------------------------------------------- SFX voices
static void startVoice(const Sample* s, float vol, float rate, float pan, int id) {
  // find a free voice; limit how many copies of one effect overlap; else steal the oldest
  int freeIdx = -1, oldestIdx = 0, sameCount = 0, sameOldest = -1;
  uint32_t oldestAge = 0xFFFFFFFF, sameAge = 0xFFFFFFFF;
  for (int i = 0; i < MAXV; ++i) {
    if (!g_v[i].s) {
      if (freeIdx < 0) freeIdx = i;
      continue;
    }
    if (g_v[i].age < oldestAge) { oldestAge = g_v[i].age; oldestIdx = i; }
    if (g_v[i].id == id) {
      sameCount++;
      if (g_v[i].age < sameAge) { sameAge = g_v[i].age; sameOldest = i; }
    }
  }
  int best;
  if (sameCount >= 6 && sameOldest >= 0) best = sameOldest;
  else if (freeIdx >= 0) best = freeIdx;
  else best = oldestIdx;
  Voice& v = g_v[best];
  v.s = s;
  v.pos = 0;
  v.rate = rate;
  pan = clampv(pan, -1.f, 1.f);
  v.vl = vol * std::sqrt(0.5f * (1 - pan));
  v.vr = vol * std::sqrt(0.5f * (1 + pan));
  v.id = id;
  v.age = ++g_age;
}

static inline short toPcm(float x) {
  x = x / (1.f + std::fabs(x) * 0.6f) * 1.2f;  // soft clip
  x = clampv(x, -1.f, 1.f);
  return (short)(x * 32000.f);
}

// ---------------------------------------------------------------- mixer
static void mixInto(short* out, int frames) {
  Req reqs[MAXREQ];
  EnterCriticalSection(&g_cs);
  int nr = g_nreq;
  for (int i = 0; i < nr; ++i) reqs[i] = g_reqs[i];
  g_nreq = 0;
  LeaveCriticalSection(&g_cs);
  for (int i = 0; i < nr; ++i) {
    const Req& r = reqs[i];
    if (r.sfx >= 0 && r.sfx < S_COUNT && !g_sfx[r.sfx].d.empty()) startVoice(&g_sfx[r.sfx], r.vol, r.pitch, r.pan, r.sfx);
  }
  static float acc[FRAMES * 2], ml[FRAMES], mr[FRAMES];
  std::fill(acc, acc + frames * 2, 0.f);
  float sfxG = g_sfxVol, musG = g_musVol, master = g_master;
  for (int vi = 0; vi < MAXV; ++vi) {
    Voice& v = g_v[vi];
    if (!v.s) continue;
    const std::vector<float>& d = v.s->d;
    float gl = v.vl * sfxG, gr = v.vr * sfxG;
    double pos = v.pos;
    int n = (int)d.size();
    for (int i = 0; i < frames; ++i) {
      int ip = (int)pos;
      if (ip >= n - 1) { v.s = nullptr; break; }
      float fr = (float)(pos - ip);
      float smp = d[ip] + (d[ip + 1] - d[ip]) * fr;
      acc[i * 2] += smp * gl;
      acc[i * 2 + 1] += smp * gr;
      pos += v.rate;
    }
    v.pos = pos;
  }
  g_music->render(ml, mr, frames, g_mood, g_intensity);
  for (int i = 0; i < frames; ++i) {
    out[i * 2] = toPcm((acc[i * 2] + ml[i] * musG) * master);
    out[i * 2 + 1] = toPcm((acc[i * 2 + 1] + mr[i] * musG) * master);
  }
}

static DWORD WINAPI mixThread(LPVOID) {
  SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
  _mm_setcsr(_mm_getcsr() | 0x8040);  // flush denormals to zero (reverb / filter tails)
  for (int i = 0; i < NBUF; ++i) {
    mixInto(g_buf[i], FRAMES);
    waveOutWrite(g_hwo, &g_hdr[i], sizeof(WAVEHDR));
  }
  while (g_run) {
    WaitForSingleObject(g_ev, 50);
    for (int i = 0; i < NBUF; ++i) {
      if (g_hdr[i].dwFlags & WHDR_DONE) {
        g_hdr[i].dwFlags &= ~WHDR_DONE;
        mixInto(g_buf[i], FRAMES);
        waveOutWrite(g_hwo, &g_hdr[i], sizeof(WAVEHDR));
      }
    }
  }
  return 0;
}

bool init() {
  InitializeCriticalSection(&g_cs);
  buildAll();
  LARGE_INTEGER qpc;
  QueryPerformanceCounter(&qpc);
  if (!g_music) g_music = new MusicEngine(mix64((uint64_t)qpc.QuadPart));
  WAVEFORMATEX wf = {};
  wf.wFormatTag = WAVE_FORMAT_PCM;
  wf.nChannels = 2;
  wf.nSamplesPerSec = RATE;
  wf.wBitsPerSample = 16;
  wf.nBlockAlign = 4;
  wf.nAvgBytesPerSec = RATE * 4;
  g_ev = CreateEventW(nullptr, FALSE, FALSE, nullptr);
  if (waveOutOpen(&g_hwo, WAVE_MAPPER, &wf, (DWORD_PTR)g_ev, 0, CALLBACK_EVENT) != MMSYSERR_NOERROR) {
    g_hwo = nullptr;
    return false;
  }
  for (int i = 0; i < NBUF; ++i) {
    memset(&g_hdr[i], 0, sizeof(WAVEHDR));
    g_hdr[i].lpData = (LPSTR)g_buf[i];
    g_hdr[i].dwBufferLength = FRAMES * 4;
    waveOutPrepareHeader(g_hwo, &g_hdr[i], sizeof(WAVEHDR));
  }
  g_run = true;
  g_thread = CreateThread(nullptr, 0, mixThread, nullptr, 0, nullptr);
  g_ok = true;
  return true;
}

void shutdown() {
  if (!g_ok) return;
  g_run = false;
  if (g_thread) {
    SetEvent(g_ev);
    WaitForSingleObject(g_thread, 1000);
    CloseHandle(g_thread);
    g_thread = nullptr;
  }
  waveOutReset(g_hwo);
  for (int i = 0; i < NBUF; ++i) waveOutUnprepareHeader(g_hwo, &g_hdr[i], sizeof(WAVEHDR));
  waveOutClose(g_hwo);
  CloseHandle(g_ev);
  g_ok = false;
}

void play(int sfx, float vol, float pitch, float pan) {
  if (!g_ok) return;
  EnterCriticalSection(&g_cs);
  if (g_nreq < MAXREQ) g_reqs[g_nreq++] = Req{sfx, vol, pitch, pan};
  LeaveCriticalSection(&g_cs);
}

void setVolumes(float master, float sfx, float music) {
  g_master = master;
  g_sfxVol = sfx;
  g_musVol = music;
}

void setMusic(int mood, float intensity) {
  g_mood = mood;
  g_intensity = intensity;
}

// ---------------------------------------------------------------- offline rendering (tests / tools)
void renderMusicScript(float seconds, std::vector<short>& stereoOut, uint32_t seed, void (*ctl)(float t, int& mood, float& intensity),
                       MusicStats* stats) {
  buildAll();
  unsigned csr = _mm_getcsr();
  _mm_setcsr(csr | 0x8040);
  MusicEngine* e = new MusicEngine(mix64(seed + 0x51ED));
  if (stats) {
    *stats = MusicStats();
    e->st = stats;
  }
  int n = std::max(0, (int)(seconds * RATE));
  stereoOut.assign((size_t)n * 2, 0);
  float ml[FRAMES], mr[FRAMES];
  int mood = -1;
  float inten = 0.f;
  for (int i = 0; i < n; i += FRAMES) {
    int f = std::min(FRAMES, n - i);
    if (ctl) ctl(i / (float)RATE, mood, inten);
    e->render(ml, mr, f, mood, inten);
    if (i + FRAMES >= n) e->logSongEnd();
    float g = g_musVol * g_master;
    for (int k = 0; k < f; ++k) {
      stereoOut[(size_t)(i + k) * 2] = toPcm(ml[k] * g);
      stereoOut[(size_t)(i + k) * 2 + 1] = toPcm(mr[k] * g);
    }
  }
  delete e;
  _mm_setcsr(csr);
}
static int g_offMood = -1;
static float g_offInt = 0.f;
void renderMusicOffline(int mood, float intensity, float seconds, std::vector<short>& stereoOut, uint32_t seed, MusicStats* stats) {
  g_offMood = mood;
  g_offInt = intensity;
  renderMusicScript(seconds, stereoOut, seed, [](float, int& m, float& in) { m = g_offMood, in = g_offInt; }, stats);
}
double synthesisTimeMs() { return g_synthMs; }

}  // namespace audio
