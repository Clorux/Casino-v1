// Dropcrawl - common math / rng / string helpers
#pragma once
#include <cstdint>
#include <cmath>
#include <cstdio>
#include <cstdarg>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>

constexpr float PI = 3.14159265358979f;
constexpr float TAU = 6.28318530717959f;

struct V2 {
  float x = 0, y = 0;
  V2() {}
  V2(float x_, float y_) : x(x_), y(y_) {}
  V2 operator+(V2 o) const { return {x + o.x, y + o.y}; }
  V2 operator-(V2 o) const { return {x - o.x, y - o.y}; }
  V2 operator*(float s) const { return {x * s, y * s}; }
  V2 operator/(float s) const { return {x / s, y / s}; }
  V2 operator-() const { return {-x, -y}; }
  V2& operator+=(V2 o) { x += o.x; y += o.y; return *this; }
  V2& operator-=(V2 o) { x -= o.x; y -= o.y; return *this; }
  V2& operator*=(float s) { x *= s; y *= s; return *this; }
};
inline V2 operator*(float s, V2 v) { return {v.x * s, v.y * s}; }
inline float dot(V2 a, V2 b) { return a.x * b.x + a.y * b.y; }
inline float cross(V2 a, V2 b) { return a.x * b.y - a.y * b.x; }
inline float len2(V2 a) { return a.x * a.x + a.y * a.y; }
inline float len(V2 a) { return std::sqrt(len2(a)); }
inline V2 norm(V2 a) { float l = len(a); return l > 1e-6f ? a / l : V2(0, 0); }
inline V2 perp(V2 a) { return {-a.y, a.x}; }
inline V2 fromAng(float a) { return {std::cos(a), std::sin(a)}; }
inline V2 rot(V2 v, float a) { float c = std::cos(a), s = std::sin(a); return {v.x * c - v.y * s, v.x * s + v.y * c}; }
inline float dist(V2 a, V2 b) { return len(a - b); }
inline float dist2(V2 a, V2 b) { return len2(a - b); }
template <class T> inline T clampv(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float lerpf(float a, float b, float t) { return a + (b - a) * t; }
inline V2 lerpv(V2 a, V2 b, float t) { return a + (b - a) * t; }
inline float approach(float v, float target, float step) {
  if (v < target) return std::min(target, v + step);
  return std::max(target, v - step);
}
// closest point on segment ab to p
inline V2 closestOnSeg(V2 p, V2 a, V2 b, float* tOut = nullptr) {
  V2 ab = b - a;
  float l2 = len2(ab);
  float t = l2 > 1e-8f ? clampv(dot(p - a, ab) / l2, 0.f, 1.f) : 0.f;
  if (tOut) *tOut = t;
  return a + ab * t;
}

// ---------------------------------------------------------------------------
// Deterministic RNG (splitmix64 based). Every random decision in the game
// flows from a seeded Rng so runs are reproducible from their seed.
struct Rng {
  uint64_t s = 1;
  Rng() {}
  explicit Rng(uint64_t seed) { reseed(seed); }
  void reseed(uint64_t seed) { s = seed * 0x2545F4914F6CDD1Dull + 0x9E3779B97F4A7C15ull; next(); }
  uint32_t next() {
    s += 0x9E3779B97F4A7C15ull;
    uint64_t z = s;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    z ^= z >> 31;
    return (uint32_t)(z >> 32);
  }
  float f() { return (next() >> 8) * (1.0f / 16777216.0f); }
  // inclusive range
  int range(int lo, int hi) {
    if (hi <= lo) return lo;
    return lo + (int)(next() % (uint32_t)(hi - lo + 1));
  }
  float rangef(float a, float b) { return a + (b - a) * f(); }
  bool chance(float p) { return f() < p; }
  template <class T> void shuffle(std::vector<T>& v) {
    for (int i = (int)v.size() - 1; i > 0; --i) std::swap(v[i], v[range(0, i)]);
  }
  int weighted(const std::vector<float>& w) {
    float tot = 0;
    for (float x : w) tot += std::max(0.f, x);
    if (tot <= 0) return -1;
    float r = f() * tot;
    for (int i = 0; i < (int)w.size(); ++i) {
      r -= std::max(0.f, w[i]);
      if (r <= 0) return i;
    }
    return (int)w.size() - 1;
  }
};

inline uint64_t mix64(uint64_t z) {
  z += 0x9E3779B97F4A7C15ull;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}

inline std::string fmt(const char* f, ...) {
  char buf[1024];
  va_list ap;
  va_start(ap, f);
  vsnprintf(buf, sizeof(buf), f, ap);
  va_end(ap);
  return std::string(buf);
}

// Colors are 0xRRGGBB
inline uint32_t rgbLerp(uint32_t a, uint32_t b, float t) {
  t = clampv(t, 0.f, 1.f);
  int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255;
  int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255;
  int r = (int)(ar + (br - ar) * t), g = (int)(ag + (bg - ag) * t), bl = (int)(ab + (bb - ab) * t);
  return (uint32_t)((r << 16) | (g << 8) | bl);
}
inline uint32_t rgbScale(uint32_t a, float s) {
  int r = clampv((int)(((a >> 16) & 255) * s), 0, 255);
  int g = clampv((int)(((a >> 8) & 255) * s), 0, 255);
  int b = clampv((int)((a & 255) * s), 0, 255);
  return (uint32_t)((r << 16) | (g << 8) | b);
}
