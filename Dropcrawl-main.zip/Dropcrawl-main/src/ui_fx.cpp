// Dropcrawl - presentation effects: particles, floating text, zaps, rings, banners
#include "app.h"

static Rng g_vr(12345);  // visual-only randomness (never touches game state)

void clearPresentation(App& a) {
  a.parts.clear();
  a.texts.clear();
  a.zaps.clear();
  a.rings.clear();
  a.banners.clear();
  a.attacks.clear();
  a.trails.clear();
  a.shake = 0;
}

void playFx(App& a, World& w, bool sounds) {
  for (auto& e : w.fx) {
    switch (e.kind) {
      case FX_TEXT: {
        bool numeric = e.text[0] == '-' || e.text[0] == '+' || (e.text[0] >= '0' && e.text[0] <= '9');
        if (!a.set.numbers && numeric && e.a.x > BOARD_X0) break;
        if (a.texts.size() > 90) a.texts.erase(a.texts.begin());
        FloatText t;
        t.p = e.a;
        t.s = e.text;
        t.col = e.col;
        t.size = e.v;
        t.maxLife = t.life = e.v > 22 ? 1.5f : 1.1f;
        a.texts.push_back(t);
        break;
      }
      case FX_SOUND:
        if (sounds) audio::play(e.i, e.v, e.v2, clampv((e.a.x - LAUNCH_X) / 450.f, -1.f, 1.f));
        break;
      case FX_BURST: {
        int n = std::min(e.i, 80);
        for (int i = 0; i < n && a.parts.size() < 1400; ++i) {
          Particle p;
          p.p = e.a;
          p.v = fromAng(g_vr.rangef(0, TAU)) * (e.v * g_vr.rangef(0.25f, 1.f));
          p.maxLife = p.life = g_vr.rangef(0.3f, 0.75f);
          p.size = (e.v2 > 0 ? e.v2 : 3.f) * g_vr.rangef(0.6f, 1.2f);
          p.col = e.col;
          p.kind = 0;
          a.parts.push_back(p);
        }
        break;
      }
      case FX_ZAP: {
        ZapFx z;
        z.col = e.col;
        V2 d = e.b - e.a;
        float L = len(d);
        int segs = clampv((int)(L / 22), 3, 14);
        V2 n = norm(perp(d));
        for (int i = 0; i <= segs; ++i) {
          float t = i / (float)segs;
          float off = (i == 0 || i == segs) ? 0.f : g_vr.rangef(-9, 9);
          z.pts.push_back(e.a + d * t + n * off);
        }
        z.life = 0.28f;
        if (a.zaps.size() < 60) a.zaps.push_back(z);
        break;
      }
      case FX_RING: {
        RingFx r;
        r.p = e.a;
        r.r = e.v;
        r.col = e.col;
        r.life = r.maxLife = 0.45f;
        if (a.rings.size() < 60) a.rings.push_back(r);
        break;
      }
      case FX_SHAKE:
        if (a.set.shake) a.shake = std::max(a.shake, e.v);
        break;
      case FX_ATTACK: {
        ShotFx s;
        s.from = e.a;
        s.to = V2(190, 60);
        s.col = e.col;
        a.attacks.push_back(s);
        break;
      }
      case FX_COIN: {
        FloatText t;
        t.p = e.a + V2(0, -14);
        t.s = fmt("+%d gold", e.i);
        t.col = 0xffd84a;
        t.size = 14;
        t.maxLife = t.life = 1.1f;
        a.texts.push_back(t);
        for (int i = 0; i < std::min(e.i, 8); ++i) {
          Particle p;
          p.p = e.a;
          p.v = fromAng(g_vr.rangef(-PI, 0)) * g_vr.rangef(80, 200);
          p.maxLife = p.life = g_vr.rangef(0.5f, 0.9f);
          p.size = 3.5f;
          p.col = 0xffd84a;
          p.kind = 2;
          a.parts.push_back(p);
        }
        break;
      }
      case FX_BANNER: {
        BannerFx b;
        b.s = e.text;
        b.col = e.col;
        b.life = 2.2f;
        a.banners.push_back(b);
        if (a.banners.size() > 3) a.banners.erase(a.banners.begin());
        break;
      }
      default: break;
    }
  }
  w.fx.clear();
}

void updatePresentation(App& a, float dt) {
  for (auto& p : a.parts) {
    p.p += p.v * dt;
    p.v *= std::max(0.f, 1.f - 2.2f * dt);
    if (p.kind != 1) p.v.y += 260.f * dt;
    p.life -= dt;
  }
  a.parts.erase(std::remove_if(a.parts.begin(), a.parts.end(), [](const Particle& p) { return p.life <= 0; }), a.parts.end());
  for (auto& t : a.texts) {
    t.p.y -= 28.f * dt;
    t.life -= dt;
  }
  a.texts.erase(std::remove_if(a.texts.begin(), a.texts.end(), [](const FloatText& t) { return t.life <= 0; }), a.texts.end());
  for (auto& z : a.zaps) z.life -= dt;
  a.zaps.erase(std::remove_if(a.zaps.begin(), a.zaps.end(), [](const ZapFx& z) { return z.life <= 0; }), a.zaps.end());
  for (auto& r : a.rings) r.life -= dt;
  a.rings.erase(std::remove_if(a.rings.begin(), a.rings.end(), [](const RingFx& r) { return r.life <= 0; }), a.rings.end());
  if (!a.banners.empty()) {
    a.banners.front().life -= dt;
    if (a.banners.front().life <= 0) a.banners.erase(a.banners.begin());
  }
  for (auto& s : a.attacks) {
    s.t += dt * 2.4f;
    if (s.t >= 1) a.hpFlash = 1;
  }
  a.attacks.erase(std::remove_if(a.attacks.begin(), a.attacks.end(), [](const ShotFx& s) { return s.t >= 1; }), a.attacks.end());
  a.shake *= std::exp(-dt * 9.f);
  if (a.shake < 0.2f) a.shake = 0;
  a.shakeOff = a.shake > 0 ? fromAng(g_vr.rangef(0, TAU)) * a.shake * 0.6f : V2(0, 0);
  a.hpFlash = std::max(0.f, a.hpFlash - dt * 2.5f);
}

void drawPresentation(App& a, bool boardClip) {
  Gfx& g = a.g;
  if (boardClip) g.pushClip(BOARD_X0, 0, BOARD_X1 - BOARD_X0, SCR_H);
  g.additive(true);
  for (auto& p : a.parts) {
    float f = p.life / p.maxLife;
    if (p.kind == 2) {
      g.fillCircle(p.p, p.size, p.col, f);
    } else {
      g.glow(p.p, p.size * 2.6f, p.col, f * 0.8f);
      g.fillCircle(p.p, p.size * 0.5f * f + 0.5f, 0xffffff, f * 0.8f);
    }
  }
  for (auto& r : a.rings) {
    float f = r.life / r.maxLife;
    g.circle(r.p, r.r * (1.15f - 0.6f * f), r.col, f * 0.9f, 3.f * f + 1);
  }
  for (auto& z : a.zaps) {
    float f = z.life / 0.28f;
    for (size_t i = 1; i < z.pts.size(); ++i) {
      g.line(z.pts[i - 1], z.pts[i], z.col, f * 0.5f, 7.f);
      g.line(z.pts[i - 1], z.pts[i], 0xffffff, f, 2.f);
    }
  }
  g.additive(false);
  if (boardClip) g.popClip();
  for (auto& s : a.attacks) {
    float t = s.t;
    V2 mid = (s.from + s.to) * 0.5f + V2(0, -120);
    V2 p = s.from * ((1 - t) * (1 - t)) + mid * (2 * (1 - t) * t) + s.to * (t * t);
    g.additive(true);
    g.glow(p, 18, s.col, 0.9f);
    g.additive(false);
    g.fillCircle(p, 5, 0xffffff, 0.9f);
  }
  for (auto& t : a.texts) {
    float f = clampv(t.life / t.maxLife * 2.f, 0.f, 1.f);
    float pop = 1.f + 0.35f * clampv((t.life - (t.maxLife - 0.12f)) / 0.12f, 0.f, 1.f);
    float sz = t.size * pop;
    g.textSh(t.s, t.p.x - 150, t.p.y - sz, 300, sz * 1.5f, sz, t.col, f, F_UIB, AL_C, VA_T);
  }
}
