// Dropcrawl - set pieces (hand-designed mini structures placed on generated boards) and pin layouts
#include "rules.h"

enum SetPieceId {
  SET_BUMPERS, SET_SLINGSHOTS, SET_WINDMILL, SET_PENDULUM, SET_TULIPS, SET_SLOT, SET_TARGETS, SET_ROLLOVERS,
  SET_GEARS, SET_GARDEN, SET_CAGE, SET_RIFT, SET_CONVEYOR, SET_MAGNET, SET_GEYSER, SET_SPRINGS, SET_COINS,
  SET_MIRRORS, SET_RUNES, SET_ANTIGRAV, SET_CHARGE, SET_SINGULARITY, SET_BELL, SET_SEEDBED, SET_JELLY,
  SET_KICKERS, SET_ELEVATOR, SET_GHOSTS, SET_FIREFLIES, SET_MIST, SET_SPRING_POOL, SET_WARPGATE,
  // v3
  SET_SHRINE, SET_WELL, SET_PINATA, SET_PRISM, SET_CONSTELLATION, SET_DICE, SET_CANNONS, SET_ROD, SET_HOURGLASS,
  SET_BLOOD, SET_SNOWSLOPE, SET_JACKPOT, SET_GEMS, SET_MIMIC, SET_RUNEROAD, SET_POPBUMPERS, SET_SPINNERROW,
  SET_TRAMPOLINE, SET_MOONGARDEN, SET_COMBO, SET_ECHO, SET_GATEVAULT, SET_LOOTNEST,
  SET_COUNT
};

struct SetPieceDef {
  const char* name;
  float radius;
  float weight;
  int minDepth;
  float y0, y1;  // preferred vertical band
};

static const SetPieceDef SETS[SET_COUNT] = {
    {"bumper triangle", 62, 1.2f, 1, 200, 700},  {"slingshots", 96, 1.0f, 1, 560, 760},
    {"windmill", 62, 1.0f, 1, 220, 700},         {"pendulum", 84, 0.9f, 2, 250, 700},
    {"tulip row", 128, 1.3f, 1, 300, 720},       {"slot machine", 70, 1.0f, 2, 260, 700},
    {"target bank", 72, 1.1f, 1, 220, 700},      {"rollover lanes", 130, 1.0f, 1, 170, 330},
    {"gear tower", 74, 0.8f, 3, 220, 680},       {"peg garden", 50, 1.2f, 1, 200, 720},
    {"treasure cage", 62, 0.7f, 2, 260, 720},    {"rift pair", 40, 0.6f, 3, 220, 700},
    {"conveyor", 132, 0.8f, 2, 300, 700},        {"magnet core", 70, 0.9f, 2, 240, 700},
    {"geyser", 60, 0.8f, 3, 560, 760},           {"spring line", 96, 0.9f, 1, 560, 760},
    {"coin pile", 52, 0.8f, 1, 250, 720},        {"mirror hall", 92, 0.7f, 3, 250, 700},
    {"rune circle", 62, 0.8f, 2, 220, 700},      {"antigravity bubble", 62, 0.7f, 3, 400, 720},
    {"charge field", 82, 0.8f, 2, 250, 700},     {"singularity", 78, 0.35f, 6, 300, 650},
    {"bell tower", 62, 0.8f, 1, 220, 700},       {"seed bed", 92, 0.7f, 1, 250, 720},
    {"jelly pool", 60, 0.6f, 2, 300, 720},       {"kicker walls", 76, 0.9f, 2, 300, 740},
    {"elevator", 70, 0.7f, 3, 480, 740},         {"ghost row", 150, 0.6f, 2, 220, 700},
    {"fireflies", 90, 0.8f, 1, 220, 700},        {"poison mist", 62, 0.6f, 2, 260, 720},
    {"healing spring", 58, 0.6f, 1, 300, 720},   {"warp gate", 74, 0.6f, 3, 240, 700},
    // v3
    {"shrine", 62, 0.45f, 2, 220, 650},          {"healing well", 56, 0.4f, 1, 300, 720},
    {"pinata", 60, 0.5f, 1, 220, 650},           {"prism", 60, 0.5f, 2, 250, 700},
    {"constellation", 100, 0.6f, 1, 200, 700},   {"dice table", 84, 0.6f, 1, 240, 700},
    {"cannon battery", 90, 0.5f, 3, 300, 720},   {"lightning rod", 54, 0.5f, 2, 220, 650},
    {"hourglass", 60, 0.45f, 3, 250, 700},       {"blood altar", 62, 0.45f, 3, 250, 700},
    {"snow slope", 110, 0.5f, 2, 250, 700},      {"jackpot tower", 60, 0.35f, 4, 250, 700},
    {"gem cluster", 60, 0.5f, 2, 250, 720},      {"lone chest", 50, 0.35f, 3, 300, 720},
    {"rune road", 150, 0.45f, 3, 250, 650},      {"pop bumpers", 84, 0.8f, 1, 250, 700},
    {"spinner row", 130, 0.6f, 2, 250, 700},     {"trampolines", 110, 0.6f, 1, 560, 760},
    {"moon garden", 60, 0.5f, 2, 220, 700},      {"combo ring", 62, 0.5f, 2, 220, 700},
    {"echo chamber", 72, 0.45f, 3, 220, 700},    {"locked cage", 72, 0.4f, 3, 300, 720},
    {"loot nest", 60, 0.45f, 2, 250, 700},
};
int setPieceByName(const char* n) {
  for (int i = 0; i < SET_COUNT; ++i)
    if (!strcmp(SETS[i].name, n)) return i;
  return -1;
}

static float biomeWeight(int biome, int id) {
  switch (biome) {
    case BI_LAIR: if (id == SET_SEEDBED || id == SET_GARDEN || id == SET_FIREFLIES || id == SET_MIST) return 2.f; break;
    case BI_DROWNED: if (id == SET_SPRING_POOL || id == SET_GEYSER || id == SET_JELLY || id == SET_CONVEYOR) return 2.f; break;
    case BI_MINES: if (id == SET_GEARS || id == SET_CONVEYOR || id == SET_ELEVATOR || id == SET_TARGETS || id == SET_PENDULUM) return 2.f; break;
    case BI_CRYPT: if (id == SET_GHOSTS || id == SET_BELL || id == SET_RUNES || id == SET_CAGE) return 2.f; break;
    case BI_FORGE: if (id == SET_GEYSER || id == SET_CHARGE || id == SET_SLINGSHOTS || id == SET_KICKERS) return 2.f; break;
    case BI_FROZEN: if (id == SET_MIRRORS || id == SET_WINDMILL || id == SET_PENDULUM || id == SET_ANTIGRAV) return 2.f; break;
    case BI_CORE: if (id == SET_SLOT || id == SET_TULIPS || id == SET_TARGETS || id == SET_COINS || id == SET_ROLLOVERS) return 2.2f; break;
    case BI_SLIME: if (id == SET_JELLY || id == SET_MIST || id == SET_SPRING_POOL || id == SET_GEYSER) return 2.2f; break;
    case BI_ABYSS: if (id == SET_SINGULARITY || id == SET_RIFT || id == SET_WARPGATE || id == SET_GHOSTS || id == SET_ANTIGRAV) return 2.5f; break;
    case BI_HALLS: if (id == SET_TULIPS || id == SET_BUMPERS || id == SET_TARGETS || id == SET_CAGE) return 1.5f; break;
  }
  switch (biome) {
    case BI_CRYPT: if (id == SET_SHRINE || id == SET_RUNEROAD || id == SET_BLOOD) return 1.8f; break;
    case BI_CORE: if (id == SET_JACKPOT || id == SET_DICE || id == SET_LOOTNEST) return 1.8f; break;
    case BI_LAIR: if (id == SET_MOONGARDEN || id == SET_WELL || id == SET_GEMS) return 1.6f; break;
    case BI_FORGE: if (id == SET_CANNONS || id == SET_ROD || id == SET_POPBUMPERS) return 1.8f; break;
    case BI_FROZEN: if (id == SET_SNOWSLOPE || id == SET_PRISM || id == SET_HOURGLASS) return 1.8f; break;
    case BI_ABYSS: if (id == SET_ECHO || id == SET_PRISM || id == SET_CONSTELLATION) return 1.8f; break;
    case BI_MINES: if (id == SET_GATEVAULT || id == SET_CANNONS || id == SET_SPINNERROW) return 1.8f; break;
    case BI_SLIME: if (id == SET_WELL || id == SET_TRAMPOLINE) return 1.8f; break;
    case BI_HALLS: if (id == SET_POPBUMPERS || id == SET_PINATA || id == SET_MIMIC) return 1.5f; break;
    case BI_DROWNED: if (id == SET_TRAMPOLINE || id == SET_CONSTELLATION || id == SET_WELL) return 1.6f; break;
  }
  return 1.f;
}

// ------------------------------------------------------------------ geometry helpers
static bool clearOfClearingsSP(const Floor& f, V2 p, float pad) {
  for (auto& c : f.clearings)
    if (dist2(c.p, p) < (c.r + pad) * (c.r + pad)) return false;
  return true;
}

static bool clearOfKeepOut(const Floor& f, V2 p, float r) {
  for (auto& k : f.keepOut)
    if (dist2(k.p, p) < (k.r + r) * (k.r + r)) return false;
  return true;
}

static bool clearOfObjects(const World& w, V2 p, float r) {
  const Floor& f = w.fl;
  for (auto& pg : f.pegs)
    if (!pg.dead && pg.kind != PK_PIN && dist2(pg.p, p) < (pg.r + r + 14) * (pg.r + r + 14)) return false;
  for (auto& s : f.segs) {
    if (s.dead || s.kind == SK_DIVIDER || s.kind == SK_FLIPPER) continue;
    float lim = (s.kind == SK_SPINNER || s.kind == SK_PENDULUM) ? s.len * 2 + r : s.th + r + 10;
    V2 cp = (s.kind == SK_SPINNER || s.kind == SK_PENDULUM) ? s.c : closestOnSeg(p, s.a, s.b);
    if (dist2(cp, p) < lim * lim) return false;
  }
  for (auto& z : f.zones) {
    if (z.dead || z.link == -7 || z.link == -8) continue;
    float zr = z.circle ? z.half.x : std::max(z.half.x, z.half.y);
    if (zr > 300) continue;
    if (dist2(z.p, p) < (zr + r) * (zr + r)) return false;
  }
  return true;
}

static void pin(World& w, V2 p, int kind = PK_PIN, float r = PIN_R) { addPeg(w, kind, p, r); }

int addTulip(World& w, V2 c, bool chucker) {
  Floor& f = w.fl;
  int pi = addPeg(w, chucker ? PK_CHUCKER : PK_TULIP, c, 11);
  if (pi < 0) return -1;
  // two petals form a cup above the sensor; tulip petals swing open after a catch
  for (int side = -1; side <= 1; side += 2) {
    V2 pivot = c + V2(side * 11.f, 2.f);
    int si = addSeg(w, SK_PETAL, pivot, pivot, 3);
    if (si < 0) continue;
    Seg& s = f.segs[si];
    s.c = pivot;
    s.len = chucker ? 26.f : 22.f;
    s.restAng = side < 0 ? -PI * 0.5f - 0.42f : -PI * 0.5f + 0.42f;
    s.upAng = side < 0 ? -PI * 0.5f - 0.95f : -PI * 0.5f + 0.95f;
    s.ang = s.restAng;
    s.a = pivot;
    s.b = pivot + fromAng(s.ang) * s.len;
    s.rest = 0.45f;
    s.link = pi;
  }
  return pi;
}

static void slingshot(World& w, V2 c, int side) {
  // a triangular slingshot: the long face is a kicker
  V2 top = c + V2(0, -46), bot = c + V2(0, 34), tip = c + V2(side * 40.f, 26);
  addSeg(w, SK_WALL, top, bot, 4);
  addSeg(w, SK_WALL, bot, tip, 4);
  int k = addSeg(w, SK_KICKER, tip, top, 5);
  (void)k;
}

static const int GARDEN_KINDS[] = {PK_CRIT, PK_GOLD, PK_HEAL, PK_MANA, PK_FIRE, PK_ICE, PK_SPARK, PK_CRYSTAL, PK_CLOVER,
                                   PK_CHAOS, PK_VAMPIRE, PK_FREEZE, PK_FEATHER, PK_RUNE, PK_SHIELD, PK_MULTI};

static bool buildSetPiece(World& w, int id, V2 c) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  switch (id) {
    case SET_BUMPERS: {
      float s = 44;
      float a0 = R.rangef(0, TAU);
      for (int k = 0; k < 3; ++k) pin(w, c + fromAng(a0 + k * TAU / 3) * (s * 0.6f), PK_BUMPER, 14);
      return true;
    }
    case SET_SLINGSHOTS:
      slingshot(w, c + V2(-58, 0), 1);
      slingshot(w, c + V2(58, 0), -1);
      return true;
    case SET_WINDMILL:
      for (int k = 0; k < 2; ++k) {
        int si = addSeg(w, SK_SPINNER, c, c, 5);
        if (si < 0) break;
        Seg& s = f.segs[si];
        s.c = c;
        s.len = 44;
        s.angVel = 2.4f;
        s.ang = k * PI * 0.5f;
        s.rest = 0.8f;
      }
      for (int k = 0; k < 4; ++k) pin(w, c + fromAng(PI * 0.25f + k * PI * 0.5f) * 58);
      return true;
    case SET_PENDULUM: {
      V2 pivot = c + V2(0, -44);
      int si = addSeg(w, SK_PENDULUM, pivot, pivot + V2(0, 80), 6);
      if (si < 0) return false;
      Seg& s = f.segs[si];
      s.c = pivot;
      s.len = 40;
      s.restAng = PI * 0.5f;
      s.upAng = R.rangef(0.7f, 1.0f);
      s.angVel = R.rangef(1.5f, 2.2f);
      s.phase = R.rangef(0, TAU);
      s.rest = 0.85f;
      pin(w, pivot, PK_STONE, 7);
      return true;
    }
    case SET_TULIPS: {
      int n = 3;
      for (int k = 0; k < n; ++k) addTulip(w, c + V2((k - 1) * 82.f, (k == 1 ? -14.f : 8.f)), false);
      return true;
    }
    case SET_SLOT:
      addTulip(w, c, true);
      pin(w, c + V2(-50, 10), PK_BUMPER, 12);
      pin(w, c + V2(50, 10), PK_BUMPER, 12);
      return true;
    case SET_TARGETS: {
      int n = R.range(3, 5);
      int bank = f.bankSerial++;
      int reward = R.range(0, 3);
      float ang = R.rangef(-0.35f, 0.35f);
      for (int k = 0; k < n; ++k) {
        V2 p = c + fromAng(ang) * ((k - (n - 1) * 0.5f) * 26.f);
        int pi = addPeg(w, PK_TARGET, p, 8);
        if (pi < 0) break;
        f.pegs[pi].link = 1000 + bank;
        f.pegs[pi].aux = reward;
      }
      return true;
    }
    case SET_ROLLOVERS: {
      int n = R.range(3, 4);
      int set = 2000 + f.bankSerial++;
      for (int k = 0; k < n; ++k) {
        float x = c.x + (k - (n - 1) * 0.5f) * 62.f;
        int zi = addZone(w, ZK_ROLLOVER, V2(x, c.y), V2(14, 16), false);
        if (zi >= 0) f.zones[zi].link = set;
        if (k < n) {
          pin(w, V2(x - 31, c.y - 14));
          pin(w, V2(x - 31, c.y + 14));
        }
      }
      pin(w, V2(c.x + n * 31.f, c.y - 14));
      pin(w, V2(c.x + n * 31.f, c.y + 14));
      return true;
    }
    case SET_GEARS: {
      int hub = addPeg(w, PK_BUMPER, c, 12);
      (void)hub;
      for (int ring = 0; ring < 2; ++ring) {
        float rr = ring == 0 ? 34.f : 60.f;
        int n = (int)(TAU * rr / 36);
        float sp = (ring == 0 ? 1.f : -1.f) * R.rangef(0.6f, 1.0f);
        for (int i = 0; i < n; ++i) {
          int pi = addPeg(w, PK_PIN, c + fromAng(i * TAU / n) * rr, PIN_R);
          if (pi < 0) break;
          Peg& p = f.pegs[pi];
          p.motion = 1;
          p.anchor = c;
          p.mA = rr;
          p.mSpeed = sp;
          p.mPhase = i * TAU / n;
        }
      }
      return true;
    }
    case SET_GARDEN: {
      int n = R.range(5, 7);
      pin(w, c, GARDEN_KINDS[R.range(0, 15)]);
      for (int k = 0; k < n; ++k) pin(w, c + fromAng(k * TAU / n) * 30, GARDEN_KINDS[R.range(0, 15)]);
      return true;
    }
    case SET_CAGE: {
      int chest = addPeg(w, PK_CHEST, c, 14);
      if (chest >= 0) f.pegs[chest].hp = 3;
      int n = 8;
      for (int k = 0; k < n; ++k) pin(w, c + fromAng(k * TAU / n) * 44, (k % 2) ? PK_GLASS : PK_STONE, (k % 2) ? 7 : 9);
      return true;
    }
    case SET_RIFT: {
      for (int t = 0; t < 100; ++t) {
        V2 o(R.rangef(PX0 + 70, PX1 - 70), R.rangef(FIELD_Y0 + 80, FIELD_Y1 - 60));
        if (dist(o, c) < 260 || !clearOfClearingsSP(f, o, 40) || !clearOfKeepOut(f, o, 40) || !clearOfObjects(w, o, 30)) continue;
        placeRift(w, c, o, 0);
        f.keepOut.push_back({o, 40, -1});
        return true;
      }
      return false;
    }
    case SET_CONVEYOR: {
      int zi = addZone(w, ZK_CONVEYOR, c, V2(122, 13), false);
      if (zi < 0) return false;
      f.zones[zi].dir = V2(R.chance(0.5f) ? 1.f : -1.f, 0);
      f.zones[zi].str = R.rangef(360, 480);
      for (int k = -2; k <= 2; ++k) pin(w, c + V2(k * 52.f, 34));
      return true;
    }
    case SET_MAGNET:
      pin(w, c, PK_MAGNET, 11);
      for (int k = 0; k < 6; ++k) pin(w, c + fromAng(k * TAU / 6 + 0.3f) * 58);
      return true;
    case SET_GEYSER: {
      int zi = addZone(w, ZK_GEYSER, c + V2(0, 10), V2(24, 64), false);
      if (zi < 0) return false;
      pin(w, c + V2(-40, 50), PK_STONE, 9);
      pin(w, c + V2(40, 50), PK_STONE, 9);
      return true;
    }
    case SET_SPRINGS: {
      for (int k = -1; k <= 1; ++k) pin(w, c + V2(k * 56.f, std::fabs((float)k) * -14.f), PK_SPRING, 10);
      return true;
    }
    case SET_COINS:
      for (int k = 0; k < 4; ++k) pin(w, c + fromAng(k * TAU / 4 + 0.4f) * 26, PK_COINS, 9);
      return true;
    case SET_MIRRORS: {
      for (int s = -1; s <= 1; s += 2) {
        int zi = addZone(w, ZK_MIRROR, c + V2(s * 52.f, 0), V2(34, 0), true);
        (void)zi;
      }
      pin(w, c + V2(0, -30), PK_MIRROR);
      pin(w, c + V2(0, 30), PK_MIRROR);
      return true;
    }
    case SET_RUNES: {
      addZone(w, ZK_RUNE, c, V2(40, 0), true);
      for (int k = 0; k < 8; ++k) pin(w, c + fromAng(k * TAU / 8) * 54);
      return true;
    }
    case SET_ANTIGRAV:
      addZone(w, ZK_ANTIGRAV, c, V2(56, 0), true);
      return true;
    case SET_CHARGE: {
      addZone(w, ZK_CHARGE, c, V2(72, 22), false);
      pin(w, c + V2(-46, -40), PK_SPARK);
      pin(w, c + V2(46, -40), PK_SPARK);
      return true;
    }
    case SET_SINGULARITY: {
      int zi = addZone(w, ZK_BLACKHOLE, c, V2(72, 0), true);
      if (zi < 0) return false;
      f.zones[zi].str = 820;
      return true;
    }
    case SET_BELL:
      pin(w, c, PK_BELL, 12);
      pin(w, c + V2(-46, 24), PK_BUMPER, 11);
      pin(w, c + V2(46, 24), PK_BUMPER, 11);
      return true;
    case SET_SEEDBED:
      for (int k = -2; k <= 2; ++k) pin(w, c + V2(k * 38.f, std::sin(k * 1.3f) * 10.f), PK_SEED);
      return true;
    case SET_JELLY: {
      addZone(w, ZK_SPRING, c, V2(40, 0), true);
      for (int k = 0; k < 5; ++k) pin(w, c + fromAng(k * TAU / 5) * 48, PK_JELLY);
      return true;
    }
    case SET_KICKERS: {
      addSeg(w, SK_KICKER, c + V2(-60, -40), c + V2(-18, 30), 5);
      addSeg(w, SK_KICKER, c + V2(60, -40), c + V2(18, 30), 5);
      pin(w, c + V2(0, -10), PK_BUMPER, 11);
      return true;
    }
    case SET_ELEVATOR: {
      addSeg(w, SK_WALL, c + V2(-24, -60), c + V2(-24, 50), 4);
      addSeg(w, SK_WALL, c + V2(24, -60), c + V2(24, 50), 4);
      int zi = addZone(w, ZK_BOOST, c + V2(0, 34), V2(18, 0), true);
      if (zi >= 0) {
        f.zones[zi].dir = V2(0, -1);
        f.zones[zi].str = 900;
      }
      return true;
    }
    case SET_GHOSTS: {
      int n = 7;
      for (int k = 0; k < n; ++k) pin(w, c + V2((k - (n - 1) * 0.5f) * 40.f, (k % 2) ? 14.f : -14.f), PK_GHOST);
      return true;
    }
    case SET_FIREFLIES: {
      int n = 4;
      for (int k = 0; k < n; ++k) {
        int pi = addPeg(w, PK_FIREFLY, c + fromAng(k * TAU / n) * 36, 7);
        if (pi < 0) break;
        Peg& p = f.pegs[pi];
        p.motion = 4;
        p.anchor = c + fromAng(k * TAU / n) * 30;
        p.mA = R.rangef(24, 40);
        p.mSpeed = R.rangef(0.5f, 0.9f) * (k % 2 ? 1.f : -1.f);
        p.mPhase = R.rangef(0, TAU);
        p.val = 2;
      }
      return true;
    }
    case SET_MIST: {
      addZone(w, ZK_MIST, c, V2(56, 0), true);
      pin(w, c + V2(-22, 0), PK_POISON);
      pin(w, c + V2(22, 0), PK_POISON);
      return true;
    }
    case SET_SPRING_POOL: {
      addZone(w, ZK_SPRING, c, V2(42, 0), true);
      for (int k = 0; k < 4; ++k) pin(w, c + fromAng(k * TAU / 4 + 0.785f) * 50, PK_HEAL);
      return true;
    }
    case SET_WARPGATE: {
      addZone(w, ZK_HASTE, c, V2(60, 20), false);
      pin(w, c + V2(-50, -40), PK_TELEPORT);
      pin(w, c + V2(50, -40), PK_TELEPORT);
      return true;
    }
    // ------------------------------------------------ v3
    case SET_SHRINE: {
      int pi = addPeg(w, PK_SHRINE, c, 15);
      if (pi >= 0) {
        f.pegs[pi].hp = 1;
        f.pegs[pi].aux = R.range(0, SHRINE_COUNT - 1);
      }
      for (int k = 0; k < 6; ++k) pin(w, c + fromAng(PI * 0.25f + k * PI / 5 + PI) * 46);
      pin(w, c + V2(-40, 30), PK_FIRE);
      pin(w, c + V2(40, 30), PK_FIRE);
      return true;
    }
    case SET_WELL: {
      int pi = addPeg(w, PK_WELL, c, 14);
      if (pi >= 0) f.pegs[pi].hp = 3;
      for (int k = 0; k < 4; ++k) pin(w, c + fromAng(k * TAU / 4 + 0.785f) * 42, PK_STONE, 8);
      return true;
    }
    case SET_PINATA: {
      int pi = addPeg(w, PK_PINATA, c, 13);
      if (pi >= 0) f.pegs[pi].hp = 3;
      for (int k = 1; k <= 2; ++k) pin(w, c + V2(0, -18.f - 20.f * k));
      for (int k = -1; k <= 1; ++k) pin(w, c + V2(k * 34.f, 38), PK_COINS, 8);
      return true;
    }
    case SET_PRISM:
      pin(w, c, PK_PRISM, PIN_R + 1);
      pin(w, c + V2(-40, 18), PK_MIRROR);
      pin(w, c + V2(40, 18), PK_MIRROR);
      pin(w, c + V2(-22, -34), PK_CRYSTAL);
      pin(w, c + V2(22, -34), PK_CRYSTAL);
      return true;
    case SET_CONSTELLATION: {
      int n = R.range(4, 5);
      V2 p = c + V2(R.rangef(-60, -40), R.rangef(-30, 30));
      for (int k = 0; k < n; ++k) {
        pin(w, p, PK_STAR, PIN_R + 1);
        p += fromAng(R.rangef(-0.9f, 0.9f)) * R.rangef(38, 50);
        p.y = clampv(p.y, c.y - 80, c.y + 80);
      }
      return true;
    }
    case SET_DICE:
      for (int k = -1; k <= 1; ++k) pin(w, c + V2(k * 40.f, (k == 0) ? -10.f : 6.f), PK_DICE, PIN_R + 1);
      pin(w, c + V2(-76, 12), PK_BUMPER, 11);
      pin(w, c + V2(76, 12), PK_BUMPER, 11);
      return true;
    case SET_CANNONS:
      pin(w, c + V2(-62, 20), PK_CANNON, PIN_R + 1);
      pin(w, c + V2(62, 20), PK_CANNON, PIN_R + 1);
      pin(w, c + V2(-62, 50), PK_STONE, 9);
      pin(w, c + V2(62, 50), PK_STONE, 9);
      pin(w, c + V2(0, -12), PK_BUMPER, 11);
      return true;
    case SET_ROD:
      pin(w, c + V2(0, -30), PK_ROD, PIN_R + 1);
      for (int k = 0; k < 3; ++k) pin(w, c + V2(0, 2.f + 24.f * k));
      pin(w, c + V2(-34, -6), PK_SPARK);
      pin(w, c + V2(34, -6), PK_SPARK);
      return true;
    case SET_HOURGLASS:
      pin(w, c, PK_HOURGLASS, PIN_R + 1);
      for (int k = 1; k <= 2; ++k) {
        float d = 26.f * k;
        pin(w, c + V2(-d, -d));
        pin(w, c + V2(d, -d));
        pin(w, c + V2(-d, d));
        pin(w, c + V2(d, d));
      }
      return true;
    case SET_BLOOD:
      pin(w, c, PK_BLOOD, PIN_R + 1);
      pin(w, c + V2(-40, -16), PK_VAMPIRE);
      pin(w, c + V2(40, -16), PK_VAMPIRE);
      pin(w, c + V2(-30, 30), PK_HEAL);
      pin(w, c + V2(30, 30), PK_HEAL);
      return true;
    case SET_SNOWSLOPE: {
      float dir = R.chance(0.5f) ? 1.f : -1.f;
      for (int k = 0; k < 5; ++k) pin(w, c + V2(dir * (-80.f + 40.f * k), -40.f + 18.f * k));
      pin(w, c + V2(dir * -96.f, -64.f), PK_SNOWBALL, PIN_R + 1);
      pin(w, c + V2(dir * 30.f, 44.f), PK_ICE);
      return true;
    }
    case SET_JACKPOT:
      pin(w, c, PK_JACKPOT, PIN_R + 1);
      for (int k = 0; k < 6; ++k) pin(w, c + fromAng(k * TAU / 6) * 34, PK_GLASS, 7);
      return true;
    case SET_GEMS: {
      int n = R.range(2, 3);
      for (int k = 0; k < n; ++k) placeGem(w, c + fromAng(k * TAU / n + 0.4f) * 18);
      for (int k = 0; k < 6; ++k) pin(w, c + fromAng(k * TAU / 6) * 46, PK_STONE, 8);
      return true;
    }
    case SET_MIMIC: {
      bool mimic = R.chance(0.7f);
      int pi = addPeg(w, mimic ? PK_MIMIC : PK_CHEST, c, 15);
      if (pi >= 0) f.pegs[pi].hp = 3;
      pin(w, c + V2(-36, 18), PK_STONE, 8);
      pin(w, c + V2(36, 18), PK_STONE, 8);
      return true;
    }
    case SET_RUNEROAD: {
      float dir = R.chance(0.5f) ? 1.f : -1.f;
      for (int k = -1; k <= 1; ++k) {
        V2 p = c + V2(dir * 95.f * k, 70.f * k);
        addZone(w, ZK_RUNE, p, V2(30, 0), true);
      }
      for (int k = 0; k < 2; ++k) pin(w, c + V2(dir * (-48.f + 95.f * k), -35.f + 70.f * k) + V2(-dir * 30.f, 0));
      return true;
    }
    case SET_POPBUMPERS:
      pin(w, c + V2(0, -36), PK_BUMPER, 13);
      pin(w, c + V2(-38, 0), PK_BUMPER, 13);
      pin(w, c + V2(38, 0), PK_BUMPER, 13);
      pin(w, c + V2(0, 36), PK_BUMPER, 13);
      addSeg(w, SK_KICKER, c + V2(-80, 20), c + V2(-58, 60), 5);
      addSeg(w, SK_KICKER, c + V2(80, 20), c + V2(58, 60), 5);
      return true;
    case SET_SPINNERROW:
      for (int k = -1; k <= 1; ++k) {
        int si = addSeg(w, SK_SPINNER, c + V2(k * 84.f, 0), c + V2(k * 84.f, 0), 4);
        if (si < 0) break;
        Seg& sg = f.segs[si];
        sg.c = c + V2(k * 84.f, 0);
        sg.len = 30;
        sg.angVel = (k % 2 ? -1.f : 1.f) * R.rangef(2.6f, 3.6f);
        sg.ang = R.rangef(0, TAU);
        sg.rest = 0.8f;
      }
      return true;
    case SET_TRAMPOLINE:
      for (int k = 0; k < 4; ++k) pin(w, c + V2(-78.f + 52.f * k, 20), PK_SPRING, 10);
      pin(w, c + V2(0, -42), PK_BUMPER, 12);
      return true;
    case SET_MOONGARDEN:
      pin(w, c, PK_MOON, PIN_R + 1);
      for (int k = 0; k < 4; ++k) pin(w, c + fromAng(k * TAU / 4 + 0.785f) * 38, PK_FEATHER);
      return true;
    case SET_COMBO: {
      pin(w, c, PK_COMBO, PIN_R + 1);
      int n = 6;
      for (int k = 0; k < n; ++k) pin(w, c + fromAng(k * TAU / n) * 40, GARDEN_KINDS[R.range(0, 15)]);
      return true;
    }
    case SET_ECHO: {
      int k2 = GARDEN_KINDS[R.range(0, 15)];
      pin(w, c, PK_ECHO, PIN_R + 1);
      pin(w, c + V2(-44, -10), k2);
      pin(w, c + V2(44, -10), k2);
      pin(w, c + V2(0, 40), PK_BUMPER, 11);
      return true;
    }
    case SET_GATEVAULT: {
      int link = 3000 + f.bankSerial++;
      int lp = addPeg(w, PK_LOOT, c, 10);
      if (lp >= 0) f.pegs[lp].val = R.chance(0.3f) ? 1 : 0;
      float sq = 30;
      V2 cs[4] = {c + V2(-sq, -sq), c + V2(sq, -sq), c + V2(sq, sq), c + V2(-sq, sq)};
      for (int i = 0; i < 4; ++i) {
        int si = addSeg(w, SK_GATE, cs[i], cs[(i + 1) % 4], 4);
        if (si >= 0) f.segs[si].link = link;
      }
      for (int t = 0; t < 200; ++t) {
        V2 p(R.rangef(PX0 + 60, PX1 - 60), R.rangef(FIELD_Y0 + 40, 520));
        if (dist(p, c) < 180 || !spotFree(w, p, 9, 8)) continue;
        int k = addPeg(w, PK_KEY, p, 9);
        if (k >= 0) f.pegs[k].link = link;
        break;
      }
      return true;
    }
    case SET_LOOTNEST:
      for (int k = 0; k < 2; ++k) {
        int lp = addPeg(w, PK_LOOT, c + V2(-16.f + 32.f * k, 0), 9);
        if (lp >= 0) f.pegs[lp].val = 0;
      }
      for (int k = 0; k < 7; ++k) pin(w, c + fromAng(k * TAU / 7) * 42, PK_GLASS, 7);
      return true;
  }
  return false;
}

bool placeNamedSetPiece(World& w, int id, V2 center) {
  if (id < 0 || id >= SET_COUNT) return false;
  Floor& f = w.fl;
  const SetPieceDef& d = SETS[id];
  Rng& R = f.rng;
  for (int t = 0; t < 220; ++t) {
    V2 c = center.x >= 0 && t == 0 ? center
                                   : V2(R.rangef(PX0 + d.radius + 16, PX1 - d.radius - 16),
                                        R.rangef(std::max(FIELD_Y0 + 30, d.y0), std::min(FIELD_Y1 - 20, d.y1)));
    if (!clearOfClearingsSP(f, c, d.radius + 14)) continue;
    if (!clearOfKeepOut(f, c, d.radius + 8)) continue;
    if (!clearOfObjects(w, c, d.radius)) continue;
    if (w.screen == RS_FLOOR && f.phase == PH_FLIGHT) {
      bool nearBall = false;
      for (auto& b : f.balls)
        if (b.alive && dist(b.p, c) < d.radius + 40) nearBall = true;
      if (nearBall) continue;
    }
    // clear pins inside the footprint first
    for (auto& p : f.pegs)
      if (!p.dead && p.kind == PK_PIN && !p.motion && dist2(p.p, c) < d.radius * d.radius) p.dead = true;
    if (!buildSetPiece(w, id, c)) continue;
    f.keepOut.push_back({c, d.radius, -1});
    return true;
  }
  return false;
}

void placeSetPieces(World& w) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  const FloorSpec& sp = f.spec;
  std::vector<int> forced;
  auto force = [&](int id, int n) {
    for (int k = 0; k < n; ++k) forced.push_back(id);
  };
  if (hasMod(w, MOD_TULIPS)) force(SET_TULIPS, 2);
  if (hasMod(w, MOD_CASINO)) force(SET_SLOT, 2);
  if (hasMod(w, MOD_CONVEYORS)) force(SET_CONVEYOR, R.range(2, 3));
  if (hasMod(w, MOD_ANTIGRAV)) force(SET_ANTIGRAV, 2);
  if (hasMod(w, MOD_MIRRORS)) force(SET_MIRRORS, 2);
  if (hasMod(w, MOD_SPRINGS)) {
    force(SET_SPRINGS, 1);
    force(SET_SPRING_POOL, 1);
  }
  if (hasMod(w, MOD_WARPED)) {
    force(SET_RIFT, 2);
    force(SET_WARPGATE, 1);
  }
  if (hasMod(w, MOD_GEYSERS)) force(SET_GEYSER, 3);
  if (hasMod(w, MOD_GOLDRUSH)) force(SET_COINS, 2);
  if (hasRelic(w, RL_TULIPSEED)) force(SET_TULIPS, 1);
  if (hasRelic(w, RL_SLOTTOKEN)) force(SET_SLOT, 1);
  if (hasRelic(w, RL_SLINGCAP)) force(SET_SLINGSHOTS, 1);
  if (sp.kind != FK_VAULT) {
    if (hasRelic(w, RL_U_CENSER)) force(SET_SHRINE, 1);
    if (hasRelic(w, RL_U_CHISEL)) force(SET_RUNEROAD, 1);
    if (hasRelic(w, RL_U_WELLSPRING)) force(SET_WELL, 1);
  }
  for (int id : forced) placeNamedSetPiece(w, id, V2(-1, -1));
  int n = 3 + std::min(3, sp.depth / 6) + R.range(0, 1);
  if (sp.kind == FK_BOSS) n = std::max(2, n - 1);
  if (sp.kind == FK_VAULT) n = 3;
  n = std::max(1, n - (int)forced.size() / 2);
  std::vector<float> wt(SET_COUNT);
  for (int i = 0; i < SET_COUNT; ++i)
    wt[i] = sp.depth >= SETS[i].minDepth ? SETS[i].weight * biomeWeight(sp.biome, i) : 0.f;
  if (sp.kind == FK_VAULT) {
    wt[SET_SINGULARITY] = wt[SET_MIST] = wt[SET_GHOSTS] = 0;
    wt[SET_COINS] *= 3;
    wt[SET_SLOT] *= 3;
    wt[SET_CAGE] *= 2;
    wt[SET_JACKPOT] *= 3;
    wt[SET_PINATA] *= 3;
    wt[SET_LOOTNEST] *= 2;
    wt[SET_MIMIC] = wt[SET_BLOOD] = 0;
  }
  switch (sp.format) {
    case 12:  // pachislot
      for (int id : {SET_TULIPS, SET_SLOT, SET_COINS, SET_JACKPOT, SET_DICE}) wt[id] *= 3;
      break;
    case 11:  // carnival
      for (int id : {SET_WINDMILL, SET_PENDULUM, SET_GEARS, SET_SPINNERROW, SET_CONVEYOR, SET_POPBUMPERS}) wt[id] *= 3;
      break;
    case 4:  // plinko
      for (int id : {SET_TULIPS, SET_TARGETS, SET_ROLLOVERS}) wt[id] *= 2.5f;
      break;
    case 13:  // temple
      for (int id : {SET_CONSTELLATION, SET_BELL, SET_RUNES}) wt[id] *= 2;
      wt[SET_SHRINE] = 0;
      break;
    case 10:  // bumper bowl
      for (int id : {SET_POPBUMPERS, SET_KICKERS, SET_SLINGSHOTS, SET_BUMPERS}) wt[id] *= 2.5f;
      break;
  }
  if (sp.kind == FK_BOSS) wt[SET_MIMIC] = wt[SET_LOOTNEST] = 0;
  int placed = 0;
  for (int tries = 0; tries < n * 4 && placed < n; ++tries) {
    int id = R.weighted(wt);
    if (id < 0) break;
    if (placeNamedSetPiece(w, id, V2(-1, -1))) {
      placed++;
      wt[id] *= 0.35f;
    } else {
      wt[id] *= 0.5f;
    }
  }
}

// ------------------------------------------------------------------ pin layouts
static bool inFieldSP(V2 p, float margin) { return p.x > PX0 + margin && p.x < PX1 - margin && p.y > FIELD_Y0 && p.y < FIELD_Y1; }

static bool clearOfFeaturesSP(const World& w, V2 p, float r) {
  const Floor& f = w.fl;
  for (auto& pg : f.pegs)
    if (!pg.dead && pg.kind != PK_PIN && pg.kind != PK_GHOST && dist2(pg.p, p) < (pg.r + r + 20) * (pg.r + r + 20)) return false;
  for (auto& s : f.segs) {
    if (s.dead || s.kind == SK_DIVIDER || s.kind == SK_FLIPPER) continue;
    if (s.kind == SK_SPINNER || s.kind == SK_PENDULUM) {
      float rr = (s.kind == SK_PENDULUM ? s.len * 2 : s.len) + r + 16;
      if (dist2(s.c, p) < rr * rr) return false;
    } else {
      V2 cp = closestOnSeg(p, s.a, s.b);
      if (dist2(cp, p) < (s.th + r + 18) * (s.th + r + 18)) return false;
    }
  }
  for (auto& z : f.zones)
    if (!z.dead && (z.kind == ZK_WELL || z.kind == ZK_BOOST || z.kind == ZK_BLACKHOLE || z.kind == ZK_PORTAL || z.kind == ZK_RIFT ||
                    z.kind == ZK_ROLLOVER) &&
        dist2(z.p, p) < (z.half.x * 0.45f + r + 8) * (z.half.x * 0.45f + r + 8))
      return false;
  for (auto& z : f.zones)
    if (!z.dead && z.kind == ZK_LAVA && std::fabs(p.x - z.p.x) < z.half.x + 8 && std::fabs(p.y - z.p.y) < z.half.y + 8) return false;
  return true;
}

static bool farFromPinsSP(const Floor& f, V2 p, float minD) {
  for (auto& pg : f.pegs)
    if (!pg.dead && dist2(pg.p, p) < minD * minD) return false;
  return true;
}

void addPinPattern(World& w, int pattern) {
  Floor& f = w.fl;
  Rng& R = f.rng;
  std::vector<V2> pts;
  int pat = pattern >= 0 ? pattern : R.range(0, 24);
  if (pattern < 0) {
    if (f.spec.biome == BI_MINES && R.chance(0.35f)) pat = 5;
    if (f.spec.biome == BI_LAIR && R.chance(0.35f)) pat = R.chance(0.5f) ? 3 : 12;
    if (f.spec.biome == BI_ABYSS && R.chance(0.4f)) pat = R.chance(0.5f) ? 8 : 9;
    if (f.spec.biome == BI_SLIME && R.chance(0.35f)) pat = 12;
  }
  bool mirror = R.chance(0.45f);
  float cx = (PX0 + PX1) * 0.5f;
  float cyy = (FIELD_Y0 + FIELD_Y1) * 0.5f;
  switch (pat) {
    case 0:
    case 1: {  // hex grid
      float sx = pat == 0 ? R.rangef(50, 56) : R.rangef(58, 64);
      float sy = pat == 0 ? R.rangef(42, 46) : R.rangef(38, 42);
      int row = 0;
      for (float y = FIELD_Y0; y <= FIELD_Y1; y += sy, ++row) {
        float off = (row % 2) ? sx * 0.5f : 0.f;
        for (float x = PX0 + 22 + off; x < PX1 - 16; x += sx) pts.push_back(V2(x, y));
      }
      mirror = false;
      break;
    }
    case 2: {  // diamond lattice
      float s = R.rangef(58, 64);
      int row = 0;
      for (float y = FIELD_Y0; y <= FIELD_Y1; y += s * 0.5f, ++row) {
        float off = (row % 2) ? s * 0.5f : 0.f;
        for (float x = PX0 + 24 + off; x < PX1 - 16; x += s) pts.push_back(V2(x, y));
      }
      mirror = false;
      break;
    }
    case 3: {  // poisson scatter
      for (int t = 0; t < 2600; ++t) {
        V2 p(R.rangef(PX0 + 16, mirror ? cx : PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 40 * 40) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      break;
    }
    case 4: {  // rings around clearings + scatter
      for (auto& c : f.clearings) {
        for (int ring = 0; ring < 2; ++ring) {
          float rr = c.r + 20 + ring * 38;
          int n = (int)(TAU * rr / 40);
          float a0 = R.rangef(0, TAU);
          for (int k = 0; k < n; ++k) pts.push_back(c.p + fromAng(a0 + k * TAU / n) * rr);
        }
      }
      for (int t = 0; t < 1400; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 42 * 42) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
    case 5: {  // columns with gaps
      float sx = R.rangef(54, 62);
      for (float x = PX0 + 26; x < PX1 - 16; x += sx) {
        float gapAt = R.rangef(FIELD_Y0, FIELD_Y1);
        for (float y = FIELD_Y0 + R.rangef(0, 18); y <= FIELD_Y1; y += 36) {
          if (std::fabs(y - gapAt) < 40) continue;
          if (R.chance(0.1f)) continue;
          pts.push_back(V2(x, y));
        }
      }
      mirror = false;
      break;
    }
    case 6: {  // chevrons
      float sy = R.rangef(62, 72);
      for (float y = FIELD_Y0; y <= FIELD_Y1; y += sy) {
        float dir = R.chance(0.5f) ? 1.f : -1.f;
        for (float x = PX0 + 20; x < (mirror ? cx : PX1 - 16); x += 40) {
          float t = (x - PX0) / (PX1 - PX0);
          float yy = y + dir * 26 * std::sin(t * PI * 2 + y * 0.01f);
          pts.push_back(V2(x, yy));
        }
      }
      break;
    }
    case 7: {  // waves
      float sy = R.rangef(46, 52);
      float amp = R.rangef(10, 22), freq = R.rangef(1.5f, 3.f);
      int row = 0;
      for (float y = FIELD_Y0; y <= FIELD_Y1; y += sy, ++row) {
        float off = (row % 2) ? 26.f : 0.f;
        for (float x = PX0 + 22 + off; x < (mirror ? cx : PX1 - 16); x += 52) {
          float t = (x - PX0) / (PX1 - PX0);
          pts.push_back(V2(x, y + amp * std::sin(t * TAU * freq + row)));
        }
      }
      break;
    }
    case 8: {  // spiral arms around the board center
      int arms = R.range(3, 5);
      float twist = R.rangef(0.008f, 0.014f) * (R.chance(0.5f) ? 1.f : -1.f);
      V2 c(cx, cyy);
      for (int a = 0; a < arms; ++a)
        for (float r = 40; r < 460; r += 30) {
          float ang = a * TAU / arms + r * twist;
          pts.push_back(c + fromAng(ang) * r);
        }
      for (int t = 0; t < 900; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 46 * 46) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
    case 9: {  // concentric arcs
      V2 c(cx, FIELD_Y0 - 60);
      for (float r = 110; r < 820; r += R.rangef(40, 48)) {
        int n = (int)(PI * r / 42);
        for (int k = 0; k <= n; ++k) {
          float ang = PI * (k / (float)n);
          pts.push_back(c + fromAng(ang) * r);
        }
      }
      mirror = false;
      break;
    }
    case 10: {  // diagonal zig-zag lines
      float sy = R.rangef(70, 84);
      for (float y0 = FIELD_Y0; y0 <= FIELD_Y1 + 40; y0 += sy)
        for (float x = PX0 + 20; x < (mirror ? cx : PX1 - 16); x += 38) {
          float t = std::fmod((x - PX0) / 160.f, 2.f);
          float tri = t < 1 ? t : 2 - t;
          pts.push_back(V2(x, y0 + tri * 40.f - 20.f));
        }
      break;
    }
    case 11: {  // funnels: stacked V shapes that channel the ball
      float sy = R.rangef(96, 116);
      for (float y = FIELD_Y0 + 10; y <= FIELD_Y1; y += sy) {
        float fx = R.rangef(PX0 + 180, PX1 - 180);
        for (float x = PX0 + 20; x < PX1 - 16; x += 36) {
          float yy = y + std::fabs(x - fx) * -0.28f + 40;
          if (std::fabs(x - fx) < 22) continue;
          pts.push_back(V2(x, yy));
        }
      }
      for (int t = 0; t < 600; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 48 * 48) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
    case 13: {  // galton board: a dense triangle grid
      float sx = R.rangef(40, 44), sy = R.rangef(34, 37);
      int row = 0;
      for (float y = FIELD_Y0 + 6; y <= FIELD_Y1; y += sy, ++row) {
        float off = (row % 2) ? sx * 0.5f : 0.f;
        for (float x = PX0 + 20 + off; x < PX1 - 16; x += sx) pts.push_back(V2(x, y));
      }
      mirror = false;
      break;
    }
    case 14: {  // little rings on a grid
      float sp = R.rangef(104, 120);
      int row = 0;
      for (float y = FIELD_Y0 + 30; y <= FIELD_Y1; y += sp * 0.87f, ++row)
        for (float x = PX0 + 50 + ((row % 2) ? sp * 0.5f : 0.f); x < PX1 - 30; x += sp)
          for (int k = 0; k < 6; ++k) pts.push_back(V2(x, y) + fromAng(k * TAU / 6 + row) * 30);
      mirror = false;
      break;
    }
    case 15: {  // crosses
      float sp = R.rangef(96, 110);
      int row = 0;
      for (float y = FIELD_Y0 + 20; y <= FIELD_Y1; y += sp * 0.8f, ++row)
        for (float x = PX0 + 44 + ((row % 2) ? sp * 0.5f : 0.f); x < PX1 - 30; x += sp) {
          V2 c(x, y);
          pts.push_back(c);
          for (int k = 0; k < 4; ++k) pts.push_back(c + fromAng(k * PI * 0.5f) * 36);
        }
      mirror = false;
      break;
    }
    case 16: {  // rain: broken vertical streaks
      for (float x = PX0 + 24; x < (mirror ? cx : PX1 - 16); x += R.rangef(46, 58)) {
        float y = FIELD_Y0 + R.rangef(0, 60);
        while (y < FIELD_Y1) {
          int n = R.range(3, 6);
          for (int k = 0; k < n && y < FIELD_Y1; ++k, y += 36) pts.push_back(V2(x + R.rangef(-4, 4), y));
          y += R.rangef(40, 90);
        }
      }
      break;
    }
    case 17: {  // double helices
      int pairs = R.range(3, 4);
      float amp = R.rangef(34, 48), k = R.rangef(0.012f, 0.018f);
      for (int h = 0; h < pairs; ++h) {
        float x0 = PX0 + (PX1 - PX0) * (h + 0.5f) / pairs;
        for (float y = FIELD_Y0; y <= FIELD_Y1; y += 30) {
          pts.push_back(V2(x0 + amp * std::sin(y * k + h), y));
          pts.push_back(V2(x0 - amp * std::sin(y * k + h), y + 15));
        }
      }
      for (int t = 0; t < 700; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 54 * 54) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
    case 18: {  // checkerboard of pin blocks
      float cell = R.rangef(110, 130);
      int r = 0;
      for (float y = FIELD_Y0; y <= FIELD_Y1; y += cell, ++r) {
        int c = 0;
        for (float x = PX0 + 10; x < PX1 - 10; x += cell, ++c) {
          if ((r + c) % 2) continue;
          for (int i = 0; i < 3; ++i)
            for (int j = 0; j < 3; ++j) pts.push_back(V2(x + 20 + 36 * i, y + 20 + 36 * j));
        }
      }
      mirror = false;
      break;
    }
    case 19: {  // radial burst from a point on the board
      V2 c(R.rangef(PX0 + 200, PX1 - 200), R.rangef(FIELD_Y0 + 150, FIELD_Y1 - 200));
      int rays = R.range(10, 14);
      float a0 = R.rangef(0, TAU);
      for (int k = 0; k < rays; ++k)
        for (float r = 50; r < 700; r += 38) pts.push_back(c + fromAng(a0 + k * TAU / rays + r * 0.0006f) * r);
      for (int t = 0; t < 500; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 60 * 60) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
    case 20: {  // stairs: short steps descending across the board
      float dir = R.chance(0.5f) ? 1.f : -1.f;
      for (float y0 = FIELD_Y0; y0 <= FIELD_Y1 + 200; y0 += R.rangef(110, 130)) {
        float x = dir > 0 ? PX0 + 24 : PX1 - 24, y = y0;
        while (x > PX0 && x < PX1 && y < FIELD_Y1 + 20) {
          for (int k = 0; k < 3; ++k) pts.push_back(V2(x + dir * 38.f * k, y));
          x += dir * 140.f;
          y += 44.f;
        }
      }
      mirror = false;
      break;
    }
    case 21: {  // honeycomb cells
      float rr = R.rangef(40, 46);
      float w2 = rr * 1.732f;
      int row = 0;
      for (float y = FIELD_Y0 + 20; y <= FIELD_Y1; y += rr * 1.5f, ++row)
        for (float x = PX0 + 40 + ((row % 2) ? w2 * 0.5f : 0.f); x < PX1 - 20; x += w2)
          for (int k = 0; k < 6; ++k) pts.push_back(V2(x, y) + fromAng(PI / 6 + k * TAU / 6) * rr);
      mirror = false;
      break;
    }
    case 22: {  // starfield: uneven scatter with bright little clusters
      int nc = R.range(6, 9);
      for (int k = 0; k < nc; ++k) {
        V2 c(R.rangef(PX0 + 60, PX1 - 60), R.rangef(FIELD_Y0 + 30, FIELD_Y1 - 30));
        pts.push_back(c);
        for (int j = 0; j < 5; ++j) pts.push_back(c + fromAng(j * TAU / 5 - PI / 2) * 36);
      }
      for (int t = 0; t < 2400; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        float md = R.rangef(34, 70);
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < md * md) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
    case 23: {  // arches opening downward
      float rw = R.rangef(62, 76);
      int row = 0;
      for (float y = FIELD_Y0 + 40; y <= FIELD_Y1; y += rw * 1.35f, ++row)
        for (float x = PX0 + rw + ((row % 2) ? rw : 0.f); x < (mirror ? cx : PX1 - 20); x += rw * 2.2f)
          for (int k = 0; k <= 6; ++k) pts.push_back(V2(x, y) + fromAng(PI + k * PI / 6) * rw);
      break;
    }
    case 24: {  // vines: random walks trailing down from the top
      int n = R.range(9, 13);
      for (int k = 0; k < n; ++k) {
        V2 p(R.rangef(PX0 + 30, PX1 - 30), FIELD_Y0 + R.rangef(0, 100));
        float dx = R.rangef(-0.5f, 0.5f);
        while (p.y < FIELD_Y1) {
          pts.push_back(p);
          dx = clampv(dx + R.rangef(-0.35f, 0.35f), -0.9f, 0.9f);
          p += norm(V2(dx, 1.f)) * 34.f;
          if (p.x < PX0 + 20 || p.x > PX1 - 20) dx = -dx;
        }
      }
      for (int t = 0; t < 600; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 56 * 56) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
    default: {  // clumps: dense pin clusters with open lanes between
      int nc = R.range(9, 14);
      for (int k = 0; k < nc; ++k) {
        V2 c(R.rangef(PX0 + 50, PX1 - 50), R.rangef(FIELD_Y0 + 20, FIELD_Y1 - 20));
        int n = R.range(5, 9);
        for (int j = 0; j < n; ++j) pts.push_back(c + fromAng(R.rangef(0, TAU)) * R.rangef(0, 52));
      }
      for (int t = 0; t < 700; ++t) {
        V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
        bool ok = true;
        for (auto& q : pts)
          if (dist2(q, p) < 60 * 60) { ok = false; break; }
        if (ok) pts.push_back(p);
      }
      mirror = false;
      break;
    }
  }
  if (mirror) {
    size_t n = pts.size();
    for (size_t i = 0; i < n; ++i) {
      V2 m(2 * cx - pts[i].x, pts[i].y);
      if (std::fabs(m.x - pts[i].x) > 36) pts.push_back(m);
    }
  }
  float holes = R.rangef(0.03f, 0.09f);
  auto tryPin = [&](V2 p) {
    if (!inFieldSP(p, 14)) return false;
    if (!clearOfClearingsSP(f, p, 14)) return false;
    if (!clearOfKeepOut(f, p, 8)) return false;
    if (!clearOfFeaturesSP(w, p, PIN_R)) return false;
    if (!farFromPinsSP(f, p, 34)) return false;
    for (auto& b : f.balls)
      if (b.alive && dist2(b.p, p) < 36 * 36) return false;
    return addPeg(w, PK_PIN, p, PIN_R) >= 0;
  };
  int placed = 0;
  for (auto& p : pts) {
    if (R.chance(holes)) continue;
    if (tryPin(p)) placed++;
  }
  // never leave a board bare: sparse layouts (or boards full of rock and walls) get a scattering of extra pins
  int have = countKind(w, PK_PIN);
  for (int t = 0; t < 3000 && have < 90; ++t) {
    V2 p(R.rangef(PX0 + 16, PX1 - 16), R.rangef(FIELD_Y0, FIELD_Y1));
    if (!farFromPinsSP(f, p, 50)) continue;
    if (tryPin(p)) have++;
  }
  (void)placed;
}

int setPieceCount() { return SET_COUNT; }
