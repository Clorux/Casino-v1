# Dropcrawl

**A roguelike pachinko descent.**

Aim, launch, and ricochet through a dungeon of living pachinko boards. Build power from pegs, smash monsters, collect strange relics, and choose your path through branching dungeons. Claim two Runes, reach the Core, and defeat **the House** to escape with the Orb of Chance.

![Dropcrawl title screen with a live dungeon board in the background](docs/images/dropcrawl-preview.png)

**[Download for Windows](https://github.com/mimizukes/Dropcrawl/releases/latest)** · **[How to play](docs/GAMEPLAY.md)** · **[Build from source](docs/BUILDING.md)** · **[Source guide](docs/ARCHITECTURE.md)**

## Play

1. Open the [latest release](https://github.com/mimizukes/Dropcrawl/releases/latest) and download `Dropcrawl-v3.0-windows-x64.zip`.
2. Extract the archive to a folder you can write to.
3. Double-click `Dropcrawl.exe` and choose **New Run**.

The game targets **64-bit Windows 10/11**. It is portable: there is no installer, and the executable does not need a separate asset pack or game runtime. Settings, saves, scores, and character records are stored next to the executable.

GitHub's **Code → Download ZIP** contains the source. Use **Releases** for the ready-to-play game.

## Inside the dungeon

- **Build your ball.** Choose from 18 species and 25 backgrounds, then develop Strength, Dexterity, Intelligence, Vitality, and Luck.
- **Make every bounce count.** Pins build power; monster hits spend it. Focus targets, visible enemy intents, abilities, and bottom pockets turn each shot into a tactical choice.
- **Explore changing boards.** Fourteen board formats combine with procedural layouts, hand-made set pieces, tulips, kickers, slot machines, portals, and hazards.
- **Find your build.** Learn abilities across fourteen schools, assemble rune combinations, and collect magic relics, random artifacts, uniques, and item sets.
- **Choose a patron.** Seventeen gods offer powers and demands. The Tumbler, Lord of Chance, may reshape the board or meddle with your ball mid-flight.
- **Keep descending.** Branching areas, Guardians, permadeath, autosaves, a Hall of Fame, and unlockable Descent Levels give each run a different path.
- **Hear a new score.** Music is composed procedurally and played with synthesized instruments; graphics are drawn in code.

## Quick controls

| Input | Action |
| --- | --- |
| Mouse / left click | Aim / launch |
| Right-click a monster / Tab | Choose / cycle the focus target |
| 1–9, then 0, - and = | Use abilities |
| G | Open your god's invocations |
| Z X C V B N | Use items |
| A / D or left / right arrow | Flippers, when available |
| Mouse wheel | Adjust strength with Precision Launcher; scroll the log |
| Hold Space / F | Fast-forward / toggle double speed |
| Esc | Pause, save and quit, settings, or help |
| F11 / Alt+Enter | Toggle fullscreen |
| F12 | Save a screenshot |

See the [player guide](docs/GAMEPLAY.md) for turn flow, loot, patrons, exotic species, and save-file details. **How to Play** is also available in the game.

## Build

Dropcrawl is written in **C++20** using Windows' Direct2D, DirectWrite, Windows Imaging Component, and waveOut APIs. No third-party game engine or downloaded asset bundle is required.

Install an x64 MinGW-w64 toolchain with `g++` and `windres` on `PATH`, then run from PowerShell:

```powershell
git clone https://github.com/mimizukes/Dropcrawl.git
cd Dropcrawl
.\build.bat
.\Dropcrawl.exe
```

The build also produces `build\dropcrawl_sim.exe`, a console simulator for automated runs. Full prerequisites, test commands, and troubleshooting are in [Building and testing](docs/BUILDING.md).

## Repository layout

```text
src/             Complete game, renderer, audio, and simulator source
res/             Windows icon and resource definition
tools/           Content, save/load, physics, aiming, and balance checks
docs/            Player guide, build guide, source map, and preview image
build.bat        Builds the game and simulator
CONTRIBUTING.md  How to report issues and contribute changes
CHANGELOG.md     Release notes
LICENSE         MIT license
```

Generated executables, build intermediates, and personal play data are excluded from Git. The Windows executable is distributed through [Releases](https://github.com/mimizukes/Dropcrawl/releases).

## Contributing

Bug reports and focused improvements are welcome. Include the version, reproduction steps, and run seed when available. Read [CONTRIBUTING.md](CONTRIBUTING.md) for development and testing guidance.

## Credits and license

Created by **mimizukes** with assistance from **Claude Code**. Inspired by **Dungeon Crawl Stone Soup** and **Diablo**.

Dropcrawl is an independent project and is not affiliated with those games or their creators.

Released under the [MIT License](LICENSE).
