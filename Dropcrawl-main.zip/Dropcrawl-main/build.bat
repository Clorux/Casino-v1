@echo off
rem Builds Dropcrawl.exe (the game) and build\dropcrawl_sim.exe (balance simulator).
rem Requires a MinGW-w64 g++ (e.g. WinLibs) on the PATH.
setlocal
cd /d "%~dp0"
if not exist build mkdir build
set SRC=src\content_abilities.cpp src\content_abilities2.cpp src\content_divine.cpp src\content_data.cpp src\content_data2.cpp src\content_data3.cpp src\floor.cpp src\floor_ball.cpp src\floor_ball2.cpp src\floor_turn.cpp src\physics.cpp src\boardgen.cpp src\setpieces.cpp src\formats.cpp src\tumbler.cpp src\mutations.cpp src\randart.cpp src\stats.cpp src\loot.cpp src\runes.cpp src\run.cpp src\save.cpp src\audio.cpp
set UI=src\sim.cpp src\gfx.cpp src\ui_common.cpp src\ui_fx.cpp src\ui_board.cpp src\ui_panels.cpp src\ui_screens.cpp src\main.cpp
set FLAGS=-std=c++20 -O2 -Wall -Wno-unused-function -Wno-missing-field-initializers
if exist res\dropcrawl.rc windres -I res res\dropcrawl.rc -O coff -o build\res.o
set RES=
if exist build\res.o set RES=build\res.o
echo Building Dropcrawl.exe ...
g++ %FLAGS% %SRC% %UI% %RES% -o Dropcrawl.exe -mwindows -static -ld2d1 -ldwrite -lwindowscodecs -lole32 -luuid -lwinmm -lgdi32 -luser32 -lshell32
if errorlevel 1 goto :fail
echo Building build\dropcrawl_sim.exe ...
g++ %FLAGS% %SRC% src\sim.cpp src\sim_main.cpp -o build\dropcrawl_sim.exe -static -lwinmm
if errorlevel 1 goto :fail
echo Done.
exit /b 0
:fail
echo BUILD FAILED
exit /b 1
