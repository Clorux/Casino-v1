#include "../src/sim.h"
#include <cstdlib>
#include <thread>
#include <atomic>
#include <mutex>
// For each ability: runs with that ability granted at max level from the start. Reports avg depth and wins vs baseline.
struct Res { double depth = 0; int wins = 0; int n = 0; };
static Res runSet(int ab, int runs, uint64_t seed0) {
  Res r;
  for (int i = 0; i < runs; ++i) {
    World w; newRun(w, seed0 + i, i % SP_COUNT, BG_FIGHTER); w.quiet = true; w.log.clear();
    if (ab >= 0) for (int k = 0; k < ABIL[ab].maxLvl; ++k) learnAbility(w, ab);
    Rng rng((seed0 + i) ^ 0x5151); BotStats bs; bs.smart = false;
    long long guard = 0;
    while (!w.dead && !w.won && guard++ < 20000000LL) { botScreenStep(w, rng, &bs); w.fx.clear(); }
    r.depth += w.depth; r.wins += w.won; r.n++;
  }
  return r;
}
int main(int argc, char** argv) {
  initContent();
  int runs = argc > 1 ? atoi(argv[1]) : 24;
  std::vector<int> ids; ids.push_back(-1);
  for (int i = 0; i < AB_FIRST_INNATE; ++i) ids.push_back(i);
  std::vector<Res> res(ids.size());
  std::atomic<int> next(0);
  int nt = std::max(1u, std::thread::hardware_concurrency());
  std::vector<std::thread> th;
  for (int t = 0; t < nt; ++t) th.emplace_back([&]() { for (;;) { int k = next++; if (k >= (int)ids.size()) break; res[k] = runSet(ids[k], runs, 424242); } });
  for (auto& t : th) t.join();
  printf("baseline: depth %.2f wins %d/%d\n", res[0].depth / res[0].n, res[0].wins, res[0].n);
  std::vector<std::pair<double, int>> order;
  for (size_t k = 1; k < ids.size(); ++k) order.push_back({res[k].depth / res[k].n, (int)k});
  std::sort(order.begin(), order.end());
  for (auto& o : order) { int k = o.second; printf("%-20s %-9s depth %5.2f (%+5.2f) wins %2d/%d\n", ABIL[ids[k]].name, SCHOOL_NAME[ABIL[ids[k]].school], res[k].depth / res[k].n, res[k].depth / res[k].n - res[0].depth / res[0].n, res[k].wins, res[k].n); }
}
