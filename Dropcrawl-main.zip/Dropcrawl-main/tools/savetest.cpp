#include "../src/sim.h"
#include <cstdlib>
int main(int argc, char** argv) {
  initContent();
  std::wstring path = L"test_save.dat";
  if (argc > 1) { std::string a = argv[1]; path.assign(a.begin(), a.end()); }
  int fails = 0;
  for (int trial = 0; trial < 12; ++trial) {
    World w; newRun(w, 500 + trial, trial % SP_COUNT, (trial * 5) % BG_COUNT); w.quiet = true;
    Rng r(trial * 31 + 7); BotStats bs; bs.smart = false;
    int steps = 3000 + trial * 4000;
    for (int i = 0; i < steps && !w.dead && !w.won; ++i) { botScreenStep(w, r, &bs); w.fx.clear(); }
    if (w.dead || w.won) { printf("trial %d ended early\n", trial); continue; }
    if (!saveRun(w, path)) { printf("trial %d: save failed\n", trial); fails++; continue; }
    World w2;
    if (!loadRun(w2, path)) { printf("trial %d: load failed\n", trial); fails++; continue; }
    w2.quiet = true;
    Rng r1 = r, r2 = r;
    for (int i = 0; i < 20000 && !w.dead && !w.won; ++i) { botScreenStep(w, r1, &bs); botScreenStep(w2, r2, &bs); w.fx.clear(); w2.fx.clear(); }
    bool same = w.pl.hp == w2.pl.hp && w.depth == w2.depth && w.pl.gold == w2.pl.gold && w.pl.xp == w2.pl.xp && w.fl.turn == w2.fl.turn && w.dead == w2.dead;
    printf("trial %2d: screen %d depth %2d/%2d hp %3d/%3d gold %4d/%4d xp %3d/%3d turn %2d/%2d -> %s\n", trial, w.screen, w.depth, w2.depth, w.pl.hp, w2.pl.hp, w.pl.gold, w2.pl.gold, w.pl.xp, w2.pl.xp, w.fl.turn, w2.fl.turn, same ? "OK" : "MISMATCH");
    if (!same) fails++;
  }
  printf("failures: %d\n", fails);
  return fails;
}
