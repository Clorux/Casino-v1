#include "../src/sim.h"
#include <cstdlib>
// Exercise every ability / item / relic / monster / mutation / randart / set piece / species in live floors and verify
// nothing crashes and actives can fire.
void ensureCapacity(World& w);
int setPieceCount();
void runeCircle(World& w, int bi, int zi);
Randart makeAffixes(uint32_t seed, int relicId);
static World makeFloor(uint64_t seed, int biome, int kind, int species = -1) {
  World w; newRun(w, seed, species >= 0 ? species : (int)(seed % SP_COUNT), BG_FIGHTER); w.quiet = true;
  w.pl.gold = 999; w.pl.mp = 50; w.pl.bonusMp = 45; recalcStats(w); w.pl.mp = w.st.maxMp;
  w.act = (biome == BI_HALLS) ? 0 : 1; w.depth = 6;
  FloorSpec s = makeFloorSpec(w, kind, biome, w.act, 3, (int)seed);
  floorBegin(w, s);
  return w;
}
static void playTurns(World& w, Rng& r, int turns) {
  for (int t = 0; t < turns && !w.dead && w.fl.phase != PH_CLEARED; ++t) {
    int g = 0;
    while (w.fl.phase != PH_AIM && w.fl.phase != PH_CLEARED && !w.dead && g++ < 30000) {
      if (w.fl.phase == PH_REDIRECT) redirect(w, 1.2f);
      else if (w.fl.phase == PH_RELAUNCH) relaunch(w, 1.9f);
      else floorUpdate(w, TICK);
    }
    if (w.fl.phase != PH_AIM || w.dead) break;
    if (!w.offers.empty()) chooseOffer(w, 0);
    if (!w.relicOffers.empty()) chooseRelicOffer(w, 0);
    launch(w, r.rangef(0.4f, PI - 0.4f), w.fl.launchSpeed);
    // mid-flight: fire every flight ability once
    for (int k = 0; k < 90; ++k) floorUpdate(w, TICK);
    for (auto& o : w.pl.abil) if (ABIL[o.id].timing == T_FLIGHT && abilityUsable(w, o.id, nullptr)) castAbility(w, o.id, V2(800, 500), V2(800, 500), nearestMonster(w, V2(800,400)));
    if (w.fl.phase == PH_REDIRECT) redirect(w, 1.3f);
    if (w.fl.phase == PH_RELAUNCH) relaunch(w, 1.7f);
    flipperPress(w, 0, true); flipperPress(w, 1, true);
  }
}
static int patronOf(int ab) {
  for (int p = 0; p < PT_COUNT; ++p) for (int k = 0; k < 5; ++k) if (PATRON[p].gifts[k] == ab) return p;
  return -1;
}
int main() {
  initContent();
  std::string err;
  if (!validateContent(err)) { printf("CONTENT ERROR: %s\n", err.c_str()); return 1; }
  int problems = 0;
  Rng r(42);
  for (int p = 0; p < PT_COUNT; ++p) for (int k = 0; k < 5; ++k) if (patronOf(PATRON[p].gifts[k]) != p) { printf("GIFT SHARED: %s\n", ABIL[PATRON[p].gifts[k]].name); problems++; }
  for (int ab = AB_FIRST_DIVINE; ab < AB_COUNT; ++ab) if (patronOf(ab) < 0) { printf("ORPHAN GIFT: %s\n", ABIL[ab].name); problems++; }
  // ---- abilities
  for (int ab = 0; ab < AB_COUNT; ++ab) {
    const AbilityDef& d = ABIL[ab];
    for (int lvl = 1; lvl <= d.maxLvl; ++lvl) {
      World w = makeFloor(100 + ab * 7 + lvl, (ab + lvl) % BI_COUNT, (ab % 5 == 0) ? FK_ELITE : FK_NORMAL);
      if (ab >= AB_FIRST_DIVINE) {
        w.pl.patron = patronOf(ab);
        w.pl.piety = PIETY_MAX; recalcStats(w);
      } else {
        for (int k = 0; k < lvl; ++k) learnAbility(w, ab);
      }
      w.fl.lastKillDef = M_GOBLIN;  // for Raise Dead
      bool castOk = true;
      if (d.timing == T_AIM || d.timing == T_ANY) {
        int mon = nearestMonster(w, V2(800, 450));
        if (d.target == TG_MONSTER && ab == AB_P_IMMOLATE && mon >= 0) w.fl.mons[mon].burn = 5;
        if (ab == AB_INFERNO) for (auto& mm : w.fl.mons) mm.burn = 5;
        if (ab == AB_EXSANGUINATE) for (auto& mm : w.fl.mons) mm.bleed = 5;
        if ((ab == AB_BANISH || ab == AB_P_BANISH) && mon >= 0) { if (w.fl.mons[mon].boss) mon = -1; else w.fl.mons[mon].hp = 1; }
        if (ab == AB_POLYMORPH && mon >= 0 && w.fl.mons[mon].boss) mon = -1;
        V2 pt(800, 470), pt2(800, 200);
        if (d.target == TG_POINT && d.innate && mon >= 0) pt = w.fl.mons[mon].p + V2(0, -w.fl.mons[mon].r - 30);
        else if (d.target == TG_POINT) { // find a free spot
          for (int t = 0; t < 400; ++t) { V2 p(r.rangef(450, 1150), r.rangef(160, 760)); if (spotFree(w, p, 42, 6)) { pt = p; break; } }
        }
        if (ab == AB_HEALWOUNDS || ab == AB_P_REWIND || ab == AB_RENEWAL) { w.pl.hp = w.st.maxHp / 3; w.fl.hpAtStart = w.st.maxHp; }
        if (ab == AB_P_CHANNEL) w.pl.mp = 0;
        if (ab == AB_P_MUTATE) w.pl.mut[MUT_FRAIL] = 1;
        if (d.target == TG_MONSTER && mon < 0) { playTurns(w, r, 2); continue; }
        castOk = castAbility(w, ab, pt, pt2, mon);
      } else if (d.timing == T_FLIGHT) {
        launch(w, 1.5f, w.fl.launchSpeed);
        for (int k = 0; k < 60; ++k) floorUpdate(w, TICK);
        castOk = w.fl.phase != PH_FLIGHT || castAbility(w, ab, V2(800, 600), V2(800, 600), nearestMonster(w, V2(800, 400)));
        if (w.fl.phase == PH_REDIRECT) redirect(w, 1.2f);
        if (w.fl.phase == PH_RELAUNCH) relaunch(w, 1.9f);
      }
      if (!castOk) { printf("CAST FAILED: %s lvl %d\n", d.name, lvl); problems++; }
      playTurns(w, r, 6);
    }
  }
  printf("abilities done\n");
  // ---- items
  for (int it = 0; it < IT_COUNT; ++it) {
    World w = makeFloor(5000 + it, it % BI_COUNT, FK_NORMAL, SP_IRON);
    w.pl.hp = 10; w.pl.mp = 0; w.pl.poison = 4;
    for (auto& s : w.pl.items) s = InvItem();
    gainItem(w, it);
    int mon = nearestMonster(w, V2(800, 400));
    if (mon >= 0 && (it == IT_W_CHARMING || it == IT_W_POLYMORPH) && w.fl.mons[mon].boss) mon = -1;
    if (it == IT_W_CHARMING && mon >= 0) w.fl.mons[mon].hp = 1;
    V2 pt(800, 400);
    if (it == IT_W_DIGGING) for (auto& p : w.fl.pegs) if (!p.dead && p.kind == PK_PIN) { pt = p.p; break; }
    if (ITEM[it].target == TG_POINT && it != IT_W_DIGGING) for (int t = 0; t < 400; ++t) { V2 p(r.rangef(450, 1150), r.rangef(160, 760)); if (spotFree(w, p, 42, 6)) { pt = p; break; } }
    bool ok = (ITEM[it].target == TG_MONSTER && mon < 0) ? true : useItem(w, 0, pt, mon);
    if (!w.relicOffers.empty()) chooseRelicOffer(w, 0);
    if (!ok) { printf("ITEM FAILED: %s\n", ITEM[it].name); problems++; }
    if (ITEM[it].wand && ok && w.pl.items[0].id == it && w.pl.items[0].charges != ITEM[it].charges - 1) { printf("WAND CHARGES WRONG: %s\n", ITEM[it].name); problems++; }
    playTurns(w, r, 4);
  }
  printf("items done\n");
  // ---- relics: all at once, several floors
  for (int rep = 0; rep < 8; ++rep) {
    World w = makeFloor(7000 + rep, rep % BI_COUNT, rep % 3);
    for (int rl = 0; rl < RL_COUNT; ++rl) if ((rl + rep) % 2 == 0) gainRelic(w, rl);
    playTurns(w, r, 10);
  }
  printf("relics done\n");
  // ---- randarts
  for (int rep = 0; rep < 300; ++rep) {
    Randart a = makeRandart((uint32_t)(rep * 2654435761u) | (uint32_t)(rep % 32));
    if (a.n < 2 || a.n > 6 || !a.name[0]) { printf("BAD RANDART %d\n", rep); problems++; }
    if (randartDesc(a).empty()) problems++;
    Randart b = makeRandart(a.seed);
    if (memcmp(&a, &b, sizeof(Randart)) != 0) { printf("RANDART NOT DETERMINISTIC %d\n", rep); problems++; }
  }
  for (int rep = 0; rep < 6; ++rep) {
    World w = makeFloor(7500 + rep, rep % BI_COUNT, FK_NORMAL);
    for (int k = 0; k < 12; ++k) gainRandart(w, newRandartSeed(w));
    playTurns(w, r, 8);
  }
  printf("randarts done\n");
  // ---- mutations
  for (int rep = 0; rep < 4; ++rep) {
    World w = makeFloor(7800 + rep, rep % BI_COUNT, FK_NORMAL);
    for (int m = 0; m < MUT_COUNT; ++m) for (int l = 0; l < MUTS[m].maxLvl; ++l) gainMutation(w, m, true);
    for (int s = 0; s < SAC_COUNT; ++s) chooseSacrifice(w, s);
    playTurns(w, r, 8);
    if (mutationSummary(w, true).empty()) problems++;
  }
  printf("mutations done\n");
  // ---- species (incl. Fiendball facets, Drakeball colors, lives) with forced level ups
  for (int sp = 0; sp < SP_COUNT; ++sp)
    for (int rep = 0; rep < 3; ++rep) {
      World w = makeFloor(8000 + sp * 10 + rep, (sp + rep) % BI_COUNT, FK_NORMAL, sp);
      for (int k = 0; k < 16; ++k) gainXp(w, xpForLevel(w.pl.xl));
      while (!w.offers.empty()) chooseOffer(w, 0);
      playTurns(w, r, 6);
      if (sp == SP_DRAKE && w.pl.draconic < 0) { printf("DRAKE NO COLOR\n"); problems++; }
    }
  printf("species done\n");
  // ---- backgrounds
  for (int bg = 0; bg < BG_COUNT; ++bg) {
    World w; newRun(w, 8500 + bg, bg % SP_COUNT, bg); w.quiet = true;
    playTurns(w, r, 5);
  }
  printf("backgrounds done\n");
  // ---- the Tumbler, cards, board transformations, set pieces, pin patterns
  for (int rep = 0; rep < 40; ++rep) {
    World w = makeFloor(8700 + rep, rep % BI_COUNT, rep % 3);
    w.pl.patron = PT_TUMBLER; w.pl.piety = PIETY_MAX; recalcStats(w);
    for (int k = 0; k < 6; ++k) { tumblerInvoke(w, k % 4); if (!w.relicOffers.empty()) chooseRelicOffer(w, 0); }
    drawCard(w, rep % 2);
    if (rep % 5 == 0) regenLayout(w, rep % 2);
    if (rep % 7 == 0) mirrorBoard(w);
    placeNamedSetPiece(w, rep % setPieceCount(), V2(-1, -1));
    playTurns(w, r, 5);
  }
  for (int pat = 0; pat < 25; ++pat) {
    World w = makeFloor(8900 + pat, pat % BI_COUNT, FK_NORMAL);
    for (auto& p : w.fl.pegs) if (p.kind == PK_PIN) p.dead = true;
    addPinPattern(w, pat);
    int n = countKind(w, PK_PIN);
    if (getenv("DC_PATTERNS")) printf("pattern %d: %d pins\n", pat, n);
    if (n < 40) { printf("PIN PATTERN %d SPARSE (%d)\n", pat, n); problems++; }
    playTurns(w, r, 2);
  }
  printf("tumbler/cards/setpieces done\n");
  // ---- every monster spawned and fought
  for (int m = 0; m < M_COUNT; ++m) {
    World w = makeFloor(9000 + m, BI_HALLS, FK_NORMAL);
    for (auto& mm : w.fl.mons) mm.dead = true;
    for (auto& c : w.fl.clearings) c.mon = -1;
    int cl = freeClearing(w, V2(800, 450), false);
    int mi = spawnMonster(w, m, cl, false);
    if (mi < 0) { printf("SPAWN FAILED %s\n", MON[m].name); problems++; continue; }
    // let it act through its whole script (and boss phases)
    for (int t = 0; t < 12 && !w.dead; ++t) {
      playTurns(w, r, 1);
      if (!w.fl.mons[mi].dead && t == 4) w.fl.mons[mi].hp = w.fl.mons[mi].maxHp / 3;  // trigger phases
      w.pl.hp = w.st.maxHp;
    }
  }
  printf("monsters done\n");
  // ---- every biome and modifier board generates
  for (int b = 0; b < BI_COUNT; ++b)
    for (int m = 0; m < MOD_COUNT; ++m) {
      World w; newRun(w, 9500 + b * 50 + m, (b + m) % SP_COUNT, BG_FIGHTER); w.quiet = true;
      w.depth = 8;
      FloorSpec s = makeFloorSpec(w, (m % 4 == 0) ? FK_ELITE : FK_NORMAL, b, 1, 2, m);
      s.nMods = 1; s.mods[0] = (uint8_t)m;
      floorBegin(w, s);
      playTurns(w, r, 3);
    }
  printf("biomes/mods done\n");

  // ================================================================ v3 systems
  // ---- stats: every ball and background, growth and stat choices
  for (int sp = 0; sp < SP_COUNT; ++sp)
    for (int bg = 0; bg < BG_COUNT; bg += 3) {
      World w; newRun(w, 20000 + sp * 31 + bg, sp, bg); w.quiet = true;
      for (int k = 0; k < STAT_COUNT; ++k)
        if (w.st.stat[k] < 1 || w.st.stat[k] > 40) { printf("STAT OUT OF RANGE %s/%s %s=%d\n", SPECIES[sp].name, BGS[bg].name, STAT_ABBR[k], w.st.stat[k]); problems++; }
      if (w.pl.hp != w.st.maxHp || w.st.maxHp < 10) { printf("BAD START HP %s/%s %d/%d\n", SPECIES[sp].name, BGS[bg].name, w.pl.hp, w.st.maxHp); problems++; }
      if (bg != BG_WANDERER && bg != BG_SHAPESHIFTER && sp != SP_CHAOS && sp != SP_CHANGELING && sp != SP_FIEND && w.pl.patron < 0) {
        // (abilities like Stoneskin can add HP; only compare when the starting ability has no passive stats)
        bool hpAb = false;
        for (auto& a : w.pl.abil) if (ABIL[a.id].h.stats) hpAb = true;
        if (!hpAb && w.st.maxHp != previewStartHp(sp, bg)) { printf("PREVIEW HP MISMATCH %s/%s preview %d real %d\n", SPECIES[sp].name, BGS[bg].name, previewStartHp(sp, bg), w.st.maxHp); problems++; }
      }
      int sum0 = 0;
      for (int k = 0; k < STAT_COUNT; ++k) sum0 += w.pl.stat[k];
      for (int k = 0; k < 11; ++k) gainXp(w, xpForLevel(w.pl.xl));
      int guard = 0;
      while (!w.offers.empty() && guard++ < 50) chooseOffer(w, w.offers[0].type == 4 ? (int)(guard % 5) : 0);
      if (w.pl.statPoints != 0) { printf("STAT POINTS LEFT %d\n", w.pl.statPoints); problems++; }
      int sum1 = 0;
      for (int k = 0; k < STAT_COUNT; ++k) sum1 += w.pl.stat[k];
      int nl = w.pl.xl - 1, n3 = w.pl.xl / 3, expect = (nl - n3) + 2 * n3;  // +1 on most levels, +2 (chosen) on every third
      if (sum1 - sum0 != expect) { printf("STAT GROWTH %s: %d, expected %d\n", SPECIES[sp].name, sum1 - sum0, expect); problems++; }
    }
  printf("stats done\n");
  // ---- magic relics: every regular relic with affixes; names and determinism
  for (int rl = 0; rl < RL_COUNT; ++rl) {
    uint32_t seed = (uint32_t)(rl * 2246822519u) | 7u;
    Randart a = makeAffixes(seed, rl), b = makeAffixes(seed, rl);
    if (memcmp(&a, &b, sizeof(Randart)) != 0) { printf("AFFIX NOT DETERMINISTIC %d\n", rl); problems++; }
    if (a.n < 1 || a.n > 2 || !a.name[0]) { printf("BAD AFFIXES %s\n", RELIC[rl].name); problems++; }
    if (RELIC[rl].tier == 1 && !RELIC[rl].synergy) { printf("UNIQUE WITHOUT SYNERGY %s\n", RELIC[rl].name); problems++; }
  }
  for (int rep = 0; rep < 6; ++rep) {
    World w = makeFloor(21000 + rep, rep % BI_COUNT, FK_NORMAL);
    for (int rl = rep; rl < RL_COUNT; rl += 3) gainRelic(w, rl, RELIC[rl].tier == 0 ? newAffixSeed(w) : 0u);
    if (w.pl.relicAffix.size() != w.pl.relics.size()) { printf("AFFIX VECTOR MISMATCH\n"); problems++; }
    for (int i = 0; i < (int)w.pl.relics.size(); ++i)
      if (relicName(w, i).empty() || relicTooltip(w, i).empty()) problems++;
    playTurns(w, r, 8);
  }
  printf("magic relics done\n");
  // ---- new pegs: every kind hit by a live ball
  for (int k = PK_LOOT; k < PK_COUNT; ++k)
    for (int rep = 0; rep < 3; ++rep) {
      World w = makeFloor(22000 + k * 5 + rep, (k + rep) % BI_COUNT, FK_NORMAL);
      launch(w, 1.4f, w.fl.launchSpeed);
      for (int t = 0; t < 30; ++t) floorUpdate(w, TICK);
      if (w.fl.phase != PH_FLIGHT || w.fl.balls.empty()) continue;
      int bi = 0;
      while (bi < (int)w.fl.balls.size() && !w.fl.balls[bi].alive) bi++;
      if (bi >= (int)w.fl.balls.size()) continue;
      V2 p = randomFieldSpot(w, 12, 6, FIELD_Y0 + 60, FIELD_Y1 - 60);
      if (p.x < 0) continue;
      int pi = addPeg(w, k, p, k == PK_SHRINE ? 15 : 9);
      if (pi < 0) continue;
      if (k == PK_LOOT) w.fl.pegs[pi].val = rep % 4;
      if (k == PK_SHRINE) w.fl.pegs[pi].aux = rep * 3 % SHRINE_COUNT;
      if (k == PK_GEM) w.fl.pegs[pi].aux = rep % STAT_COUNT;
      for (int h = 0; h < 4 && bi < (int)w.fl.balls.size() && w.fl.balls[bi].alive && !w.fl.pegs[pi].dead; ++h) onPegHit(w, bi, pi, 200.f);
      for (int t = 0; t < 2000 && w.fl.phase == PH_FLIGHT; ++t) floorUpdate(w, TICK);
      playTurns(w, r, 3);
    }
  printf("new pegs done\n");
  // ---- new pockets: every kind
  for (int k = PO_LOOT; k < PO_COUNT; ++k)
    for (int rep = 0; rep < 2; ++rep) {
      World w = makeFloor(23000 + k * 5 + rep, (k + rep) % BI_COUNT, FK_NORMAL);
      w.pl.patron = rep ? PT_VRASK : -1;
      for (auto& p : w.fl.pockets) p.kind = p.orig = (uint8_t)k;
      layoutPockets(w);
      playTurns(w, r, 4);
    }
  printf("new pockets done\n");
  // ---- champions: every affix
  for (int af = 0; af < AFFIX_COUNT; ++af)
    for (int uni = 0; uni < 2; ++uni) {
      World w = makeFloor(24000 + af * 7 + uni, af % BI_COUNT, FK_NORMAL);
      int mi = -1;
      for (int i = 0; i < (int)w.fl.mons.size(); ++i) if (!w.fl.mons[i].dead && !w.fl.mons[i].boss) { mi = i; break; }
      if (mi < 0) continue;
      w.fl.mons[mi].champ = 0;
      w.fl.mons[mi].affix = 0;
      makeChampion(w, mi, uni, af);
      if (!hasAffix(w.fl.mons[mi], af)) { printf("AFFIX NOT APPLIED %s\n", AFFIX_NAME[af]); problems++; }
      if (uni && !w.fl.mons[mi].uname[0]) { printf("UNIQUE WITHOUT NAME\n"); problems++; }
      for (int t = 0; t < 8 && !w.dead; ++t) { playTurns(w, r, 1); w.pl.hp = w.st.maxHp; }
    }
  printf("champions done\n");
  // ---- board formats: each with every floor kind, no monster inside walls; the Tumbler reformats
  for (int fm = 0; fm < FORMAT_COUNT; ++fm)
    for (int kind = 0; kind < 4; ++kind)
      for (int rep = 0; rep < 3; ++rep) {
        World w; newRun(w, 25000 + fm * 40 + kind * 7 + rep, (fm + rep) % SP_COUNT, BG_FIGHTER); w.quiet = true;
        w.depth = 5 + rep * 6; w.act = rep;
        int biome = (fm + kind + rep) % BI_COUNT;
        FloorSpec sp = makeFloorSpec(w, kind, biome, rep, kind == FK_BOSS ? 6 : 2, fm * 3 + rep);
        sp.format = (uint8_t)fm;
        floorBegin(w, sp);
        for (int i = 0; i < (int)w.fl.mons.size(); ++i) {
          const Monster& m = w.fl.mons[i];
          if (m.dead) continue;
          for (auto& sg : w.fl.segs) {
            if (sg.dead || sg.kind != SK_WALL) continue;
            if (dist(closestOnSeg(m.p, sg.a, sg.b), m.p) < m.r) { printf("MONSTER IN WALL: format %s %s\n", FORMAT_NAME[fm], MON[m.def].name); problems++; break; }
          }
        }
        if (kind != FK_VAULT && aliveMonsterCount(w) == 0) { printf("NO MONSTERS: format %s kind %d\n", FORMAT_NAME[fm], kind); problems++; }
        if (countKind(w, PK_PIN) < 30) {
          printf("FORMAT %s SPARSE (%d pins, kind %d, depth %d, keepOut %d, pegs %d)\n", FORMAT_NAME[fm], countKind(w, PK_PIN), kind, w.depth,
                 (int)w.fl.keepOut.size(), (int)w.fl.pegs.size());
          problems++;
        }
        playTurns(w, r, 3);
        if (w.fl.phase == PH_AIM) reformatBoard(w, (fm + 3 + rep) % FORMAT_COUNT);
        playTurns(w, r, 3);
      }
  printf("formats done\n");
  // ---- runes & runewords
  for (int rep = 0; rep < 12; ++rep) {
    World w = makeFloor(26000 + rep, rep % BI_COUNT, FK_NORMAL);
    for (int ab = rep * 11 % 60; ab < AB_FIRST_INNATE; ab += 13) learnAbility(w, ab);
    int zi = addZone(w, ZK_RUNE, V2(800, 500), V2(30, 0), true);
    for (int k = 0; k < 40; ++k) {
      if (w.fl.phase != PH_AIM) break;
      launch(w, 1.5f, w.fl.launchSpeed);
      for (int t = 0; t < 20; ++t) floorUpdate(w, TICK);
      for (int bi = 0; bi < (int)w.fl.balls.size(); ++bi)
        if (w.fl.balls[bi].alive && zi >= 0) {
          for (int q = 0; q < 3 && w.fl.balls[bi].alive; ++q) {
            w.fl.balls[bi].runeMask = 0;
            runeCircle(w, bi, zi);
          }
        }
      for (int t = 0; t < 3000 && w.fl.phase == PH_FLIGHT; ++t) floorUpdate(w, TICK);
      int g = 0;
      while (w.fl.phase == PH_ENEMY && g++ < 30000) floorUpdate(w, TICK);
      if (!w.offers.empty()) chooseOffer(w, 0);
      if (!w.relicOffers.empty()) chooseRelicOffer(w, 0);
      w.pl.hp = w.st.maxHp;
      if (w.fl.phase == PH_CLEARED || w.dead) break;
    }
  }
  printf("runes done\n");
  // ---- loot, shards, shrines, mid-flight Tumbler tricks
  for (int rep = 0; rep < 10; ++rep) {
    World w = makeFloor(27000 + rep, rep % BI_COUNT, FK_NORMAL);
    for (int t = 0; t < 4; ++t) dropLoot(w, V2(700 + 30 * t, 400), t);
    gainShard(w, 3);
    if (w.relicOffers.empty()) { printf("SHARDS DID NOT FUSE\n"); problems++; }
    else chooseRelicOffer(w, 0);
    activateShrine(w, rep % SHRINE_COUNT, V2(800, 300));
    w.pl.patron = PT_TUMBLER; w.pl.piety = PIETY_MAX; w.tumblerMood = 10; recalcStats(w);
    launch(w, 1.5f, w.fl.launchSpeed);
    for (int k = 0; k < 600 && w.fl.phase == PH_FLIGHT; ++k) {
      w.fl.shot.tumblerActs = 0;
      w.fl.shot.tumbleClock = -10;
      if (w.fl.shotTime < 0.7f) w.fl.shotTime = 0.7f;
      tumblerFlightAct(w);
      floorUpdate(w, TICK);
    }
    playTurns(w, r, 4);
    sweepLoot(w);
  }
  printf("loot/shards/shrines done\n");
  printf("PROBLEMS: %d\n", problems);
  return problems;
}
