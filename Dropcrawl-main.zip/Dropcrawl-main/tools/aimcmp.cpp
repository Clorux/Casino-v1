#include "../src/sim.h"
#include <cstdlib>
static int monHp(const World& w) { int h = 0; for (auto& m : w.fl.mons) if (!m.dead) h += m.hp + m.shield; return h; }
static float outcome(const World& w, float a, uint64_t salt) {
  World t = w; t.quiet = true; t.fl.rng.s ^= mix64(salt);
  launch(t, a, t.fl.launchSpeed); int g = 0; while (t.fl.phase == PH_FLIGHT && g++ < 7200) floorUpdate(t, TICK);
  return (float)(monHp(w) - monHp(t));
}
int main(int argc, char** argv) {
  initContent();
  double sumR = 0, sumS16 = 0, sumS6 = 0; int n = 0;
  for (int trial = 0; trial < 30; ++trial) {
    World w; newRun(w, 900 + trial, trial % SP_COUNT, trial % BG_COUNT); w.quiet = true;
    Rng r(trial); BotStats bs; bs.smart = false;
    int adv = 2000 + (trial % 6) * 3000;
    for (int i = 0; i < adv && !w.dead; ++i) { botScreenStep(w, r, &bs); w.fx.clear(); }
    int g = 0; while (!(w.screen == RS_FLOOR && w.fl.phase == PH_AIM && w.offers.empty() && w.relicOffers.empty()) && !w.dead && g++ < 100000) { botScreenStep(w, r, &bs); w.fx.clear(); }
    if (w.dead || !canLaunch(w)) continue;
    float a16 = botPickAngle(w, 16, 2, 0.012f, 1234 + trial);
    float a6 = botPickAngle(w, 6, 2, 0.012f, 999 + trial);
    double R = 0, S16 = 0, S6 = 0; const int K = 24;
    Rng rr(trial * 77);
    for (int k = 0; k < K; ++k) {
      uint64_t salt = 50000 + k * 13;
      R += outcome(w, rr.rangef(0.3f, PI - 0.3f), salt);
      S16 += outcome(w, a16, salt);
      S6 += outcome(w, a6, salt);
    }
    R /= K; S16 /= K; S6 /= K;
    printf("trial %2d depth %2d: random %6.1f  smart16 %6.1f  smart6 %6.1f\n", trial, w.depth, R, S16, S6);
    sumR += R; sumS16 += S16; sumS6 += S6; n++;
  }
  printf("MEAN over %d states: random %.1f  smart16 %.1f (%+.0f%%)  smart6 %.1f (%+.0f%%)\n", n, sumR / n, sumS16 / n, 100 * (sumS16 / sumR - 1), sumS6 / n, 100 * (sumS6 / sumR - 1));
}
