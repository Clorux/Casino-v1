#include "../src/sim.h"
#include <cstdlib>
// measure value distribution per launch angle from a fixed start-of-floor state
static float shotVal(const World& a, const World& b) {
  int h0=0,h1=0; for (auto& m : a.fl.mons) if (!m.dead) h0 += m.hp; for (auto& m : b.fl.mons) if (!m.dead) h1 += m.hp;
  return (float)(h0 - h1);
}
int main(int argc, char** argv) {
  initContent();
  uint64_t seed = argc > 1 ? atoll(argv[1]) : 1;
  int floors = argc > 2 ? atoi(argv[2]) : 0;
  World w; newRun(w, seed, SP_IRON, BG_FIGHTER); w.quiet = true;
  // advance a few floors with random bot for a mid-game state
  Rng r(seed); BotStats bs; bs.smart = false;
  while (w.depth <= floors && !w.dead) botScreenStep(w, r, &bs);
  while (!(w.screen == RS_FLOOR && w.fl.phase == PH_AIM && w.offers.empty()) && !w.dead) botScreenStep(w, r, &bs);
  printf("depth %d xl %d monsters %d basePower %d\n", w.depth, w.pl.xl, aliveMonsterCount(w), w.st.basePower);
  const int N = 40, S = 60;
  double grand = 0; double best = -1; int bestA = 0;
  for (int c = 0; c < N; ++c) {
    float a = 0.2f + (PI - 0.4f) * (c + 0.5f) / N;
    double sum = 0, sq = 0;
    for (int s = 0; s < S; ++s) {
      World t = w; t.fl.rng.s ^= mix64(s * 7777 + c);
      launch(t, a + (s % 2 ? 0.004f : -0.004f), t.fl.launchSpeed);
      int g = 0; while (t.fl.phase == PH_FLIGHT && g++ < 7200) floorUpdate(t, TICK);
      float v = shotVal(w, t); sum += v; sq += v * v;
    }
    double mean = sum / S, sd = std::sqrt(std::max(0.0, sq / S - mean * mean));
    grand += mean; if (mean > best) { best = mean; bestA = c; }
    printf("angle %5.1f deg: mean dmg %6.1f  sd %6.1f\n", a * 180 / PI, mean, sd);
  }
  printf("avg over angles %.1f, best %.1f (angle idx %d)\n", grand / N, best, bestA);
}
