#include "../src/game.h"
#include <cstdlib>
int main(int argc, char** argv) {
  initContent();
  int arg = argc > 1 ? atoi(argv[1]) : 3;
  World w; newRun(w, 1000 + arg, arg % SP_COUNT, (arg * 3) % BG_COUNT);
  launch(w, 1.25f, w.fl.launchSpeed);
  for (int i = 0; i < 400; ++i) {
    floorUpdate(w, TICK);
    if (i % 10 == 0 && !w.fl.balls.empty()) { auto& b = w.fl.balls[0]; printf("t=%3d p=(%.0f,%.0f) v=(%.0f,%.0f) pow=%d alive=%d phase=%d\n", i, b.p.x, b.p.y, b.v.x, b.v.y, b.power, b.alive, w.fl.phase); }
    if (w.fl.phase != PH_FLIGHT) { printf("phase %d at %d\n", w.fl.phase, i); break; }
  }
}
