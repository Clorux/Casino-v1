// Dropcrawl - ball flow test: fires shots across every board format (plain, windy, and with the floor's own
// modifiers) and measures how long shots take and whether balls stall, crawl, fizzle or get stuck.
// usage: flowtest [seedsPerFormat=24] [anglesPerFloor=10] [onlyFormat=-1]
#include "../src/sim.h"
#include "../src/rules.h"
#include <algorithm>
#include <cstdlib>

struct Acc {
  std::vector<float> dur;
  double slow = 0, alive = 0;
  int stalls3 = 0, stalls6 = 0, fizzles = 0, stuckEnds = 0, shots = 0, over20 = 0, rescues = 0;
  std::string stuckWhere;
  float worstStall = 0, longest = 0;
  std::string worstWhere, longWhere;
};

int main(int argc, char** argv) {
  initContent();
  int seeds = argc > 1 ? atoi(argv[1]) : 24;
  int angles = argc > 2 ? atoi(argv[2]) : 10;
  int only = argc > 3 ? atoi(argv[3]) : -1;
  int traceSeed = argc > 4 ? atoi(argv[4]) : -1, traceAngle = argc > 5 ? atoi(argv[5]) : -1, traceVar = argc > 6 ? atoi(argv[6]) : -1;
  static const int BIOMES[] = {BI_HALLS, BI_LAIR, BI_MINES, BI_CRYPT, BI_FORGE, BI_FROZEN, BI_DROWNED, BI_SLIME, BI_ABYSS, BI_CORE};
  static const char* VARIANT[3] = {"plain", "windy", "mods"};
  Acc total[3];
  printf("%-12s %-6s %6s %6s %6s %6s %6s %6s %6s %6s %6s\n", "format", "var", "shots", "mean", "p90", "max", "slow%", "st>3s", "st>6s",
         "fizzl", "stuck");
  for (int fm = 0; fm < FORMAT_COUNT; ++fm) {
    if (only >= 0 && fm != only) continue;
    for (int var = 0; var < 3; ++var) {
      Acc A;
      for (int s = 0; s < seeds; ++s) {
        World w;
        newRun(w, 7000 + s * 31 + fm, SP_IRON, BG_FIGHTER);
        w.quiet = true;
        w.depth = 4 + s % 8;
        int biome = BIOMES[s % 10];
        FloorSpec sp = makeFloorSpec(w, FK_NORMAL, biome, 1 + s % 3, s % 3, s);
        sp.format = (uint8_t)fm;
        if (var == 0) sp.nMods = 0;
        if (var == 1) {
          sp.nMods = 1;
          sp.mods[0] = MOD_WINDY;
        }
        floorBegin(w, sp);
        w.offers.clear();
        w.relicOffers.clear();
        if (w.fl.phase != PH_AIM) continue;
        for (int k = 0; k < angles; ++k) {
          World t = w;
          t.fl.rng.s ^= mix64((uint64_t)(k * 7777 + s * 13 + var));
          float ang = 0.3f + (PI - 0.6f) * (k + 0.5f) / angles;
          launch(t, ang, t.fl.launchSpeed);
          std::vector<float> deepY, noProg, lastAge, lastY;
          std::vector<int> hits, lastStuck;
          std::vector<bool> was;
          int ticks = 0;
          float worst = 0;
          bool tracing = s == traceSeed && k == traceAngle && var == traceVar;
          if (tracing) {
            for (auto& sg : t.fl.segs)
              if (!sg.dead) printf("seg kind %d (%.0f,%.0f)-(%.0f,%.0f)\n", sg.kind, sg.a.x, sg.a.y, sg.b.x, sg.b.y);
            for (auto& z : t.fl.zones)
              if (!z.dead) printf("zone kind %d at (%.0f,%.0f) half (%.0f,%.0f) str %.0f\n", z.kind, z.p.x, z.p.y, z.half.x, z.half.y, z.str);
            for (auto& m : t.fl.mons)
              if (!m.dead) printf("monster %s at (%.0f,%.0f) r %.0f\n", MON[m.def].name, m.p.x, m.p.y, m.r);
          }
          while (t.fl.phase == PH_FLIGHT && ticks < 120 * 70) {
            floorUpdate(t, TICK);
            ticks++;
            auto& B = t.fl.balls;
            if (tracing && ticks % 30 == 0)
              for (size_t i = 0; i < B.size(); ++i)
                if (B[i].alive) {
                  const Peg* near = nullptr;
                  float nd = 1e9f;
                  for (auto& pg : t.fl.pegs)
                    if (!pg.dead && dist(pg.p, B[i].p) < nd) nd = dist(pg.p, B[i].p), near = &pg;
                  printf("t=%5.2f ball %zu id %d p=(%.0f,%.0f) v=(%.0f,%.0f) idle %.1f trips %d stuck %d near peg kind %d at %.0f px\n",
                         ticks * TICK, i, B[i].id, B[i].p.x, B[i].p.y, B[i].v.x, B[i].v.y,
                         i < t.fl.watch.size() ? t.fl.watch[i].idleT : -1.f, i < t.fl.watch.size() ? t.fl.watch[i].portals : -1,
                         B[i].stuckCount, near ? near->kind : -1, nd);
                }
            if (deepY.size() < B.size()) {
              size_t o = deepY.size();
              deepY.resize(B.size());
              noProg.resize(B.size());
              hits.resize(B.size());
              lastAge.resize(B.size());
              lastY.resize(B.size());
              lastStuck.resize(B.size());
              was.resize(B.size());
              for (size_t i = o; i < B.size(); ++i) {
                deepY[i] = B[i].p.y;
                noProg[i] = 0;
                hits[i] = B[i].pegHits + B[i].monHits;
                was[i] = true;
              }
            }
            for (size_t i = 0; i < B.size(); ++i) {
              const Ball& b = B[i];
              if (!b.alive) {
                if (was[i]) {
                  was[i] = false;
                  if (lastAge[i] > 44.8f) A.fizzles++;
                  else if (lastStuck[i] >= 5 && lastY[i] < POCKET_TOP - 30) {
                    A.stuckEnds++;
                    char sb[96];
                    snprintf(sb, sizeof(sb), "seed %d angle %d at y %.0f", s, k, lastY[i]);
                    A.stuckWhere = sb;
                  }
                  if (lastStuck[i] >= 3) A.rescues++;
                }
                continue;
              }
              bool sentUp = lastAge[i] > 0 && b.p.y < lastY[i] - 60.f;  // portal / catcher / teleport, as the game counts it
              lastAge[i] = b.age;
              lastY[i] = b.p.y;
              lastStuck[i] = b.stuckCount;
              A.alive += TICK;
              if (len(b.v) < 110.f) A.slow += TICK;
              int h = b.pegHits + b.monHits;
              if (b.p.y > deepY[i] + 20.f || sentUp) {
                deepY[i] = b.p.y;
                noProg[i] = 0;
              } else if (h != hits[i] && b.staleHits < 2) {
                noProg[i] = 0;
              } else {
                noProg[i] += TICK;
              }
              hits[i] = h;
              worst = std::max(worst, noProg[i]);
            }
          }
          // balls whose death ended the shot (the ball list is cleared in the same tick)
          for (size_t i = 0; i < was.size(); ++i)
            if (was[i]) {
              if (lastAge[i] > 44.8f) A.fizzles++;
              else if (lastStuck[i] >= 5 && lastY[i] < POCKET_TOP - 30) {
                A.stuckEnds++;
                char sb[96];
                snprintf(sb, sizeof(sb), "seed %d angle %d at y %.0f", s, k, lastY[i]);
                A.stuckWhere = sb;
              }
              if (lastStuck[i] >= 3) A.rescues++;
            }
          float d = ticks * TICK;
          if (d > A.longest) {
            A.longest = d;
            char lb[96];
            snprintf(lb, sizeof(lb), "seed %d angle %d, %d balls", s, k, (int)t.fl.balls.size());
            A.longWhere = lb;
          }
          A.dur.push_back(d);
          A.shots++;
          if (d > 20.f) A.over20++;
          if (worst > 3.f) A.stalls3++;
          if (worst > 6.f) A.stalls6++;
          if (worst > A.worstStall) {
            A.worstStall = worst;
            char buf[96];
            snprintf(buf, sizeof(buf), "seed %d biome %d angle %d", s, biome, k);
            A.worstWhere = buf;
          }
        }
      }
      if (A.dur.empty()) continue;
      std::vector<float> d = A.dur;
      std::sort(d.begin(), d.end());
      double mean = 0;
      for (float x : d) mean += x;
      mean /= d.size();
      printf("%-12s %-6s %6d %6.1f %6.1f %6.1f %6.1f %6d %6d %6d %6d   worst stall %.1fs (%s)  longest: %s\n", FORMAT_NAME[fm],
             VARIANT[var], A.shots, mean, d[d.size() * 9 / 10], d.back(), 100.0 * A.slow / std::max(1e-9, A.alive), A.stalls3, A.stalls6,
             A.fizzles, A.stuckEnds, A.worstStall, A.worstWhere.c_str(), A.longWhere.c_str());
      if (A.rescues || A.stuckEnds) printf("             rescued %d, stuck-ended %d (%s)\n", A.rescues, A.stuckEnds, A.stuckWhere.c_str());
      Acc& T = total[var];
      T.dur.insert(T.dur.end(), A.dur.begin(), A.dur.end());
      T.slow += A.slow;
      T.alive += A.alive;
      T.stalls3 += A.stalls3;
      T.stalls6 += A.stalls6;
      T.fizzles += A.fizzles;
      T.stuckEnds += A.stuckEnds;
      T.rescues += A.rescues;
      T.shots += A.shots;
      T.over20 += A.over20;
    }
  }
  for (int var = 0; var < 3; ++var) {
    Acc& T = total[var];
    if (T.dur.empty()) continue;
    std::sort(T.dur.begin(), T.dur.end());
    double mean = 0;
    for (float x : T.dur) mean += x;
    mean /= T.dur.size();
    printf("TOTAL %-6s shots %d  mean %.2fs  p90 %.1fs  max %.1fs  slow %.1f%%  stalls>3s %d  >6s %d  shots>20s %d  fizzles %d  stuck-ends %d  rescued %d\n",
           VARIANT[var], T.shots, mean, T.dur[T.dur.size() * 9 / 10], T.dur.back(), 100.0 * T.slow / std::max(1e-9, T.alive), T.stalls3,
           T.stalls6, T.over20, T.fizzles, T.stuckEnds, T.rescues);
  }
}
